#include "cheats.hpp"
#include "cheat_review.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <functional>
namespace fs=std::filesystem;
namespace {fs::path base,root;unsigned scenarios=0,checks=0,reviews=0;const std::vector<uint32_t> denied={0x04000000,0x1000,0x11111111};
void require(bool ok,const char*message){++checks;if(!ok){std::cerr<<"FAIL "<<message<<"\n";std::exit(1);}}
nc::Game game(){nc::Game g;g.id=0x01007300020FA000ULL;g.buildId="4B159F0F7A360669";g.buildVerified=true;return g;}
fs::path target(const nc::Game&g){return root/"atmosphere"/"contents"/nc::hexId(g.id)/"cheats"/(g.buildId+".txt");}
void write(const fs::path&p,const std::string&text){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<text;require(bool(f),"fixture written");}
std::string read(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void run(const std::function<void()>&test){root=base/("case-"+std::to_string(++scenarios));fs::create_directory(root);reviews=0;test();}
}
namespace nc {
std::string installTestRoot(){return root.generic_string();}
std::string blockedCheatReason(const Game&g,const Cheat&c){++reviews;return g.id==game().id&&g.buildId==game().buildId&&c.opcodes==denied?"synthetic-reviewed-code":"";}
}
int main(){
 const auto tmp=fs::temp_directory_path();base=tmp/("ninmagic-attach-preflight-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));require(base.parent_path()==tmp,"dedicated temp boundary");fs::create_directory(base);
 run([]{std::string error;require(nc::preflightInstalledCheats(game(),error)&&error.empty()&&reviews==0,"missing SD file is safe and read-only");require(fs::is_empty(root),"missing SD tree not created");});
 run([]{auto g=game();g.buildVerified=false;std::string e;require(!nc::preflightInstalledCheats(g,e)&&reviews==0,"unverified title rejected");});
 run([]{const auto p=target(game());write(p,"\xef\xbb\xbf# comment\r\n[Title only]\r\n\r\n{Master}\r\n04000000 00002000 22222222\r\n[Safe]\r\n04000000 00001000 22222222 // note\n");const auto before=read(p);std::string e;require(nc::preflightInstalledCheats(game(),e)&&reviews==2,"safe master and ordinary sections reviewed");require(read(p)==before&&!fs::exists(root/"config"),"safe preflight never edits files or receipts");});
 for(const std::string header:{"[Renamed]","{Pretend master}","[Another source name]"})run([&]{auto p=target(game());const auto data=header+"\n04000000 00001000 11111111\n";write(p,data);std::string e;require(!nc::preflightInstalledCheats(game(),e)&&e.find("synthetic-reviewed-code")!=std::string::npos,"name or master flag cannot hide reviewed code");require(read(p)==data&&!fs::exists(root/"config"),"blocked code and save receipt preserved");});
 run([]{auto g=game();const auto p=target(g).parent_path()/"0123456789ABCDEF.txt";write(p,"[Denied other build]\n04000000 00001000 11111111\n");std::string e;require(nc::preflightInstalledCheats(g,e)&&reviews==0,"other BID never selected");});
 run([]{const auto p=target(game());write(p,"[Safe]\n04000000 00001000 22222222\n[Late denied]\n04000000 00001000 11111111\n");std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==2,"all definitions inspected including final section");});
 run([]{const auto p=target(game());const std::string s="[Empty]\n; no codes\n";write(p,s);std::string e;require(nc::preflightInstalledCheats(game(),e)&&reviews==0&&read(p)==s,"empty metadata section contains no auto-load code");});
 for(const std::string &malformed:std::vector<std::string>{"04000000 00001000 22222222\n","[Bad\n04000000 00001000 22222222\n","[Bad]\nnot-a-code\n",std::string("[Binary]\n\0",10)})run([&]{const auto p=target(game());write(p,malformed);std::string e;require(!nc::preflightInstalledCheats(game(),e)&&!e.empty()&&read(p)==malformed,"uncertain syntax blocks attach without writes");});
 run([]{const auto p=target(game());std::string s="[Too many words]\n";for(unsigned i=0;i<257;++i)s+="22222222 ";write(p,s);std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==0&&read(p)==s,"oversized definition is not silently truncated");});
 run([]{const auto p=target(game());const auto s="#"+std::string(65536,'x');write(p,s);std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==0&&read(p)==s,"64KiB file budget enforced before parsing");});
 run([]{const auto p=target(game());fs::create_directories(p);std::string e;require(!nc::preflightInstalledCheats(game(),e),"file path cannot be a directory");});
 run([]{const auto p=target(game()),outside=base/"owned-outside.txt";write(outside,"[Safe]\n04000000 00001000 22222222\n");fs::create_directories(p.parent_path());fs::create_symlink(outside,p);require(fs::is_symlink(p),"real link fixture");std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==0,"file link blocks attach");});
 run([]{const auto outside=base/"owned-parent";fs::create_directory(outside);fs::create_directory_symlink(outside,root/"atmosphere");std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==0,"parent link blocks attach");});
 run([]{const auto alias=base/"owned-root-alias";fs::create_directory_symlink(root,alias);root=alias;std::string e;require(!nc::preflightInstalledCheats(game(),e)&&reviews==0,"root link is checked without trailing slash dereference");});
 require(base.parent_path()==tmp&&base.filename().string().rfind("ninmagic-attach-preflight-",0)==0,"cleanup root verified");fs::remove_all(base);std::cout<<"attach_preflight: "<<scenarios<<" scenarios, "<<checks<<" checks PASS\n";
}

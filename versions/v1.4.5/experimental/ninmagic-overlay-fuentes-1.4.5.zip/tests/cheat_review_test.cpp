// Optional private fixture argument exercises real reviewed definitions without
// embedding an author's cheat database in the public application sources.
#include "../source/cheat_review.cpp"
#include "cheats.hpp"
#include <fstream>
#include <iostream>
#include <iterator>

namespace {
unsigned checks=0;
void require(bool value,const char *message){++checks;if(!value){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
std::string hex(const std::array<uint8_t,32> &bytes){constexpr char H[]="0123456789abcdef";std::string text;for(auto b:bytes){text+=H[b>>4];text+=H[b&15];}return text;}
void known(const std::string &text,const char *expected,size_t chunk){
    nc::FingerprintSha256 hash;for(size_t at=0;at<text.size();at+=chunk)hash.add(reinterpret_cast<const uint8_t*>(text.data()+at),std::min(chunk,text.size()-at));require(hex(hash.finish())==expected,"SHA256 standard known-answer vector");
}
nc::Game game(){nc::Game g;g.id=0x010015100B514000ULL;g.buildId="FF773E90972D544E";g.fullBuildId="FF773E90972D544EB79406EAA65396D53C43EFB9000000000000000000000000";g.buildVerified=true;return g;}
nc::Cheat harmless(){nc::Cheat c;c.name="Coin";c.source="Synthetic fixture";c.group="synthetic";c.selected=true;c.opcodes={0x04000000,0x00001000,0x00000009};return c;}
}
int main(int argc,char **argv){
    require(argc==1||argc==2,"optional private source TXT argument only");
    known("","e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",1);
    known("abc","ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",1);
    known("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq","248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1",7);
    known(std::string(1000000,'a'),"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0",997);
    auto g=game();auto safe=harmless();
    require(nc::blockedCheatReason(g,safe).empty(),"an effect name alone never causes a block");
    nc::Pack p;p.game=g;p.compatible=true;p.cheats={safe};std::vector<nc::Cheat> selected;std::string error;
    require(nc::selectedCheats(p,selected,error)&&selected.size()==1,"unreviewed ordinary definition remains selectable");
    if(argc==2){
        std::ifstream file(argv[1],std::ios::binary);require(bool(file),"open private author fixture read-only");const std::string text{std::istreambuf_iterator<char>(file),{}};std::vector<nc::Cheat> data;
        require(nc::parseCheats(text,"Original private source",data,error)&&data.size()==11,"parse all eleven private reviewed definitions");size_t words=0;
        const auto reason=nc::blockedCheatReason(g,data.front());
        require(reason.size()<=512&&reason.find("CD6E42AEE7934F4D")!=std::string::npos,"review names the source's earlier Build ID within the UI bound");
        require(reason.find("1.0.0 según la fuente")!=std::string::npos&&reason.find("no validado para tu versión")!=std::string::npos,"review attributes source version without promising compatibility");
        for(const auto &original:data){
            words+=original.opcodes.size();require(!nc::blockedCheatReason(g,original).empty(),"exact reviewed opcode fingerprint is blocked");
            auto renamed=original;renamed.name="Renamed harmless label";renamed.source="Another provider or local import";renamed.group="Different master group";renamed.selected=false;renamed.liveState=nc::CheatState::Enabled;
            require(!nc::blockedCheatReason(g,renamed).empty(),"name/source/group/selection/live state do not bypass fingerprint");
            auto master=renamed;master.master=true;require(!nc::blockedCheatReason(g,master).empty(),"master flag does not bypass review");
            auto otherTitle=g;otherTitle.id+=0x10000;require(nc::blockedCheatReason(otherTitle,original).empty(),"review is scoped to exact Title ID");
            auto older=g;older.buildId="CD6E42AEE7934F4D";older.fullBuildId.clear();require(nc::blockedCheatReason(older,original).empty(),"old intended Build ID is not globally quarantined");
            auto lower=g;lower.buildId="ff773e90972d544e";require(!nc::blockedCheatReason(lower,original).empty(),"lowercase Build ID cannot bypass");
            auto stale=g;stale.fullBuildId.clear();require(!nc::blockedCheatReason(stale,original).empty(),"legacy cache without full BID cannot bypass short exact identity guard");
            auto changed=original;changed.opcodes.back()^=1;require(nc::blockedCheatReason(g,changed).empty(),"different opcode content is not this exact review fingerprint");
            auto shorter=original;shorter.opcodes.pop_back();require(nc::blockedCheatReason(g,shorter).empty(),"word-count/content must match exactly");
            nc::Pack blocked;blocked.game=g;blocked.compatible=true;blocked.cheats={renamed};blocked.cheats[0].selected=true;const auto before=blocked.cheats[0].opcodes;
            require(!nc::selectedCheats(blocked,selected,error)&&selected.empty()&&!error.empty(),"final selection guard rejects renamed cached reviewed definition");
            require(nc::selectedText(blocked,error).empty(),"blocked definition cannot be exported for installation");
            require(blocked.cheats[0].opcodes==before&&blocked.cheats[0].liveState==nc::CheatState::Enabled,"review leaves original words and real ON state intact");
            blocked.cheats[0].selected=false;blocked.cheats.push_back(safe);require(nc::selectedCheats(blocked,selected,error)&&selected.size()==1,"unselected reviewed item does not prevent unrelated safe selection");
            blocked.cheats.clear();master.group="synthetic";master.selected=false;blocked.cheats={master,safe};require(!nc::selectedCheats(blocked,selected,error)&&selected.empty(),"automatically included reviewed master also blocks before side effects");
        }
        require(words==281,"all eleven exact source definitions and words covered");
    }
    std::cout<<"cheat review: "<<checks<<" SHA256, exact scope, stale cache and selection checks passed\n";
}

// Synthetic author-independent fixtures; no published third-party codes bundled.
#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <filesystem>
#include <iostream>
#include <minizip/zip.h>
namespace fs=std::filesystem;
namespace {
unsigned checks=0;
void require(bool ok,const char *message){++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
void makeZip(const std::string &path,const std::vector<std::pair<std::string,std::string>> &files){
    zipFile zip=zipOpen64(path.c_str(),APPEND_STATUS_CREATE);require(zip,"open synthetic archive");
    for(const auto &file:files){zip_fileinfo meta{};meta.external_fa=0100644u<<16;
        require(zipOpenNewFileInZip64(zip,file.first.c_str(),&meta,nullptr,0,nullptr,0,nullptr,0,0,0)==ZIP_OK,"open synthetic member");
        require(zipWriteInFileInZip(zip,file.second.data(),unsigned(file.second.size()))==ZIP_OK&&zipCloseFileInZip(zip)==ZIP_OK,"write synthetic member");}
    require(zipClose(zip,nullptr)==ZIP_OK,"close synthetic archive");
}
}
int main(int argc,char **argv){
    require(argc>=2&&argc<=4,"explicit fresh test directory and optional public source ZIPs");const auto base=fs::absolute(argv[1]);fs::create_directories(base);
    const auto dir=(base/"cache").generic_string();setenv("NC_CATALOG_ROOT",dir.c_str(),1);
    nc::Game game;game.id=0x01007300020FA000ULL;game.buildId="4B159F0F7A360669";game.buildVerified=true;
    const std::string a="[Synthetic health]\n04000000 00000100 00000009\n",same="[Same words other name]\n04000000 00000100 00000009\n",b="[Synthetic money]\n04000000 00000200 00000032\n";
    const auto nx=(base/"remote.zip").generic_string(),sthetix=(base/"sthetix.zip").generic_string(),arch=(base/"arch.zip").generic_string();const auto member="titles/"+nc::hexId(game.id)+"/cheats/"+game.buildId+".txt";
    makeZip(nx,{{member,b},{"titles/01007300020FA001/cheats/4B159F0F7A360660.txt",a}});
    makeZip(sthetix,{{member,"[Synthetic extra published option]\n04000000 00000400 00000001\n"}});
    makeZip(arch,{{"MyNXCheats-main/Synthetic Game/"+nc::hexId(game.id)+"/cheats/"+game.buildId+".txt",b}});
    unsigned gets=0,heads=0;bool offline=false,missing=false,malformed=false,brokenNx=false;
    nc::testNetworkReady=true;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &error,nc::RemoteStamp *stamp,bool head){
        if(stamp)*stamp={"\"one\"","Mon, 26 Oct 2026 00:00:00 GMT","123",200};
        if(offline){error="Synthetic offline";return false;}
        if(head){++heads;return true;}++gets;
        if(url==nc::NxCodeUrl){if(brokenNx)return nc::writeSmall(path,"not a ZIP");fs::copy_file(nx,path,fs::copy_options::overwrite_existing);return true;}
        if(url==nc::SthetixUrl){fs::copy_file(sthetix,path,fs::copy_options::overwrite_existing);return true;}
        if(url==nc::Arch9Url){fs::copy_file(arch,path,fs::copy_options::overwrite_existing);return true;}
        require(url.find(nc::hexId(game.id))!=std::string::npos,"selected game only, no repository-wide queries");
        if(missing||(url.find(game.buildId)==std::string::npos&&url.find("4b159f0f7a360669")==std::string::npos)){if(stamp)stamp->status=404;error="Synthetic HTTP404";return false;}
        return nc::writeSmall(path,malformed?"<html>unusable</html>":url.find("MyNXCheats")!=std::string::npos?a:same);
    };
    std::vector<nc::CheatSourceReport> reports;std::string error;nc::Catalog catalog;
    auto unverified=game;unverified.buildVerified=false;
    require(!nc::refreshGameSources(unverified,false,reports,error)&&gets==0,"unverified identity never queried");
    require(nc::refreshGameSources(game,false,reports,error)&&reports.size()==6&&gets==6,"six additional published providers, once per selected game");
    for(const auto &report:reports)require(report.checked&&report.cached&&report.found,"successful source report is explicit");
    auto pack=nc::findCheats(game,catalog);
    require(pack.compatible&&pack.cheats.size()==3,"exact source caches including new archive are visible without global catalog");
    require(std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const nc::Cheat &c){return c.source=="sthetix/nx-cheats-db";}),"new complete archive provider retains its origin");
    require(std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const nc::Cheat &c){return c.source.find("MyNXCheats")!=std::string::npos&&c.source.find("ibnux")!=std::string::npos;}),"identical instructions deduplicated, both origins retained");
    const auto priorGets=gets;nc::findCheats(game,catalog);require(gets==priorGets,"offline lookup has no network side effects");
    require(nc::refreshGameSources(game,false,reports,error)&&gets==priorGets,"six-hour cache avoids repeated selected-game downloads");
    for(const auto &report:reports)require(!report.checked&&report.cached,"TTL reports local reuse without claiming fresh online check");
    require(nc::refreshGameSources(game,true,reports,error)&&gets==priorGets+3&&heads==3,"forced plain-source refresh and unchanged shared ZIP HEADs");
    const auto providers=nc::gameProviders(game);std::string raw;
    require(nc::providerText(game,providers[0],nc::providerPath(game,providers[0]),raw)&&raw==a,"raw authored text preserved behind CRC envelope");
    auto other=game;other.buildId="4B159F0F7A360660";
    require(!nc::findCheats(other,catalog).compatible,"other BID never substituted");other=game;other.id++;
    require(!nc::findCheats(other,catalog).compatible,"same filename under another TID never substituted");
    offline=true;require(!nc::refreshGameSources(game,true,reports,error)&&!error.empty(),"offline source failure reported");
    require(nc::findCheats(game,catalog).cheats.size()==3,"network failure preserves all verified caches");
    for(const auto &report:reports)require(report.cached&&!report.checked,"offline source reports cache instead of success");
    offline=false;
    malformed=true;require(!nc::refreshGameSources(game,true,reports,error),"HTML or malformed code rejected");
    require(nc::findCheats(game,catalog).cheats.size()==3,"malformed upstream never replaces existing valid codes");malformed=false;
    missing=true;require(nc::refreshGameSources(game,true,reports,error)&&reports[0].checked&&reports[0].cached,"HTTP404 distinct from outage; old published codes retained");missing=false;
    brokenNx=true;require(nc::removeOutput(nc::providerRoot()+"/nxcheatcode.zip.remote",error),"force new NX archive validation");
    require(!nc::refreshGameSources(game,true,reports,error)&&nc::findCheats(game,catalog).cheats.size()==3,"bad shared ZIP preserves previous cache");brokenNx=false;
    // CRC corruption falls back to its own previous file, never another identity.
    const auto cached=nc::providerPath(game,providers[0]);require(nc::readSmall(cached,raw,size_t(nc::MaxFile)+4096),"read fixture envelope");
    raw.back()^=1;require(nc::writeSmall(cached,raw),"damage synthetic current CRC");
    require(nc::cachedText(game,providers[0],raw)&&raw==a,"interrupted/corrupt current file falls back to verified previous file");
    require(!nc::providerText(other,providers[0],cached+".previous",raw),"envelope identity independently checked");
    // Different master instructions must keep apparently duplicate options separate.
    nc::Pack masters;std::vector<nc::Cheat> one,two;std::string parseError;
    require(nc::parseCheats("{Master}\n04000000 00000000 00000001\n"+a,"A",one,parseError)&&nc::parseCheats("{Master}\n04000000 00000000 00000002\n"+a,"B",two,parseError),"synthetic master fixtures parse");
    nc::appendSourceCheats(masters,one,"group-A");nc::appendSourceCheats(masters,two,"group-B");
    require(masters.cheats.size()==4,"different master bindings prevent cross-source deduplication");
    nc::Pack identical;nc::appendSourceCheats(identical,one,"group-A");for(auto &c:one)c.source="C";nc::appendSourceCheats(identical,one,"group-C");
    require(std::count_if(identical.cheats.begin(),identical.cheats.end(),[](const nc::Cheat &c){return !c.master;})==1,"identical masters allow option deduplication");
    // New snapshot is merged, preserving an older exact Build ID.
    makeZip(nx,{{member.substr(0,member.size()-20)+"4B159F0F7A360670.txt",a}});
    require(nc::refreshGameSources(game,true,reports,error)&&nc::findCheats(game,catalog).compatible,"shared ZIP update preserves previous exact Build ID");
    require(nc::findCheats(game,catalog).availableBuilds.size()==2,"new and historical BIDs both indexed for selected game");
    const auto recovery=dir+"/recovery.cache";
    require(nc::writeSmall(recovery+".previous","verified previous"),"create previous-only interrupted cache");
    require(!nc::promoteSource(recovery+".absent",recovery,error),"failed rename from previous-only cache reported");
    require(nc::readSmall(recovery+".previous",raw,128)&&raw=="verified previous","failed promotion never deletes the only verified recovery copy");
    require(nc::writeSmall(recovery,"corrupt current")&&!nc::promoteSource(recovery+".absent",recovery,error,false),"failed replacement of corrupt current also reported");
    require(nc::readSmall(recovery+".previous",raw,128)&&raw=="verified previous","corrupt current never replaces verified previous backup");
    const auto archiveCache=nc::providerRoot()+"/sthetix.zip";fs::copy_file(archiveCache,archiveCache+".previous",fs::copy_options::overwrite_existing);
    require(nc::writeSmall(archiveCache,"corrupt current archive"),"create recovered-archive validator fixture");const auto getsBeforeRecovery=gets;
    require(nc::refreshGameSources(game,false,reports,error)&&gets==getsBeforeRecovery+1&&reports[4].checked,"NRO recovered archive forces GET instead of reusing current TTL/ETag for previous");
    for(int argument=2;argument<argc;++argument){
        std::vector<nc::CatalogEntry> actual;error.clear();
        require(nc::indexArchive(argv[argument],"Public source audit",actual,error,true),"optional real source ZIP passes production bounds, exact paths and CRC validation");
        const auto count=actual.size();std::cout<<"real public ZIP: "<<count<<" exact Title ID/Build ID files\n";
        const auto merged=(base/("real-merged-"+std::to_string(argument)+".zip")).generic_string();
        if(!nc::mergeInto({argv[argument]},merged,error)){std::cerr<<"Real source merge: "<<error<<"\n";require(false,"real provider merge must succeed");}
        actual.clear();
        require(nc::indexArchive(merged,"Public source audit",actual,error,true)&&actual.size()==count,"real provider merge preserves every exact identity");
    }
    if(argc==4){
        const auto actualRoot=(base/"real-game-query").generic_string();setenv("NC_CATALOG_ROOT",actualRoot.c_str(),1);
        nc::Game wonder;wonder.id=0x010015100B514000ULL;wonder.buildId="FF773E90972D544E";wonder.fullBuildId="FF773E90972D544EB79406EAA65396D53C43EFB9000000000000000000000000";wonder.buildVerified=true;
        nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &failure,nc::RemoteStamp *stamp,bool head){
            if(stamp)*stamp={"\"real fixture\"","Fri, 26 Sep 2026 00:00:00 GMT","8550804",200};
            if(url==nc::SthetixUrl||url==nc::NxCodeUrl){if(!head)fs::copy_file(url==nc::SthetixUrl?argv[3]:argv[2],path,fs::copy_options::overwrite_existing);return true;}
            if(url==nc::Arch9Url){if(!head)fs::copy_file(arch,path,fs::copy_options::overwrite_existing);return true;}
            if(stamp)stamp->status=404;
            failure="Synthetic missing exact text";return false;
        };
        error.clear();require(nc::refreshGameSources(wonder,false,reports,error),"NRO real new source refresh is complete for exact Wonder Build ID");
        auto found=nc::findCheats(wonder,nc::Catalog{});size_t words=0;for(const auto &cheat:found.cheats){words+=cheat.opcodes.size();require(cheat.source=="sthetix/nx-cheats-db"&&!cheat.master,"NRO real source preserves origin and master flags");}
        require(found.compatible&&found.cheats.size()==11&&words==281,"NRO public APIs expose all eleven exact real Wonder options");
        wonder.buildId.back()='0';require(!nc::findCheats(wonder,nc::Catalog{}).compatible,"NRO new provider does not substitute real Wonder codes for another BID");
        std::cout<<"real NRO Sthetix: definitions="<<found.cheats.size()<<" words="<<words<<"\n";
    }
    nc::testTransfer={};nc::testNetworkReady=false;
    std::cout<<"providers: "<<checks<<" exact identity, cache, origin and failure checks passed\n";
}

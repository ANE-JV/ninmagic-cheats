#include "options.hpp"
#include <algorithm>
#include <cstdlib>
#include <iostream>

namespace {
unsigned checks=0;
void require(bool value,const char *message){++checks;if(!value){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
nc::Cheat cheat(const std::string &name){nc::Cheat c;c.name=name;c.source="Author";c.group="Author:game:build";c.opcodes={0x04000000,0x100,1};return c;}
std::vector<std::string> effects(std::initializer_list<std::string> names){nc::Pack p;for(const auto &name:names)p.cheats.push_back(cheat(name));return nc::optionEffects(p,{});}
bool includes(const std::vector<std::string> &names,const std::string &name){return std::find(names.begin(),names.end(),name)!=names.end();}
}
int main() {
    for(const std::string name:{"Infinite HP","Inf HP","Inf. Health","HP Inf","InfHP","Unlimited Health","vida infinita","\xe2\x88\x9e HP"})require(nc::cheatLabel(cheat(name))=="Vida infinita","explicit health aliases translated");
    require(nc::cheatLabel(cheat("Inf HP (Hold ZR) - Player 2"))=="Vida infinita (Hold ZR) - Player 2","hold condition and player variant preserved exactly");
    require(nc::cheatLabel(cheat("mm2 inf hp"))=="mm2 Vida infinita","character or game qualifier preserved");
    require(nc::cheatLabel(cheat("Max HP"))=="Vida máxima"&&!includes(effects({"Max HP"}),"Vida infinita"),"maximum HP is not infinite health");
    require(nc::cheatLabel(cheat("Inf MP"))=="MP infinitos"&&!includes(effects({"Inf MP"}),"Vida infinita"),"MP does not imply HP");
    require(nc::cheatLabel(cheat("Infinite Lives"))=="Vidas infinitas"&&!includes(effects({"Infinite Lives"}),"Vida infinita"),"lives count is distinct from health");
    require(nc::cheatLabel(cheat("Max Lives"))=="Vidas máximas"&&!includes(effects({"Max Lives"}),"Vidas infinitas"),"maximum lives does not imply infinite lives");
    require(nc::cheatLabel(cheat("Infinite Ammo (ZL + B)"))=="Munición infinita (ZL + B)","ammo label preserves activation buttons");
    require(nc::cheatLabel(cheat("No Reload"))=="Sin recargar"&&!includes(effects({"No Reload"}),"Munición infinita"),"no reload does not promise unlimited ammo");
    require(nc::cheatLabel(cheat("Invulnerability"))=="Invulnerabilidad"&&!includes(effects({"Invulnerability"}),"Vida infinita"),"invulnerability remains distinct from HP cheat");
    require(includes(effects({"God Mode"}),"Modo dios")&&!includes(effects({"God Mode"}),"Invencibilidad"),"god-mode label does not invent specific mechanics");
    require(nc::cheatLabel(cheat("Infinite Stamina"))=="Resistencia infinita","stamina translated literally");
    require(nc::cheatLabel(cheat("Infinite Magic"))=="Magia infinita"&&!includes(effects({"Infinite Magic"}),"MP infinitos"),"magic does not invent MP terminology");
    require(nc::cheatLabel(cheat("Infinite SP"))=="SP infinitos"&&!includes(effects({"Infinite SP"}),"Resistencia infinita"),"SP retains ambiguous original resource abbreviation");
    require(nc::cheatLabel(cheat("Infinite Energy"))=="Energía infinita","energy translated literally");
    require(nc::cheatLabel(cheat("Unlimited Inventory"))=="Inventario ilimitado"&&!includes(effects({"Unlimited Inventory"}),"Objetos infinitos"),"inventory capacity does not imply infinite items");
    require(nc::cheatLabel(cheat("Infinite Gold"))=="Oro infinito"&&!includes(effects({"Infinite Gold"}),"Dinero infinito"),"gold retains named currency");
    require(nc::cheatLabel(cheat("60fps (Handheld)"))=="60 FPS (Handheld)","FPS label preserves mode");
    require(nc::cheatLabel(cheat("30 FPS (Default)"))=="30 FPS (Default)","default frame-rate variant preserved");
    require(nc::cheatLabel(cheat("Disable Dynamic Resolution"))=="Desactivar Resolución dinámica","resolution labels preserve enable/disable instruction in Spanish");
    require(effects({"Disable Dynamic Resolution"})==std::vector<std::string>{"Resolución"},"disabling DRS does not imply removing resolution");
    require(nc::cheatLabel(cheat("Disable Depth of Field (Hold ZR)"))=="Desactivar Profundidad de campo (Hold ZR)","graphics verb translated while preserving activation condition");
    require(effects({"Disable Depth of Field"})==std::vector<std::string>{"Gráficos"},"disabling depth of field does not mean disabling graphics");
    require(nc::cheatLabel(cheat("Enable Dynamic Resolution"))=="Activar Resolución dinámica","activation verb translated literally");
    require(effects({"Disable Unusual Feature"})==std::vector<std::string>{"Trucos generales"},"control verb alone does not invent an effect category");
    require(nc::cheatLabel(cheat("Disable Bloom"))=="Desactivar bloom","graphics action translated");
    require(nc::cheatLabel(cheat("Infinite Health + Infinite Ammo"))=="Vida infinita + Munición infinita","combined effects both translated without splitting their option");
    require(nc::cheatLabel(cheat("Inf. Health (OFF)"))=="Vida infinita (OFF)","reset/OFF variant remains visible");
    auto off=effects({"HP Inf Off"});require(includes(off,"Desactivar Vida infinita")&&!includes(off,"Vida infinita"),"OFF-only code is not advertised as available health-on effect");
    require(includes(effects({"Enemy Infinite Health"}),"Vida infinita (enemigos)"),"explicit enemy subject shown in effect summary");
    auto unknown=cheat("Unusual Action 17");unknown.categories=nc::Fps|nc::Graphics;
    require(nc::cheatLabel(unknown)==unknown.name&&nc::explainCheat(unknown)=="Nombre original: Unusual Action 17","unknown names are retained without invented explanation");
    auto publishedGod=cheat("God Mode");publishedGod.source="OblivionReign/GBATemp";const auto originalGod=publishedGod;const auto godDetail=nc::explainCheat(publishedGod);
    require(godDetail.find("Efecto sin comprobar")!=std::string::npos&&godDetail.find("no restaura la instrucción")!=std::string::npos,"curated God Mode explains effect uncertainty and persistent instruction patch");
    require(godDetail.find("cierra y reabre")!=std::string::npos,"curated God Mode explains restart after removal");
    require(publishedGod.name==originalGod.name&&publishedGod.source==originalGod.source&&publishedGod.opcodes==originalGod.opcodes,"explanation does not change author metadata or opcode words");
    auto restore=cheat("Restore code - God Mode OFF");restore.source="Mirror: OblivionReign/GBATemp";const auto restoreDetail=nc::explainCheat(restore);
    require(restoreDetail.find("No la combines con God Mode")!=std::string::npos&&restoreDetail.find("desmarcar su casilla no lo apaga")!=std::string::npos,"curated restoration requires God Mode removal and preserves checkbox distinction");
    require(nc::explainCheat(cheat("God Mode"))!=godDetail,"source-specific patch description does not claim a mechanic for unrelated authors");
    auto water=cheat("Max/ Infinite Bellabel Water");water.source="OblivionReign/GBATemp";require(nc::explainCheat(water).find("instrucción modificada")==std::string::npos,"God patch explanation is not assigned to Water");
    const auto waterDetail=nc::explainCheat(water);require(waterDetail.find("Bellabel Park")!=std::string::npos&&waterDetail.find("no lo actives")!=std::string::npos&&waterDetail.find("no es vida")!=std::string::npos,"Bellabel resource is content-specific and not generic life or water");
    nc::Pack p;p.cheats={unknown};auto summary=nc::optionEffects(p,{});
    require(summary==std::vector<std::string>{"Trucos generales"},"broad category flags do not invent named effects");
    p.cheats={cheat("Inf HP"),cheat("Infinite HP"),cheat("60 FPS"),cheat("30 FPS"),cheat("Invincibility"),cheat("Inf Ammo"),cheat("Disable Bloom"),cheat("720p Locked")};
    summary=nc::optionEffects(p,{});
    require(summary==std::vector<std::string>{"Vida infinita","Munición infinita","Invencibilidad","60 FPS","30 FPS","Resolución","Gráficos"},"available effects deduplicated and placed in stable useful order");
    for(auto &c:p.cheats)c.selected=false;
    require(nc::optionEffects(p,{})==summary,"summary shows available effects without requiring selection");
    auto master=cheat("Infinite Health 60 FPS");master.master=true;p.cheats={master};require(nc::optionEffects(p,{}).empty()&&nc::cheatLabel(master)==master.name,"master code never advertises standalone selectable effects");
    nc::ModEntry mod;mod.name="Infinite Health 60FPS 4K Graphics";mod.format=nc::ModFormat::Archive;
    p.cheats.clear();require(nc::optionEffects(p,{mod})==std::vector<std::string>{"Mods publicados"},"unverified mods do not advertise exact-version effects");
    require(includes(effects({"Handheld 1920x1080 Locked"}),"Resolución"),"explicit display dimensions recognized");
    require(!includes(effects({"Coins 720","Item x2","HP Info","InfiniteMP"}),"Resolución")&&!includes(effects({"HP Info","InfiniteMP"}),"Vida infinita"),"unrelated amounts and substrings never infer effects");
    auto original=cheat("Infinite HP (Hold ZR)");original.selected=true;const auto before=original;
    nc::cheatLabel(original);nc::explainCheat(original);p.cheats={original};nc::optionEffects(p,{});
    require(original.name==before.name&&original.opcodes==before.opcodes&&original.selected==before.selected&&original.group==before.group&&original.source==before.source,"display helpers never change source metadata selection or code");
    require(nc::cheatLabel(cheat("Munición infinita"))=="Munición infinita","Spanish accent normalization preserves friendly label");
    require(nc::explainCheat(cheat("Inf HP (Hold ZR)")).find("Hold ZR")!=std::string::npos,"description retains named activation condition");
    require(nc::optionEffects({},{}).empty(),"empty game catalog does not invent availability");
    auto hearts=cheat("Infinite / Max Hearts Press ZR");hearts.opcodes={0x80000200,0x01000000,0x01CC0764,0x50,0x20000000};
    auto rupees=cheat("9999 Rupees Press L");rupees.opcodes={0x80000040,0x02000000,0x01CC0760,0x270f,0x20000000};
    require(nc::cheatLabel(hearts)=="Corazones infinitos/máximos · pulsar ZR","actual Link's Awakening hearts label retains required ZR button");
    require(nc::cheatLabel(rupees)=="9999 rupias · pulsar L","actual Link's Awakening rupee label retains amount and required L button");
    require(nc::explainCheat(hearts).find("Mantén ZR dentro del juego")!=std::string::npos&&nc::explainCheat(hearts).find("Al soltarlo")!=std::string::npos,"actual key-conditional heart code explains holding and release");
    require(nc::explainCheat(rupees).find("Mantén L dentro del juego")!=std::string::npos&&nc::explainCheat(rupees).find("9999")!=std::string::npos,"actual key-conditional rupee code explains amount and holding");
    auto variant=hearts;variant.name+=" (Player 2 / ZL+ZR)";
    require(nc::cheatLabel(variant)=="Corazones infinitos/máximos · pulsar ZR (Player 2 / ZL+ZR)","actual hotkey translation retains trailing variant and extra conditions");
    p.cheats={hearts,rupees};summary=nc::optionEffects(p,{});
    require(summary==std::vector<std::string>{"Corazones (pulsar ZR)","9999 rupias (pulsar L)"},"actual hotkey effects do not advertise permanent infinite health or money");
    variant=hearts;variant.opcodes={0x01000000,0x01CC0764,0x50};
    require(nc::explainCheat(variant).find("El nombre del autor indica pulsar ZR")!=std::string::npos&&nc::explainCheat(variant).find("Mantén")==std::string::npos,"name-only hint does not invent a conditional execution structure");
    require(hearts.name=="Infinite / Max Hearts Press ZR"&&hearts.opcodes==std::vector<uint32_t>{0x80000200,0x01000000,0x01CC0764,0x50,0x20000000},"friendly explanation never strips or alters actual author button guard");
    require(nc::cheatLabel(cheat("Have 3/4 Hearts (Press ZL+ZR)"))=="Have 3/4 Hearts (pulsar ZL+ZR)","literal press translation retains all button combinations");
    std::cout<<"options: "<<checks<<" naming and effect-summary checks passed\n";
}

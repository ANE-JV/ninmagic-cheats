// Synthetic fixtures only. Optional third-party archive is supplied privately
// through argv and is never copied into the public source package.
#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <filesystem>
#include <iostream>
#include <minizip/zip.h>
namespace fs=std::filesystem;
namespace {
unsigned checks=0;
void require(bool value,const char *message){++checks;if(!value){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
void makeZip(const std::string &path,const std::vector<std::pair<std::string,std::string>> &files,unsigned mode=0100644){
    zipFile z=zipOpen64(path.c_str(),APPEND_STATUS_CREATE);require(z,"open synthetic author ZIP");
    for(const auto &f:files){zip_fileinfo m{};m.external_fa=mode<<16;
        require(zipOpenNewFileInZip64(z,f.first.c_str(),&m,nullptr,0,nullptr,0,nullptr,0,0,0)==ZIP_OK,"open author member");
        require(zipWriteInFileInZip(z,f.second.data(),unsigned(f.second.size()))==ZIP_OK&&zipCloseFileInZip(z)==ZIP_OK,"write author member");}
    require(zipClose(z,nullptr)==ZIP_OK,"close author archive");
}
bool isSource(const std::vector<nc::GameProvider> &sources,const char *key){return std::any_of(sources.begin(),sources.end(),[&](const auto &p){return p.key==key;});}
nc::Game game(uint64_t tid=0x01007300020FA000ULL,std::string bid="4B159F0F7A360669"){
    nc::Game g;g.id=tid;g.buildId=std::move(bid);g.fullBuildId=g.buildId+std::string(48,'0');g.buildVerified=true;g.running=true;return g;
}
}
int main(int argc,char **argv){
    require(argc==2||argc==3,"fresh fixture directory and optional real author ZIP");
    const auto base=fs::absolute(argv[1]);fs::create_directories(base);const auto root=(base/"cache").generic_string();setenv("NC_CATALOG_ROOT",root.c_str(),1);
    const auto g=game();const auto tid=nc::hexId(g.id),bid=g.buildId;
    const auto authorPath="MyNXCheats-main/Synthetic Game Name/"+tid+"/cheats/"+bid+".txt";
    const std::string code="[Synthetic published health]\n04000000 00000100 00000009\n";
    const auto archive=(base/"author.zip").generic_string(),other=(base/"other.zip").generic_string();
    makeZip(archive,{{authorPath,code}});makeZip(other,{{"contents/01007300020FA001/cheats/4B159F0F7A360670.txt",code}});
    std::string error,text;bool found=false;uint64_t parsedTid=0;std::string parsedBid;
    require(!nc::memberIdentity(authorPath,parsedTid,parsedBid),"author layout never broadens canonical grammar");
    require(nc::archiveIdentity(authorPath,parsedTid,parsedBid,nc::ArchiveProfile::Arch9)&&parsedTid==g.id&&parsedBid==bid,"explicit author profile accepts exact root/game/title/cheats/build");
    for(const auto &bad:std::vector<std::string>{"Other-main/Game/"+tid+"/cheats/"+bid+".txt","MyNXCheats-main/../"+tid+"/cheats/"+bid+".txt","MyNXCheats-main/Game/"+tid+"/cheats/"+bid+".txt/","MyNXCheats-main/Game/extra/"+tid+"/cheats/"+bid+".txt","MyNXCheats-main/Game/"+tid+"/saves/"+bid+".txt","MyNXCheats-main/Game/"+tid+"/cheats/0000000000000000.txt","MyNXCheats-main/Game\\Name/"+tid+"/cheats/"+bid+".txt"})
        require(!nc::archiveIdentity(bad,parsedTid,parsedBid,nc::ArchiveProfile::Arch9),"profile rejects wrong root, traversal, extra depth, directory and non-cheat identity");
    require(nc::zipExact(archive,g,text,found,error)&&!found,"canonical direct reader ignores author layout");
    require(nc::zipExact(archive,g,text,found,error,nc::ArchiveProfile::Arch9)&&found&&text==code,"target-only author lookup preserves bytes");
    auto different=g;different.buildId.back()='0';different.fullBuildId.replace(0,16,different.buildId);
    require(nc::zipExact(archive,different,text,found,error,nc::ArchiveProfile::Arch9)&&!found&&text.empty(),"author profile never substitutes another BID");
    std::vector<nc::CatalogEntry> entries;
    require(!nc::indexArchive(archive,"Arch9",entries,error,true)&&entries.empty(),"general NRO index ignores author paths");error.clear();
    require(nc::indexArchive(archive,"Arch9",entries,error,true,false,nc::ArchiveProfile::Arch9)&&entries.size()==1,"NRO profile indexes only explicitly accepted identity");entries.clear();
    makeZip(archive,{{authorPath,code},{"MyNXCheats-main/Other Game/"+tid+"/cheats/"+bid+".txt",code}});
    require(!nc::zipExact(archive,g,text,found,error,nc::ArchiveProfile::Arch9)&&!found&&text.empty(),"duplicate BID in separate game folders is ambiguous");
    require(!nc::indexArchive(archive,"Arch9",entries,error,true,false,nc::ArchiveProfile::Arch9)&&entries.empty(),"duplicate author identities never enter NRO index");
    for(const char *dependency:{"patch.ips","patch.IPS32","patch.pchtxt","backup.7z","exefs_patches/group/file.bin","romfs/data/file.bin","exefs/main"}){
        makeZip(archive,{{authorPath,code},{std::string("MyNXCheats-main/Synthetic Game Name/")+dependency,"dependency"}});
        error.clear();require(!nc::zipExact(archive,g,text,found,error,nc::ArchiveProfile::Arch9)&&!found&&!error.empty(),"author dependencies fail closed even after matching target");
        error.clear();require(!nc::indexArchive(archive,"Arch9",entries,error,true,false,nc::ArchiveProfile::Arch9)&&entries.empty(),"NRO rejects source with patch dependency");
    }
    makeZip(archive,{{authorPath,code}},0120777);
    require(!nc::zipExact(archive,g,text,found,error,nc::ArchiveProfile::Arch9)&&!found,"author symlink is not a regular cheat file");
    require(!nc::indexArchive(archive,"Arch9",entries,error,true,false,nc::ArchiveProfile::Arch9)&&entries.empty(),"NRO author symlink rejected");
    makeZip(archive,{{authorPath,code}});
    unsigned archGets=0,archHeads=0;bool changed=false,cancelled=false,abortArch=false;
    nc::testNetworkReady=true;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &why,nc::RemoteStamp *remote,bool head){
        if(remote)*remote={changed?"new":"stable","Tue, 27 Oct 2026 00:00:00 GMT","123",200};
        if(url==nc::Arch9Url){if(head){++archHeads;return true;}++archGets;fs::copy_file(archive,path,fs::copy_options::overwrite_existing);if(abortArch)cancelled=true;return true;}
        if(url==nc::GeneralUrl||url==nc::RawUrl||url==nc::NxCodeUrl||url==nc::SthetixUrl){if(!head)fs::copy_file(other,path,fs::copy_options::overwrite_existing);return true;}
        if(remote)remote->status=404;
        why="Synthetic canonical raw404";return false;
    };
    nc::Pack pack;std::vector<nc::CheatSourceReport> reports;
    require(nc::findPublishedGameDirect(g,false,pack,reports,error)&&pack.compatible&&pack.cheats.size()==1&&pack.cheats[0].source=="Arch9SK7/MyNXCheats","new profile is queried and contributes exact published code");
    require(archGets==1&&archHeads==0,"initial author ZIP downloaded once");
    require(nc::findPublishedGameDirect(g,false,pack,reports,error)&&archGets==1&&archHeads==0,"per-game six-hour cache performs no HTTP");
    require(nc::findPublishedGameDirect(different,false,pack,reports,error)&&!pack.compatible&&archGets==1&&archHeads==0,"global recent archive shared across different exact BID queries");
    require(nc::findPublishedGameDirect(g,true,pack,reports,error)&&archGets==1&&archHeads==1,"forced update uses unchanged shared ZIP HEAD without GET");
    const auto saved=nc::providerRoot()+"/arch9sk7-direct.zip";std::string before,after;
    require(nc::readSmall(saved,before,size_t(nc::MaxArchive)),"record author cache");
    changed=true;makeZip(archive,{{authorPath,"[Synthetic malformed author]\nINVALID\n"}});
    require(!nc::findPublishedGameDirect(g,true,pack,reports,error)&&pack.compatible,"invalid new author text is incomplete and retains exact cached options");
    require(nc::readSmall(saved,after,size_t(nc::MaxArchive))&&before==after,"invalid new target cannot replace prior ZIP");
    makeZip(archive,{{authorPath,code},{"MyNXCheats-main/Game/romfs/config.bin","patch"}});
    require(!nc::findPublishedGameDirect(g,true,pack,reports,error)&&pack.compatible,"new patch dependency does not hide local usable codes");
    require(nc::readSmall(saved,after,size_t(nc::MaxArchive))&&before==after,"patch-bearing replacement preserves old ZIP bytes");
    makeZip(archive,{{authorPath,code}});abortArch=true;
    require(!nc::findPublishedGameDirect(g,true,pack,reports,error,[&]{return cancelled;})&&error.find("cancelada")!=error.npos,"cancel after author download is incomplete");
    require(nc::readSmall(saved,after,size_t(nc::MaxArchive))&&before==after,"cancellation never promotes author download");abortArch=cancelled=false;
    const auto nroRoot=(base/"nro-cache").generic_string();setenv("NC_CATALOG_ROOT",nroRoot.c_str(),1);changed=false;
    require(nc::refreshGameSources(g,false,reports,error),"NRO queries new author ZIP with existing providers");
    pack=nc::findCheats(g,nc::Catalog{});
    require(pack.compatible&&pack.cheats.size()==1&&pack.cheats[0].source=="Arch9SK7/MyNXCheats","NRO reads author cache without relaxing canonical parser");
    const auto nroSaved=nc::providerRoot()+"/arch9sk7.zip";require(nc::readSmall(nroSaved,before,size_t(nc::MaxArchive)),"record original author archive in NRO");
    changed=true;makeZip(archive,{{authorPath,"[Synthetic malformed]\nINVALID\n"}});
    require(!nc::refreshGameSources(g,true,reports,error)&&nc::findCheats(g,nc::Catalog{}).compatible,"NRO target syntax is validated before replacement");
    require(nc::readSmall(nroSaved,after,size_t(nc::MaxArchive))&&before==after,"NRO malformed author target preserves original source ZIP");
    const auto cross=(base/"cross-game-cache").generic_string();fs::create_directories(fs::path(cross)/"published-sources");setenv("NC_CATALOG_ROOT",cross.c_str(),1);
    const auto oldMember="MyNXCheats-main/Other valid game/01007300020FA001/cheats/4B159F0F7A360670.txt";
    makeZip(archive,{{oldMember,code},{authorPath,"[Malformed target B in ZIP accepted for game A]\nINVALID\n"}});
    for(const char *key:{"arch9sk7","arch9sk7-direct"}){
        const auto current=nc::providerRoot()+"/"+key+".zip";
        fs::copy_file(archive,current);makeZip(current+".previous",{{authorPath,code}});
        require(nc::markChecked(current+".checked",nc::Arch9Url)&&nc::writeSmall(current+".remote",nc::stampText(nc::Arch9Url,{"new","Tue, 27 Oct 2026 00:00:00 GMT","123",200})),"create apparently recent cross-game archive validators");
    }
    entries.clear();std::string usedArchive;
    require(nc::archiveCachedEntries(g,"arch9sk7","Arch9SK7/MyNXCheats",entries,error,&usedArchive,nc::ArchiveProfile::Arch9)&&usedArchive.find(".previous")!=usedArchive.npos,"NRO prefers usable previous target over malformed current from another game");
    bool currentValid=true;
    require(nc::zipFallback(nc::providerRoot()+"/arch9sk7-direct.zip",g,text,found,error,&currentValid,nc::ArchiveProfile::Arch9)&&found&&text==code&&!currentValid,"direct fallback uses parsed previous target and invalidates current TTL/ETag eligibility");
    const auto beforeCrossGets=archGets,beforeCrossHeads=archHeads;
    require(!nc::refreshGameSources(g,false,reports,error)&&nc::findCheats(g,nc::Catalog{}).compatible,"NRO rechecks malformed cached target without claiming complete absence");
    require(archGets==beforeCrossGets+1&&archHeads==beforeCrossHeads,"NRO never reuses recent/unchanged validators from malformed current target");
    require(!nc::findPublishedGameDirect(g,false,pack,reports,error)&&pack.compatible&&pack.cheats.size()==1,"overlay cross-game malformed target stays incomplete with previous exact code");
    require(archGets==beforeCrossGets+2&&archHeads==beforeCrossHeads,"overlay also GETs instead of trusting other-game current validators");
    require(std::size(nc::catalog_sources::Bad1dea)==22,"explicit reviewed raw table has22 entries");
    for(const auto &entry:nc::catalog_sources::Bad1dea){
        const auto sources=nc::gameProviders(game(entry.title,entry.build));
        auto p=std::find_if(sources.begin(),sources.end(),[](const auto &s){return s.key=="bad1dea-54fc969";});
        require(p!=sources.end()&&p->url==entry.url&&p->url.find("/54fc9698d30291e1a785706f6cbc121667fbd02f/")!=p->url.npos,"only exact pinned raw path is generated");
        require(p->url.find("/cheats/"+std::string(entry.build)+".txt")!=p->url.npos,"raw BID filename is exact, not inferred from version");
    }
    require(!isSource(nc::gameProviders(g),"bad1dea-54fc969"),"unlisted title cannot fetch author raw paths");
    auto wonder=game(0x010015100B514000ULL,"ff773e90972d544e");
    require(isSource(nc::gameProviders(wonder),"oblivion-wonder"),"curated author source applies only to verified exact Wonder identity, accepting hex case");
    wonder.buildId="CD6E42AEE7934F4D";require(!isSource(nc::gameProviders(wonder),"oblivion-wonder"),"curated route never applies to older Wonder build");
    wonder=game(0x010015100B514001ULL,"FF773E90972D544E");require(!isSource(nc::gameProviders(wonder),"oblivion-wonder"),"curated route never applies to different Title ID");
    makeZip(archive,{{authorPath,code}});changed=false;
    const auto baseTransfer=nc::testTransfer;const auto &route=nc::catalog_sources::Bad1dea[0];const auto rawGame=game(route.title,route.build);
    unsigned rawGets=0;bool rawOffline=false;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &why,nc::RemoteStamp *remote,bool head){
        if(url==route.url){++rawGets;if(remote)*remote={"raw-stable","Tue, 27 Oct 2026 00:00:00 GMT","60",200};if(rawOffline){if(remote)remote->status=0;why="Synthetic exact raw TCP error";return false;}return nc::writeSmall(path,code);}
        return baseTransfer(url,path,why,remote,head);
    };
    const auto rawRoot=(base/"raw-cache").generic_string();setenv("NC_CATALOG_ROOT",rawRoot.c_str(),1);
    require(nc::findPublishedGameDirect(rawGame,false,pack,reports,error)&&pack.compatible&&pack.cheats.size()==1&&rawGets==1,"pinned raw route is queried in direct overlay and contributes its original text");
    require(pack.cheats[0].source=="bad1dea/NXCheats (revisión 54fc969)"&&!pack.cheats[0].selected,"raw author credit preserved and search never selects code");
    require(nc::refreshGameSources(rawGame,false,reports,error)&&nc::findCheats(rawGame,nc::Catalog{}).compatible&&rawGets==1,"NRO reads shared pinned raw cache and six-hour timestamp without another request");
    rawOffline=true;
    require(!nc::findPublishedGameDirect(rawGame,true,pack,reports,error)&&pack.compatible&&error.find("Synthetic exact raw TCP error")!=error.npos,"raw request failure stays incomplete with previous exact options");
    auto providers=nc::gameProviders(rawGame);const auto p=std::find_if(providers.begin(),providers.end(),[](const auto &s){return s.key=="bad1dea-54fc969";});require(p!=providers.end(),"find exact pinned provider");
    unsigned missingCalls=0;std::string used;nc::RemoteStamp remote;
    nc::testTransfer=[&](const std::string &url,const std::string&,std::string &why,nc::RemoteStamp *stamp,bool){++missingCalls;require(url==route.url,"missing pinned URL is never rewritten");if(stamp)stamp->status=404;why="Synthetic404";return false;};
    require(!nc::downloadProvider(*p,rawRoot+"/unused.download",error,remote,nc::DirectText,used)&&missingCalls==1&&used==route.url,"pinned404 never probes lowercase, latest or another BID");
    const auto curatedRoot=(base/"curated-cache").generic_string();setenv("NC_CATALOG_ROOT",curatedRoot.c_str(),1);wonder=game(0x010015100B514000ULL,"FF773E90972D544E");
    unsigned curatedGets=0;bool curatedOffline=false;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &why,nc::RemoteStamp *stamp,bool head){
        if(url.find("/catalog/oblivionreign/")!=url.npos){++curatedGets;require(url=="https://raw.githubusercontent.com/ANE-JV/ninmagic-cheats/main/catalog/oblivionreign/contents/010015100B514000/cheats/FF773E90972D544E.txt","curated URL has literal author and exact identifiers");if(stamp)*stamp={"curated-stable","Tue, 27 Oct 2026 00:00:00 GMT","60",200};if(curatedOffline){if(stamp)stamp->status=0;why="Synthetic curated TCP error";return false;}return nc::writeSmall(path,code);}
        return baseTransfer(url,path,why,stamp,head);
    };
    require(nc::findPublishedGameDirect(wonder,false,pack,reports,error)&&pack.compatible&&pack.cheats.size()==1&&curatedGets==1&&pack.cheats[0].source=="OblivionReign/GBATemp","curated exact Wonder source contributes code separately from other providers");
    require(nc::refreshGameSources(wonder,false,reports,error)&&nc::findCheats(wonder,nc::Catalog{}).compatible&&curatedGets==1,"curated raw source shares its verified cache with NRO");
    curatedOffline=true;
    require(!nc::findPublishedGameDirect(wonder,true,pack,reports,error)&&pack.compatible&&error.find("Synthetic curated TCP error")!=error.npos,"curated failure never reports complete or deletes prepared compatible options");
    if(argc==3){
        entries.clear();error.clear();require(nc::indexArchive(argv[2],"Arch9SK7/MyNXCheats",entries,error,true,false,nc::ArchiveProfile::Arch9),"real private author ZIP passes CRC and explicit identity profile");
        size_t nroValid=0,overlayValid=0;for(const auto &entry:entries){
            unzFile z=unzOpen64(argv[2]);require(z&&unzLocateFile(z,entry.path.c_str(),1)==UNZ_OK&&nc::currentFile(z,text,error),"read real exact author member");unzClose(z);
            std::vector<nc::Cheat> parsed;if(nc::parseCheats(text,entry.source,parsed,error))++nroValid;if(nc::parseDirect(text,entry.source,parsed,error))++overlayValid;
        }
        std::cout<<"real author ZIP: identities="<<entries.size()<<" syntaxNRO="<<nroValid<<" syntaxOverlay="<<overlayValid<<"\n";
    }
    nc::testTransfer={};nc::testNetworkReady=false;
    std::cout<<"author providers: "<<checks<<" profile, dependency, exact-ID, cache and cancellation checks PASS\n";
}

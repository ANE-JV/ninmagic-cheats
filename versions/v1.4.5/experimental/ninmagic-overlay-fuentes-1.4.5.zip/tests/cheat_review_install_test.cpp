// The optional author's TXT stays outside the public source/package. No author
// opcodes are embedded here; all filesystem writes use a dedicated host sandbox.
#include "cheats.hpp"
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
fs::path sandbox;
unsigned checks=0;
void require(bool value,const char *message){++checks;if(!value)throw std::runtime_error(message);}
std::string read(const fs::path &path){std::ifstream in(path,std::ios::binary);return {std::istreambuf_iterator<char>(in),{}};}
void write(const fs::path &path,const std::string &data){fs::create_directories(path.parent_path());std::ofstream out(path,std::ios::binary);out.write(data.data(),data.size());require(bool(out),"host fixture write");}
std::string serialize(const nc::Cheat &cheat,bool master){
    std::string text=master?"{Renamed local master}\n":"[Renamed local option]\n";
    for(const auto word:cheat.opcodes){char hex[10];std::snprintf(hex,sizeof(hex),"%08X\n",word);text+=hex;}
    return text;
}
nc::Game game(){nc::Game g;g.id=0x010015100B514000ULL;g.buildId="FF773E90972D544E";g.buildVerified=true;return g;}
void cleanup(){
    const auto parent=fs::weakly_canonical(fs::temp_directory_path());const auto path=fs::weakly_canonical(sandbox);
    require(path.parent_path()==parent&&path.filename().string().find("ninmagic-review-install-")==0,"validated host-only cleanup scope");
    fs::remove_all(path);
}
}
namespace nc {std::string installTestRoot(){return sandbox.string();}}
int main(int argc,char **argv){
    try{
        require(argc==2,"private TXT argument required");const auto text=read(argv[1]);std::vector<nc::Cheat> data;std::string error;
        require(nc::parseCheats(text,"Private author fixture",data,error)&&data.size()==11,"parse eleven private definitions");
        sandbox=fs::temp_directory_path()/("ninmagic-review-install-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
        require(fs::create_directory(sandbox),"create dedicated host sandbox");const auto g=game();
        for(auto cheat:data){
            cheat.name="Renamed imported definition";cheat.source="Unrelated source label";cheat.group="group";cheat.selected=true;
            nc::Pack pack;pack.game=g;pack.compatible=true;pack.cheats={cheat};
            const auto outcome=nc::installPack(pack);
            require(!outcome.ok&&!outcome.message.empty(),"review blocks real install entry point");
            require(!fs::exists(sandbox/"atmosphere")&&!fs::exists(sandbox/"config"),"rejected install makes no directories or SD-style files");
        }
        const auto target=sandbox/"atmosphere"/"contents"/nc::hexId(g.id)/"cheats"/(g.buildId+".txt");
        for(const auto &cheat:data)for(bool master:{false,true}){
            const auto bytes=serialize(cheat,master);write(target,bytes);
            require(!nc::preflightInstalledCheats(g,error)&&error.find("CD6E42AEE7934F4D")!=std::string::npos,"real SD preflight blocks exact fingerprint even renamed/as master");
            require(read(target)==bytes&&!fs::exists(sandbox/"config"),"preflight leaves installed bytes and backups unchanged");
        }
        write(target,"[Synthetic safe option]\n04000000 00001000 00000009\n");
        require(nc::preflightInstalledCheats(g,error),"unreviewed synthetic definition is not globally blocked");
        auto old=g;old.buildId="CD6E42AEE7934F4D";const auto oldTarget=target.parent_path()/(old.buildId+".txt");write(oldTarget,serialize(data.front(),false));
        require(nc::preflightInstalledCheats(old,error),"quarantine does not claim a global block of the earlier source Build ID");
        cleanup();std::cout<<"cheat review install: "<<checks<<" exact-entry/no-write/preflight checks passed\n";return 0;
    }catch(const std::exception &exception){std::cerr<<"FAILED: "<<exception.what()<<"\nHost fixtures preserved at "<<sandbox<<'\n';return 1;}
}

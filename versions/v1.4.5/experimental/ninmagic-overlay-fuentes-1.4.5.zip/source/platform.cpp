#include "platform.hpp"
#include "platform_internal.hpp"
#include "cheats.hpp"
#include "live_receipt.hpp"
#include "memory_scan_guard.hpp"
#include "scan_read_policy.hpp"
#include "title_metadata.hpp"
#include "ui_text.hpp"
#include <switch.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <new>
#include <set>

namespace nc {
namespace {
bool nsReady=false,fsldrReady=false,ncmReady=false,pmReady=false,ldrReady=false;
Result fsldrInitResult=0,pmInitResult=0,ldrInitResult=0;
Service cheatService{};
bool cheatReady=false;
uint64_t selfPid=0;
native::scan::ReadPolicy scanReadPolicy;
native::LiveReceipt liveReceipt;
bool receiptStorageReady=true;
std::string receiptStorageError;
Result cheatReadError=0;
std::string cheatReadStep;
constexpr uint64_t MinUser=0x0100000000010000ULL;
constexpr size_t MaxRecords=16384;
std::string rcText(Result rc){char s[16];std::snprintf(s,sizeof(s),"0x%08lX",static_cast<unsigned long>(rc));return s;}
bool readResult(Result rc,const char*step){if(R_FAILED(rc)){cheatReadError=rc;cheatReadStep=step;return false;}return true;}
std::string bounded(const char*p,size_t n){size_t z=0;while(z<n&&p[z])++z;return std::string(p,z);}
int titleLanguage() {
    if(R_FAILED(setInitialize()))return -1;
    u64 code=0;SetLanguage language=SetLanguage_ENUS;
    Result rc=setGetSystemLanguage(&code);
    if(R_SUCCEEDED(rc))rc=setMakeLanguage(code,&language);
    setExit();
    // Same Settings-to-NACP mapping as libnx runtime/nacp.c. Unknown future
    // system languages use the validated English/available-title fallback.
    static constexpr int indices[]={2,0,3,4,7,6,14,12,8,10,11,13,1,9,5,14,13,15};
    const int index=static_cast<int>(language);
    return R_SUCCEEDED(rc)&&index>=0&&index<18?indices[index]:-1;
}
bool applyTitleMetadata(Game&game,const void*bytes,size_t size,int preferredLanguage) {
    TitleMetadata metadata;std::string metadataError;
    if(!parseTitleMetadata(bytes,size,metadata,metadataError,preferredLanguage)) {
        if(metadata.versionValid)game.version=metadata.version;
        return false;
    }
    if(metadata.versionValid)game.version=metadata.version;
    // Display another real localized entry when the selected script has no
    // glyphs in our font. Identity and cheat matching always retain game.id.
    int selected=-1;
    const auto usable=[&](int index){return index>=0&&static_cast<unsigned>(index)<metadata.languageCount&&metadata.languages[index].nameValid&&ui_text::canDisplayUtf8(metadata.languages[index].name);};
    if(usable(metadata.selectedLanguage))selected=metadata.selectedLanguage;
    else for(int index:{0,1,6,5})if(usable(index)){selected=index;break;}
    if(selected<0)for(unsigned index=0;index<metadata.languageCount;++index)if(usable(static_cast<int>(index))){selected=static_cast<int>(index);break;}
    if(selected<0)return false;
    const auto&entry=metadata.languages[selected];game.name=entry.name;
    if(entry.authorValid&&ui_text::canDisplayUtf8(entry.author))game.author=entry.author;
    else if(metadata.authorValid&&ui_text::canDisplayUtf8(metadata.author))game.author=metadata.author;
    else for(unsigned index=0;index<metadata.languageCount;++index){const auto&other=metadata.languages[index];if(other.authorValid&&ui_text::canDisplayUtf8(other.author)){game.author=other.author;break;}}
    return true;
}
std::string fullBuild(const uint8_t *bytes) {
    static constexpr char h[]="0123456789ABCDEF";std::string value;
    for(unsigned i=0;i<32;++i){value+=h[bytes[i]>>4];value+=h[bytes[i]&15];}return value;
}
bool storageAllowed(uint8_t storage){return storage==NcmStorageId_SdCard||storage==NcmStorageId_BuiltInUser||storage==NcmStorageId_GameCard;}
bool contentFor(uint64_t id,const NsApplicationContentMetaStatus&s){
    return storageAllowed(s.storageID)&&((s.meta_type==NcmContentMetaType_Application&&s.application_id==id)||(s.meta_type==NcmContentMetaType_Patch&&s.application_id==(id^0x800ULL)));
}
bool readStatuses(Game&game,std::vector<NsApplicationContentMetaStatus>&statuses,std::string&error) {
    statuses.clear();game.sd=game.nand=game.card=false;game.versionKnown=false;game.contentVersion=0;
    for(s32 offset=0;;) {
        NsApplicationContentMetaStatus batch[32]{};s32 count=0;
        Result rc=nsListApplicationContentMetaStatus(game.id,offset,batch,32,&count);
        if(R_FAILED(rc)||count<0||count>32||static_cast<size_t>(offset+count)>MaxRecords){error="No se pudieron leer los contenidos del juego ("+rcText(rc)+").";return false;}
        if(!count)break;
        for(s32 i=0;i<count;++i)if(contentFor(game.id,batch[i])) {
            const auto&s=batch[i];statuses.push_back(s);
            game.sd|=s.storageID==NcmStorageId_SdCard;game.nand|=s.storageID==NcmStorageId_BuiltInUser;game.card|=s.storageID==NcmStorageId_GameCard;
        }
        offset+=count;
    }
    if(statuses.empty()){error="El juego no tiene contenido instalado accesible.";return false;}
    std::stable_sort(statuses.begin(),statuses.end(),[](const auto&a,const auto&b){
        if(a.meta_type!=b.meta_type)return a.meta_type==NcmContentMetaType_Patch;
        if(a.version!=b.version)return a.version>b.version;
        return a.storageID>b.storageID;
    });
    game.contentVersion=statuses.front().version;game.versionKnown=true;return true;
}
bool getNativeMetadata(native::Metadata &m,bool attach) {
    if(!cheatReady)return false;
    if(attach&&!readResult(serviceDispatch(&cheatService,65003),"dmnt:cht/65003"))return false;
    u8 present=0;
    if(!readResult(serviceDispatchOut(&cheatService,65000,present),"dmnt:cht/65000")||!present)return false;
    if(!readResult(serviceDispatchOut(&cheatService,65002,m),"dmnt:cht/65002")||!m.pid||m.pid==selfPid||m.title<MinUser)return false;
    if(pmReady){u64 applicationPid=0;if(!readResult(pmdmntGetApplicationProcessId(&applicationPid),"pm:dmnt/GetApplicationProcessId")||applicationPid!=m.pid)return false;}
    return validBuild(native::buildString(m.build));
}
bool loaderMetadata(native::Metadata &m,std::string *diagnostic=nullptr) {
    const auto fail=[&](const std::string&step,Result rc){if(diagnostic)*diagnostic=step+"="+rcText(rc);return false;};
    if(!pmReady)return fail("pm/init",pmInitResult);
    if(!ldrReady)return fail("ldr/init",ldrInitResult);
    u64 pid=0,tid=0;
    Result rc=pmdmntGetApplicationProcessId(&pid);
    if(R_FAILED(rc))return fail("pm/application-pid",rc);
    if(!pid||pid==selfPid){if(diagnostic)*diagnostic="pm/application-pid: sin otro juego en ejecución";return false;}
    rc=pmdmntGetProgramId(&tid,pid);if(R_FAILED(rc))return fail("pm/program-id",rc);
    if(tid<MinUser){if(diagnostic)*diagnostic="pm/program-id: no es un juego de usuario";return false;}
    LoaderModuleInfo modules[2]{};s32 count=0;
    rc=ldrDmntGetProcessModuleInfo(pid,modules,2,&count);if(R_FAILED(rc))return fail("ldr/modules",rc);
    if(count!=2){if(diagnostic)*diagnostic="ldr/modules: "+std::to_string(count)+", se requieren 2";return false;}
    u64 verifyPid=0,verifyTid=0;
    if(R_FAILED(pmdmntGetApplicationProcessId(&verifyPid))||verifyPid!=pid||R_FAILED(pmdmntGetProgramId(&verifyTid,pid))||verifyTid!=tid)return false;
    const auto bid=native::buildString(modules[1].build_id);
    if(!validBuild(bid)||bid=="0000000000000000"||bid=="FFFFFFFFFFFFFFFF")return false;
    m={};m.pid=pid;m.title=tid;m.mainBase=modules[1].base_address;m.mainSize=modules[1].size;std::memcpy(m.build,modules[1].build_id,sizeof(m.build));return true;
}
ScanIdentity scanIdentity(const native::Metadata&m) {
    ScanIdentity value;value.pid=m.pid;value.title=m.title;value.fullBuildId=fullBuild(m.build);
    value.mainBase=m.mainBase;value.mainSize=m.mainSize;value.heapBase=m.heapBase;value.heapSize=m.heapSize;value.aliasBase=m.aliasBase;value.aliasSize=m.aliasSize;return value;
}
bool checkScanIdentity(const ScanIdentity&expected,std::string&error) {
    if(!cheatReady||expected.pid==selfPid||!native::scan::valid(expected)){error="La identidad del escaneo no es válida o el motor no está disponible.";return false;}
    native::Metadata current{},loader{};
    if(!getNativeMetadata(current,false)){error="No se pudo verificar el proceso del escaneo; no se leyó memoria.";return false;}
    if(!native::scan::same(expected,scanIdentity(current))){error="El proceso, Build ID o mapa MAIN/HEAP cambió. Inicia una búsqueda nueva.";return false;}
    // ForceOpen also accepts one-module HBL processes. Independently require
    // the two-module retail layout; never use dmnt attachment as that proof.
    if(!loaderMetadata(loader)||loader.pid!=expected.pid||loader.title!=expected.title||fullBuild(loader.build)!=expected.fullBuildId||loader.mainBase!=expected.mainBase||loader.mainSize!=expected.mainSize){error="El cargador ya no confirma el juego real de esta sesión. No se admite escanear homebrew.";return false;}
    return true;
}
bool openScanProcess(const Game&game,ScanIdentity&identity,bool attach,std::string&error) {
    identity={};error.clear();
    if(!cheatReady){error="dmnt:cht no está disponible para buscar valores.";return false;}
    if(!game.running||!game.buildVerified||!validBuild(game.buildId)||!native::scan::fullBuild(game.fullBuildId)||game.fullBuildId.substr(0,16)!=game.buildId){error="Abre el juego real y entra por Álbum para comprobar su Build ID antes de buscar valores.";return false;}
    native::Metadata loader{};
    if(!loaderMetadata(loader)||loader.title!=game.id||loader.pid==selfPid||fullBuild(loader.build)!=game.fullBuildId){error="No hay un juego real con este Title ID y Build ID en segundo plano. Homebrew no está admitido.";return false;}
    u8 present=0;Result rc=serviceDispatchOut(&cheatService,65000,present);
    if(R_FAILED(rc)){error="No se pudo consultar el motor de búsqueda ("+rcText(rc)+").";return false;}
    if(!present) {
        if(!attach){error="El motor aún no está conectado al juego. Confirma Iniciar búsqueda para conectarlo.";return false;}
        native::Metadata immediatelyBefore{};
        if(!loaderMetadata(immediatelyBefore)||immediatelyBefore.pid!=loader.pid||immediatelyBefore.title!=loader.title||fullBuild(immediatelyBefore.build)!=game.fullBuildId){error="El proceso cambió antes de conectar el motor. Vuelve a seleccionar el juego.";return false;}
        // This is the explicit scan-start boundary. Atmosphere may load this
        // game's existing SD cheats during attachment; the caller must explain
        // that side effect before invoking this function.
        rc=serviceDispatch(&cheatService,65003);
        if(R_FAILED(rc)){error="No se pudo conectar el motor al juego ("+rcText(rc)+").";return false;}
    }
    native::Metadata metadata{};
    if(!getNativeMetadata(metadata,false)||metadata.pid!=loader.pid||metadata.title!=game.id||fullBuild(metadata.build)!=game.fullBuildId){error="El motor no coincide con el proceso confirmado. No se inició el escaneo.";return false;}
    auto next=scanIdentity(metadata);
    if(!checkScanIdentity(next,error))return false;
    identity=std::move(next);return true;
}
void runningEnvironment(Environment&env) {
    env.dmnt=cheatReady;env.runningTitle=0;env.runningBuild.clear();native::Metadata m{};
    if(getNativeMetadata(m,false)||loaderMetadata(m)){env.runningTitle=m.title;env.runningBuild=native::buildString(m.build);}
}
bool nativeProgramPath(const NsApplicationContentMetaStatus&status,std::string&path) {
    if(!ncmReady)return false;
    NcmContentMetaDatabase db{};NcmContentStorage cs{};
    Result rc=ncmOpenContentMetaDatabase(&db,static_cast<NcmStorageId>(status.storageID));
    if(R_FAILED(rc))return false;
    NcmContentMetaKey key{};key.id=status.application_id;key.version=status.version;key.type=status.meta_type;
    NcmContentId content{};
    rc=ncmContentMetaDatabaseGetContentIdByTypeAndIdOffset(&db,&content,&key,NcmContentType_Program,0);
    ncmContentMetaDatabaseClose(&db);
    if(R_FAILED(rc))return false;
    rc=ncmOpenContentStorage(&cs,static_cast<NcmStorageId>(status.storageID));if(R_FAILED(rc))return false;
    char value[FS_MAX_PATH]{};rc=ncmContentStorageGetPath(&cs,value,sizeof(value),&content);ncmContentStorageClose(&cs);
    if(R_FAILED(rc)||!value[0])return false;
    path=bounded(value,sizeof(value));return true;
}
bool installedBuild(Game&game,const std::vector<NsApplicationContentMetaStatus>&statuses,std::string&error) {
    if(!fsldrReady){error="No se pudo abrir fsp-ldr para leer el Build ID (init="+rcText(fsldrInitResult)+"). Abre el juego y vuelve desde Álbum.";return false;}
    Result last=0;std::string step="sin contenido efectivo";
    // Only the newest effective Application/Patch is eligible. Never fall back
    // to the older base executable when an update is installed.
    const auto&effective=statuses.front();
    for(const auto&status:statuses) {
        if(status.meta_type!=effective.meta_type||status.version!=effective.version)continue;
        std::string path;
        if(hosversionBefore(20,0,0)&&!nativeProgramPath(status,path)){step="NCM/program-path";continue;}
        FsCodeInfo info{};FsFileSystem fs{};
        step="CodeFS/open storage="+std::to_string(status.storageID)+" meta="+std::to_string(status.meta_type)+" version="+std::to_string(status.version);
        last=fsldrOpenCodeFileSystem(&info,game.id,static_cast<NcmStorageId>(status.storageID),path.c_str(),FsContentAttributes_None,&fs);
        if(R_FAILED(last))continue;
        step="CodeFS/main-open";
        FsFile main{};last=fsFsOpenFile(&fs,"/main",FsOpenMode_Read,&main);
        if(R_FAILED(last)){fsFsClose(&fs);continue;}
        uint8_t header[0x60]{};u64 got=0;
        step="CodeFS/main-read";
        last=fsFileRead(&main,0,header,sizeof(header),FsReadOption_None,&got);fsFileClose(&main);fsFsClose(&fs);
        if(R_FAILED(last))continue;
        if(got!=sizeof(header)||std::memcmp(header,"NSO0",4)){step="CodeFS/NSO-header bytes="+std::to_string(got);continue;}
        const auto bid=native::buildString(header+0x40);if(!validBuild(bid)||bid=="0000000000000000"||bid=="FFFFFFFFFFFFFFFF"){step="CodeFS/NSO-build-id inválido";continue;}
        game.buildId=bid;game.fullBuildId=fullBuild(header+0x40);game.buildVerified=true;game.detail="Build ID leído del ejecutable instalado.";return true;
    }
    error="No se pudo verificar el Build ID del ejecutable instalado ("+step+", rc="+rcText(last)+")";
    error+=". Abre el juego, vuelve a Álbum y vuelve a buscar.";return false;
}
uint64_t scanNowNs(){return armTicksToNs(armGetSystemTick());}
uint64_t scanElapsedNs(uint64_t started){const auto ended=scanNowNs();return ended>=started?ended-started:0;}
class FastReadProof final:public native::scan::ReadProofSource {
public:
    bool metadata(native::Metadata&value,std::string&error)override{
        if(!cheatReady){error="El motor no está disponible para verificar la lectura.";return false;}
        const Result rc=serviceDispatchOut(&cheatService,65002,value);
        if(R_FAILED(rc)){error="No se pudo verificar metadata del proceso ("+rcText(rc)+").";return false;}
        if(value.pid==selfPid){error="No se admite leer el propio proceso del buscador.";return false;}return true;
    }
    bool fullProof(const ScanIdentity&identity,std::string&error)override{return checkScanIdentity(identity,error);}
    uint64_t nowNs()override{return scanNowNs();}
};
class ScanAccess final:public native::scan::Access {
    bool fastRead=false;
public:
    explicit ScanAccess(bool fast=false):fastRead(fast){}
    bool verify(const ScanIdentity&identity,std::string&error)override{if(!fastRead)return checkScanIdentity(identity,error);FastReadProof proof;return scanReadPolicy.verify(identity,proof,error);}
    bool query(uint64_t address,native::scan::Mapping&mapping,std::string&error)override {
        const uint64_t started=fastRead?scanNowNs():0;
        MemoryInfo current{};const Result rc=serviceDispatchInOut(&cheatService,65104,address,current);
        if(fastRead)scanReadPolicy.queried(scanElapsedNs(started),R_SUCCEEDED(rc));
        if(R_FAILED(rc)){error="No se pudo consultar la página del valor ("+rcText(rc)+").";return false;}
        mapping={current.addr,current.size,current.perm,current.type};return true;
    }
    bool read(uint64_t address,void*buffer,size_t size,std::string&error)override {
        const uint64_t started=fastRead?scanNowNs():0;
        const struct {u64 address,size;} input{address,static_cast<u64>(size)};
        const Result rc=serviceDispatchIn(&cheatService,65102,input,
            .buffer_attrs={SfBufferAttr_Out|SfBufferAttr_HipcMapAlias},
            .buffers={{buffer,size}});
        if(fastRead)scanReadPolicy.readAttempted(size,scanElapsedNs(started),R_SUCCEEDED(rc));
        if(R_FAILED(rc)){error="No se pudo leer el valor del juego ("+rcText(rc)+").";return false;}
        return true;
    }
};
class CheatRuntime final:public native::Runtime {
public:
    bool metadata(native::Metadata &value)override{return getNativeMetadata(value,false);}
    bool entries(std::vector<native::Entry>&value)override {
        u64 count=0;if(!readResult(serviceDispatchOut(&cheatService,65200,count),"dmnt:cht/65200")||count>128)return false;
        value.resize(static_cast<size_t>(count));if(!count)return true;
        const u64 offset=0;u64 got=0;
        Result rc=serviceDispatchInOut(&cheatService,65201,offset,got,
            .buffer_attrs={SfBufferAttr_Out|SfBufferAttr_HipcMapAlias},
            .buffers={{value.data(),value.size()*sizeof(native::Entry)}});
        return readResult(rc,"dmnt:cht/65201")&&got==count;
    }
    bool add(const native::Definition&value,uint32_t&id)override {
        const u8 disabled=0;
        return R_SUCCEEDED(serviceDispatchInOut(&cheatService,65204,disabled,id,
            .buffer_attrs={SfBufferAttr_In|SfBufferAttr_HipcMapAlias|SfBufferAttr_FixedSize},
            .buffers={{&value,sizeof(value)}}));
    }
    bool remove(uint32_t id)override{return R_SUCCEEDED(serviceDispatchIn(&cheatService,65205,id));}
    bool toggle(uint32_t id)override{return R_SUCCEEDED(serviceDispatchIn(&cheatService,65203,id));}
    bool master(const native::Definition&value)override {
        return R_SUCCEEDED(serviceDispatch(&cheatService,65209,
            .buffer_attrs={SfBufferAttr_In|SfBufferAttr_HipcMapAlias|SfBufferAttr_FixedSize},
            .buffers={{&value,sizeof(value)}}));
    }
};
}
bool peekScanProcess(const Game&game,ScanIdentity&identity,std::string&error) {
    return openScanProcess(game,identity,false,error);
}
bool getScanProcess(const Game&game,ScanIdentity&identity,std::string&error) {
    return openScanProcess(game,identity,true,error);
}
bool enumerateScanRegions(const ScanIdentity&identity,std::vector<ScanRegion>&regions,std::string&error) {
    regions.clear();error.clear();if(!checkScanIdentity(identity,error))return false;
    u64 count=0;Result rc=serviceDispatchOut(&cheatService,65100,count);
    if(R_FAILED(rc)){error="No se pudo contar las regiones del juego ("+rcText(rc)+").";return false;}
    if(!checkScanIdentity(identity,error))return false;
    if(!count||count>MaxRecords){error="El mapa del juego está vacío o supera el límite de regiones.";return false;}
    std::vector<ScanRegion> next;uint64_t previousEnd=0;
    for(u64 offset=0;offset<count;) {
        if(!checkScanIdentity(identity,error))return false;
        MemoryInfo mappings[64]{};u64 received=0;const auto capacity=std::min<u64>(64,count-offset);
        rc=serviceDispatchInOut(&cheatService,65101,offset,received,
            .buffer_attrs={SfBufferAttr_Out|SfBufferAttr_HipcMapAlias},
            .buffers={{mappings,static_cast<size_t>(capacity)*sizeof(MemoryInfo)}});
        if(R_FAILED(rc)){error="No se pudo leer el mapa del juego ("+rcText(rc)+").";return false;}
        if(!checkScanIdentity(identity,error))return false;
        if(!received||received>capacity){error="El mapa del juego cambió durante la lectura. Inicia otra búsqueda.";return false;}
        for(u64 n=0;n<received;++n) {
            const auto&m=mappings[n];
            if(!m.size||m.size>UINT64_MAX-m.addr||m.addr<previousEnd){error="El mapa del juego contiene regiones inválidas o solapadas.";return false;}
            previousEnd=m.addr+m.size;
            native::scan::append(identity,{m.addr,m.size,m.perm,m.type},next);
        }
        offset+=received;
    }
    if(!checkScanIdentity(identity,error))return false;
    u64 countAfter=0;rc=serviceDispatchOut(&cheatService,65100,countAfter);
    if(R_FAILED(rc)||countAfter!=count){error="El mapa de memoria cambió durante la búsqueda. Vuelve a prepararla.";return false;}
    if(!checkScanIdentity(identity,error))return false;
    std::sort(next.begin(),next.end(),[](const ScanRegion&a,const ScanRegion&b){return a.address<b.address;});
    for(size_t n=1;n<next.size();++n)if(next[n].address<next[n-1].address+next[n-1].size){error="Las regiones de datos se solapan; no se escanearon.";return false;}
    if(next.empty()){error="No hay páginas de datos MAIN/HEAP con lectura y escritura disponibles.";return false;}
    regions=std::move(next);return true;
}
bool readScanMemory(const ScanIdentity&identity,uint64_t address,void*buffer,size_t size,std::string&error) {
    const auto started=scanNowNs();
    ScanAccess access(true);const bool ok=native::scan::checkedRead(identity,address,buffer,size,access,error);
    scanReadPolicy.checked(scanElapsedNs(started),ok);
    if(ok)scanReadPolicy.completed(size);else scanReadPolicy.invalidate();return ok;
}
ScanReadStats scanReadStats(){return scanReadPolicy.metrics();}
void resetScanReadSession(){scanReadPolicy.reset();}
bool hasLiveOwnership(const Game&game){
    return liveReceipt.valid&&liveReceipt.title==game.id&&liveReceipt.buildId==game.buildId&&
        (!liveReceipt.changes.empty()||liveReceipt.masterAdded);
}
bool platformInit(Environment&env,std::string&error) {
    resetScanReadSession();
    error.clear();env.applet=appletGetAppletType()!=AppletType_Application;
    svcGetProcessId(&selfPid,CUR_PROCESS_HANDLE);
    SetSysFirmwareVersion version{};Result rc=setsysInitialize();
    if(R_SUCCEEDED(rc)){rc=setsysGetFirmwareVersion(&version);setsysExit();}
    env.firmware=R_SUCCEEDED(rc)?bounded(version.display_version,sizeof(version.display_version)):"No disponible";
    env.atmosphere=hosversionIsAtmosphere()?"Atmosphere detectado":"Atmosphere no detectado";
    rc=splInitialize();if(R_SUCCEEDED(rc)){u64 ver=0;if(R_SUCCEEDED(splGetConfig(static_cast<SplConfigItem>(65000),&ver))){
        char text[64];std::snprintf(text,sizeof(text),"Atmosphere %u.%u.%u",unsigned((ver>>56)&255),unsigned((ver>>48)&255),unsigned((ver>>40)&255));env.atmosphere=text;}splExit();}
    nsReady=R_SUCCEEDED(rc=nsInitialize());if(!nsReady){error="No se pudo abrir el servicio de juegos: "+rcText(rc);return false;}
    fsldrReady=R_SUCCEEDED(fsldrInitResult=fsldrInitialize());ncmReady=R_SUCCEEDED(ncmInitialize());pmReady=R_SUCCEEDED(pmInitResult=pmdmntInitialize());ldrReady=R_SUCCEEDED(ldrInitResult=ldrDmntInitialize());
    cheatReady=R_SUCCEEDED(smGetService(&cheatService,"dmnt:cht"));runningEnvironment(env);
    env.detail=env.applet?"Álbum: permite mantener un juego abierto en segundo plano.":"Modo aplicación: instalación de cheats para el próximo inicio.";
    receiptStorageReady=native::loadLiveReceipt(liveReceipt,receiptStorageError);
    if(!receiptStorageReady)env.detail+=" No se pudo leer el recibo de activación guardado.";
    return true;
}
void platformExit() {
    resetScanReadSession();
    if(cheatReady)serviceClose(&cheatService);
    if(ldrReady)ldrDmntExit();
    if(pmReady)pmdmntExit();
    if(ncmReady)ncmExit();
    if(fsldrReady)fsldrExit();
    if(nsReady)nsExit();
    cheatReady=ldrReady=pmReady=ncmReady=fsldrReady=nsReady=false;
    liveReceipt={};
}
bool resolveBuild(Game&game,Environment&env,std::string&error) {
    error.clear();game.buildVerified=false;game.running=false;game.buildId.clear();game.fullBuildId.clear();game.detail.clear();
    if(game.id<MinUser||!nsReady){error="El juego seleccionado no es una aplicación de usuario.";return false;}
    std::vector<NsApplicationContentMetaStatus> statuses;
    if(!readStatuses(game,statuses,error))return false;
    native::Metadata metadata{};
    if(getNativeMetadata(metadata,false)) {
        env.runningTitle=metadata.title;env.runningBuild=native::buildString(metadata.build);
        if(metadata.title==game.id){game.buildId=env.runningBuild;game.fullBuildId=fullBuild(metadata.build);game.buildVerified=game.running=true;game.detail="Build ID verificado en el juego en ejecución.";return true;}
    }else runningEnvironment(env);
    // Loader module IDs can establish the running BID even if dmnt is disabled.
    std::string loaderError;
    if(loaderMetadata(metadata,&loaderError)&&metadata.title==game.id) {
        game.buildId=native::buildString(metadata.build);game.fullBuildId=fullBuild(metadata.build);game.buildVerified=game.running=true;
        env.runningTitle=metadata.title;env.runningBuild=game.buildId;game.detail="Build ID verificado por el cargador del juego abierto.";return true;
    }
    if(installedBuild(game,statuses,error))return true;
    if(!loaderError.empty())error+=" Cargador: "+loaderError+".";
    game.detail=error;return false;
}
bool detectRunningGame(Game&game,Environment&env,std::string&error) {
    game={};error.clear();native::Metadata before{};
    if(!nsReady||!loaderMetadata(before)){error="Abre un juego y vuelve al overlay para consultar sus cheats publicados.";return false;}
    Game next;next.id=before.title;next.name="Juego "+hexId(next.id);
    next.buildId=native::buildString(before.build);next.fullBuildId=fullBuild(before.build);
    next.running=next.buildVerified=true;next.detail="Build ID verificado en el juego abierto.";
    auto*control=new(std::nothrow) NsApplicationControlData{};
    if(!control){error="No hay memoria suficiente en el overlay. Consulta este juego desde la aplicación.";return false;}
    u64 actual=0;const auto rc=nsGetApplicationControlData(NsApplicationControlSource_Storage,next.id,control,sizeof(*control),&actual);
    if(R_SUCCEEDED(rc)&&actual>=sizeof(NacpStruct))applyTitleMetadata(next,&control->nacp,sizeof(control->nacp),titleLanguage());
    delete control;
    native::Metadata after{};
    if(!loaderMetadata(after)||before.pid!=after.pid||before.title!=after.title||fullBuild(before.build)!=fullBuild(after.build)){
        error="El juego cambió mientras se comprobaba su versión. Vuelve a cargar el overlay.";return false;
    }
    env.runningTitle=next.id;env.runningBuild=next.buildId;game=std::move(next);return true;
}
bool scanGames(std::vector<Game>&games,Environment&env,std::string&error) {
    games.clear();error.clear();if(!nsReady){error="El servicio de aplicaciones no está disponible.";return false;}
    runningEnvironment(env);std::set<uint64_t> seen;unsigned skipped=0,unreadableNames=0;
    const int preferredLanguage=titleLanguage();
    for(s32 offset=0;;) {
        NsApplicationRecord records[32]{};s32 count=0;Result rc=nsListApplicationRecord(records,32,offset,&count);
        if(R_FAILED(rc)||count<0||count>32||static_cast<size_t>(offset+count)>MaxRecords){games.clear();error="No se pudo enumerar la biblioteca: "+rcText(rc);return false;}
        if(!count)break;
        for(s32 i=0;i<count;++i) {
            Game game;game.id=records[i].application_id;if(game.id<MinUser||!seen.insert(game.id).second)continue;
            std::vector<NsApplicationContentMetaStatus> statuses;std::string why;
            if(!readStatuses(game,statuses,why)){++skipped;continue;}
            game.name="Juego "+hexId(game.id);auto*control=new NsApplicationControlData{};u64 actual=0;
            rc=nsGetApplicationControlData(NsApplicationControlSource_Storage,game.id,control,sizeof(*control),&actual);
            if(R_SUCCEEDED(rc)&&actual>=sizeof(NacpStruct)) {
                if(!applyTitleMetadata(game,&control->nacp,sizeof(control->nacp),preferredLanguage))++unreadableNames;
            }else ++unreadableNames;
            delete control;
            game.running=env.runningTitle==game.id;
            if(game.running){game.buildId=env.runningBuild;game.buildVerified=true;game.detail="Juego abierto: Build ID disponible.";}
            games.push_back(std::move(game));
        }offset+=count;
    }
    std::sort(games.begin(),games.end(),[](const Game&a,const Game&b){if(a.running!=b.running)return a.running;return a.name==b.name?a.id<b.id:a.name<b.name;});
    if(skipped)error=std::to_string(skipped)+" entradas sin contenido accesible omitidas.";
    if(unreadableNames){if(!error.empty())error+=" ";error+=std::to_string(unreadableNames)+" nombres no disponibles; se muestra su Title ID.";}
    return true;
}
bool inspectActive(const Game&game,unsigned&count,std::string&error) {
    count=0;error.clear();
    native::Metadata loader{};
    const bool running=game.running||(loaderMetadata(loader)&&loader.title==game.id);
    if(!cheatReady) {
        if(!running)return true;
        error="No se pueden revisar los cheats cargados: dmnt:cht no está disponible. Cierra el juego antes de continuar.";return false;
    }
    u8 present=0;Result rc=serviceDispatchOut(&cheatService,65000,present);
    if(R_FAILED(rc)) {
        if(!running)return true;
        error="No se pudo consultar el motor de cheats del juego abierto ("+rcText(rc)+"). Cierra el juego antes de continuar.";return false;
    }
    if(!present)return true;
    native::Metadata initial{};
    rc=serviceDispatchOut(&cheatService,65002,initial);
    if(R_FAILED(rc)) {
        if(!running)return true;
        error="No se pudieron verificar los cheats cargados en el juego abierto. Cierra el juego antes de continuar.";return false;
    }
    if(initial.title!=game.id||initial.pid==selfPid)return true;
    if(!initial.pid||!game.buildVerified||native::buildString(initial.build)!=game.buildId) {
        error="El juego abierto ya no coincide con el Build ID revisado. Vuelve a buscar sus cheats.";return false;
    }
    CheatRuntime runtime;std::vector<native::Entry> entries;
    if(!runtime.entries(entries)) {
        error="No se pudieron enumerar los cheats cargados. Cierra el juego antes de continuar.";return false;
    }
    std::set<uint32_t> ids;
    for(const auto&e:entries)if(e.id>=128||e.definition.count==0||e.definition.count>256||!ids.insert(e.id).second) {
        error="El inventario de cheats cargados no es válido. Cierra el juego antes de continuar.";return false;
    }
    native::Metadata after{};
    if(!getNativeMetadata(after,false)||after.pid!=initial.pid||after.title!=game.id||native::buildString(after.build)!=game.buildId) {
        error="El proceso del juego cambió durante la revisión. Vuelve a buscar sus cheats.";return false;
    }
    count=static_cast<unsigned>(entries.size());return true;
}
bool readLiveState(Pack&pack,std::string&error) {
    auto unconfirmed=[&](const std::string&reason){for(auto&c:pack.cheats)c.liveState=CheatState::Unknown;pack.liveChecked=false;pack.livePid=0;pack.liveDetail=error=reason;return false;};
    error.clear();cheatReadError=0;cheatReadStep.clear();
    if(!cheatReady)return unconfirmed("dmnt:cht no está disponible. Estado del motor sin confirmar.");
    u8 present=0;const Result rc=serviceDispatchOut(&cheatService,65000,present);
    if(R_FAILED(rc))return unconfirmed("No se pudo consultar el motor ("+rcText(rc)+"). Estado sin confirmar.");
    if(!present)return unconfirmed("El motor no está conectado a un juego. No se ha confirmado ningún cheat activo.");
    CheatRuntime runtime;
    const bool ok=native::readCheckedState(pack,runtime,error);
    if(!ok&&R_FAILED(cheatReadError)){error+=" "+cheatReadStep+": "+rcText(cheatReadError);pack.liveDetail=error;}
    if(ok&&liveReceipt.valid&&liveReceipt.title==pack.game.id&&liveReceipt.buildId==pack.game.buildId&&liveReceipt.pid!=pack.livePid)pack.liveDetail+=" El proceso es distinto al de la activación guardada.";
    return ok;
}
Outcome applyLive(const Pack&pack) {
    if(!cheatReady){Outcome out;out.message="dmnt:cht no está disponible. Instala los cheats y reinicia el juego con Atmosphere.";return out;}
    Outcome out;std::vector<Cheat> chosen;if(!selectedCheats(pack,chosen,out.message))return out;
    if(!receiptStorageReady){out.message=receiptStorageError+" No se aplicaron nuevos cheats en directo.";return out;}
    native::Metadata metadata{};
    if(pack.sessionOnly&&!checkScanIdentity(pack.sessionBinding,out.message))return out;
    if(!getNativeMetadata(metadata,false)) {
        if(pack.sessionOnly){out.message="El motor de la búsqueda ya no está conectado a la misma sesión. Vuelve a empezar; no se conectó otro proceso.";return out;}
        if(!loaderMetadata(metadata)||metadata.title!=pack.game.id||native::buildString(metadata.build)!=pack.game.buildId) {
            out.message="No hay un juego con este Title ID y Build ID en segundo plano. Abre ese juego y entra por Álbum para activar en directo.";return out;
        }
        const u64 expectedPid=metadata.pid;
        if(!preflightInstalledCheats(pack.game,out.message))return out;
        native::Metadata beforeAttach{};
        if(!loaderMetadata(beforeAttach)||beforeAttach.pid!=expectedPid||beforeAttach.title!=pack.game.id||native::buildString(beforeAttach.build)!=pack.game.buildId||
           (!pack.game.fullBuildId.empty()&&fullBuild(beforeAttach.build)!=pack.game.fullBuildId)){
            out.message="El juego cambió mientras se revisaban los cheats de la SD. No se conectó el motor; vuelve a comprobar el juego.";return out;
        }
        // Explicit activation is allowed to attach dmnt, like scan start.
        // Its attach operation also loads that game's current SD cheat file.
        if(!getNativeMetadata(metadata,true)||metadata.pid!=expectedPid||metadata.title!=pack.game.id||native::buildString(metadata.build)!=pack.game.buildId) {
            out.message="No se pudo conectar el motor al proceso verificado. Reinicia el juego antes de volver a intentar la activación.";return out;
        }
    }
    if(pack.sessionOnly)for(const auto&cheat:chosen){
        if(cheat.master||cheat.opcodes.empty()||((cheat.opcodes[0]>>20)&15)!=2)continue;
        uint64_t address=0;size_t size=0;
        if(!native::scan::aliasStaticAddress(pack.sessionBinding,cheat.opcodes.data(),cheat.opcodes.size(),address,size)){out.message="El código Alias de la prueba no es una escritura estática válida de esta sesión.";return out;}
        ScanAccess access;
        if(!native::scan::checkedAliasTarget(pack.sessionBinding,address,size,access,out.message))return out;
    }
    CheatRuntime runtime;out=native::applyChecked(pack,runtime,&liveReceipt);
    if(out.ok) {
        std::string error;
        const bool saved=liveReceipt.valid&&(liveReceipt.masterAdded||!liveReceipt.changes.empty())?native::saveLiveReceipt(liveReceipt,error):native::clearLiveReceipt(error);
        if(!saved){out.ok=false;out.message="Los cheats están activados, pero no se pudo guardar el recibo para retirarlos al reabrir la aplicación. "+error+" Retíralos ahora sin salir del NRO o cierra y abre el juego.";}
    }
    return out;
}
Outcome removeLive(const Game&game) {
    if(!cheatReady){Outcome out;out.message="dmnt:cht no está disponible. Cierra y abre el juego para detener sus cheats.";return out;}
    if(!receiptStorageReady){Outcome out;out.message=receiptStorageError+" Cierra y abre el juego para detener los cheats.";return out;}
    CheatRuntime runtime;auto out=native::undoChecked(game,runtime,liveReceipt);
    std::string error;
    const bool saved=liveReceipt.valid?native::saveLiveReceipt(liveReceipt,error):native::clearLiveReceipt(error);
    if(!saved){out.ok=false;out.liveEffect=out.liveEffect==LiveEffect::NoOwned?LiveEffect::Unchanged:LiveEffect::Uncertain;out.message+=" No se pudo actualizar el recibo guardado: "+error+" Cierra y abre el juego.";}
    return out;
}
}

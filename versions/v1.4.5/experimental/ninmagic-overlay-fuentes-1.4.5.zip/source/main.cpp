#include <switch.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include "catalog.hpp"
#include "cheats.hpp"
#include "cheat_review.hpp"
#include "diagnostics.hpp"
#include "gameplay.hpp"
#include "platform.hpp"
#include "published_cache.hpp"
#include "ui.hpp"

namespace {
enum class Kind { Init, Scan, Search, Sync, Prepare, Apply, Remove, Refresh, CheckAppUpdate, PrepareAppUpdate, InstallAppUpdate };
struct Job {
    Kind kind=Kind::Init;Thread thread{};bool active=false,ok=false;
    std::atomic<bool> done{false};
    nc::Environment env;nc::Catalog catalog;std::vector<nc::Game> games;
    nc::Game game;nc::Pack pack;nc::Outcome outcome;nc::ExistingContent existing;
    std::string error;
    nc::AppUpdateInfo appUpdate;
    std::string appUpdateDetail,recoveryError,overlayCacheError;
} job;
constexpr const char *AppPath="sdmc:/switch/ninmagic-cheats/ninmagic-cheats.nro";
// A failed recheck must never bind the old codes to a new build.
bool sameBuild(nc::Game &game,std::string &error) {
    nc::Game current=game;
    if(!nc::resolveBuild(current,job.env,error)||!current.buildVerified||current.buildId!=game.buildId||(!game.fullBuildId.empty()&&current.fullBuildId!=game.fullBuildId)) {
        error="El Build ID cambió o no se pudo comprobar. Vuelve a buscar cheats para este juego. "+error;
        for(auto &c:job.pack.cheats)c.liveState=nc::CheatState::Unknown;
        job.pack.liveChecked=false;job.pack.livePid=0;job.pack.liveDetail=error;return false;
    }
    game=std::move(current);return true;
}
void readState(const char *event) {
    std::string detail;nc::readLiveState(job.pack,detail);
    nc::logCheatDiagnostic(event,job.pack,detail);
}
void recordUpdate(bool checked,const std::string&error){
    nc::Pack report;report.game.name="NinMagic: consulta de actualización";report.game.version=job.appUpdate.version;
    report.lookupState=checked?nc::LookupState::Complete:nc::LookupState::Incomplete;
    report.detail="Canal configurado="+std::to_string(job.appUpdate.configured)+" actualización disponible="+std::to_string(job.appUpdate.available)+". "+job.appUpdate.detail;
    nc::logCheatDiagnostic("comprobar-actualizacion",report,error);
}
std::string sourceSummary(const std::vector<nc::CheatSourceReport>&reports){
    std::string result;
    for(const auto&r:reports){if(!result.empty())result+=" · ";result+=r.source+": "+(r.found?(r.cached?"guardados":"disponibles"):r.checked?"sin opciones compatibles":r.cached?"consulta guardada":"sin comprobar");}
    return result;
}
void preparePublishedOverlay(bool queryComplete){
    job.overlayCacheError.clear();
    if(!job.pack.game.buildVerified||job.pack.game.fullBuildId.size()!=64)return;
    // A failed provider lookup must not replace a prepared list with an empty
    // result. Valid exact-build codes can still be shared after a partial query.
    if(job.pack.cheats.empty()&&!queryComplete)return;
    if(!nc::savePublishedCache(job.pack,job.overlayCacheError))job.pack.detail+=" Overlay: "+job.overlayCacheError;
}
void work(void *) {
    job.outcome={};
    switch(job.kind) {
    case Kind::Init: {
        job.ok=nc::platformInit(job.env,job.error);
        if(job.ok)job.ok=nc::scanGames(job.games,job.env,job.error);
        std::string cacheError;nc::loadCatalog(job.catalog,cacheError);
        std::string updateError;
        job.env.network=nc::refreshCatalog(job.catalog,false,updateError);
        if(!job.env.network)job.catalog.detail+=" · Sin actualización: "+updateError;
        if(!job.recoveryError.empty())job.appUpdateDetail=job.recoveryError;
        else {const bool checked=nc::checkAppUpdate(job.appUpdate,updateError);if(!checked)job.appUpdateDetail=updateError;recordUpdate(checked,updateError);}
        break;
    }
    case Kind::Scan:job.ok=nc::scanGames(job.games,job.env,job.error);break;
    case Kind::Search: {
        const bool verified=nc::resolveBuild(job.game,job.env,job.error);
        std::vector<nc::CheatSourceReport> reports;std::string sourceError;
        const bool providersComplete=verified&&nc::refreshGameSources(job.game,false,reports,sourceError);
        const bool queryComplete=providersComplete&&job.catalog.generalReady&&job.env.network;
        nc::logSourceReports(job.game,reports,verified?sourceError:job.error);
        job.pack=nc::findCheats(job.game,job.catalog);nc::gameplayOnly(job.pack);
        job.pack.lookupState=!verified?nc::LookupState::NotChecked:queryComplete?nc::LookupState::Complete:nc::LookupState::Incomplete;
        job.pack.cachedLookup=!job.pack.cheats.empty()&&(!queryComplete||std::any_of(reports.begin(),reports.end(),[](const auto&r){return r.found&&r.cached&&!r.checked;}));
        if(!job.error.empty())job.pack.detail=job.error+" "+job.pack.detail;
        if(!reports.empty())job.pack.detail+=" "+sourceSummary(reports);
        if(!sourceError.empty())job.pack.detail+=" "+sourceError+" Se conserva la información guardada de las fuentes que no respondieron.";
        preparePublishedOverlay(queryComplete);readState("buscar");job.ok=true;break;
    }
    case Kind::Sync: {
        job.ok=nc::syncCatalog(job.catalog,job.error);job.env.network=job.ok;
        std::vector<nc::CheatSourceReport> reports;std::string sourceError,buildError;
        if(job.game.id&&nc::resolveBuild(job.game,job.env,buildError)){
            const bool providersComplete=nc::refreshGameSources(job.game,true,reports,sourceError);
            const bool queryComplete=providersComplete&&job.catalog.generalReady&&job.ok;
            job.pack=nc::findCheats(job.game,job.catalog);nc::gameplayOnly(job.pack);
            job.pack.lookupState=queryComplete?nc::LookupState::Complete:nc::LookupState::Incomplete;
            job.pack.cachedLookup=!job.pack.cheats.empty()&&(!queryComplete||std::any_of(reports.begin(),reports.end(),[](const auto&r){return r.found&&r.cached&&!r.checked;}));
            preparePublishedOverlay(queryComplete);
        }
        if(job.game.id)nc::logSourceReports(job.game,reports,buildError.empty()?sourceError:buildError);
        job.outcome.ok=job.ok;
        job.outcome.message=job.ok?"Catálogo actualizado. "+std::to_string(job.catalog.entries.size())+" archivos de versiones disponibles. Los nuevos cheats aparecerán al seleccionar el juego.":job.error+" Se conserva el catálogo anterior.";
        if(!reports.empty())job.outcome.message+=" "+sourceSummary(reports);
        if(!sourceError.empty())job.outcome.message+=" Algunas fuentes no respondieron; se conservan sus códigos guardados.";
        if(!buildError.empty())job.outcome.message+=" Versión del juego sin comprobar: "+buildError;
        if(!job.overlayCacheError.empty())job.outcome.message+=" No se pudo preparar la lista del overlay: "+job.overlayCacheError;
        break;
    }
    case Kind::Prepare: {
        job.ok=sameBuild(job.pack.game,job.error);
        std::vector<nc::Cheat> chosen;
        if(job.ok)job.ok=nc::selectedCheats(job.pack,chosen,job.error);
        bool exists=false;
        if(job.ok)job.ok=nc::inspectInstalledCheats(job.pack.game,exists,job.error);
        job.existing={};job.existing.game=job.pack.game;job.existing.exists=job.existing.cheats=exists;
        if(job.ok)job.ok=nc::inspectActive(job.pack.game,job.existing.activeCheats,job.error);
        job.pack.liveHydrated=true;readState("revisar");break;
    }
    case Kind::Apply: {
        const bool approvedRunning=job.pack.game.running;
        if(!sameBuild(job.pack.game,job.error)){job.outcome.message=job.error;break;}
        if(job.pack.game.running!=approvedRunning){job.outcome.message="El juego se abrió o cerró después de confirmar. Vuelve a revisar la selección.";break;}
        bool exists=false;unsigned active=0;
        if(!nc::inspectInstalledCheats(job.pack.game,exists,job.error)||!nc::inspectActive(job.pack.game,active,job.error)){job.outcome.message=job.error;break;}
        if(exists!=job.existing.exists||active!=job.existing.activeCheats){job.outcome.message="Los cheats anteriores cambiaron después de revisarlos. Vuelve a pulsar Y y confirma de nuevo.";break;}
        job.outcome=job.pack.game.running?nc::applyLive(job.pack):nc::installPack(job.pack);
        job.ok=job.outcome.ok;job.pack.liveHydrated=true;readState("aplicar");
        nc::logCheatDiagnostic("resultado-aplicar",job.pack,job.outcome.message);break;
    }
    case Kind::Remove: {
        const bool approvedRunning=job.pack.game.running;
        if(!sameBuild(job.pack.game,job.error)){job.outcome.message=job.error;break;}
        if(job.pack.game.running!=approvedRunning){job.outcome.message="El juego se abrió o cerró después de confirmar. Vuelve a revisar la retirada.";break;}
        if(job.pack.game.running)job.outcome=nc::removeLive(job.pack.game);
        else {
            job.outcome=nc::restorePack(job.pack.game);
            if(job.outcome.ok) {
                if(!job.outcome.previousContent.empty()||!job.outcome.previousPatches.empty()) {
                    job.outcome.ok=false;
                    job.outcome.message+=" La copia antigua incluye archivos externos de la versión con mods. Su recuperación queda pendiente; conserva la copia indicada y usa aquella versión para completar la recuperación.";
                } else if(!nc::finishPackRecovery(job.pack.game,job.outcome.transactionId,job.error)) {
                    job.outcome.ok=false;job.outcome.message+=" "+job.error;
                }
            }
        }
        job.ok=job.outcome.ok;job.pack.liveHydrated=true;readState("retirar");
        nc::logCheatDiagnostic("resultado-retirar",job.pack,job.outcome.message);break;
    }
    case Kind::Refresh:
        job.pack.liveHydrated=true;job.ok=sameBuild(job.pack.game,job.error);
        if(job.ok)job.ok=nc::readLiveState(job.pack,job.error);
        else {for(auto &c:job.pack.cheats)c.liveState=nc::CheatState::Unknown;job.pack.liveChecked=false;job.pack.liveDetail=job.error;}
        nc::logCheatDiagnostic("leer-estado",job.pack,job.error);break;
    case Kind::CheckAppUpdate:
        job.ok=nc::checkAppUpdate(job.appUpdate,job.error);job.appUpdateDetail=job.ok?"":job.error;recordUpdate(job.ok,job.error);break;
    case Kind::PrepareAppUpdate:
        job.ok=nc::prepareAppUpdate(job.appUpdate,AppPath,job.error);
        if(!job.ok)job.appUpdateDetail=job.error;
        break;
    case Kind::InstallAppUpdate:
        job.ok=nc::installPreparedAppUpdate(job.appUpdate,AppPath,job.error);
        job.outcome.ok=job.ok;job.outcome.message=job.ok?"Nueva versión instalada y verificada. Cierra NinMagic y vuelve a abrirla. Se conserva una copia de la versión anterior.":job.error;break;
    }
    job.done.store(true,std::memory_order_release);
}
bool start(Kind kind,nc::View &v) {
    job.kind=kind;job.env=v.env;job.catalog=v.catalog;job.error.clear();job.ok=false;job.done.store(false);
    job.appUpdate=v.appUpdate;job.appUpdateDetail.clear();job.overlayCacheError.clear();
    if(kind==Kind::Sync)job.game=v.games.empty()?nc::Game{}:v.games[std::clamp(v.selected,0,int(v.games.size())-1)];
    Result rc=threadCreate(&job.thread,work,nullptr,nullptr,512*1024,0x2c,-2);
    if(R_SUCCEEDED(rc)){rc=threadStart(&job.thread);if(R_FAILED(rc))threadClose(&job.thread);}
    if(R_FAILED(rc)){v.outcome={};v.outcome.message="No se pudo iniciar la operación.";v.screen=nc::Screen::Result;return false;}
    job.active=true;appletSetAutoSleepDisabled(true);return true;
}
std::vector<size_t> visible(const nc::View &v) {
    std::vector<size_t> out;for(size_t i=0;i<v.pack.cheats.size();++i)if(!v.pack.cheats[i].master)out.push_back(i);return out;
}
}
int main(int,char**) {
    nc::recoverAppUpdate(AppPath,job.recoveryError);
    const Result rom=romfsInit();
    bool romMounted=R_SUCCEEDED(rom);
    if(R_FAILED(rom)||!nc::uiInit("romfs:")) {
        consoleInit(nullptr);std::printf("ninmagic-cheats: faltan recursos. Copia el NRO completo.\nPulsa + para salir.\n");
        PadState p;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&p);
        while(appletMainLoop()){padUpdate(&p);if(padGetButtonsDown(&p)&HidNpadButton_Plus)break;consoleUpdate(nullptr);}
        consoleExit(nullptr);if(R_SUCCEEDED(rom))romfsExit();return 1;
    }
    Framebuffer fb{};Result rc=framebufferCreate(&fb,nwindowGetDefault(),1280,720,PIXEL_FORMAT_RGBA_8888,2);
    if(R_FAILED(rc)){nc::uiExit();romfsExit();return 1;}
    if(R_FAILED(framebufferMakeLinear(&fb))){framebufferClose(&fb);nc::uiExit();romfsExit();return 1;}
    PadState pad;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&pad);
    nc::View view;view.status="Detectando juegos y actualizando el catálogo por Internet...";
    start(Kind::Init,view);bool quit=false;uint64_t repeatStart=0,lastRepeat=0,lastDirection=0;
    while(appletMainLoop()&&!quit) {
        padUpdate(&pad);const auto down=padGetButtonsDown(&pad),held=padGetButtons(&pad);
        const uint64_t now=armTicksToNs(armGetSystemTick());
        if(job.active&&job.done.load(std::memory_order_acquire)) {
            threadWaitForExit(&job.thread);threadClose(&job.thread);job.active=false;appletSetAutoSleepDisabled(false);
            view.env=job.env;view.catalog=job.catalog;
            view.appUpdate=job.appUpdate;view.appUpdateDetail=job.appUpdateDetail;
            if(job.kind==Kind::Init||job.kind==Kind::Scan) {
                view.games=std::move(job.games);view.selected=std::clamp(view.selected,0,std::max(0,int(view.games.size())-1));
                if(job.ok){view.screen=nc::Screen::Library;view.status=view.catalog.entries.empty()?"Y actualiza el catálogo de cheats publicados.":job.kind==Kind::Init?(job.env.network?"Catálogo comprobado. Elige un juego para ver sus cheats publicados.":"Catálogo guardado disponible; Y vuelve a comprobar las fuentes."):"Biblioteca actualizada. Elige un juego para ver sus cheats.";}
                else {view.returnScreen=0;view.outcome={};view.outcome.message=job.error;view.screen=nc::Screen::Result;}
            } else if(job.kind==Kind::Search) {
                view.pack=std::move(job.pack);view.filter=0;view.cheatSelected=0;view.restore=false;view.screen=nc::Screen::Cheats;
                if(!view.games.empty())view.games[view.selected]=view.pack.game;
            } else if(job.kind==Kind::Prepare) {
                view.pack=std::move(job.pack);view.existing=job.existing;view.liveRequested=view.pack.game.running;
                if(job.ok)view.screen=nc::Screen::Confirm;
                else {view.outcome={};view.outcome.message=job.error;view.screen=nc::Screen::Result;view.returnScreen=1;}
            } else if(job.kind==Kind::Refresh) {
                view.pack=std::move(job.pack);view.screen=nc::Screen::Cheats;
            } else if(job.kind==Kind::CheckAppUpdate) {
                view.screen=nc::Screen::AppUpdate;
            } else if(job.kind==Kind::PrepareAppUpdate) {
                if(!job.ok)view.screen=nc::Screen::AppUpdate;
                else {
                    if(romMounted){romfsExit();romMounted=false;}
                    view.screen=nc::Screen::Busy;view.status="Instalando la descarga verificada y conservando el NRO anterior...";start(Kind::InstallAppUpdate,view);
                }
            } else if(job.kind==Kind::InstallAppUpdate) {
                view.outcome=std::move(job.outcome);view.returnScreen=4;view.screen=nc::Screen::Result;
            } else {
                if(job.kind==Kind::Apply||job.kind==Kind::Remove)view.pack=std::move(job.pack);
                view.outcome=std::move(job.outcome);view.screen=nc::Screen::Result;view.returnScreen=job.kind==Kind::Sync?0:1;
            }
        }
        if(!job.active) {
            using nc::Screen;
            const uint64_t up=HidNpadButton_Up|HidNpadButton_StickLUp,downKey=HidNpadButton_Down|HidNpadButton_StickLDown;
            const uint64_t direction=(held&up)?up:(held&downKey)?downKey:0;
            bool move=(down&(up|downKey))!=0;
            if(direction!=lastDirection){repeatStart=now;lastRepeat=now;lastDirection=direction;}
            if(direction&&now-repeatStart>350000000ULL&&now-lastRepeat>85000000ULL){move=true;lastRepeat=now;}
            const int delta=(held&up)?-1:1;
            if(down&HidNpadButton_Plus)quit=true;
            else if(view.screen==Screen::Library) {
                if(move&&!view.games.empty())view.selected=(view.selected+delta+int(view.games.size()))%int(view.games.size());
                if(down&HidNpadButton_Minus)view.screen=Screen::Help;
                else if(down&HidNpadButton_L){view.restore=false;view.screen=Screen::Busy;view.status="Buscando una versión nueva de NinMagic...";start(Kind::CheckAppUpdate,view);}
                else if(down&HidNpadButton_Y){view.restore=false;view.screen=Screen::Busy;view.status="Buscando publicaciones nuevas y comprobando el catálogo...";start(Kind::Sync,view);}
                else if(down&HidNpadButton_X){view.screen=Screen::Loading;view.status="Actualizando los juegos instalados...";start(Kind::Scan,view);}
                else if((down&HidNpadButton_A)&&!view.games.empty()){
                    job.game=view.games[view.selected];view.screen=Screen::Loading;view.status="Comprobando el Build ID y buscando cheats de jugabilidad...";start(Kind::Search,view);
                }
            } else if(view.screen==Screen::Cheats) {
                const auto rows=visible(view);
                if(move&&!rows.empty())view.cheatSelected=(view.cheatSelected+delta+int(rows.size()))%int(rows.size());
                if(down&HidNpadButton_B)view.screen=Screen::Library;
                else if(down&HidNpadButton_X){job.pack=view.pack;view.screen=Screen::Busy;view.status="Leyendo el estado real del motor, sin cambiar la selección...";start(Kind::Refresh,view);}
                else if(down&HidNpadButton_L){view.restore=true;view.liveRequested=view.pack.game.running;view.screen=Screen::Confirm;}
                else if((down&HidNpadButton_Y)&&nc::selectedCount(view.pack)) {
                    view.restore=false;job.pack=view.pack;view.screen=Screen::Busy;view.status="Comprobando la versión y los cheats anteriores...";start(Kind::Prepare,view);
                } else if((down&HidNpadButton_A)&&!rows.empty()) {
                    auto &c=view.pack.cheats[rows[view.cheatSelected]];const auto reason=nc::blockedCheatReason(view.pack.game,c);
                    if(!c.selected&&!reason.empty()){view.outcome={};view.outcome.message=reason;view.returnScreen=1;view.screen=Screen::Result;}
                    else c.selected=!c.selected;
                }
            } else if(view.screen==Screen::Confirm) {
                if(down&HidNpadButton_B)view.screen=Screen::Cheats;
                else if(down&HidNpadButton_A){
                    job.pack=view.pack;job.existing=view.existing;view.screen=Screen::Busy;
                    view.status=view.restore?"Retirando los cheats de NinMagic...":"Aplicando la selección al juego comprobado...";
                    start(view.restore?Kind::Remove:Kind::Apply,view);
                }
            } else if(view.screen==Screen::Result) {
                if(down&(HidNpadButton_A|HidNpadButton_B))view.screen=view.returnScreen==4?Screen::AppUpdate:view.returnScreen==1?Screen::Cheats:Screen::Library;
            } else if(view.screen==Screen::AppUpdate) {
                if(down&HidNpadButton_B)view.screen=Screen::Library;
                else if(down&HidNpadButton_X){if(view.appUpdate.installed)view.appUpdateDetail="Cierra y vuelve a abrir NinMagic para ejecutar la versión nueva antes de volver a comprobar.";else {view.screen=Screen::Busy;view.status="Comprobando el canal de actualizaciones de NinMagic...";start(Kind::CheckAppUpdate,view);}}
                else if((down&HidNpadButton_A)&&view.appUpdate.configured&&view.appUpdate.available&&!view.appUpdate.installed){view.restore=false;view.screen=Screen::Busy;view.status="Descargando y verificando el NRO antes de sustituir la aplicación...";start(Kind::PrepareAppUpdate,view);}
            } else if(view.screen==Screen::Help) {
                if(down&(HidNpadButton_B|HidNpadButton_A|HidNpadButton_Minus))view.screen=Screen::Library;
            }
        }
        u32 stride=0;auto *pixels=static_cast<uint32_t*>(framebufferBegin(&fb,&stride));nc::uiDraw(pixels,int(stride/4),view);framebufferEnd(&fb);++view.frame;
    }
    if(job.active){threadWaitForExit(&job.thread);threadClose(&job.thread);}
    std::string exitDetail;nc::readLiveState(view.pack,exitDetail);nc::logCheatDiagnostic("salir",view.pack,exitDetail);
    appletSetAutoSleepDisabled(false);nc::catalogExit();nc::platformExit();nc::uiExit();framebufferClose(&fb);if(romMounted)romfsExit();return 0;
}

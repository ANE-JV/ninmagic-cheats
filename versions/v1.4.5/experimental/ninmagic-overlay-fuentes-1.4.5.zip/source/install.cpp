#include "cheats.hpp"
#include "cheat_review.hpp"
#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <map>
#include <set>
#include <sstream>
#include <string_view>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
#ifdef NC_INSTALL_TEST
std::string installTestRoot();
#endif
namespace {
constexpr size_t MaxFile=2*1024*1024;
std::string sdRoot() {
#ifdef NC_INSTALL_TEST
    return installTestRoot();
#else
    return "sdmc:";
#endif
}
bool regular(const std::string &p,bool &exists,std::string &error) {
    struct stat s{};exists=false;
    if(lstat(p.c_str(),&s)!=0){if(errno==ENOENT)return true;error="No se pudo revisar el archivo: "+p;return false;}
    exists=true;if(S_ISLNK(s.st_mode)||!S_ISREG(s.st_mode)||s.st_size<0||uint64_t(s.st_size)>MaxFile){error="Archivo no admitido: "+p;return false;}return true;
}
bool directory(const std::string &p,std::string &error,bool create=true) {
    struct stat s{};
    if(lstat(p.c_str(),&s)!=0) {
        if(errno!=ENOENT||!create||mkdir(p.c_str(),0777)!=0){error="No se pudo abrir la carpeta: "+p;return false;}
        if(lstat(p.c_str(),&s)!=0){error="No se pudo comprobar la carpeta creada.";return false;}
    }
    if(S_ISLNK(s.st_mode)||!S_ISDIR(s.st_mode)){error="La ruta no es una carpeta segura: "+p;return false;}return true;
}
bool folders(const std::string &relative,std::string &error,bool create=true) {
    std::string p=sdRoot();size_t start=0;
    while(start<relative.size()) {
        const auto end=relative.find('/',start);const auto part=relative.substr(start,end==std::string::npos?end:end-start);
        if(part.empty()||part=="."||part==".."||part.find(':')!=std::string::npos){error="Ruta inválida.";return false;}
        p+="/"+part;if(!directory(p,error,create))return false;
        if(end==std::string::npos)break;
        start=end+1;
    }
    return true;
}
bool read(const std::string &p,std::string &data,bool &exists,std::string &error,size_t limit=MaxFile) {
    data.clear();if(!regular(p,exists,error))return false;if(!exists)return true;
    FILE *f=std::fopen(p.c_str(),"rb");if(!f){error="No se pudo leer: "+p;return false;}
    char buf[16384];size_t n=0;bool ok=true;
    while((n=std::fread(buf,1,sizeof(buf),f))) {if(data.size()+n>limit){ok=false;break;}data.append(buf,n);}
    if(std::ferror(f))ok=false;
    if(std::fclose(f)!=0)ok=false;
    if(!ok){error="Lectura incompleta: "+p;return false;}return true;
}
bool writeNew(const std::string &p,const std::string &data,std::string &error) {
    int fd=open(p.c_str(),O_WRONLY|O_CREAT|O_EXCL,0666);
    if(fd<0){error="No se pudo crear: "+p;return false;}
    size_t n=0;bool ok=true;
    while(n<data.size()) {const auto count=::write(fd,data.data()+n,data.size()-n);if(count<=0){ok=false;break;}n+=size_t(count);}
    if(ok&&fsync(fd)!=0)ok=false;
    if(close(fd)!=0)ok=false;
    if(!ok){error="No se pudo guardar por completo: "+p;return false;}
    std::string saved;bool exists=false;return read(p,saved,exists,error)&&exists&&saved==data;
}
bool replace(const std::string &p,const std::string &data,const std::string &token,std::string &error) {
    std::string temp,old;unsigned attempt=0;
    for(;attempt<10000;++attempt) {
        const auto base=p+".ninmagic-"+token+"-"+std::to_string(attempt);temp=base+".new";old=base+".old";
        struct stat st{};if(lstat(temp.c_str(),&st)!=0&&errno==ENOENT&&lstat(old.c_str(),&st)!=0&&errno==ENOENT)break;
    }
    if(attempt==10000){error="Demasiados archivos temporales pendientes de revisión.";return false;}
    bool exists=false;if(!regular(p,exists,error)||!writeNew(temp,data,error))return false;
    if(exists&&std::rename(p.c_str(),old.c_str())!=0){error="No se pudo apartar el archivo anterior.";return false;}
    if(std::rename(temp.c_str(),p.c_str())!=0) {
        if(exists)std::rename(old.c_str(),p.c_str());
        error="No se pudo activar el nuevo archivo; conserva la copia de seguridad.";return false;
    }
    if(exists)std::remove(old.c_str());
    return true;
}
bool restoreOne(const std::string &target,const std::string &old,bool existed,const std::string &token,std::string &error) {
    if(existed)return replace(target,old,token,error);
    bool now=false;if(!regular(target,now,error))return false;
    if(now&&std::remove(target.c_str())!=0){error="No se pudo retirar el archivo creado por NinMagic.";return false;}return true;
}
bool validateGame(const Game &g,std::string &error) {
    if(!g.buildVerified||g.id<0x0100000000010000ULL||!validBuild(g.buildId)){error="Primero verifica el Build ID exacto del juego.";return false;}return true;
}
std::string upper(std::string s){for(char &c:s)if(c>='a'&&c<='f')c-=32;return s;}
std::string cheatRelative(const Game &g){return "atmosphere/contents/"+hexId(g.id)+"/cheats";}
std::string backupRelative(const Game &g){return "config/NinMagicCheats/backups/"+hexId(g.id)+"/"+upper(g.buildId);}
std::string serial(unsigned n){char s[9];std::snprintf(s,sizeof(s),"%08u",n);return s;}
bool serialValid(const std::string &s) {return s.size()==8&&std::all_of(s.begin(),s.end(),[](unsigned char c){return c>='0'&&c<='9';});}
uint32_t crc(const std::string &s) {
    uint32_t value=0xffffffff;
    for(unsigned char c:s){value^=c;for(unsigned n=0;n<8;++n)value=(value>>1)^(0xedb88320u&uint32_t(-int32_t(value&1)));}return ~value;
}
std::string linkedBackups(const Game &game,const std::string &content,const std::string &patches) {
    const auto body="NMR1\n"+hexId(game.id)+"\n"+upper(game.buildId)+"\n"+(content.empty()?"-":content)+"\n"+(patches.empty()?"-":patches)+"\n";
    char sum[10];std::snprintf(sum,sizeof(sum),"%08X",crc(body));return body+sum+"\n";
}
bool parseLinks(const Game &game,const std::string &data,std::string &content,std::string &patches) {
    std::istringstream in(data);std::string magic,tid,bid,a,b,sum,extra;
    if(!std::getline(in,magic)||!std::getline(in,tid)||!std::getline(in,bid)||!std::getline(in,a)||!std::getline(in,b)||!std::getline(in,sum)||std::getline(in,extra))return false;
    if(magic!="NMR1"||tid!=hexId(game.id)||bid!=upper(game.buildId)||(a!="-"&&!serialValid(a))||(b!="-"&&!serialValid(b)))return false;
    content=a=="-"?"":a;patches=b=="-"?"":b;
    return data==linkedBackups(game,content,patches);
}
bool togglesText(const std::vector<Cheat> &selected,const std::string &old,std::string &result) {
    // Keep unrelated Build IDs' states and normalize the documented toggle
    // grammar, so an old malformed line cannot silently disable the selection.
    std::map<std::string,bool> states;size_t i=0;
    while(i<old.size()) {
        while(i<old.size()&&std::isspace(static_cast<unsigned char>(old[i])))++i;
        if(i==old.size())break;
        if(old[i]!='[')return false;
        const auto close=old.find(']',++i);if(close==std::string::npos||close==i||close-i>63)return false;
        const auto name=old.substr(i,close-i);for(unsigned char c:name)if(c<32||c==127||c=='['||c=='{'||c=='}')return false;
        i=close+1;while(i<old.size()&&std::isspace(static_cast<unsigned char>(old[i])))++i;
        const auto start=i;while(i<old.size()&&!std::isspace(static_cast<unsigned char>(old[i])))++i;
        auto state=old.substr(start,i-start);for(char &c:state)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if(state=="true"||state=="on"||state=="1")states[name]=true;
        else if(state=="false"||state=="off"||state=="0")states[name]=false;
        else return false;
    }
    for(const auto &c:selected)if(!c.master)states[c.name]=true;
    result.clear();for(const auto &s:states)result+="["+s.first+"]\n"+(s.second?"true\n":"false\n");
    return true;
}
}

bool inspectInstalledCheats(const Game &game,bool &exists,std::string &error) {
    exists=false;error.clear();
    if(!validateGame(game,error))return false;
    std::string path=sdRoot();
    for(const auto &part:std::vector<std::string>{"", "atmosphere", "contents",hexId(game.id),"cheats"}) {
        if(!part.empty())path+="/"+part;
        struct stat info{};
        const auto checked=part.empty()?path+"/":path;
        if(lstat(checked.c_str(),&info)!=0) {
            if(errno==ENOENT)return true;
            error="No se pudo comprobar la carpeta de cheats instalada.";return false;
        }
        if(S_ISLNK(info.st_mode)||!S_ISDIR(info.st_mode)){error="Una carpeta de cheats contiene un enlace o no es una carpeta regular.";return false;}
    }
    if(!regular(path+"/"+upper(game.buildId)+".txt",exists,error)){exists=false;return false;}
    return true;
}

bool preflightInstalledCheats(const Game &game,std::string &error) {
    error.clear();bool exists=false;
    if(!validateGame(game,error)||!directory(sdRoot(),error,false))return false;
    if(!inspectInstalledCheats(game,exists,error))return false;
    if(!exists)return true;
    const auto path=sdRoot()+"/"+cheatRelative(game)+"/"+upper(game.buildId)+".txt";
    // Atmosphere's file loader is bounded to64KiB. Never allocate the generic
    // install reader's2MiB limit inside the4MiB overlay, including file growth.
    std::string text;if(!read(path,text,exists,error,65535))return false;
    if(!exists)return true;
    const auto fail=[&](const std::string &reason){error="No se conectó el motor: "+reason+" Revisa o retira antes el archivo de cheats instalado para este Build ID; no se borró ningún archivo.";return false;};
    if(text.find('\0')!=std::string::npos)return fail("el archivo SD contiene datos binarios.");
    const auto trim=[](std::string_view s){const auto a=s.find_first_not_of(" \t\r\n");return a==s.npos?std::string_view{}:s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);};
    Cheat current;bool header=false;
    const auto finish=[&](){
        if(!header||current.opcodes.empty())return true;
        const auto reason=blockedCheatReason(game,current);
        return reason.empty()||fail("el archivo SD incluye un código en revisión. "+reason);
    };
    // Per-section parsing avoids std::istringstream and retains only one
    // <=256-word definition. Names and toggles cannot bypass a fingerprint.
    size_t at=text.compare(0,3,"\xef\xbb\xbf")==0?3:0;
    while(at<text.size()) {
        const auto end=text.find('\n',at);const auto n=(end==std::string::npos?text.size():end)-at;
        auto line=trim(std::string_view(text.data()+at,n));at=end==std::string::npos?text.size():end+1;
        if(line.empty()||line[0]=='#'||line[0]==';'||line.substr(0,2)=="//")continue;
        if(line[0]=='['||line[0]=='{') {
            const auto closing=line[0]=='['?']':'}';
            if(line.size()<3||line.back()!=closing)return fail("no se pudo interpretar una cabecera del archivo SD.");
            if(!finish())return false;
            current={};current.master=closing=='}';header=true;
            const auto name=trim(line.substr(1,line.size()-2));
            if(name.empty()||name.find_first_of("[]{}")!=name.npos||std::any_of(name.begin(),name.end(),[](unsigned char c){return c<32||c==127;}))return fail("hay una cabecera inválida en el archivo SD.");
            current.name.assign(name.substr(0,63));continue;
        }
        if(!header)return fail("hay instrucciones sin cabecera en el archivo SD.");
        while(!line.empty()) {
            const auto endWord=line.find_first_of(" \t\r");const auto token=line.substr(0,endWord);
            if(token[0]=='#'||token[0]==';'||token.substr(0,2)=="//")break;
            if(token.size()!=8||!std::all_of(token.begin(),token.end(),[](unsigned char c){return std::isxdigit(c)!=0;}))return fail("hay instrucciones ilegibles en el archivo SD.");
            uint32_t word=0;for(unsigned char c:token)word=(word<<4)|(c<='9'?c-'0':std::toupper(c)-'A'+10);
            current.opcodes.push_back(word);if(current.opcodes.size()>256)return fail("una definición SD supera el límite del motor.");
            line=endWord==line.npos?std::string_view{}:trim(line.substr(endWord));
        }
    }
    if(!finish())return false;
    // Recheck the ancestry immediately before the caller's process recheck.
    return inspectInstalledCheats(game,exists,error);
}

Outcome installPack(const Pack &pack,const std::string &previousContent,const std::string &previousPatches) {
    if(pack.sessionOnly){Outcome out;out.message="Las pruebas del creador pertenecen a una sesión concreta. No se guardan como cheats para otro inicio del juego.";return out;}
    Outcome out;std::string error;
    if((!previousContent.empty()&&!serialValid(previousContent))||(!previousPatches.empty()&&!serialValid(previousPatches))){out.message="Referencia de copia anterior inválida.";return out;}
    std::vector<Cheat> selected;
    if(!selectedCheats(pack,selected,error)){out.message=error;return out;}
    if(pack.game.running){out.message="Cierra el juego antes de instalar para el próximo inicio. Usa R si quieres aplicar los cheats ahora al juego en ejecución.";return out;}
    const auto text=selectedText(pack,error);if(text.empty()){out.message=error;return out;}
    if(!folders(cheatRelative(pack.game),error)||!folders(backupRelative(pack.game),error)){out.message=error;return out;}
    const auto dir=sdRoot()+"/"+cheatRelative(pack.game),root=sdRoot()+"/"+backupRelative(pack.game);
    const auto target=dir+"/"+upper(pack.game.buildId)+".txt",toggles=dir+"/toggles.txt";
    std::string old,oldToggles;bool oldExists=false,togglesExist=false;
    if(!read(target,old,oldExists,error)||!read(toggles,oldToggles,togglesExist,error)){out.message=error;return out;}
    if(oldToggles.size()>256*1024){out.message="El archivo de estados de cheats es demasiado grande.";return out;}
    // Write only known-safe toggle names; original bytes are backed up separately.
    std::string newToggles;
    if(!togglesText(selected,oldToggles,newToggles)){out.message="El archivo toggles.txt existente no es válido. Corrígelo o aparta una copia antes de instalar.";return out;}
    if(newToggles.size()>=65536){out.message="El archivo toggles.txt resultante supera el límite de 64 KiB de Atmosphère.";return out;}
    unsigned number=0;std::string backup;
    for(;number<100000;++number){backup=root+"/"+serial(number);struct stat st{};if(lstat(backup.c_str(),&st)!=0&&errno==ENOENT)break;}
    if(number==100000||!directory(backup,error)){out.message=error.empty()?"Demasiadas copias guardadas.":error;return out;}
    out.backupPath=backup;
    out.transactionId=serial(number);
    const std::string manifest=std::string("NMC1")+(oldExists?'1':'0')+(togglesExist?'1':'0')+"\n";
    if(!writeNew(backup+"/previous-cheats.txt",old,error)||!writeNew(backup+"/previous-toggles.txt",oldToggles,error)||
       !writeNew(backup+"/new-cheats.txt",text,error)||!writeNew(backup+"/new-toggles.txt",newToggles,error)||
       !writeNew(backup+"/related.bin",linkedBackups(pack.game,previousContent,previousPatches),error)||!writeNew(backup+"/ready",manifest,error)) {
        out.message="No se cambiaron los cheats. "+error;return out;
    }
    const auto token=serial(number);
    std::string current,currentToggles;bool currentExists=false,currentTogglesExist=false;
    if(!read(target,current,currentExists,error)||!read(toggles,currentToggles,currentTogglesExist,error)||currentExists!=oldExists||currentTogglesExist!=togglesExist||current!=old||currentToggles!=oldToggles) {
        out.message="Los archivos de cheats cambiaron mientras se preparaba la copia. Vuelve a revisar la selección.";return out;
    }
    bool changedCheats=replace(target,text,token,error),changedToggles=false;
    if(changedCheats)changedToggles=replace(toggles,newToggles,token,error);
    if(!changedCheats||!changedToggles) {
        const auto reason=error;std::string rollback;
        const bool a=restoreOne(target,old,oldExists,token+"r",rollback),b=restoreOne(toggles,oldToggles,togglesExist,token+"r",rollback);
        out.message=reason+(a&&b?" Se restauraron los archivos anteriores.":" La restauración necesita revisión; tienes la copia de seguridad.");return out;
    }
    if(!writeNew(backup+"/complete","NMC1\n",error)){out.message="Archivos instalados, pero no se pudo confirmar el registro. Conserva la copia de seguridad.";return out;}
    out.ok=true;out.count=selectedCount(pack);
    out.message="Cheats instalados y seleccionados para el próximo inicio del juego. "+std::to_string(out.count)+" seleccionados. Copia anterior guardada.";
    return out;
}
Outcome restorePack(const Game &game) {
    Outcome out;std::string error;
    if(!validateGame(game,error)){out.message=error;return out;}
    if(game.running){out.message="Cierra el juego antes de restaurar sus archivos de cheats.";return out;}
    if(!folders(backupRelative(game),error,false)){out.message="No hay una copia disponible para este Build ID.";return out;}
    const auto root=sdRoot()+"/"+backupRelative(game),dir=sdRoot()+"/"+cheatRelative(game);
    DIR *d=opendir(root.c_str());if(!d){out.message="No se pudo revisar la copia.";return out;}
    std::vector<std::string> candidates;while(auto *e=readdir(d))if(serialValid(e->d_name))candidates.emplace_back(e->d_name);closedir(d);
    std::sort(candidates.rbegin(),candidates.rend());
    for(const auto &s:candidates) {
        const auto backup=root+"/"+s;if(!directory(backup,error,false)){out.message=error;return out;}
        bool exists=false;std::string marker;
        if(!read(backup+"/restored",marker,exists,error)){out.message=error;return out;}
        const bool alreadyRestored=exists;
        if(alreadyRestored&&marker!="NMC1\n"){out.message="Registro de restauración no válido.";return out;}
        if(!read(backup+"/ready",marker,exists,error)||!exists)continue;
        if(marker.size()!=7||marker.compare(0,4,"NMC1")||marker[6]!='\n'||(marker[4]!='0'&&marker[4]!='1')||(marker[5]!='0'&&marker[5]!='1')){out.message="Registro de copia inválido.";return out;}
        const bool had=marker[4]=='1',hadToggles=marker[5]=='1';
        std::string related,contentLink,patchLink;bool hasLinks=false;
        if(!read(backup+"/related.bin",related,hasLinks,error)||(hasLinks&&!parseLinks(game,related,contentLink,patchLink))){out.message="El registro de copias relacionadas no es válido. Conserva la copia para revisión.";out.backupPath=backup;return out;}
        if(alreadyRestored) {
            std::string acknowledged;bool done=false;
            if(!read(backup+"/associations-complete",acknowledged,done,error)||(done&&acknowledged!="NMC1\n")){out.message="No se pudo revisar el cierre de las copias relacionadas.";out.backupPath=backup;return out;}
            if((contentLink.empty()&&patchLink.empty())||done)continue;
            out.ok=true;out.message="Los archivos de esta instalación ya se retiraron. Se continuará recuperando únicamente sus copias relacionadas.";
            out.backupPath=backup;out.transactionId=s;out.previousContent=contentLink;out.previousPatches=patchLink;return out;
        }
        std::string old,oldToggles,newText,newToggles,now,nowToggles;bool has=false,hasToggles=false;
        bool a=false,b=false,c=false,f=false;
        if(!read(backup+"/previous-cheats.txt",old,a,error)||!a||!read(backup+"/previous-toggles.txt",oldToggles,b,error)||!b||
           !read(backup+"/new-cheats.txt",newText,c,error)||!c||!read(backup+"/new-toggles.txt",newToggles,f,error)||!f||
           !read(dir+"/"+upper(game.buildId)+".txt",now,has,error)||!read(dir+"/toggles.txt",nowToggles,hasToggles,error)) {out.message="Copia incompleta. "+error;return out;}
        if((has&&now!=newText&&now!=old)||(hasToggles&&nowToggles!=newToggles&&nowToggles!=oldToggles)) {
            out.message="Los cheats cambiaron después de la instalación. La copia está disponible; restaúrala manualmente para conservar esos cambios.";out.backupPath=backup;return out;
        }
        if(((had||hadToggles)&&!folders(cheatRelative(game),error))||!restoreOne(dir+"/"+upper(game.buildId)+".txt",old,had,s+"u",error)||!restoreOne(dir+"/toggles.txt",oldToggles,hadToggles,s+"u",error)||!writeNew(backup+"/restored","NMC1\n",error)) {
            out.message="Restauración incompleta. "+error;out.backupPath=backup;return out;
        }
        out.ok=true;out.message="Archivos de cheats anteriores restaurados. Se conserva la copia de seguridad.";out.backupPath=backup;out.transactionId=s;out.previousContent=contentLink;out.previousPatches=patchLink;return out;
    }
    out.message="No hay una copia pendiente de restaurar para este juego y Build ID.";return out;
}
bool finishPackRecovery(const Game &game,const std::string &token,std::string &error) {
    error.clear();
    if(!validateGame(game,error)||!serialValid(token)||!folders(backupRelative(game)+"/"+token,error,false))return false;
    const auto backup=sdRoot()+"/"+backupRelative(game)+"/"+token;
    std::string marker,related,a,b;bool exists=false;
    if(!read(backup+"/restored",marker,exists,error)||!exists||marker!="NMC1\n"||!read(backup+"/related.bin",related,exists,error)||!exists||!parseLinks(game,related,a,b)) {
        error="No se pudo confirmar el registro de recuperación de esta instalación.";return false;
    }
    if(!read(backup+"/associations-complete",marker,exists,error))return false;
    if(exists){if(marker=="NMC1\n")return true;error="El cierre de recuperación no es válido.";return false;}
    return writeNew(backup+"/associations-complete","NMC1\n",error);
}
}

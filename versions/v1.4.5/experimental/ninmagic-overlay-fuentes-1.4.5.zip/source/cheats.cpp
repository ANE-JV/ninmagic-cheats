#include "cheats.hpp"
#include "cheat_review.hpp"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <set>
#include <sstream>

namespace nc {
namespace {
std::string trim(const std::string &s) {
    const auto a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos)return {};
    return s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);
}
std::string lower(std::string s) {for(char &c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return s;}
bool contains(const std::string &s,std::initializer_list<const char*> words) {
    for(const auto *w:words)if(s.find(w)!=std::string::npos)return true;
    return false;
}
bool word(const std::string &s,const std::string &token) {
    size_t i=0;while((i=s.find(token,i))!=std::string::npos) {
        const auto end=i+token.size();
        if((i==0||!std::isalnum(static_cast<unsigned char>(s[i-1])))&&(end==s.size()||!std::isalnum(static_cast<unsigned char>(s[end]))))return true;
        ++i;
    }return false;
}
std::string boundedName(std::string name) {
    if(name.size()<=63)return name;
    size_t n=63;while(n>0&&(static_cast<unsigned char>(name[n])&0xc0)==0x80)--n;
    return name.substr(0,n);
}
bool nameValid(const std::string &s) {
    if(s.empty()||s.size()>63)return false;
    for(unsigned char c:s)if(c<32||c=='['||c==']'||c=='{'||c=='}'||c==127)return false;
    return true;
}
}
bool validBuild(const std::string &s) {
    if(s.size()!=16)return false;
    bool any=false;
    for(unsigned char c:s){if(!std::isxdigit(c))return false;if(c!='0')any=true;}
    return any;
}
unsigned classifyCheat(const std::string &name) {
    const auto s=lower(name);unsigned result=0;
    if(contains(s,{"fps","framerate","frame rate","frame-rate","vsync","v-sync"}))result|=Fps;
    if(contains(s,{"resol","1080","720p","900p","2160","1440","540p","480p","360p","drs","dynamic res","render scale","rendering scale"}))result|=Resolution;
    for(size_t i=1;i+1<s.size();++i)if(s[i]=='x'&&std::isdigit(static_cast<unsigned char>(s[i-1]))&&std::isdigit(static_cast<unsigned char>(s[i+1])))result|=Resolution;
    if(contains(s,{"graphic","shadow","bloom","blur","occlusion","anti-alias","antialias","fxaa","taa ","taa]","texture","draw distance","lod ","level of detail","depth of field","dof ","vignette","fog ","no fog","post-process","post process","motion","reflection","ambient","anisotrop","fov","film grain","chromatic","volumetric"}))result|=Graphics;
    for(const auto *token:{"aa","taa","msaa","smaa","lod","dof","ssao","ssr"})if(word(s,token))result|=Graphics;
    return result?result:General;
}
bool parseCheats(const std::string &input,const std::string &source,std::vector<Cheat> &cheats,std::string &error) {
    cheats.clear();error.clear();
    if(input.empty()||input.size()>2*1024*1024||input.find('\0')!=std::string::npos) {error="El archivo de cheats está vacío, es demasiado grande o contiene datos binarios.";return false;}
    std::string data=input;if(data.compare(0,3,"\xef\xbb\xbf")==0)data.erase(0,3);
    std::istringstream in(data);std::string line;Cheat current;bool header=false;size_t lines=0;
    auto finish=[&](){if(header&&!current.opcodes.empty())cheats.push_back(current);};
    while(std::getline(in,line)) {
        if(++lines>100000||line.size()>16384){error="Archivo de cheats fuera de los límites admitidos.";cheats.clear();return false;}
        line=trim(line);if(line.empty()||line[0]=='#'||line[0]==';'||line.compare(0,2,"//")==0)continue;
        if(line.front()=='['||line.front()=='{') {
            const char end=line.front()=='['?']':'}';
            if(line.size()<3||line.back()!=end){error="Cabecera de cheat incompleta.";cheats.clear();return false;}
            finish();current={};current.name=boundedName(trim(line.substr(1,line.size()-2)));
            current.master=end=='}';current.source=source;current.group=source;current.categories=classifyCheat(current.name);header=true;
            if(!nameValid(current.name)||cheats.size()>4096){error="Nombre de cheat inválido o demasiadas entradas.";cheats.clear();return false;}
            continue;
        }
        if(!header){error="Códigos sin cabecera de cheat.";cheats.clear();return false;}
        std::istringstream words(line);std::string word;
        while(words>>word) {
            if(word.compare(0,2,"//")==0||word[0]=='#'||word[0]==';')break;
            if(word.size()!=8||!std::all_of(word.begin(),word.end(),[](unsigned char c){return std::isxdigit(c);})) {
                error="El archivo incluye una instrucción de cheat no válida.";cheats.clear();return false;
            }
            uint32_t value=0;for(unsigned char c:word)value=(value<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);
            current.opcodes.push_back(value);
            if(current.opcodes.size()>256){error="Un cheat supera las 256 instrucciones admitidas por Atmosphère.";cheats.clear();return false;}
        }
    }
    finish();
    if(cheats.empty()){error="Este archivo no contiene cheats utilizables.";return false;}
    return true;
}
bool selectedCheats(const Pack &pack,std::vector<Cheat> &selected,std::string &error) {
    selected.clear();error.clear();
    if(!pack.compatible||!pack.game.buildVerified||!validBuild(pack.game.buildId)||pack.game.id<0x0100000000010000ULL) {
        error="Falta verificar el Title ID y el Build ID exactos del juego.";return false;
    }
    std::set<std::string> groups;
    for(const auto &c:pack.cheats)if(c.selected&&!c.master){
        const auto review=blockedCheatReason(pack.game,c);if(!review.empty()){error=review;return false;}
        groups.insert(c.group.empty()?c.source:c.group);
    }
    if(groups.empty()){error="Selecciona al menos un cheat.";return false;}
    Cheat master;bool haveMaster=false;
    for(const auto &c:pack.cheats)if(c.master&&groups.count(c.group.empty()?c.source:c.group)) {
        const auto review=blockedCheatReason(pack.game,c);if(!review.empty()){error=review;return false;}
        if(!haveMaster){master=c;haveMaster=true;}
        else if(master.opcodes!=c.opcodes){error="Las fuentes seleccionadas requieren códigos maestros diferentes. Selecciona cheats de una sola fuente.";return false;}
    }
    if(haveMaster)selected.push_back(master);
    std::set<std::string> names;
    for(const auto &c:pack.cheats)if(c.selected&&!c.master) {
        auto duplicate=std::find_if(selected.begin(),selected.end(),[&](const Cheat &other){return !other.master&&other.name==c.name;});
        if(duplicate!=selected.end()) {
            if(duplicate->opcodes!=c.opcodes){error="Dos cheats seleccionados tienen el mismo nombre y códigos diferentes. Elige uno.";selected.clear();return false;}
            continue;
        }
        selected.push_back(c);
    }
    if(selected.size()-(haveMaster?1:0)>127){error="Selecciona menos cheats: Atmosphère admite 127 cheats y un código maestro.";selected.clear();return false;}
    size_t textBytes=0,opcodeWords=0;
    for(const auto &c:selected) {
        if(!nameValid(c.name)||c.opcodes.empty()||c.opcodes.size()>256) {error="La selección contiene un cheat inválido.";selected.clear();return false;}
        if(!names.insert(c.name).second){error="Los nombres de los códigos seleccionados deben ser distintos.";selected.clear();return false;}
        textBytes+=c.name.size()+4+c.opcodes.size()*9;
        opcodeWords+=c.opcodes.size();
    }
    if(textBytes>=65536){error="La selección supera el archivo de 64 KiB admitido por Atmosphère. Selecciona menos cheats.";selected.clear();return false;}
    if(opcodeWords>1024){error="Los cheats elegidos superan la capacidad total del motor de Atmosphère. Selecciona menos opciones para que puedan ejecutarse.";selected.clear();return false;}
    return validateWriteConflicts(selected,error);
}
bool validateWriteConflicts(const std::vector<Cheat> &selected,std::string &error) {
    // Straight-line static writes to the same target cannot simultaneously hold
    // different values (e.g. the 30 FPS and 60 FPS alternatives). Do not guess
    // about conditional/register-based code; those are still author-dependent.
    struct Write {uint32_t opcode,address;std::vector<uint32_t> values;std::string name;};
    std::vector<Write> writes;
    for(const auto &c:selected)if(!c.master) {
        std::vector<Write> local;bool linear=true;
        for(size_t i=0;i<c.opcodes.size();) {
            const auto op=c.opcodes[i];const auto size=(op>>24)&15;const size_t n=size==8?4:3;
            if((op>>28)!=0||(size!=1&&size!=2&&size!=4&&size!=8)||i+n>c.opcodes.size()){linear=false;break;}
            local.push_back({op,c.opcodes[i+1],std::vector<uint32_t>(c.opcodes.begin()+i+2,c.opcodes.begin()+i+n),c.name});i+=n;
        }
        if(!linear)continue;
        for(const auto &w:local)for(const auto &other:writes)if(w.opcode==other.opcode&&w.address==other.address&&w.values!=other.values) {
            error="Conflicto entre '"+other.name+"' y '"+w.name+"': escriben valores distintos en la misma dirección. Selecciona una variante.";return false;
        }
        writes.insert(writes.end(),local.begin(),local.end());
    }
    return true;
}
std::string selectedText(const Pack &pack,std::string &error) {
    std::vector<Cheat> selected;if(!selectedCheats(pack,selected,error))return {};
    std::string result;
    for(const auto &c:selected) {
        result+=(c.master?"{":"[")+c.name+(c.master?"}\n":"]\n");
        for(size_t i=0;i<c.opcodes.size();++i) {char s[10];std::snprintf(s,sizeof(s),"%08X",c.opcodes[i]);result+=s;result+=(i%4==3||i+1==c.opcodes.size())?'\n':' ';}
        result+='\n';
    }
    return result;
}
}

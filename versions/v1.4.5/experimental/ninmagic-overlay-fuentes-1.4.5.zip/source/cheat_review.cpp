#include "cheat_review.hpp"
#include <algorithm>
#include <array>
#include <cstring>

namespace nc {
namespace {
// Portable SHA-256, also exercised against standard known-answer vectors in
// the host tests. No crypto library, iostream locale or author code is linked.
class FingerprintSha256 {
    uint32_t state[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    std::array<uint8_t,64> pending{};
    size_t used=0;uint64_t length=0;
    static uint32_t rotate(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
    void block(const uint8_t *input){
        static constexpr uint32_t constants[64]={
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
        };
        uint32_t words[64];
        for(unsigned i=0;i<16;++i)words[i]=(uint32_t(input[i*4])<<24)|(uint32_t(input[i*4+1])<<16)|(uint32_t(input[i*4+2])<<8)|input[i*4+3];
        for(unsigned i=16;i<64;++i){const auto a=words[i-15],b=words[i-2];words[i]=words[i-16]+(rotate(a,7)^rotate(a,18)^(a>>3))+words[i-7]+(rotate(b,17)^rotate(b,19)^(b>>10));}
        uint32_t a=state[0],b=state[1],c=state[2],d=state[3],e=state[4],f=state[5],g=state[6],h=state[7];
        for(unsigned i=0;i<64;++i){
            const auto first=h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+constants[i]+words[i];
            const auto second=(rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c));
            h=g;g=f;f=e;e=d+first;d=c;c=b;b=a;a=first+second;
        }
        state[0]+=a;state[1]+=b;state[2]+=c;state[3]+=d;state[4]+=e;state[5]+=f;state[6]+=g;state[7]+=h;
    }
public:
    void add(const uint8_t *bytes,size_t count){
        length+=count;
        while(count){const auto take=std::min(count,pending.size()-used);std::memcpy(pending.data()+used,bytes,take);used+=take;bytes+=take;count-=take;if(used==pending.size()){block(pending.data());used=0;}}
    }
    std::array<uint8_t,32> finish(){
        const uint64_t bits=length*8;pending[used++]=0x80;
        if(used>56){std::fill(pending.begin()+used,pending.end(),0);block(pending.data());used=0;}
        std::fill(pending.begin()+used,pending.begin()+56,0);
        for(unsigned i=0;i<8;++i)pending[63-i]=uint8_t(bits>>(i*8));
        block(pending.data());std::array<uint8_t,32> digest{};
        for(unsigned i=0;i<8;++i)for(unsigned j=0;j<4;++j)digest[i*4+j]=uint8_t(state[i]>>(24-j*8));
        return digest;
    }
};
struct ReviewFingerprint {size_t words;const char *sha256;};
// Exact suspect definitions published under FF77, identical to older CD6E
// definitions. Digests cover uint32 opcode words serialized little-endian.
// Keep the definitions visible; this is a new-activation block, not a claim
// that all other codes are safe or that the reported crash was reproduced.
constexpr ReviewFingerprint Fingerprints[]={
    {27,"0d08c9eae38a9c1bf1974fd1d0548febbc212496875a32ff94a8c0901719c021"},
    {42,"b4c8448f5fc1ba21cf17456175831bf4ba33b42c17765e68dd1ec4ed55208531"},
    {34,"ccd8c2d8a039aba6a55719b6d09a07949cda369da5f965bb8698185afd274f6c"},
    {20,"e981e9a2712b9fbb4191f6ab7adbc94a8d7303b094fdb1edbcb5484fb92f5d6d"},
    {67,"141ef327633be8bb206d856098b4de5f3ea9982b3850057ad88a64d027bc8b34"},
    {30,"8675f8f4025c713ed0ad6210b2d3fe43017ec4a7f830393e9d84004e8fcfc32f"},
    {3,"0cc50aaa0d1fb433a630d72be7f7bd09250b589d90b0afdd97daf9ce8b71f4b8"},
    {15,"770ae50241bc4b4d1a865e0b0dab46f52eab0ac4c9260d033a1aec68f776da4e"},
    {15,"26abc1384ff7f4b45c7875f6c1f2c970a81f38b6bc0e1c25d5144587a8845d34"},
    {15,"61a75fc5cb43d0daf51539d9c4c35c67057686ecc440dbcfb99bc980c9ecc4e1"},
    {13,"420cbf8eab1e0ad4996e6f2025dd2ad8ed1e269ab64bff5db3757f2b9e9e1455"}
};
bool reviewIdentity(const Game &game){
    constexpr char Bid[]="FF773E90972D544E";
    if(game.id!=0x010015100B514000ULL||game.buildId.size()!=16)return false;
    for(size_t i=0;i<16;++i){const char c=game.buildId[i];if((c>='a'&&c<='f'?char(c-'a'+'A'):c)!=Bid[i])return false;}
    return true;
}
bool sameDigest(const std::array<uint8_t,32> &digest,const char *hex){
    constexpr char Hex[]="0123456789abcdef";
    for(size_t i=0;i<digest.size();++i)if(hex[i*2]!=Hex[digest[i]>>4]||hex[i*2+1]!=Hex[digest[i]&15])return false;
    return true;
}
}
std::string blockedCheatReason(const Game &game,const Cheat &cheat){
    if(!reviewIdentity(game))return {};
    if(std::none_of(std::begin(Fingerprints),std::end(Fingerprints),[&](const ReviewFingerprint &entry){return entry.words==cheat.opcodes.size();}))return {};
    FingerprintSha256 hash;
    for(uint32_t word:cheat.opcodes){const uint8_t bytes[4]={uint8_t(word),uint8_t(word>>8),uint8_t(word>>16),uint8_t(word>>24)};hash.add(bytes,sizeof(bytes));}
    const auto digest=hash.finish();
    for(const auto &entry:Fingerprints)if(entry.words==cheat.opcodes.size()&&sameDigest(digest,entry.sha256))
        return "Código en revisión: publicado también para Build ID CD6E42AEE7934F4D (1.0.0 según la fuente); no validado para tu versión. Su nueva activación está bloqueada hasta verificar la compatibilidad.";
    return {};
}
}

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "https_lite.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __SWITCH__
#include <switch.h>
#include <netdb.h>
#include <poll.h>
#include <sys/socket.h>
#endif

namespace nc::https_lite {
namespace detail {
constexpr size_t HeaderLimit=32*1024,IoSize=16*1024,UrlLimit=8192;
struct Url {std::string host,target,canonical;};
using Reader=std::function<int(void*,size_t,std::string&)>;
using Writer=std::function<bool(const void*,size_t)>;
bool aborted(const std::function<bool()> &cancelled,std::string &error){
    if(cancelled&&cancelled()){error="Consulta HTTPS cancelada.";return true;}return false;
}
bool clean(const std::string&s){return std::all_of(s.begin(),s.end(),[](unsigned char c){return c>=32&&c!=127;});}
std::string lower(std::string s){for(char&c:s)c=char(std::tolower(static_cast<unsigned char>(c)));return s;}
std::string trim(const std::string&s){const auto a=s.find_first_not_of(" \t"),b=s.find_last_not_of(" \t");return a==std::string::npos?"":s.substr(a,b-a+1);}
bool parseUrl(const std::string &text,Url&out,std::string &error){
    if(text.size()>UrlLimit||text.rfind("https://",0)!=0||!clean(text)||text.find('\\')!=std::string::npos||text.find(' ')!=std::string::npos){error="Solo se admiten URLs HTTPS válidas y acotadas.";return false;}
    const auto end=text.find_first_of("/?#",8);auto host=text.substr(8,end==std::string::npos?end:end-8);
    if(host.size()>4&&host.compare(host.size()-4,4,":443")==0)host.resize(host.size()-4);
    if(host.empty()||host.size()>253||host.front()=='.'||host.back()=='.'||host.find("..")!=std::string::npos||!std::all_of(host.begin(),host.end(),[](unsigned char c){return std::isalnum(c)||c=='.'||c=='-';})){
        error="El servidor HTTPS no tiene un nombre admitido.";return false;
    }
    size_t begin=0;while(begin<host.size()){const auto next=host.find('.',begin);const auto n=(next==std::string::npos?host.size():next)-begin;if(!n||n>63||host[begin]=='-'||host[begin+n-1]=='-'){error="El nombre DNS no es válido.";return false;}begin=next==std::string::npos?host.size():next+1;}
    std::string target=end==std::string::npos?"/":text.substr(end);const auto fragment=target.find('#');if(fragment!=std::string::npos)target.resize(fragment);
    if(target.empty())target="/";else if(target.front()=='?')target='/'+target;
    if(target.front()!='/'){error="La ruta HTTPS no es válida.";return false;}
    out={lower(host),target,"https://"+lower(host)+target};return true;
}
bool redirectUrl(const Url &base,const std::string&location,Url&out,std::string&error){
    if(location.empty()||location.size()>UrlLimit||!clean(location)||location.find('\\')!=std::string::npos){error="Redirección HTTPS no válida.";return false;}
    if(location.rfind("https://",0)==0)return parseUrl(location,out,error);
    if(location.rfind("//",0)==0)return parseUrl("https:"+location,out,error);
    if(location.find(':')!=std::string::npos){error="Se rechazó una redirección fuera de HTTPS.";return false;}
    std::string path;
    if(location.front()=='/')path=location;
    else if(location.front()=='?')path=base.target.substr(0,base.target.find('?'))+location;
    else if(location.front()=='#')path=base.target+location;
    else {const auto current=base.target.substr(0,base.target.find('?'));path=current.substr(0,current.rfind('/')+1)+location;}
    // Resolve dot segments only in the path; signed query strings stay exact.
    const auto suffix=path.find_first_of("?#");const auto tail=suffix==std::string::npos?"":path.substr(suffix);const auto raw=path.substr(0,suffix);
    std::string normalized="/";size_t at=1;
    while(at<=raw.size()){const auto slash=raw.find('/',at);const auto part=raw.substr(at,slash==std::string::npos?slash:slash-at);if(part==".."){if(normalized.size()>1){normalized.pop_back();const auto p=normalized.rfind('/');normalized.resize(p+1);}}else if(part!="."&&!part.empty())normalized+=part+'/';if(slash==std::string::npos)break;at=slash+1;}
    if(raw.empty()||raw.back()!='/'){if(normalized.size()>1)normalized.pop_back();}
    return parseUrl("https://"+base.host+normalized+tail,out,error);
}
bool number(const std::string&s,unsigned base,uint64_t&out){
    if(s.empty())return false;
    uint64_t value=0;
    for(unsigned char c:s){unsigned digit=c>='0'&&c<='9'?c-'0':c>='A'&&c<='F'?c-'A'+10:c>='a'&&c<='f'?c-'a'+10:99;if(digit>=base||value>(std::numeric_limits<uint64_t>::max()-digit)/base)return false;value=value*base+digit;}
    out=value;return true;
}
class Input {
    Reader reader;const std::function<bool()>&cancelled;std::array<char,IoSize> buffer{};size_t at=0,size=0;
public:
    size_t headerBytes=0;
    Input(Reader r,const std::function<bool()>&c):reader(std::move(r)),cancelled(c){}
    int take(void*to,size_t cap,std::string&error){
        if(aborted(cancelled,error))return -1;
        if(at==size){const auto n=reader(buffer.data(),buffer.size(),error);if(n<0)return -1;if(size_t(n)>buffer.size()){error="El transporte devolvió un tamaño inválido.";return -1;}at=0;size=size_t(n);if(!n)return 0;}
        const auto n=std::min(cap,size-at);std::memcpy(to,buffer.data()+at,n);at+=n;return int(n);
    }
    bool line(std::string&out,std::string&error,bool header=true){
        out.clear();char c=0;
        for(;;){if((header&&++headerBytes>HeaderLimit)||(!header&&out.size()>1024)){error="Las cabeceras HTTPS exceden su límite.";return false;}if(take(&c,1,error)!=1){if(error.empty())error="Cabecera HTTPS incompleta.";return false;}if(c=='\r'){if((header&&++headerBytes>HeaderLimit)||take(&c,1,error)!=1||c!='\n'){if(error.empty())error="Fin de línea HTTP inválido.";return false;}return true;}if(c=='\n'||(static_cast<unsigned char>(c)<32&&c!='\t')||c==127){error="Cabecera HTTP no válida.";return false;}out+=c;}
    }
    bool exact(void*to,size_t cap,std::string&error){size_t done=0;while(done<cap){const int n=take(static_cast<char*>(to)+done,cap-done,error);if(n<=0){if(error.empty())error="El cuerpo HTTPS llegó incompleto.";return false;}done+=size_t(n);}return true;}
};
struct Headers {Response response;std::string location;bool hasLength=false,chunked=false;uint64_t length=0;};
bool headerField(const std::string&line,std::string&name,std::string&value,std::string&error){
    const auto colon=line.find(':');if(colon==std::string::npos||!colon||line.front()==' '||line.front()=='\t'){error="Campo HTTP inválido.";return false;}
    name=lower(line.substr(0,colon));if(!std::all_of(name.begin(),name.end(),[](unsigned char c){return std::isalnum(c)||std::strchr("!#$%&'*+-.^_`|~",c);})) {error="Nombre de campo HTTP inválido.";return false;}value=trim(line.substr(colon+1));return true;
}
bool readHeaders(Input&input,Headers&out,std::string&error){
    for(unsigned interim=0;interim<5;++interim){Headers next;std::string line;
        if(!input.line(line,error))return false;
        if(line.size()<12||(line.compare(0,9,"HTTP/1.1 ")&&line.compare(0,9,"HTTP/1.0 "))||line[9]<'1'||line[9]>'5'||line[10]<'0'||line[10]>'9'||line[11]<'0'||line[11]>'9'||(line.size()>12&&line[12]!=' ')){error="Respuesta HTTP no reconocida.";return false;}
        next.response.status=(line[9]-'0')*100+(line[10]-'0')*10+line[11]-'0';bool haveTe=false,haveEncoding=false;
        for(;;){if(!input.line(line,error))return false;if(line.empty())break;std::string name,value;if(!headerField(line,name,value,error))return false;
            if(name=="content-length"){uint64_t n=0;if(!number(value,10,n)||(next.hasLength&&n!=next.length)){error="Content-Length inválido o ambiguo.";return false;}next.hasLength=true;next.length=n;next.response.length=std::to_string(n);}
            else if(name=="transfer-encoding"){if(haveTe||lower(value)!="chunked"){error="Transfer-Encoding no admitido.";return false;}haveTe=next.chunked=true;}
            else if(name=="content-encoding"){if(haveEncoding||lower(value)!="identity"){error="El servidor devolvió contenido comprimido no solicitado.";return false;}haveEncoding=true;}
            else if(name=="etag"){if(value.size()>512||!next.response.etag.empty()){error="ETag demasiado grande o ambiguo.";return false;}next.response.etag=value;}
            else if(name=="last-modified"){if(value.size()>128||!next.response.modified.empty()){error="Last-Modified no admitido.";return false;}next.response.modified=value;}
            else if(name=="location"){if(value.size()>UrlLimit||!next.location.empty()){error="Location ambiguo o demasiado grande.";return false;}next.location=value;}
        }
        if(next.hasLength&&next.chunked){error="Respuesta HTTP con dos delimitaciones incompatibles.";return false;}
        if(next.response.status>=200){out=std::move(next);return true;}
        if(next.response.status==101){error="No se admite cambiar el protocolo HTTP.";return false;}
    }
    error="Demasiadas respuestas provisionales HTTP.";return false;
}
bool readBody(Input&input,const Headers&headers,const Writer&writer,uint64_t limit,const std::function<bool()>&cancelled,Response&response,std::string&error){
    if(headers.hasLength&&headers.length>limit){error="La descarga excede el tamaño permitido.";return false;}
    std::array<char,IoSize> data{};
    const auto copy=[&](uint64_t amount){while(amount){if(aborted(cancelled,error))return false;const auto take=size_t(std::min<uint64_t>(amount,data.size()));if(!input.exact(data.data(),take,error))return false;if(!writer(data.data(),take)){error="No se pudo escribir la descarga en la microSD.";return false;}amount-=take;response.bytes+=take;}return true;};
    if(headers.chunked){size_t chunkMetadata=0;for(;;){std::string line;if(!input.line(line,error,false))return false;chunkMetadata+=line.size()+2;if(chunkMetadata>4*1024*1024){error="Demasiadas delimitaciones chunked.";return false;}const auto semicolon=line.find(';');const auto count=line.substr(0,semicolon);uint64_t chunk=0;if(count.size()>16||!number(count,16,chunk)){error="Tamaño chunked inválido.";return false;}
            if(!chunk){for(;;){if(!input.line(line,error))return false;if(line.empty())return true;std::string name,value;if(!headerField(line,name,value,error))return false;if(name=="content-length"||name=="transfer-encoding"||name=="content-encoding"||name=="location"){error="Trailer HTTP de delimitación no admitido.";return false;}}}
            if(chunk>limit-response.bytes){error="La descarga chunked excede el tamaño permitido.";return false;}if(!copy(chunk))return false;char crlf[2];if(!input.exact(crlf,2,error)||crlf[0]!='\r'||crlf[1]!='\n'){if(error.empty())error="Chunk HTTPS sin cierre CRLF.";return false;}
        }}
    if(headers.hasLength)return copy(headers.length);
    for(;;){if(aborted(cancelled,error))return false;const int n=input.take(data.data(),data.size(),error);if(n<0)return false;if(!n)return true;if(uint64_t(n)>limit-response.bytes){error="La descarga excede el tamaño permitido.";return false;}if(!writer(data.data(),size_t(n))){error="No se pudo escribir la descarga en la microSD.";return false;}response.bytes+=uint64_t(n);}
}
bool outputPath(const std::string&path,std::string&error){
    if(path.empty()||path.size()>1024||path.find('\\')!=std::string::npos){error="Ruta temporal HTTPS no admitida.";return false;}
#ifdef __SWITCH__
    if(path.rfind("sdmc:/config/NinMagicCheats/",0)!=0){error="La descarga HTTPS debe permanecer en la caché privada.";return false;}
#endif
    size_t at=path.front()=='/'?1:0;for(;;){const auto slash=path.find('/',at);const auto part=path.substr(at,slash==std::string::npos?slash:slash-at);if(part.empty()||part=="."||part==".."){error="La ruta temporal HTTPS contiene un segmento inválido.";return false;}struct stat st{};const std::string current=slash==std::string::npos?path:path.substr(0,slash);if(lstat(current.c_str(),&st)!=0){if(slash==std::string::npos&&errno==ENOENT)return true;error="No se pudo revisar la carpeta temporal HTTPS.";return false;}if(S_ISLNK(st.st_mode)||(slash==std::string::npos?!S_ISREG(st.st_mode):!S_ISDIR(st.st_mode))){error="La ruta HTTPS contiene un enlace o un tipo no admitido.";return false;}if(slash==std::string::npos)return true;at=slash+1;}
}
#ifdef __SWITCH__
bool sockets=false,nifm=false,ssl=false;
Result nifmHintResult=0;int nifmHintStatus=-1;
std::string networkHint(){char text[72];std::snprintf(text,sizeof(text)," nifm_rc=0x%08lX nifm_status=%d",static_cast<unsigned long>(nifmHintResult),nifmHintStatus);return text;}
std::string resultText(const char*step,Result rc){char text[96];std::snprintf(text,sizeof(text),"%s (0x%08lX)",step,static_cast<unsigned long>(rc));return text;}
// Report only a validated DNS name, never a path, signed redirect or query.
std::string socketError(const std::string&host,const char*step,int code,Result result,int socketCode=0,short events=0){
    char detail[176];std::snprintf(detail,sizeof(detail)," etapa=%s errno=%d last_bsd=0x%08lX so_error=%d revents=0x%X",step,code,static_cast<unsigned long>(result),socketCode,unsigned(static_cast<unsigned short>(events)));
    return "HTTPS host="+host+detail+networkHint();
}
uint64_t nowMs(){return armTicksToNs(armGetSystemTick())/1000000;}
bool initialize(std::string&error){
    if(hosversionBefore(16,0,0)){error="El HTTPS nativo del overlay requiere firmware 16 o posterior para limitar sus esperas.";return false;}
    if(!sockets){const SocketInitConfig cfg={16*1024,64*1024,0,0,16*1024,32*1024,1,1,BsdServiceType_User};const auto rc=socketInitialize(&cfg);if(R_FAILED(rc)){error=resultText("No se pudo iniciar BSD HTTPS",rc);return false;}sockets=true;}
    // A NIFM system connectivity hint does not prove reachability of this
    // HTTPS peer. Keep it as diagnostic context; actual bounded TCP/TLS decides.
    if(!nifm){nifmHintResult=nifmInitialize(NifmServiceType_User);nifm=R_SUCCEEDED(nifmHintResult);}
    nifmHintStatus=-1;
    if(nifm){NifmInternetConnectionType type{};u32 strength=0;NifmInternetConnectionStatus status{};nifmHintResult=nifmGetInternetConnectionStatus(&type,&strength,&status);if(R_SUCCEEDED(nifmHintResult))nifmHintStatus=static_cast<int>(status);}
    if(!ssl){const auto rc=sslInitialize(1);if(R_FAILED(rc)){error=resultText("No se pudo iniciar SSL nativo",rc)+networkHint();return false;}ssl=true;}
    return true;
}
class Connection {
    int fd=-1;SslContext context{};SslConnection connection{};bool hasContext=false,hasConnection=false;
    const std::function<bool()>&cancelled;uint64_t deadline=0;std::string peer;
    bool check(std::string&error){if(aborted(cancelled,error))return false;if(nowMs()>deadline){error="Se agotó el tiempo de la descarga HTTPS.";return false;}return true;}
public:
    explicit Connection(const std::function<bool()>&c):cancelled(c),deadline(nowMs()+180000){}
    ~Connection(){if(hasConnection)sslConnectionClose(&connection);if(fd>=0)close(fd);if(hasContext)sslContextClose(&context);}
    bool open(const Url&url,std::string&error){
        peer=url.host;
        if(!check(error))return false;
        addrinfo hints{},*addresses=nullptr;hints.ai_family=AF_INET;hints.ai_socktype=SOCK_STREAM;
        errno=0;
        const int dns=getaddrinfo(url.host.c_str(),"443",&hints,&addresses);
        const int dnsErrno=errno;
        if(dns||!addresses){if(addresses)freeaddrinfo(addresses);error=socketError(peer,"dns/getaddrinfo",dnsErrno,0)+" gai="+std::to_string(dns);return false;}
        bool connected=false;const auto connectLimit=nowMs()+15000;std::string failure;
        for(auto*address=addresses;address&&check(error)&&nowMs()<connectLimit;address=address->ai_next){
            errno=0;fd=socket(address->ai_family,address->ai_socktype,address->ai_protocol);
            if(fd<0){failure=socketError(peer,"tcp/socket",errno,socketGetLastResult());continue;}
            // A fresh socket has no flags to preserve. libnx supports only
            // O_NONBLOCK here; F_GETFL uses a private ioctl and is unnecessary.
            // Its from_nx(-1) conversion can also return a positive flag mask,
            // so inspect errno/Result rather than trusting only the return sign.
            errno=0;const int nonblocking=fcntl(fd,F_SETFL,O_NONBLOCK);
            const int flagError=errno;const Result flagResult=socketGetLastResult();
            if(nonblocking<0||flagError||R_FAILED(flagResult)){failure=socketError(peer,"tcp/fcntl-setfl",flagError,flagResult);close(fd);fd=-1;continue;}
            errno=0;
            const int result=connect(fd,address->ai_addr,address->ai_addrlen);
            const int connectError=errno;const Result connectResult=socketGetLastResult();
            if(result==0||connectError==EISCONN)connected=true;
            else if(connectError==EINPROGRESS||connectError==EWOULDBLOCK||connectError==EALREADY||connectError==EINTR){
                failure=socketError(peer,"tcp/connect-pendiente",connectError,connectResult);
                while(check(error)&&nowMs()<connectLimit){
                    pollfd event{fd,POLLOUT,0};errno=0;const int ready=poll(&event,1,200);
                    const int pollError=errno;const Result pollResult=socketGetLastResult();
                    if(ready<0&&pollError==EINTR)continue;
                    if(ready<0){failure=socketError(peer,"tcp/poll",pollError,pollResult,0,event.revents);break;}
                    if(!ready)continue;
                    if(event.revents&POLLNVAL){failure=socketError(peer,"tcp/poll-fd",EBADF,pollResult,0,event.revents);break;}
                    if(!(event.revents&(POLLOUT|POLLERR|POLLHUP)))continue;
                    int socketCode=0;socklen_t size=sizeof(socketCode);errno=0;
                    const int option=getsockopt(fd,SOL_SOCKET,SO_ERROR,&socketCode,&size);
                    const int optionError=errno;const Result optionResult=socketGetLastResult();
                    if(option<0||size!=sizeof(socketCode)){failure=socketError(peer,"tcp/so-error",option<0?optionError:EIO,optionResult,socketCode,event.revents);break;}
                    if(socketCode){failure=socketError(peer,"tcp/connect-resultado",0,optionResult,socketCode,event.revents);break;}
                    if(event.revents&(POLLERR|POLLHUP)){failure=socketError(peer,"tcp/poll-cerrado",ECONNRESET,pollResult,0,event.revents);break;}
                    connected=true;break;
                }
                if(!connected&&nowMs()>=connectLimit)failure=socketError(peer,"tcp/tiempo-agotado",ETIMEDOUT,0);
            }else failure=socketError(peer,"tcp/connect",connectError,connectResult);
            if(connected)break;
            close(fd);fd=-1;
        }
        freeaddrinfo(addresses);if(!connected){if(error.empty())error=failure.empty()?socketError(peer,"tcp/tiempo-agotado",ETIMEDOUT,0):failure;return false;}
        Result rc=sslCreateContext(&context,SslVersion_TlsV12|SslVersion_TlsV13);if(R_FAILED(rc)){error=resultText("No se pudo crear el contexto TLS",rc);return false;}hasContext=true;
        rc=sslContextCreateConnection(&context,&connection);if(R_FAILED(rc)){error=resultText("No se pudo crear la conexión TLS",rc);return false;}hasConnection=true;
        // Keep the libnx descriptor ours; SSL owns/closes its internal duplicate.
        rc=sslConnectionSetOption(&connection,SslOptionType_DoNotCloseSocket,true);if(R_FAILED(rc)){error=resultText("No se pudo configurar el socket TLS",rc);return false;}
        rc=sslConnectionSetHostName(&connection,url.host.c_str(),u32(url.host.size()+1));if(R_FAILED(rc)){error=resultText("No se pudo verificar el nombre TLS",rc);return false;}
        rc=sslConnectionSetVerifyOption(&connection,SslVerifyOption_PeerCa|SslVerifyOption_HostName|SslVerifyOption_DateCheck);if(R_FAILED(rc)){error=resultText("No se pudo exigir la validación TLS completa",rc);return false;}
        errno=0;const int returned=socketSslConnectionSetSocketDescriptor(&connection,fd);if(returned>=0){close(returned);error="El servicio SSL no respetó la propiedad del socket.";return false;}if(errno!=ENOENT){error=resultText("No se pudo asociar el socket TLS",socketGetLastResult());return false;}
        rc=sslConnectionSetIoMode(&connection,SslIoMode_Blocking);if(R_SUCCEEDED(rc))rc=sslConnectionSetIoTimeout(&connection,10000);
        if(R_FAILED(rc)){error=resultText("No se pudo acotar la espera TLS",rc);return false;}
        if(!check(error))return false;
        rc=sslConnectionDoHandshake(&connection,nullptr,nullptr,nullptr,0);if(R_FAILED(rc)){error="HTTPS host="+peer+" etapa=tls/handshake "+resultText("Certificado, nombre o fecha no confirmados",rc)+networkHint();return false;}return check(error);
    }
    bool send(const std::string&request,std::string&error){size_t done=0;while(done<request.size()){if(!check(error))return false;u32 count=0;const auto rc=sslConnectionWrite(&connection,request.data()+done,u32(request.size()-done),&count);if(R_FAILED(rc)||!count||count>request.size()-done){error=resultText("No se pudo enviar la petición HTTPS",rc);return false;}done+=count;}return check(error);}
    int read(void*data,size_t cap,std::string&error){if(!check(error))return -1;u32 count=0;const auto rc=sslConnectionRead(&connection,data,u32(cap),&count);if(R_FAILED(rc)||count>cap){error="HTTPS host="+peer+" etapa=tls/read "+resultText("No se pudo leer la respuesta",rc);return -1;}if(!check(error))return -1;return int(count);}
};
#elif defined(NC_HTTPS_LITE_TEST)
std::function<bool(const Url&,std::string&)> testOpen;
std::function<bool(const std::string&,std::string&)> testSend;
Reader testRead;
bool initialize(std::string&){return true;}
class Connection {
    const std::function<bool()>&cancelled;
public:
    explicit Connection(const std::function<bool()>&c):cancelled(c){}
    bool open(const Url&u,std::string&e){return !aborted(cancelled,e)&&testOpen&&testOpen(u,e);}
    bool send(const std::string&r,std::string&e){return !aborted(cancelled,e)&&testSend&&testSend(r,e);}
    int read(void*p,size_t n,std::string&e){return aborted(cancelled,e)||!testRead?-1:testRead(p,n,e);}
};
#endif
} // detail

bool download(const std::string&url,const std::string&path,Response&response,std::string&error,bool head,uint64_t maxBytes,const std::function<bool()>&cancelled){
    response={};error.clear();detail::Url current;if(!detail::parseUrl(url,current,error)||detail::aborted(cancelled,error))return false;
    if(!head&&(!maxBytes||maxBytes>64ULL*1024*1024||!detail::outputPath(path,error))){if(error.empty())error="Tamaño máximo HTTPS no admitido.";return false;}
#if defined(__SWITCH__) || defined(NC_HTTPS_LITE_TEST)
    if(!detail::initialize(error)){error="HTTPS host="+current.host+" etapa=inicializar "+error;return false;}
    for(unsigned redirects=0;redirects<=5;++redirects){
        detail::Connection connection(cancelled);if(!connection.open(current,error))return false;
        const std::string request=std::string(head?"HEAD ":"GET ")+current.target+" HTTP/1.1\r\nHost: "+current.host+"\r\nUser-Agent: NinMagic-Cheats/1\r\nAccept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n";
        if(!connection.send(request,error))return false;
        detail::Input input([&](void*data,size_t cap,std::string&e){return connection.read(data,cap,e);},cancelled);detail::Headers headers;
        if(!detail::readHeaders(input,headers,error))return false;
        response=headers.response;response.finalUrl=current.canonical;
        if(response.status==301||response.status==302||response.status==303||response.status==307||response.status==308){if(redirects==5){error="Demasiadas redirecciones HTTPS.";return false;}detail::Url next;if(!detail::redirectUrl(current,headers.location,next,error))return false;current=std::move(next);continue;}
        if(response.status!=200){error="La fuente respondió HTTP "+std::to_string(response.status)+".";return false;}
        if(head)return !detail::aborted(cancelled,error);
        const std::string pending=path+".https-part";if(!detail::outputPath(pending,error))return false;
        struct stat st{};if(lstat(pending.c_str(),&st)==0&&unlink(pending.c_str())!=0){error="No se pudo retirar un temporal HTTPS anterior.";return false;}
        const int descriptor=open(pending.c_str(),O_CREAT|O_EXCL|O_WRONLY,0600);if(descriptor<0){error="No se pudo crear el temporal HTTPS en microSD.";return false;}
        FILE*file=fdopen(descriptor,"wb");if(!file){close(descriptor);unlink(pending.c_str());error="No se pudo abrir el temporal HTTPS.";return false;}
        bool ok=detail::readBody(input,headers,[&](const void*data,size_t count){return fwrite(data,1,count,file)==count;},maxBytes,cancelled,response,error);
        if(ok&&(fflush(file)!=0||fsync(fileno(file))!=0)){ok=false;error="No se pudo confirmar la escritura HTTPS en microSD.";}
        if(fclose(file)!=0){ok=false;error="No se pudo cerrar la descarga HTTPS.";}
        if(ok)ok=!detail::aborted(cancelled,error)&&detail::outputPath(path,error);
        if(ok&&rename(pending.c_str(),path.c_str())!=0){ok=false;error="No se pudo activar la descarga HTTPS; se conserva el destino anterior.";}
        if(!ok)unlink(pending.c_str());
        return ok;
    }
#else
    (void)head;(void)maxBytes;error="SSL nativo solo está disponible en la consola.";
#endif
    return false;
}
void shutdown(){
#ifdef __SWITCH__
    if(detail::ssl){sslExit();detail::ssl=false;}if(detail::nifm){nifmExit();detail::nifm=false;}if(detail::sockets){socketExit();detail::sockets=false;}detail::nifmHintResult=0;detail::nifmHintStatus=-1;
#endif
}
} // nc::https_lite

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "catalog.hpp"
#include "cheats.hpp"
#include "archive_merge.hpp"
#include "release_index.hpp"
#include "bad1dea_sources.hpp"
#include <minizip/unzip.h>
#ifdef __SWITCH__
#include <switch.h>
#ifdef NC_PUBLISHED_OVERLAY
#include "https_lite.hpp"
#else
#include <curl/curl.h>
#endif
#endif
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <map>
#include <set>
#include <sstream>
#include <string_view>
#include <sys/stat.h>
#include <unistd.h>
#ifdef NC_CATALOG_TEST
#include <functional>
#endif

namespace nc {
namespace {
constexpr uint64_t MaxArchive=64ULL*1024*1024, MaxFile=2ULL*1024*1024;
constexpr uint64_t MaxExpanded=256ULL*1024*1024;
constexpr size_t MaxEntries=20000, MaxMembers=60000;
const char *GeneralUrl="https://github.com/HamletDuFromage/switch-cheats-db/releases/latest/download/contents_complete.zip";
const char *RawUrl="https://github.com/HamletDuFromage/switch-cheats-db/releases/latest/download/contents.zip";
struct RemoteStamp {std::string etag,modified,length;long status=0;};
#ifdef NC_CATALOG_TEST
bool testNetworkReady=false;
uint64_t testInflatedBytes=0;
std::function<bool(const std::string&,const std::string&,std::string&,RemoteStamp*,bool)> testTransfer;
#endif
#if defined(__SWITCH__) && !defined(NC_PUBLISHED_OVERLAY)
bool socketsReady=false, nifmReady=false, curlReady=false;
std::string networkHint;
#endif
std::function<bool()> queryCancelled;
bool queryStopped(std::string &error){if(queryCancelled&&queryCancelled()){error="Consulta cancelada; se conservan las copias verificadas.";return true;}return false;}

std::string root() {
#ifdef NC_CATALOG_TEST
    const char *value=std::getenv("NC_CATALOG_ROOT");return value?value:"catalog-test";
#else
    return "sdmc:/config/NinMagicCheats";
#endif
}
bool statPath(const std::string &path,struct stat &st) {return lstat(path.c_str(),&st)==0;}
bool regular(const std::string &path,uint64_t max) {
    struct stat st{};return statPath(path,st)&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=max;
}
bool directory(const std::string &path) {
    struct stat st{};
    if(statPath(path,st))return S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);
    if(errno!=ENOENT)return false;
#ifdef _WIN32
    return mkdir(path.c_str())==0;
#else
    return mkdir(path.c_str(),0777)==0;
#endif
}
bool ensureRoot(std::string &error) {
#ifndef NC_CATALOG_TEST
    if(!directory("sdmc:/config")){error="No se puede abrir la carpeta config de la microSD.";return false;}
#endif
    if(!directory(root())){error="No se puede abrir la carpeta de NinMagic Cheats.";return false;}
    return true;
}
bool readSmall(const std::string &path,std::string &out,size_t max) {
    out.clear();if(!regular(path,max))return false;
    FILE *f=fopen(path.c_str(),"rb");if(!f)return false;
    std::array<char,4096> b{};size_t n;
    while((n=fread(b.data(),1,b.size(),f))) {if(out.size()+n>max){fclose(f);return false;}out.append(b.data(),n);}
    bool ok=!ferror(f);fclose(f);return ok;
}
bool writeSmall(const std::string &path,const std::string &text) {
    struct stat st{};if(statPath(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;
    FILE *f=fopen(path.c_str(),"wb");if(!f)return false;
    bool ok=fwrite(text.data(),1,text.size(),f)==text.size()&&fflush(f)==0;
    if(ok)ok=fsync(fileno(f))==0;
    if(fclose(f)!=0)ok=false;
    return ok;
}
std::string upper(std::string value) {
    for(char &c:value)c=char(std::toupper(static_cast<unsigned char>(c)));
    return value;
}
bool hex16(const std::string &value) {
    return value.size()==16&&std::all_of(value.begin(),value.end(),[](unsigned char c){return std::isxdigit(c)!=0;});
}
enum class ArchiveProfile { Canonical, Arch9 };
bool memberIdentity(const std::string &path,uint64_t &title,std::string &build) {
    if(path.empty()||path.size()>512||path[0]=='/'||path.find('\\')!=std::string::npos||path.find(':')!=std::string::npos)return false;
    // This helper is used for every central-directory member on the overlay.
    // Avoid iostream locale facets and per-component allocations.
    std::array<std::string_view,5> parts{};size_t count=0,at=0;
    while(at<path.size()){
        const auto end=path.find('/',at);const auto length=(end==std::string::npos?path.size():end)-at;
        const std::string_view part(path.data()+at,length);
        if(count==parts.size()||part.empty()||part=="."||part=="..")return false;
        parts[count++]=part;if(end==std::string::npos)break;at=end+1;
    }
    // Releases use contents/<TID>/cheats/<BID>.txt. GitHub's source ZIP adds
    // one repository folder before titles/. Mirrors may omit that folder.
    size_t p=0;
    if(count==5&&(parts[1]=="titles"||parts[1]=="contents"))p=1;
    const auto isHex=[](std::string_view value){return value.size()==16&&std::all_of(value.begin(),value.end(),[](unsigned char c){return std::isxdigit(c)!=0;});};
    if(count!=p+4||(parts[p]!="contents"&&parts[p]!="titles")||!isHex(parts[p+1])||parts[p+2]!="cheats")return false;
    const auto filename=parts[p+3];
    if(filename.size()!=20||upper(std::string(filename.substr(16)))!=".TXT"||!isHex(filename.substr(0,16)))return false;
    title=0;for(unsigned char c:parts[p+1]){c=static_cast<unsigned char>(std::toupper(c));title=(title<<4)|(c<='9'?c-'0':c-'A'+10);}
    if(title<0x0100000000010000ULL)return false;
    build=upper(std::string(filename.substr(0,16)));return build!="0000000000000000";
}
bool archiveIdentity(const std::string &path,uint64_t &title,std::string &build,ArchiveProfile profile){
    if(profile==ArchiveProfile::Canonical)return memberIdentity(path,title,build);
    if(path.empty()||path.size()>512||path[0]=='/'||path.back()=='/'||path.find('\\')!=std::string::npos||path.find(':')!=std::string::npos||std::any_of(path.begin(),path.end(),[](unsigned char c){return c<32||c==127;}))return false;
    std::array<std::string_view,5> parts{};size_t count=0,at=0;
    while(at<path.size()){
        const auto end=path.find('/',at);const auto length=(end==path.npos?path.size():end)-at;const std::string_view part(path.data()+at,length);
        if(count==parts.size()||part.empty()||part=="."||part=="..")return false;
        parts[count++]=part;if(end==path.npos)break;at=end+1;
    }
    if(count!=5||parts[0]!="MyNXCheats-main"||parts[3]!="cheats"||!hex16(std::string(parts[2])))return false;
    // Route only this explicitly named author profile into the existing strict
    // canonical identity parser. The general archive grammar is unchanged.
    return memberIdentity("contents/"+std::string(parts[2])+"/cheats/"+std::string(parts[4]),title,build);
}
bool unsupportedAuthorMember(const std::string &path,ArchiveProfile profile){
    if(profile!=ArchiveProfile::Arch9)return false;
    auto name=upper(path);for(char &c:name)if(c=='\\')c='/';const auto dot=name.find_last_of('.');
    if(dot!=name.npos&&(name.substr(dot)==".IPS"||name.substr(dot)==".IPS32"||name.substr(dot)==".PCHTXT"||name.substr(dot)==".7Z"))return true;
    return name.find("/EXEFS_PATCHES/")!=name.npos||name.find("/ROMFS/")!=name.npos||name.find("/EXEFS/")!=name.npos;
}
bool currentFile(unzFile zip,std::string &out,std::string &error) {
    unz_file_info64 info{};
    if(unzGetCurrentFileInfo64(zip,&info,nullptr,0,nullptr,0,nullptr,0)!=UNZ_OK||info.uncompressed_size>MaxFile||(info.flag&1)||(info.compression_method!=0&&info.compression_method!=8)) {
        error="El catálogo contiene un archivo no admitido o demasiado grande.";return false;
    }
    if(unzOpenCurrentFile(zip)!=UNZ_OK){error="No se puede abrir un cheat del catálogo.";return false;}
    out.clear();out.reserve(size_t(info.uncompressed_size));std::array<char,16384> buffer{};
    int n=0;bool ok=true;
    while((n=unzReadCurrentFile(zip,buffer.data(),unsigned(buffer.size())))>0) {
#ifdef NC_CATALOG_TEST
        testInflatedBytes+=uint64_t(n);
#endif
        if(out.size()+size_t(n)>MaxFile){ok=false;break;}out.append(buffer.data(),size_t(n));
    }
    const int closed=unzCloseCurrentFile(zip);
    if(n<0||closed!=UNZ_OK||out.size()!=info.uncompressed_size)ok=false;
    if(!ok)error="Catálogo dañado: el tamaño o el CRC del archivo no coincide.";
    return ok;
}
bool indexArchive(const std::string &file,const std::string &source,std::vector<CatalogEntry> &entries,std::string &error,bool verify,bool manual=false,ArchiveProfile profile=ArchiveProfile::Canonical) {
    if(!regular(file,MaxArchive)){error="Falta el archivo de catálogo de "+source+".";return false;}
    unzFile zip=unzOpen64(file.c_str());
    if(!zip){error="El catálogo de "+source+" no es un ZIP válido.";return false;}
    unz_global_info64 global{};bool ok=unzGetGlobalInfo64(zip,&global)==UNZ_OK&&global.number_entry>0&&global.number_entry<=MaxMembers;
    std::set<std::pair<uint64_t,std::string>> unique;size_t start=entries.size();uint64_t expanded=0;
    int result=ok?unzGoToFirstFile(zip):UNZ_BADZIPFILE;
    for(uint64_t i=0;ok&&i<global.number_entry;++i) {
        unz_file_info64 info{};std::array<char,1024> name{};
        if(result!=UNZ_OK||unzGetCurrentFileInfo64(zip,&info,name.data(),unsigned(name.size()),nullptr,0,nullptr,0)!=UNZ_OK||info.size_filename>=name.size()||std::strlen(name.data())!=info.size_filename) {ok=false;break;}
        if(unsupportedAuthorMember(name.data(),profile)){error="La fuente de autor contiene un parche o archivo 7z; no se importará como cheats independientes.";ok=false;break;}
        std::string checked;
        if(manual){const unsigned type=(info.external_fa>>16)&0xf000;if(info.uncompressed_size>MaxFile||(type!=0&&type!=0x8000&&type!=0x4000)||!currentFile(zip,checked,error)){ok=false;break;}}
        expanded+=info.uncompressed_size;
        if(expanded>MaxExpanded){ok=false;break;}
        uint64_t title=0;std::string build;
        if(archiveIdentity(name.data(),title,build,profile)) {
            const auto type=(info.external_fa>>16)&0xf000;
            if(profile==ArchiveProfile::Arch9&&type&&type!=0x8000){ok=false;break;}
            if(entries.size()-start>=MaxEntries||!unique.emplace(title,build).second){error="Catálogo ambiguo: contiene un Build ID duplicado.";ok=false;break;}
            if(info.uncompressed_size==0||info.uncompressed_size>MaxFile||(info.flag&1)||(info.compression_method!=0&&info.compression_method!=8)){ok=false;break;}
            if(verify&&!manual) {std::string data;if(!currentFile(zip,data,error)){ok=false;break;}}
            if(manual){std::vector<Cheat> parsed;if(!parseCheats(checked,source,parsed,error)){ok=false;break;}}
            CatalogEntry entry;entry.titleId=title;entry.buildId=build;entry.source=source;entry.path=name.data();entry.archive=file;entries.push_back(std::move(entry));
        }
        result=unzGoToNextFile(zip);
    }
    if(result!=UNZ_END_OF_LIST_OF_FILE)ok=false;
    unzClose(zip);
    if(!ok||entries.size()==start) {
        entries.resize(start);if(error.empty())error="El catálogo de "+source+" está vacío, dañado o supera los límites.";return false;
    }
    return true;
}
void appendManual(Catalog &catalog){
    const auto path=root()+"/manual-cheats.zip";struct stat st{};
    if(!statPath(path,st)&&errno==ENOENT)return;
    std::vector<CatalogEntry> imported;std::string error;
    if(!indexArchive(path,"Importacion local",imported,error,true,true)){catalog.detail+=" · Importación local omitida: "+error;return;}
    catalog.entries.insert(catalog.entries.end(),imported.begin(),imported.end());
    catalog.detail+=" · "+std::to_string(imported.size())+" versiones de importación local";
}
bool loadSlot(char slot,Catalog &catalog,std::string &error,bool verify=false) {
    std::string path=root()+"/catalog-"+slot,complete;
    struct stat parent{};
    if(!statPath(path,parent)||!S_ISDIR(parent.st_mode)||S_ISLNK(parent.st_mode)){error="No existe una carpeta válida de catálogo.";return false;}
    if(!readSmall(path+"/complete.txt",complete,128)){error="El catálogo local todavía no está completo.";return false;}
    complete.erase(std::remove(complete.begin(),complete.end(),'\r'),complete.end());
    if(complete.rfind("NINMAGIC-CATALOG-1\n",0)!=0){error="El catálogo local todavía no está completo.";return false;}
    Catalog next;
    if(!indexArchive(path+"/general.zip","Hamlet",next.entries,error,verify))return false;
    next.generalReady=true;next.graphicsReady=false;
    auto newline=complete.find('\n',19);next.stamp=complete.substr(19,newline==std::string::npos?std::string::npos:newline-19);
    if(next.stamp.empty())next.stamp="Caché local";
    next.detail=std::to_string(next.entries.size())+" versiones de cheats publicados · fuente FPS/gráficos retirada";
    appendManual(next);
    catalog=std::move(next);return true;
}
char activeSlot() {std::string s;return readSmall(root()+"/active.txt",s,8)&&!s.empty()&&s[0]=='b'?'b':'a';}
bool safeUrl(const std::string &url) {
    if(url.size()<9||url.size()>2048||url.rfind("https://",0)!=0)return false;
    auto end=url.find('/',8);std::string host=url.substr(8,end==std::string::npos?std::string::npos:end-8);
    return !host.empty()&&host.find('@')==std::string::npos&&std::none_of(url.begin(),url.end(),[](unsigned char c){return c<=32||c==127||c=='\\';});
}
std::string trim(std::string v) {auto p=v.find_first_not_of(" \t\r\n");if(p==std::string::npos)return {};auto q=v.find_last_not_of(" \t\r\n");return v.substr(p,q-p+1);}
bool sourceUrls(std::string &general,std::string &graphics,std::string &error,std::string *raw=nullptr) {
    general=GeneralUrl;graphics.clear();if(raw)*raw=RawUrl;std::string contents,customRaw;
    struct stat st{};
    if(!statPath(root()+"/sources.ini",st))return errno==ENOENT;
    if(!readSmall(root()+"/sources.ini",contents,8192)){error="No se puede leer sources.ini.";return false;}
    size_t at=0;
    while(at<contents.size()) {
        const auto end=contents.find('\n',at);std::string line=trim(contents.substr(at,(end==std::string::npos?contents.size():end)-at));at=end==std::string::npos?contents.size():end+1;
        if(line.empty()||line[0]=='#'||line[0]==';')continue;
        size_t eq=line.find('=');if(eq==std::string::npos){error="Línea inválida en sources.ini.";return false;}
        std::string key=trim(line.substr(0,eq)),value=trim(line.substr(eq+1));
        if(key=="graphics_url")continue; // Legacy option: never consulted.
        if(key!="general_url"&&key!="graphics_url"&&key!="raw_url"){error="Opción desconocida en sources.ini: "+key;return false;}
        if(!safeUrl(value)){error="Las fuentes deben ser URLs HTTPS válidas.";return false;}
        if(key=="raw_url")customRaw=value;else general=value;
    }
    if(raw)*raw=!customRaw.empty()?customRaw:general==GeneralUrl?RawUrl:"";
    return true;
}
#if defined(__SWITCH__) && defined(NC_PUBLISHED_OVERLAY)
bool networkInit(std::string &error){error.clear();return !queryStopped(error);}
bool download(const std::string &url,const std::string &path,std::string &error,RemoteStamp *remote=nullptr,bool head=false,uint64_t limit=MaxArchive){
    if(!safeUrl(url)){error="URL de catálogo inválida.";return false;}
    https_lite::Response response;
    const bool ok=https_lite::download(url,path,response,error,head,limit,queryCancelled);
    if(remote)*remote={response.etag,response.modified,response.length,response.status};
    return ok;
}
#elif defined(__SWITCH__)
struct Download {FILE *file=nullptr;uint64_t written=0,limit=MaxArchive;};
size_t header(char *bytes,size_t size,size_t count,void *user) {
    if(size&&count>SIZE_MAX/size)return 0;
    size_t length=size*count;if(length>16384)return 0;
    auto &stamp=*static_cast<RemoteStamp*>(user);std::string line(bytes,length);
    if(line.rfind("HTTP/",0)==0){stamp={};return length;}
    auto colon=line.find(':');if(colon==std::string::npos)return length;
    std::string key=upper(trim(line.substr(0,colon))),value=trim(line.substr(colon+1));
    if(value.size()>512||std::any_of(value.begin(),value.end(),[](unsigned char c){return c<32||c==127;}))return length;
    if(key=="ETAG")stamp.etag=value;else if(key=="LAST-MODIFIED")stamp.modified=value;else if(key=="CONTENT-LENGTH")stamp.length=value;
    return length;
}
size_t receive(void *ptr,size_t size,size_t count,void *user) {
    auto &download=*static_cast<Download*>(user);
    if(size&&count>SIZE_MAX/size)return 0;
    size_t bytes=size*count;
    if(bytes>download.limit-download.written)return 0;
    size_t n=fwrite(ptr,1,bytes,download.file);download.written+=n;return n;
}
bool networkInit(std::string &error) {
    if(!socketsReady) {Result rc=socketInitializeDefault();if(R_FAILED(rc)){char value[32];std::snprintf(value,sizeof(value),"0x%08lX",static_cast<unsigned long>(rc));error="No se puede abrir BSD para HTTPS ("+std::string(value)+").";return false;}socketsReady=true;}
    Result rc=0;
    if(!nifmReady) {rc=nifmInitialize(NifmServiceType_User);nifmReady=R_SUCCEEDED(rc);}
    NifmInternetConnectionType type{};u32 strength=0;NifmInternetConnectionStatus status{};
    if(nifmReady)rc=nifmGetInternetConnectionStatus(&type,&strength,&status);
    char hint[96];std::snprintf(hint,sizeof(hint),"NIFM rc=0x%08lX estado=%d",static_cast<unsigned long>(rc),nifmReady&&R_SUCCEEDED(rc)?int(status):-1);networkHint=hint;
    // NIFM reports Nintendo's connection state, not reachability of the HTTPS
    // host. A blocked connectivity test must not suppress the bounded request.
    if(!curlReady) {if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK){error="No se puede abrir HTTPS.";return false;}curlReady=true;}
    return true;
}
bool download(const std::string &url,const std::string &path,std::string &error,RemoteStamp *remote=nullptr,bool head=false,uint64_t limit=MaxArchive) {
    if(!safeUrl(url)){error="URL de catálogo inválida.";return false;}
    struct stat st{};if(!head&&statPath(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La ruta del catálogo no es un archivo regular.";return false;}
    FILE *f=head?nullptr:fopen(path.c_str(),"wb");if(!head&&!f){error="No se puede escribir el catálogo en la microSD.";return false;}
    CURL *curl=curl_easy_init();if(!curl){if(f)fclose(f);error="No se puede iniciar la descarga.";return false;}
    Download d{f,0,limit};char detail[CURL_ERROR_SIZE]{};RemoteStamp stamp;
    curl_easy_setopt(curl,CURLOPT_URL,url.c_str());
    curl_easy_setopt(curl,CURLOPT_USERAGENT,"NinMagic-Cheats");
    curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,1L);
    curl_easy_setopt(curl,CURLOPT_MAXREDIRS,5L);
    curl_easy_setopt(curl,CURLOPT_PROTOCOLS,long(CURLPROTO_HTTPS));
    curl_easy_setopt(curl,CURLOPT_REDIR_PROTOCOLS,long(CURLPROTO_HTTPS));
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);
    curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,20L);
    curl_easy_setopt(curl,CURLOPT_TIMEOUT,180L);
    curl_easy_setopt(curl,CURLOPT_LOW_SPEED_LIMIT,512L);
    curl_easy_setopt(curl,CURLOPT_LOW_SPEED_TIME,30L);
    curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L);
    curl_easy_setopt(curl,CURLOPT_FAILONERROR,1L);
    curl_easy_setopt(curl,CURLOPT_MAXFILESIZE_LARGE,curl_off_t(limit));
    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,receive);
    curl_easy_setopt(curl,CURLOPT_WRITEDATA,&d);
    curl_easy_setopt(curl,CURLOPT_ERRORBUFFER,detail);
    curl_easy_setopt(curl,CURLOPT_HEADERFUNCTION,header);
    curl_easy_setopt(curl,CURLOPT_HEADERDATA,&stamp);
    if(head)curl_easy_setopt(curl,CURLOPT_NOBODY,1L);
    CURLcode result=curl_easy_perform(curl);long status=0;curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&status);
    curl_easy_cleanup(curl);bool ok=result==CURLE_OK&&status==200&&(head||d.written>0);
    if(f){if(fflush(f)!=0)ok=false;if(ok&&fsync(fileno(f))!=0)ok=false;if(fclose(f)!=0)ok=false;}
    stamp.status=status;if(remote)*remote=stamp;
    if(!ok){
        if(!head)unlink(path.c_str());
        if(result==CURLE_OK)error="La descarga no contiene un ZIP válido (HTTP "+std::to_string(status)+").";
        else error="No se pudo descargar el catálogo por HTTPS: "+std::string(detail[0]?detail:curl_easy_strerror(result));
        if(!status&&!networkHint.empty())error+=" ("+networkHint+").";
    }
    return ok;
}
#else
bool networkInit(std::string &error) {
#ifdef NC_CATALOG_TEST
    if(testNetworkReady)return true;
#endif
    error="La sincronización de red solo está disponible en Switch.";return false;
}
bool download(const std::string &url,const std::string &path,std::string &error,RemoteStamp *remote=nullptr,bool head=false,uint64_t limit=MaxArchive) {
#ifdef NC_CATALOG_TEST
    if(testTransfer){const bool ok=testTransfer(url,path,error,remote,head);return ok&&(head||regular(path,limit));}
#else
    (void)url;(void)path;(void)error;(void)remote;(void)head;(void)limit;
#endif
    return false;
}
#endif
std::string stampText(const std::string &url,const RemoteStamp &stamp){return std::string("NMCREMOTE1\n")+url+"\n"+stamp.etag+"\n"+stamp.modified+"\n"+stamp.length+"\n";}
bool unchanged(const std::string &file,const std::string &url,const RemoteStamp &stamp){std::string previous;return (!stamp.etag.empty()||!stamp.modified.empty())&&readSmall(file,previous,4096)&&previous==stampText(url,stamp);}
struct Seen {std::string published,signature;};
using SeenMap=std::map<uint64_t,Seen>;
bool readSeen(const std::string &file,SeenMap &seen){
    seen.clear();std::string data;if(!readSmall(file,data,256*1024))return false;std::istringstream input(data);std::string header;if(!std::getline(input,header)||header!="NMCRELEASES1")return false;
    uint64_t id=0;std::string published,signature;
    while(input>>id>>published>>signature){if(!id||published.size()>64||signature.size()!=16||!hex16(signature)||seen.size()>=10000||seen.count(id))return false;seen[id]={published,signature};}
    return input.eof()&&!seen.empty();
}
std::string seenText(const SeenMap &seen){std::string data="NMCRELEASES1\n";for(const auto &row:seen)data+=std::to_string(row.first)+" "+row.second.published+" "+row.second.signature+"\n";return data;}
bool publishedReleases(std::vector<CheatRelease> &releases,std::string &error){
    releases.clear();
    for(unsigned page=1;page<=20;++page){const std::string file=root()+"/release-index.pending";const std::string url="https://api.github.com/repos/HamletDuFromage/switch-cheats-db/releases?per_page=100&page="+std::to_string(page);if(!download(url,file,error))return false;std::string json;bool loaded=readSmall(file,json,8*1024*1024);unlink(file.c_str());std::vector<CheatRelease> batch;if(!loaded||!parseCheatReleases(json,batch,error)){if(error.empty())error="No se pudo leer el historial publicado de cheats.";return false;}size_t count=batch.size();releases.insert(releases.end(),batch.begin(),batch.end());if(count<100){std::sort(releases.begin(),releases.end(),[](const auto &a,const auto &b){return a.published<b.published||(a.published==b.published&&a.id<b.id);});return true;}}
    error="El historial supera el límite de páginas de esta versión.";return false;
}
bool removeOutput(const std::string &path,std::string &error){struct stat st{};if(!statPath(path,st)){if(errno==ENOENT)return true;error="No se pudo revisar un archivo temporal de caché.";return false;}if(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||unlink(path.c_str())!=0){error="La caché contiene una ruta temporal no admitida.";return false;}return true;}
bool mergeInto(const std::vector<std::string> &inputs,const std::string &output,std::string &error){
    if(inputs.empty()){error="No hay archivos de cheats que combinar.";return false;}std::vector<std::string> chunk;std::string previous;unsigned part=0;
    for(size_t at=0;at<inputs.size();){chunk.clear();if(!previous.empty())chunk.push_back(previous);while(at<inputs.size()&&chunk.size()<8)chunk.push_back(inputs[at++]);const std::string target=at==inputs.size()?output:output+".merge-"+std::to_string(part++);if(!removeOutput(target,error)||!mergeCheatArchives(chunk,target,error))return false;if(!previous.empty()&&!removeOutput(previous,error))return false;previous=target;}
    return true;
}
const char *NxCodeUrl="https://github.com/tomvita/NXCheatCode/releases/latest/download/titles.zip";
const char *SthetixUrl="https://github.com/sthetix/nx-cheats-db/releases/latest/download/contents_complete.zip";
const char *Arch9Url="https://codeload.github.com/Arch9SK7/MyNXCheats/zip/refs/heads/main";
constexpr time_t SourceTtl=6*60*60;
struct GameProvider {std::string key,name,url;};
bool providerGame(const Game &game){return game.id>=0x0100000000010000ULL&&game.buildVerified&&validBuild(game.buildId);}
std::vector<GameProvider> gameProviders(const Game &game){
    const auto tid=hexId(game.id),bid=upper(game.buildId);std::string lower=bid;
    for(char &c:lower)c=char(std::tolower(static_cast<unsigned char>(c)));
    std::vector<GameProvider> result={{"mynx","Tomvita/MyNXCheats","https://github.com/tomvita/MyNXCheats/releases/download/"+tid+"/"+bid+".txt"},
            {"ibnux","ibnux/switch-cheat","https://raw.githubusercontent.com/ibnux/switch-cheat/master/atmosphere/titles/"+tid+"/cheats/"+lower+".txt"},
            {"oldmankain","OldManKain/Switch-Cheats-Mods-Saves","https://raw.githubusercontent.com/OldManKain/Switch-Cheats-Mods-Saves/main/Titles/"+tid+"/cheats/"+bid+".txt"}};
    if(game.id==0x010015100B514000ULL&&bid=="FF773E90972D544E")result.push_back({"oblivion-wonder","OblivionReign/GBATemp","https://raw.githubusercontent.com/ANE-JV/ninmagic-cheats/main/catalog/oblivionreign/contents/010015100B514000/cheats/FF773E90972D544E.txt"});
    for(const auto &entry:catalog_sources::Bad1dea)if(entry.title==game.id&&bid==entry.build)result.push_back({"bad1dea-54fc969","bad1dea/NXCheats (revisión 54fc969)",entry.url});
    return result;
}
bool downloadProvider(const GameProvider &provider,const std::string &path,std::string &error,RemoteStamp &remote,uint64_t limit,std::string &usedUrl){
    usedUrl=provider.url;
    if(download(usedUrl,path,error,&remote,false,limit))return true;
    if(provider.key!="oldmankain"||remote.status!=404||queryStopped(error))return false;
    std::string lower=provider.url;for(size_t i=lower.size()-20;i<lower.size()-4;++i)lower[i]=char(std::tolower(static_cast<unsigned char>(lower[i])));
    if(lower==provider.url)return false;
    usedUrl=lower;error.clear();return download(usedUrl,path,error,&remote,false,limit);
}
std::string providerRoot(){return root()+"/published-sources";}
bool providerDirectoryExists(){struct stat st{};return statPath(providerRoot(),st)&&S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);}
std::string providerPath(const Game &game,const GameProvider &provider){return providerRoot()+"/"+provider.key+"-"+hexId(game.id)+"-"+upper(game.buildId)+".cache";}
std::string crcText(const std::string &text){return hexId(uint64_t(crc32(0,reinterpret_cast<const Bytef*>(text.data()),uInt(text.size()))));}
bool providerText(const Game &game,const GameProvider &provider,const std::string &path,std::string &text){
    std::string data;if(!readSmall(path,data,size_t(MaxFile)+4096))return false;
    std::istringstream input(data);std::string magic,key,tid,bid,url,crc;
    if(!std::getline(input,magic)||!std::getline(input,key)||!std::getline(input,tid)||!std::getline(input,bid)||!std::getline(input,url)||!std::getline(input,crc)||magic!="NMCPUBLISHED1"||key!=provider.key||tid!=hexId(game.id)||bid!=upper(game.buildId)||url!=provider.url)return false;
    const auto at=input.tellg();if(at<0)return false;text=data.substr(size_t(at));
    if(text.empty()||text.size()>MaxFile||crc!=crcText(text))return false;
    std::vector<Cheat> parsed;std::string error;return parseCheats(text,provider.name,parsed,error);
}
bool cachedText(const Game &game,const GameProvider &provider,std::string &text){
    if(!providerDirectoryExists())return false;
    const auto file=providerPath(game,provider);return providerText(game,provider,file,text)||providerText(game,provider,file+".previous",text);
}
bool recentCheck(const std::string &path,const std::string &url){
    std::string data;if(!readSmall(path,data,4096))return false;
    const auto prefix=std::string("NMCCHECK1\n")+url+"\n";
    if(data.rfind(prefix,0)!=0)return false;
    const auto number=trim(data.substr(prefix.size()));if(number.empty()||number.size()>20||!std::all_of(number.begin(),number.end(),[](unsigned char c){return std::isdigit(c)!=0;}))return false;
    char *end=nullptr;errno=0;const auto value=strtoull(number.c_str(),&end,10);const auto now=std::time(nullptr);
    return !errno&&end&&!*end&&now>0&&value<=uint64_t(now)&&uint64_t(now)-value<uint64_t(SourceTtl);
}
bool markChecked(const std::string &path,const std::string &url){return writeSmall(path,"NMCCHECK1\n"+url+"\n"+std::to_string(std::time(nullptr))+"\n");}
bool promoteSource(const std::string &pending,const std::string &target,std::string &error,bool currentVerified=true){
    struct stat st{};const bool exists=statPath(target,st);
    if(exists&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La caché del proveedor no es un archivo regular.";return false;}
    if(exists&&currentVerified){
        if(!removeOutput(target+".previous",error))return false;
        if(rename(target.c_str(),(target+".previous").c_str())!=0){error="No se pudo conservar la copia anterior del proveedor.";return false;}
    }else if(exists&&unlink(target.c_str())!=0){error="No se pudo apartar la caché dañada del proveedor.";return false;}
    // A previous-only cache is the recovery copy, not disposable scratch.
    if(rename(pending.c_str(),target.c_str())!=0){if(exists&&currentVerified)rename((target+".previous").c_str(),target.c_str());error="No se pudo activar la caché del proveedor; se conserva la anterior.";return false;}
    return true;
}
// Iterate the central directory only; no repository paths are ever extracted.
// Filtering by Title ID here avoids adding thousands of optional entries to RAM.
bool archiveGameEntries(const std::string &path,const Game &game,std::vector<CatalogEntry> &entries,std::string &error,const std::string &source="Tomvita/NXCheatCode",ArchiveProfile profile=ArchiveProfile::Canonical){
    if(!regular(path,MaxArchive))return false;
    unzFile zip=unzOpen64(path.c_str());if(!zip)return false;unz_global_info64 global{};
    bool ok=unzGetGlobalInfo64(zip,&global)==UNZ_OK&&global.number_entry>0&&global.number_entry<=MaxMembers;
    int next=ok?unzGoToFirstFile(zip):UNZ_BADZIPFILE;const auto start=entries.size();std::set<std::string> unique;
    for(uint64_t n=0;ok&&n<global.number_entry;++n){
        unz_file_info64 info{};std::array<char,1024> name{};
        if(next!=UNZ_OK||unzGetCurrentFileInfo64(zip,&info,name.data(),unsigned(name.size()),nullptr,0,nullptr,0)!=UNZ_OK||info.size_filename>=name.size()||strlen(name.data())!=info.size_filename){ok=false;break;}
        if(unsupportedAuthorMember(name.data(),profile)){ok=false;break;}
        uint64_t tid=0;std::string bid;
        if(archiveIdentity(name.data(),tid,bid,profile)&&tid==game.id){
            const auto type=(info.external_fa>>16)&0xf000;
            if(profile==ArchiveProfile::Arch9&&type&&type!=0x8000){ok=false;break;}
            if(entries.size()-start>=1000||!unique.insert(bid).second){ok=false;break;}
            CatalogEntry entry;entry.titleId=tid;entry.buildId=bid;entry.source=source;entry.archive=path;entry.path=name.data();entries.push_back(std::move(entry));
        }
        next=unzGoToNextFile(zip);
    }
    if(next!=UNZ_END_OF_LIST_OF_FILE)ok=false;
    unzClose(zip);if(!ok){entries.resize(start);error="El índice de "+source+" está dañado o es ambiguo.";}return ok;
}
bool archiveCachedEntries(const Game &game,const std::string &key,const std::string &source,std::vector<CatalogEntry> &entries,std::string &error,std::string *used=nullptr,ArchiveProfile profile=ArchiveProfile::Canonical){
    if(!providerDirectoryExists())return false;
    const auto path=providerRoot()+"/"+key+".zip";
    const auto start=entries.size();
    const auto usable=[&](const std::string &file){
        if(!archiveGameEntries(file,game,entries,error,source,profile))return false;
        if(profile==ArchiveProfile::Arch9){
            for(size_t i=start;i<entries.size();++i)if(entries[i].buildId==upper(game.buildId)){
                unzFile zip=unzOpen64(file.c_str());std::string text;std::vector<Cheat> parsed;
                const bool valid=zip&&unzLocateFile(zip,entries[i].path.c_str(),1)==UNZ_OK&&currentFile(zip,text,error)&&parseCheats(text,source,parsed,error);
                if(zip)unzClose(zip);
                if(!valid){entries.resize(start);if(error.empty())error="El archivo de autor guardado no es válido para este Build ID.";return false;}
                break;
            }
        }
        return true;
    };
    if(usable(path)){if(used)*used=path;return true;}
    if(usable(path+".previous")){if(used)*used=path+".previous";return true;}
    return false;
}
bool nxEntries(const Game &game,std::vector<CatalogEntry> &entries,std::string &error,std::string *used=nullptr){return archiveCachedEntries(game,"nxcheatcode","Tomvita/NXCheatCode",entries,error,used);}
void appendSourceCheats(Pack &pack,std::vector<Cheat> cheats,const std::string &group){
    std::vector<std::vector<uint32_t>> masters;for(const auto &c:cheats)if(c.master)masters.push_back(c.opcodes);
    for(auto &cheat:cheats){
        cheat.group=group;
        auto duplicate=pack.cheats.end();
        if(!cheat.master)duplicate=std::find_if(pack.cheats.begin(),pack.cheats.end(),[&](const Cheat &existing){
            if(existing.master||existing.opcodes!=cheat.opcodes)return false;
            std::vector<std::vector<uint32_t>> previousMasters;
            for(const auto &m:pack.cheats)if(m.master&&m.group==existing.group)previousMasters.push_back(m.opcodes);
            return previousMasters==masters;
        });
        if(duplicate!=pack.cheats.end()){
            if(duplicate->source.find(cheat.source)==std::string::npos)duplicate->source+=" / "+cheat.source;
        }else pack.cheats.push_back(std::move(cheat));
    }
}
constexpr size_t DirectText=64*1024,DirectEntries=128,DirectWords=8192;
bool directIdentity(const Game &game){return providerGame(game)&&game.fullBuildId.size()==64&&upper(game.fullBuildId).find_first_not_of("0123456789ABCDEF")==std::string::npos&&upper(game.fullBuildId.substr(0,16))==upper(game.buildId);}
std::string_view stripView(std::string_view value){const auto first=value.find_first_not_of(" \t\r\n");return first==value.npos?std::string_view{}:value.substr(first,value.find_last_not_of(" \t\r\n")-first+1);}
// The overlay parser keeps one input buffer. The general parser deliberately
// allows larger source files and copies its input, so it is not used here.
bool parseDirect(const std::string &text,const std::string &source,std::vector<Cheat> &out,std::string &error){
    out.clear();error.clear();if(text.empty()||text.size()>DirectText||text.find('\0')!=std::string::npos){error="Este archivo supera el límite de texto del overlay o contiene datos binarios.";return false;}
    Cheat current;bool header=false;size_t words=0,headers=0;
    const auto fail=[&](const char *message){out.clear();error=message;return false;};
    const auto finish=[&](){if(header&&!current.opcodes.empty())out.push_back(std::move(current));current={};};
    size_t at=text.compare(0,3,"\xef\xbb\xbf")==0?3:0;
    while(at<text.size()){
        if(queryStopped(error)){out.clear();return false;}
        const auto end=text.find('\n',at);const auto length=(end==std::string::npos?text.size():end)-at;
        auto line=stripView(std::string_view(text.data()+at,length));at=end==std::string::npos?text.size():end+1;
        if(line.size()>16384)return fail("Una línea publicada supera el límite del overlay.");
        if(line.empty()||line[0]=='#'||line[0]==';'||line.substr(0,2)=="//")continue;
        if(line[0]=='['||line[0]=='{'){
            const char closing=line[0]=='['?']':'}';if(line.size()<3||line.back()!=closing||++headers>DirectEntries)return fail("Cabecera inválida o más de 128 definiciones en una fuente del overlay.");
            finish();auto name=stripView(line.substr(1,line.size()-2));size_t n=std::min<size_t>(63,name.size());while(n<name.size()&&n&&(static_cast<unsigned char>(name[n])&0xc0)==0x80)--n;
            current.name.assign(name.data(),n);if(current.name.empty()||current.name.find_first_of("[]{}")!=std::string::npos||std::any_of(current.name.begin(),current.name.end(),[](unsigned char c){return c<32||c==127;}))return fail("Nombre de cheat no admitido.");
            current.source=source;current.group=source;current.master=closing=='}';current.categories=classifyCheat(current.name);header=true;continue;
        }
        if(!header)return fail("Instrucciones publicadas sin cabecera.");
        while(!line.empty()){
            const auto endWord=line.find_first_of(" \t\r");const auto token=line.substr(0,endWord);
            if(token[0]=='#'||token[0]==';'||token.substr(0,2)=="//")break;
            if(token.size()!=8||!std::all_of(token.begin(),token.end(),[](unsigned char c){return std::isxdigit(c)!=0;}))return fail("La fuente contiene una instrucción inválida.");
            uint32_t value=0;for(unsigned char c:token)value=(value<<4)|(c<='9'?c-'0':std::toupper(c)-'A'+10);
            current.opcodes.push_back(value);if(current.opcodes.size()>256||++words>DirectWords)return fail("Las instrucciones publicadas superan el presupuesto del overlay.");
            line=endWord==line.npos?std::string_view{}:stripView(line.substr(endWord));
        }
    }
    finish();if(out.empty())return fail("La fuente no contiene cheats utilizables.");return true;
}
bool directAppend(Pack &pack,std::vector<Cheat> data,const std::string &group,std::string &error){
    data.erase(std::remove_if(data.begin(),data.end(),[](const Cheat &c){return !c.master&&(c.categories&(Fps|Resolution|Graphics));}),data.end());
    if(std::none_of(data.begin(),data.end(),[](const Cheat &c){return !c.master;}))return true;
    size_t words=0;for(const auto &c:pack.cheats)words+=c.opcodes.size();for(const auto &c:data)words+=c.opcodes.size();
    if(pack.cheats.size()+data.size()>DirectEntries||words>DirectWords){error="La lista combinada supera 128 definiciones u 8192 palabras. Esta fuente no se añadió; no se recortaron opciones ni maestros.";return false;}
    appendSourceCheats(pack,std::move(data),group);return true;
}
bool readDirectFile(const std::string &path,std::string &text){
    text.clear();struct stat st{};if(!statPath(path,st)||!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||st.st_size<=0||uint64_t(st.st_size)>DirectText)return false;
    FILE *file=fopen(path.c_str(),"rb");if(!file)return false;text.resize(size_t(st.st_size));const bool ok=fread(text.data(),1,text.size(),file)==text.size()&&fgetc(file)==EOF&&!ferror(file);fclose(file);if(!ok)text.clear();return ok;
}
bool directWrapped(const Game &game,const GameProvider &provider,const std::string &path,std::string *text){
    struct stat st{};if(!statPath(path,st)||!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||st.st_size<=0||uint64_t(st.st_size)>DirectText+4096)return false;
    FILE *file=fopen(path.c_str(),"rb");if(!file)return false;
    const std::array<std::string,5> expected={"NMCPUBLISHED1",provider.key,hexId(game.id),upper(game.buildId),provider.url};std::array<char,4096> line{};bool ok=true;
    for(const auto &value:expected){if(!fgets(line.data(),int(line.size()),file)){ok=false;break;}const auto n=strlen(line.data());if(!n||line[n-1]!='\n'||std::string(line.data(),n-1)!=value){ok=false;break;}}
    std::string wanted;if(ok&&fgets(line.data(),int(line.size()),file)){const auto n=strlen(line.data());if(n&&line[n-1]=='\n')wanted.assign(line.data(),n-1);else ok=false;}else ok=false;
    const auto start=ftell(file);if(start<0||uint64_t(start)>=uint64_t(st.st_size)||uint64_t(st.st_size)-uint64_t(start)>DirectText)ok=false;
    if(text){text->clear();if(ok)text->reserve(size_t(st.st_size)-size_t(start));}
    std::array<char,8192> buffer{};uint32_t crc=0;size_t size=0,n=0;
    while(ok&&(n=fread(buffer.data(),1,buffer.size(),file))){if(size+n>DirectText||queryStopped(wanted)){ok=false;break;}size+=n;crc=uint32_t(crc32(crc,reinterpret_cast<const Bytef*>(buffer.data()),uInt(n)));if(text)text->append(buffer.data(),n);}
    ok=ok&&!ferror(file)&&size>0&&hexId(crc)==wanted;fclose(file);if(!ok&&text)text->clear();return ok;
}
bool directCached(const Game &game,const GameProvider &provider,std::string *text){const auto path=providerPath(game,provider);return directWrapped(game,provider,path,text)||directWrapped(game,provider,path+".previous",text);}
bool storeDirect(const Game &game,const GameProvider &provider,const std::string &text,std::string &error){
    if(queryStopped(error))return false;
    const auto path=providerPath(game,provider),pending=path+".pending";struct stat st{};
    if(statPath(pending,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La ruta temporal no es un archivo regular.";return false;}
    const auto prefix="NMCPUBLISHED1\n"+provider.key+"\n"+hexId(game.id)+"\n"+upper(game.buildId)+"\n"+provider.url+"\n"+crcText(text)+"\n";
    FILE *file=fopen(pending.c_str(),"wb");if(!file){error="No se pudo guardar la fuente publicada.";return false;}
    bool ok=fwrite(prefix.data(),1,prefix.size(),file)==prefix.size()&&fwrite(text.data(),1,text.size(),file)==text.size()&&fflush(file)==0;if(ok)ok=fsync(fileno(file))==0;if(fclose(file)!=0)ok=false;
    if(!ok||!directWrapped(game,provider,pending,nullptr)){error="La copia descargada no se pudo verificar en la SD.";return false;}
    if(queryStopped(error))return false;
    return promoteSource(pending,path,error,directWrapped(game,provider,path,nullptr));
}
// Read only central headers and the exact requested member. An unrelated bad
// payload is not decompressed; every member is CRC-checked when actually used.
bool zipExact(const std::string &path,const Game &game,std::string &text,bool &found,std::string &error,ArchiveProfile profile=ArchiveProfile::Canonical){
    text.clear();found=false;if(!regular(path,MaxArchive)){error="No hay una copia regular del ZIP.";return false;}
    unzFile zip=unzOpen64(path.c_str());if(!zip){error="El archivo no es un ZIP válido.";return false;}unz_global_info64 global{};
    bool ok=unzGetGlobalInfo64(zip,&global)==UNZ_OK&&global.number_entry<=MaxMembers;uint64_t expanded=0;
    int next=ok?unzGoToFirstFile(zip):UNZ_BADZIPFILE;
    if(ok&&!global.number_entry)next=UNZ_END_OF_LIST_OF_FILE;
    for(uint64_t i=0;ok&&i<global.number_entry;++i){
        if((i%64)==0&&queryStopped(error)){ok=false;break;}
        unz_file_info64 info{};std::array<char,1024> name{};
        if(next!=UNZ_OK||unzGetCurrentFileInfo64(zip,&info,name.data(),unsigned(name.size()),nullptr,0,nullptr,0)!=UNZ_OK||info.size_filename>=name.size()||strlen(name.data())!=info.size_filename||info.uncompressed_size>MaxExpanded-expanded){ok=false;break;}
        if(unsupportedAuthorMember(name.data(),profile)){error="La fuente de autor incluye parches o archivos dependientes; no se importará como cheats independientes.";ok=false;break;}
        expanded+=info.uncompressed_size;uint64_t tid=0;std::string bid;
        if(archiveIdentity(name.data(),tid,bid,profile)&&tid==game.id&&bid==upper(game.buildId)){
            const auto type=(info.external_fa>>16)&0xf000;
            if(found||!info.uncompressed_size||info.uncompressed_size>DirectText||(type&&type!=0x8000)||!currentFile(zip,text,error)){ok=false;break;}found=true;
        }
        next=unzGoToNextFile(zip);
    }
    if(next!=UNZ_END_OF_LIST_OF_FILE)ok=false;
    unzClose(zip);
    if(!ok){found=false;text.clear();if(error.empty())error="ZIP incompleto, ambiguo o fuera de los límites del overlay.";}return ok;
}
bool usableZipExact(const std::string &path,const Game &game,std::string &text,bool &found,std::string &error,ArchiveProfile profile){
    if(!zipExact(path,game,text,found,error,profile))return false;
    if(profile==ArchiveProfile::Arch9&&found){std::vector<Cheat> parsed;if(!parseDirect(text,"Arch9SK7/MyNXCheats",parsed,error)){text.clear();found=false;return false;}}
    return true;
}
bool zipFallback(const std::string &path,const Game &game,std::string &text,bool &found,std::string &error,bool *currentValid=nullptr,ArchiveProfile profile=ArchiveProfile::Canonical){
    const bool current=usableZipExact(path,game,text,found,error,profile);if(currentValid)*currentValid=current;
    return current||usableZipExact(path+".previous",game,text,found,error,profile);
}
bool seedExact(const Game &game,std::string &text,bool &found,std::string &error){
    found=false;const char first=activeSlot();
    for(const char slot:{first,first=='a'?'b':'a'}){const auto directoryPath=root()+"/catalog-"+slot;struct stat st{};std::string marker;
        if(!statPath(directoryPath,st)||!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)||!readSmall(directoryPath+"/complete.txt",marker,128)||marker.rfind("NINMAGIC-CATALOG-1",0)!=0)continue;
        if(zipExact(directoryPath+"/general.zip",game,text,found,error)&&found)return true;
    }
    return true;
}
bool refreshDirectZip(const Game &game,const std::string &key,const std::string &url,bool force,std::string &text,bool &found,CheatSourceReport &report,std::string &error,ArchiveProfile profile=ArchiveProfile::Canonical){
    const auto path=providerRoot()+"/"+key+".zip";std::string ignored;bool currentValid=false;bool cached=zipFallback(path,game,text,found,ignored,&currentValid,profile);report.cached=report.cached||cached;
    if(!force&&currentValid&&recentCheck(path+".checked",url))return true;
    if(queryStopped(error))return false;
    RemoteStamp remote;
    if(currentValid){if(!download(url,"",error,&remote,true)){report.httpStatus=remote.status;return false;}report.httpStatus=remote.status;
        if(unchanged(path+".remote",url,remote)){report.checked=true;return markChecked(path+".checked",url);}}
    // Do not retain a previous text buffer during a streamed ZIP download.
    text.clear();std::string{}.swap(text);found=false;const auto pending=path+".download";
    if(!removeOutput(pending,error)||!download(url,pending,error,&remote)){report.httpStatus=remote.status;return false;}report.httpStatus=remote.status;
    if(!zipExact(pending,game,text,found,error,profile)||queryStopped(error))return false;
    // A valid CRC alone does not make the requested author file usable. Reject
    // an invalid/oversized target before replacing a previously usable ZIP.
    if(found){std::vector<Cheat> checked;if(!parseDirect(text,report.source,checked,error))return false;}
    std::string previousText;bool previousFound=false;const bool currentVerified=usableZipExact(path,game,previousText,previousFound,ignored,profile);std::string{}.swap(previousText);
    if(!promoteSource(pending,path,error,currentVerified))return false;
    report.checked=report.cached=true;
    if(!writeSmall(path+".remote",stampText(url,remote))||!markChecked(path+".checked",url)){error="ZIP guardado; no se pudo registrar la comprobación.";return false;}return true;
}
enum class DirectKind {Plain,Hamlet,Nx,Sthetix,Arch9};
bool directFallback(const Game &game,const GameProvider &provider,DirectKind kind,std::string &text,bool &found){
    found=directCached(game,provider,&text);if(found)return true;std::string ignored;
    if(kind==DirectKind::Hamlet){if(seedExact(game,text,found,ignored)&&found)return true;
        for(const char *key:{"hamlet-latest","hamlet-raw"})if(zipFallback(providerRoot()+"/"+key+".zip",game,text,found,ignored)&&found)return true;}
    if(kind==DirectKind::Nx){for(const char *key:{"nx-direct","nxcheatcode"})if(zipFallback(providerRoot()+"/"+key+".zip",game,text,found,ignored)&&found)return true;}
    if(kind==DirectKind::Sthetix){for(const char *key:{"sthetix-direct","sthetix"})if(zipFallback(providerRoot()+"/"+key+".zip",game,text,found,ignored)&&found)return true;}
    if(kind==DirectKind::Arch9){for(const char *key:{"arch9sk7-direct","arch9sk7"})if(zipFallback(providerRoot()+"/"+key+".zip",game,text,found,ignored,nullptr,ArchiveProfile::Arch9)&&found)return true;}
    text.clear();return true;
}
}

void logSourceReports(const Game &game,const std::vector<CheatSourceReport> &reports,const std::string &error){
    std::string ignored;if(!ensureRoot(ignored)||!directory(providerRoot()))return;
    const auto clean=[](const std::string &value,size_t cap){std::string result;result.reserve(std::min(value.size(),cap));for(unsigned char c:value){if(result.size()>=cap)break;result+=c<32||c==127?' ':char(c);}return result;};
    std::string data="NINMAGIC-SOURCES-1\ntime="+std::to_string(std::time(nullptr))+"\ntitle="+hexId(game.id)+"\nbid="+clean(game.buildId,16)+"\nfull-bid="+clean(game.fullBuildId,64)+"\nbuild-verified="+std::to_string(game.buildVerified)+"\nerror="+clean(error,4096)+"\n";
    for(const auto &report:reports){const auto privateQuery=report.url.find_first_of("?#");data+="\nsource="+clean(report.source,128)+"\nurl="+clean(report.url.substr(0,privateQuery),2048)+"\nhttp="+std::to_string(report.httpStatus)+" checked="+std::to_string(report.checked)+" cached="+std::to_string(report.cached)+" found="+std::to_string(report.found)+"\ndetail="+clean(report.detail,4096)+"\n";}
    if(data.size()<=32*1024)writeSmall(providerRoot()+"/last-query.txt",data);
}
bool findPublishedGameDirect(const Game &game,bool force,Pack &pack,std::vector<CheatSourceReport> &reports,std::string &error,const std::function<bool()> &cancelled){
    pack={};pack.game=game;reports.clear();error.clear();
    struct Cancellation {std::function<bool()> previous;explicit Cancellation(const std::function<bool()> &next):previous(std::move(queryCancelled)){queryCancelled=next;}~Cancellation(){queryCancelled=std::move(previous);}} cancellation(cancelled);
    const auto finish=[&](bool ok){pack.compatible=std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const Cheat &c){return !c.master;});if(pack.compatible)pack.availableBuilds={upper(game.buildId)};pack.detail=pack.compatible?"Opciones publicadas para el Title ID y Build ID exactos. Seleccionar no activa códigos.":ok?"No se encontraron opciones compatibles en las fuentes comprobadas.":"No se pudo completar la consulta de cheats.";if(!error.empty())pack.detail+=" Consulta incompleta: "+error;logSourceReports(game,reports,error);return ok;};
    if(!directIdentity(game)){error="No se pudo verificar el Build ID completo del juego. No se consultaron fuentes ni se eligieron códigos de otra versión.";return finish(false);}
    if(queryStopped(error)||!ensureRoot(error)||!directory(providerRoot())){if(error.empty())error="No se pudo abrir la caché de fuentes.";return finish(false);}
    std::string general,legacy,raw;if(!sourceUrls(general,legacy,error,&raw))return finish(false);
    std::vector<std::pair<GameProvider,DirectKind>> sources={{{"hamlet-direct","Hamlet",general},DirectKind::Hamlet},{{"nx-direct-game","Tomvita/NXCheatCode",NxCodeUrl},DirectKind::Nx},{{"sthetix-direct-game","sthetix/nx-cheats-db",SthetixUrl},DirectKind::Sthetix},{{"arch9sk7-game","Arch9SK7/MyNXCheats",Arch9Url},DirectKind::Arch9}};
    for(const auto &provider:gameProviders(game))sources.push_back({provider,DirectKind::Plain});
    bool allOk=true;
    for(const auto &source:sources){
        if(queryStopped(error)){allOk=false;break;}
        const auto &provider=source.first;const auto kind=source.second;CheatSourceReport report;report.source=provider.name;report.url=provider.url;
        const auto path=providerPath(game,provider);const bool hadCache=directCached(game,provider,nullptr);
        bool found=false,success=false,fresh=false;std::string text,failure;std::vector<Cheat> parsed;
        const bool recent=!force&&recentCheck(path+(hadCache?".checked":".missing.checked"),provider.url);
        if(recent){directFallback(game,provider,kind,text,found);report.cached=hadCache||found;report.detail="Consulta reciente guardada; no se volvió a consultar Internet.";success=true;}
        else if(!networkInit(failure))success=false;
        else if(kind==DirectKind::Plain){
            RemoteStamp remote;
            if(removeOutput(path+".download",failure)&&downloadProvider(provider,path+".download",failure,remote,DirectText,report.url)){
                report.httpStatus=remote.status;report.checked=true;fresh=found=readDirectFile(path+".download",text);success=found;if(!found)failure="El archivo publicado supera 64 KiB o no se pudo leer.";
            }else {report.httpStatus=remote.status;if(remote.status==404){report.checked=true;success=true;failure.clear();}}
            std::string ignored;removeOutput(path+".download",ignored);
        }else {
            success=refreshDirectZip(game,kind==DirectKind::Hamlet?"hamlet-latest":kind==DirectKind::Nx?"nx-direct":kind==DirectKind::Sthetix?"sthetix-direct":"arch9sk7-direct",provider.url,force,text,found,report,failure,kind==DirectKind::Arch9?ArchiveProfile::Arch9:ArchiveProfile::Canonical);fresh=found;
            if(success&&!found&&kind==DirectKind::Hamlet&&!raw.empty()){success=refreshDirectZip(game,"hamlet-raw",raw,force,text,found,report,failure);fresh=found;}
        }
        std::string parseError;
        if(found&&!parseDirect(text,provider.name,parsed,parseError)){success=false;fresh=found=false;parsed.clear();if(failure.empty())failure=std::move(parseError);}
        if(fresh&&found){
            std::string stored;if(!storeDirect(game,provider,text,stored)){success=false;if(failure.empty())failure=stored;}
            else report.cached=true;
        }
        if(!found){
            text.clear();parsed.clear();bool cachedFound=false;directFallback(game,provider,kind,text,cachedFound);
            if(cachedFound){std::string cacheError;if(parseDirect(text,provider.name,parsed,cacheError)){found=true;report.cached=true;}else{success=false;if(failure.empty())failure="La copia guardada no es válida para el overlay: "+cacheError;}}
        }
        report.found=found;
        if(found){std::string appendError;if(!directAppend(pack,std::move(parsed),provider.name+":"+hexId(game.id)+":"+upper(game.buildId),appendError)){success=false;failure=appendError;}}
        if(success&&!queryStopped(failure)){
            if(!recent&&!markChecked(path+(found?".checked":".missing.checked"),provider.url)){success=false;failure="No se pudo registrar la consulta de esta fuente.";}
            if(report.httpStatus==404)report.detail=found?"El archivo canónico ya no está publicado; se conserva la copia local.":"No hay archivo canónico para este Title ID y Build ID.";
            if(report.detail.empty())report.detail=found?"Archivo publicado con identificadores exactos.":"No hay archivo exacto en esta fuente consultada.";
        }else success=false;
        if(!success){allOk=false;if(failure.empty())failure="No se pudo completar la consulta.";report.detail=failure+(report.cached?" Se conserva la copia local.":"");if(!error.empty())error+=" · ";error+=provider.name+": "+failure;}
        reports.push_back(std::move(report));
    }
    if(!queryStopped(error)&&regular(root()+"/manual-cheats.zip",MaxArchive)){
        std::string text,importError;bool found=false;CheatSourceReport report;report.source="Importacion local";report.url="manual-cheats.zip";report.cached=true;
        if(!zipExact(root()+"/manual-cheats.zip",game,text,found,importError)){allOk=false;report.detail=importError;}
        else if(found){std::vector<Cheat> parsed;if(parseDirect(text,report.source,parsed,importError)&&directAppend(pack,std::move(parsed),report.source+":"+hexId(game.id)+":"+upper(game.buildId),importError))report.found=true;else{allOk=false;report.detail=importError;}}
        if(!importError.empty()){if(!error.empty())error+=" · ";error+="Importación local: "+importError;}reports.push_back(std::move(report));
    }
    return finish(allOk&&!queryStopped(error));
}

bool refreshGameSources(const Game &game,bool force,std::vector<CheatSourceReport> &reports,std::string &error){
    reports.clear();error.clear();
    if(!providerGame(game)){error="Abre el juego para verificar su Title ID y Build ID exactos antes de consultar fuentes.";return false;}
    if(!ensureRoot(error)||!directory(providerRoot())){if(error.empty())error="No se puede abrir la caché de proveedores publicados.";return false;}
    std::string networkError;bool network=false,networkTried=false,allOk=true;
    const auto online=[&](){if(!networkTried){network=networkInit(networkError);networkTried=true;}return network;};
    for(const auto &provider:gameProviders(game)){
        CheatSourceReport report;report.source=provider.name;report.url=provider.url;std::string text;
        report.cached=cachedText(game,provider,text);report.found=report.cached;
        const auto path=providerPath(game,provider);
        if(!force&&recentCheck(path+(report.cached?".checked":".missing.checked"),provider.url)){report.detail=report.cached?"Copia local reciente para este Build ID.":"La consulta reciente no encontró el archivo canónico para este Build ID.";reports.push_back(std::move(report));continue;}
        std::string failure;RemoteStamp remote;
        if(!online())failure=networkError;
        else if(downloadProvider(provider,path+".download",failure,remote,MaxFile,report.url)){
            std::vector<Cheat> parsed;
            if(!readSmall(path+".download",text,size_t(MaxFile))||!parseCheats(text,provider.name,parsed,failure)){if(failure.empty())failure="El archivo publicado no contiene cheats válidos.";}
            else {
                const auto wrapped="NMCPUBLISHED1\n"+provider.key+"\n"+hexId(game.id)+"\n"+upper(game.buildId)+"\n"+provider.url+"\n"+crcText(text)+"\n"+text;
                const auto pending=path+".pending";
                std::string oldText;const bool currentVerified=providerText(game,provider,path,oldText);
                if(!writeSmall(pending,wrapped)||!providerText(game,provider,pending,text)||!promoteSource(pending,path,failure,currentVerified)){if(failure.empty())failure="No se pudo confirmar el archivo del proveedor.";}
                else {report.checked=report.cached=report.found=true;report.detail="Archivo publicado con Title ID y Build ID exactos.";std::string ignored;removeOutput(path+".missing.checked",ignored);if(!markChecked(path+".checked",provider.url))failure="Códigos guardados; no se pudo registrar la hora de comprobación.";}
            }
        }else if(remote.status==404){
            report.checked=true;report.detail=report.cached?"El archivo canónico ya no está publicado; se conserva la copia local.":"No hay archivo canónico publicado para este Title ID y Build ID.";
            if(!markChecked(path+(report.cached?".checked":".missing.checked"),provider.url))failure="No se pudo registrar la consulta del proveedor.";else failure.clear();
        }
        report.httpStatus=remote.status;
        if(!report.checked&&failure.empty())failure="No se pudo comprobar el proveedor.";
        std::string ignored;removeOutput(path+".download",ignored);
        if(!failure.empty()){allOk=false;report.detail=failure+(report.cached?" Se usa la copia local verificada.":"");error+=(error.empty()?"":" · ")+provider.name+": "+report.detail;}
        reports.push_back(std::move(report));
    }
    for(const auto &archive:std::array<std::array<std::string,3>,3>{{{{"nxcheatcode","Tomvita/NXCheatCode",NxCodeUrl}},{{"sthetix","sthetix/nx-cheats-db",SthetixUrl}},{{"arch9sk7","Arch9SK7/MyNXCheats",Arch9Url}}}}){
    const auto &key=archive[0],&source=archive[1],&url=archive[2];
    const auto profile=key=="arch9sk7"?ArchiveProfile::Arch9:ArchiveProfile::Canonical;
    CheatSourceReport report;report.source=source;report.url=url;
    std::vector<CatalogEntry> entries;std::string failure;const auto path=providerRoot()+"/"+key+".zip";
    std::string oldCache;report.cached=archiveCachedEntries(game,key,source,entries,failure,&oldCache,profile);report.found=std::any_of(entries.begin(),entries.end(),[&](const CatalogEntry &e){return e.buildId==upper(game.buildId);});failure.clear();
    const bool currentCached=report.cached&&oldCache==path;
    if(!force&&currentCached&&recentCheck(path+".checked",url))report.detail="Catálogo compartido reciente; consulta local por Title ID y Build ID.";
    else if(!online())failure=networkError;
    else {
        RemoteStamp remote;const bool probed=!currentCached||download(url,"",failure,&remote,true);
        const bool same=currentCached&&probed&&unchanged(path+".remote",url,remote);
        if(same){report.checked=true;report.detail="La publicación no ha cambiado.";if(!markChecked(path+".checked",url))failure="No se pudo registrar la comprobación de "+source+".";}
        else if(probed&&download(url,path+".download",failure,&remote)){
            std::vector<CatalogEntry> checked;
            if(indexArchive(path+".download",report.source,checked,failure,true,false,profile)){
                bool targetValid=true;
                if(profile==ArchiveProfile::Arch9){
                    for(const auto &entry:checked)if(entry.titleId==game.id&&entry.buildId==upper(game.buildId)){
                        unzFile zip=unzOpen64((path+".download").c_str());std::string text;std::vector<Cheat> parsed;
                        targetValid=zip&&unzLocateFile(zip,entry.path.c_str(),1)==UNZ_OK&&currentFile(zip,text,failure)&&parseCheats(text,source,parsed,failure);
                        if(zip)unzClose(zip);
                        if(!targetValid&&failure.empty())failure="El archivo solicitado de la fuente de autor no es válido.";
                        break;
                    }
                }
                checked.clear();std::vector<std::string> inputs;
                if(report.cached)inputs.push_back(oldCache);
                inputs.push_back(path+".download");
                bool staged=false;
                if(targetValid&&profile==ArchiveProfile::Arch9){
                    if(removeOutput(path+".pending",failure)){
                        staged=rename((path+".download").c_str(),(path+".pending").c_str())==0;
                        if(!staged)failure="No se pudo preparar el ZIP original del autor.";
                    }
                }else if(targetValid)staged=mergeInto(inputs,path+".pending",failure)&&indexArchive(path+".pending",report.source,checked,failure,true);
                if(staged&&promoteSource(path+".pending",path,failure,oldCache==path)){
                    report.checked=report.cached=true;entries.clear();report.found=archiveCachedEntries(game,key,source,entries,failure,nullptr,profile)&&std::any_of(entries.begin(),entries.end(),[&](const CatalogEntry &e){return e.buildId==upper(game.buildId);});
                    report.detail=profile==ArchiveProfile::Arch9?"ZIP original del autor verificado; se conserva una copia anterior.":"Catálogo publicado verificado; se conservan los Build IDs anteriores.";
                    if(!writeSmall(path+".remote",stampText(url,remote))||!markChecked(path+".checked",url))failure="Catálogo guardado; no se pudo registrar su comprobación.";
                }
            }
        }
        report.httpStatus=remote.status;
    }
    if(!report.checked&&report.detail.empty()&&failure.empty())failure="No se pudo comprobar "+source+".";
    std::string ignored;removeOutput(path+".download",ignored);
    if(!failure.empty()){allOk=false;report.detail=failure+(report.cached?" Se usa la copia local.":"");error+=(error.empty()?"":" · ")+report.source+": "+report.detail;}
    reports.push_back(std::move(report));
    }
    return allOk;
}

bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error) {
    error.clear();return networkInit(error)&&download(url,path,error);
}
bool loadCatalog(Catalog &catalog,std::string &error) {
    error.clear();catalog={};char slot=activeSlot();
    if(loadSlot(slot,catalog,error))return true;
    std::string second;
    if(loadSlot(slot=='a'?'b':'a',catalog,second)) {catalog.detail+=" · recuperado de la copia anterior";error.clear();return true;}
    error="No hay una caché válida. Actualiza las bases de cheats para descargarlas.";return false;
}
bool syncCatalog(Catalog &catalog,std::string &error) {return refreshCatalog(catalog,true,error);}
bool refreshCatalog(Catalog &catalog,bool force,std::string &error) {
    error.clear();
    if(!ensureRoot(error))return false;
    std::string general,graphics,raw;
    if(!sourceUrls(general,graphics,error,&raw)||!networkInit(error))return false;
    // Only overwrite the inactive slot. The active archives remain readable
    // until both replacements, every accepted member CRC and commit marker pass.
    char current=activeSlot();Catalog previous;std::string ignored;
    bool cached=loadSlot(current,previous,ignored);
    if(!cached&&loadSlot(current=='a'?'b':'a',previous,ignored)){current=current=='a'?'b':'a';cached=true;}
    const std::string old=root()+"/catalog-"+current;
    SeenMap seen;if(!cached||!readSeen(old+"/releases-seen.txt",seen))seen.clear();
    std::string knownPublished;for(const auto &record:seen)knownPublished=std::max(knownPublished,record.second.published);
    std::vector<CheatRelease> releases,chosen;
    const bool official=general==GeneralUrl;
    std::string historyError;
    const bool historyOk=!official||publishedReleases(releases,historyError);
    size_t pending=0,selectedAssets=0;
    if(official&&historyOk&&!releases.empty()) {
        if(seen.empty()) {
            // A bare NRO must never download all past years on the console.
            // The full historical seed is prepared on the PC and bundled.
            // Fetch the latest first, but never mark older publications as
            // processed without reading them. The supplied historical seed
            // already includes its complete publication ledger.
            chosen.push_back(releases.back());
            pending=releases.size()-1;
        } else {
            for(const auto &release:releases){const auto oldRecord=seen.find(release.id);if(oldRecord!=seen.end()&&oldRecord->second.signature==cheatReleaseSignature(release))continue;if(selectedAssets+release.assets.size()>8){++pending;continue;}chosen.push_back(release);selectedAssets+=release.assets.size();}
            if(force&&std::none_of(chosen.begin(),chosen.end(),[&](const auto &release){return release.id==releases.back().id;}))chosen.push_back(releases.back());
        }
    }
    RemoteStamp generalStamp,rawStamp;
    std::string probeError;
    bool generalChanged=force||!cached||!chosen.empty();
    if(!official||!historyOk) {
        probeError.clear();const bool probed=download(general,"",probeError,&generalStamp,true);
        generalChanged=force||!cached||!probed||!unchanged(old+"/remote-general.txt",general,generalStamp);
        if(!raw.empty()){probeError.clear();if(!download(raw,"",probeError,&rawStamp,true)||!unchanged(old+"/remote-raw.txt",raw,rawStamp))generalChanged=true;}
    }
    if(!generalChanged) {
        if(cached)catalog=std::move(previous);
        if(!historyOk){error=historyError;return false;}
        if(pending){error="Quedan lanzamientos de cheats pendientes. Vuelve a actualizar para continuar sin perder la base guardada.";return false;}
        return true;
    }
    char slot=current=='a'?'b':'a';std::string path=root()+"/catalog-"+slot;
    if(!directory(path)){error="No se puede crear la nueva caché.";return false;}
    struct stat st{};
    for(const char *name:{"complete.txt","general.zip"}) {
        std::string target=path+"/"+name;
        if(statPath(target,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La nueva caché contiene una ruta no admitida.";return false;}
    }
    unlink((path+"/complete.txt").c_str());
    std::vector<std::string> olderInputs,newerInputs,temporary;
    SeenMap nextSeen=seen;
    if(generalChanged&&official&&historyOk&&!chosen.empty()) {
        for(const auto &release:chosen) {
            auto assets=release.assets;std::sort(assets.begin(),assets.end(),[](const auto &a,const auto &b){return a.name=="contents.zip"&&b.name!="contents.zip";});
            for(const auto &asset:assets) {
                if(asset.size>MaxArchive){error="Un archivo histórico nuevo supera 64 MiB. Actualiza el historial en el PC; la base anterior se conserva.";return false;}
                const std::string target=path+"/release-"+std::to_string(release.id)+(asset.name=="contents.zip"?"-raw.zip":"-complete.zip");
                if(!download(asset.url,target,error))return false;
                struct stat actual{};if(!statPath(target,actual)||uint64_t(actual.st_size)!=asset.size){error="Un lanzamiento descargado no coincide con el tamaño publicado.";return false;}
                temporary.push_back(target);(release.published<knownPublished?olderInputs:newerInputs).push_back(target);
            }
            nextSeen[release.id]={release.published,cheatReleaseSignature(release)};
        }
    } else if(generalChanged) {
        if(!raw.empty()){const auto target=path+"/latest-raw.zip";if(!download(raw,target,error,&rawStamp))return false;temporary.push_back(target);newerInputs.push_back(target);}
        const auto target=path+"/latest-complete.zip";if(!download(general,target,error,&generalStamp))return false;temporary.push_back(target);newerInputs.push_back(target);
    }
    std::vector<std::string> generalInputs=olderInputs;
    if(cached)generalInputs.push_back(old+"/general.zip");
    generalInputs.insert(generalInputs.end(),newerInputs.begin(),newerInputs.end());
    if(!mergeInto(generalInputs,path+"/general.zip",error))return false;
    Catalog next;
    if(!indexArchive(path+"/general.zip","Hamlet",next.entries,error,true))return false;
    time_t now=std::time(nullptr);struct tm when{};char stamp[40]="Actualizado";
    if(gmtime_r(&now,&when))std::strftime(stamp,sizeof(stamp),"%Y-%m-%d %H:%M UTC",&when);
    const auto retainedStamp=[&](const char *name,const std::string &url,const RemoteStamp &remote){
        std::string previousStamp;
        if(cached&&remote.etag.empty()&&remote.modified.empty()&&readSmall(old+"/"+name,previousStamp,4096)&&previousStamp.rfind(std::string("NMCREMOTE1\n")+url+"\n",0)==0)return previousStamp;
        return stampText(url,remote);
    };
    if(!writeSmall(path+"/releases-seen.txt",seenText(nextSeen))||!writeSmall(path+"/remote-general.txt",retainedStamp("remote-general.txt",general,generalStamp))||!writeSmall(path+"/remote-raw.txt",retainedStamp("remote-raw.txt",raw,rawStamp))||!writeSmall(path+"/last-check.txt",std::to_string(static_cast<long long>(now))+"\n")){error="No se pudo confirmar el índice de actualizaciones de la base.";return false;}
    for(const auto &file:temporary)if(!removeOutput(file,error))return false;
    if(!writeSmall(path+"/complete.txt",std::string("NINMAGIC-CATALOG-1\n")+stamp+"\n")){error="No se puede guardar el cierre de la caché.";return false;}
    if(!writeSmall(root()+"/active.pending",std::string(1,slot)+"\n")){error="No se puede guardar la selección de caché.";return false;}
    // FAT rename does not replace an existing destination. Retain the previous
    // marker as active.previous until the pending marker is in place.
    unlink((root()+"/active.previous").c_str());
    bool had=regular(root()+"/active.txt",8);
    if(had&&rename((root()+"/active.txt").c_str(),(root()+"/active.previous").c_str())!=0){error="No se puede conservar el marcador anterior.";return false;}
    if(rename((root()+"/active.pending").c_str(),(root()+"/active.txt").c_str())!=0) {
        if(had)rename((root()+"/active.previous").c_str(),(root()+"/active.txt").c_str());
        error="No se puede activar la nueva caché. Se conserva la anterior.";return false;
    }
    next.generalReady=true;next.graphicsReady=false;next.stamp=stamp;next.detail=std::to_string(next.entries.size())+" versiones de cheats publicados · fuente FPS/gráficos retirada";
    appendManual(next);
    catalog=std::move(next);
    if(!historyOk){error="Se conservó la base disponible, pero no se pudo comprobar todo el historial: "+historyError;return false;}
    if(pending){error="Base guardada; quedan "+std::to_string(pending)+" lanzamientos pendientes. Vuelve a actualizar para continuar, o instala el historial completo incluido en el paquete del PC.";return false;}
    return true;
}
Pack findCheats(const Game &game,const Catalog &catalog) {
    Pack result;result.game=game;std::set<std::string> builds;
    std::vector<CatalogEntry> entries;
    for(const auto &entry:catalog.entries)if(entry.titleId==game.id)entries.push_back(entry);
    std::string optionalError;nxEntries(game,entries,optionalError);archiveCachedEntries(game,"sthetix","sthetix/nx-cheats-db",entries,optionalError);archiveCachedEntries(game,"arch9sk7","Arch9SK7/MyNXCheats",entries,optionalError,nullptr,ArchiveProfile::Arch9);
    for(const auto &entry:entries)builds.insert(entry.buildId);
    result.availableBuilds.assign(builds.begin(),builds.end());
    if(!providerGame(game)) {result.detail="Abre este juego, vuelve a hbmenu y selecciónalo para comprobar su Build ID exacto.";return result;}
    std::vector<std::string> failures;
    for(const auto &entry:entries) {
        if(entry.titleId!=game.id||entry.buildId!=upper(game.buildId))continue;
        unzFile zip=regular(entry.archive,MaxArchive)?unzOpen64(entry.archive.c_str()):nullptr;
        if(!zip){failures.push_back(entry.source+": no se puede abrir su caché");continue;}
        std::string text,error;bool ok=unzLocateFile(zip,entry.path.c_str(),1)==UNZ_OK&&currentFile(zip,text,error);
        unzClose(zip);
        std::vector<Cheat> cheats;
        if(ok)ok=parseCheats(text,entry.source,cheats,error);
        if(!ok){failures.push_back(entry.source+": "+(error.empty()?"no se puede leer el archivo":error));continue;}
        appendSourceCheats(result,std::move(cheats),entry.source+":"+hexId(entry.titleId)+":"+entry.buildId);
    }
    for(const auto &provider:gameProviders(game)){
        std::string text;if(!cachedText(game,provider,text))continue;
        std::vector<Cheat> cheats;std::string error;
        if(parseCheats(text,provider.name,cheats,error)){builds.insert(upper(game.buildId));appendSourceCheats(result,std::move(cheats),provider.name+":"+hexId(game.id)+":"+upper(game.buildId));}
    }
    result.availableBuilds.assign(builds.begin(),builds.end());
    result.compatible=std::any_of(result.cheats.begin(),result.cheats.end(),[](const Cheat &c){return !c.master;});
    if(result.compatible)result.detail="Cheats del Title ID y Build ID exactos. Marca solo las opciones que quieras aplicar.";
    else if(builds.empty())result.detail="Las fuentes guardadas no contienen cheats para este Title ID y Build ID.";
    else result.detail="Hay cheats para otras versiones, pero ninguno para este Build ID. No se aplicarán códigos incompatibles.";
    for(const auto &failure:failures)result.detail+=" "+failure;
    return result;
}
void catalogExit() {
#if defined(__SWITCH__) && defined(NC_PUBLISHED_OVERLAY)
    https_lite::shutdown();
#elif defined(__SWITCH__)
    if(curlReady){curl_global_cleanup();curlReady=false;}
    if(nifmReady){nifmExit();nifmReady=false;}
    if(socketsReady){socketExit();socketsReady=false;}
#endif
}
}

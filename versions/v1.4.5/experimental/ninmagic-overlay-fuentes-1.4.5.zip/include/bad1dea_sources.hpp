#pragma once
#include <cstdint>

namespace nc::catalog_sources {
// Public author repository under MIT; route metadata only, no cheat opcodes.
// Snapshot pinned after excluding paired IPS/archive dependencies and _old.
// Refresh this table with an app release, not by guessing a newer Build ID.
// License: third_party/BAD1DEA-NXCHEATS-LICENSE.txt.
struct RawSource {uint64_t title;const char *build;const char *url;};
inline constexpr RawSource Bad1dea[]={
    {0x01000EB0276F2000ULL,"89547BD4E42B0FE0","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/01000EB0276F2000%20Garfield%20-%20Escape%20From%20Monday/atmosphere/contents/01000EB0276F2000/cheats/89547BD4E42B0FE0.txt"},
    {0x01001B300B9BE000ULL,"2607A74F5DF7754C","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/01001B300B9BE000%20Diablo%20III%3A%20Eternal%20Collection/atmosphere/contents/01001B300B9BE000/cheats/2607A74F5DF7754C.txt"},
    {0x010027901C89C000ULL,"5134D58C555B8E71","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/010027901C89C000%20Hello%20Kitty%20Island%20Adventure/atmosphere/contents/010027901C89C000/cheats/5134D58C555B8E71.txt"},
    {0x01005270232F2000ULL,"9FE60A212CFF9B9A","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/01005270232F2000%20OCTOPATH%20TRAVELER%200/atmosphere/contents/01005270232F2000/cheats/9FE60A212CFF9B9A.txt"},
    {0x010057D006492000ULL,"67DACC049CEEE858","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/010057D006492000%20Octopath%20Traveler%E2%84%A2/atmosphere/contents/010057D006492000/cheats/67DACC049CEEE858.txt"},
    {0x0100606026F12000ULL,"84E182F72EE1DA4F","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100606026F12000%20FINAL%20FANTASY%20RESONANCE/atmosphere/contents/0100606026F12000/cheats/84E182F72EE1DA4F.txt"},
    {0x0100726014352000ULL,"DB0507F36B84200A","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100726014352000%20Diablo%C2%AE%20II%3A%20Resurrected%E2%84%A2/atmosphere/contents/0100726014352000/cheats/DB0507F36B84200A.txt"},
    {0x010083B01D9B8000ULL,"C3611D05649C0E16","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/010083B01D9B8000%20Baladins/atmosphere/contents/010083B01D9B8000/cheats/C3611D05649C0E16.txt"},
    {0x0100853015E86000ULL,"27749F7144B46203","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100853015E86000%20No%20Man's%20Sky/atmosphere/contents/0100853015E86000/cheats/27749F7144B46203.txt"},
    {0x0100853015E86000ULL,"5507E92D36CD1F9C","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100853015E86000%20No%20Man's%20Sky/atmosphere/contents/0100853015E86000/cheats/5507E92D36CD1F9C.txt"},
    {0x0100853015E86000ULL,"97C71E2471E850BD","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100853015E86000%20No%20Man's%20Sky/atmosphere/contents/0100853015E86000/cheats/97C71E2471E850BD.txt"},
    {0x0100A3501946E000ULL,"0D9649011312F62E","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100A3501946E000%20OCTOPATH%20TRAVELER%20II/atmosphere/contents/0100A3501946E000/cheats/0D9649011312F62E.txt"},
    {0x0100A7C01B792000ULL,"9E9D887D59F7F7DB","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100A7C01B792000%20Minecraft%20Dungeons%20II/atmosphere/contents/0100A7C01B792000/cheats/9E9D887D59F7F7DB.txt"},
    {0x0100B04026946000ULL,"2A303783D368DF8A","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100B04026946000%20Chained%20Beasts/atmosphere/contents/0100B04026946000/cheats/2A303783D368DF8A.txt"},
    {0x0100B1C0249B4000ULL,"E258A7371ECD2A27","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100B1C0249B4000%20Frostpunk/atmosphere/contents/0100B1C0249B4000/cheats/E258A7371ECD2A27.txt"},
    {0x0100BA4026E94000ULL,"0F1169AA7D0FA452","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100BA4026E94000%20Castlevania%3A%20Belmont's%20Curse/atmosphere/contents/0100BA4026E94000/cheats/0F1169AA7D0FA452.txt"},
    {0x0100C1101EE5A000ULL,"950FB0C3D58D6A7B","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100C1101EE5A000%20High%20On%20Life/atmosphere/contents/0100C1101EE5A000/cheats/950FB0C3D58D6A7B.txt"},
    {0x0100C2500FC20000ULL,"28C4287AEE36F749","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100C2500FC20000%20Splatoon%E2%84%A2%203/atmosphere/contents/0100C2500FC20000/cheats/28C4287AEE36F749.txt"},
    {0x0100C3601518C000ULL,"5D9401301AB2BB49","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100C3601518C000%20Sid%20Meier's%20Civilization%C2%AE%20VII/atmosphere/contents/0100C3601518C000/cheats/5D9401301AB2BB49.txt"},
    {0x0100D1D027E96000ULL,"07C3F500203A719B","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100D1D027E96000%20Castlevania%20Belmont's%20Curse%20Demo/atmosphere/contents/0100D1D027E96000/cheats/07C3F500203A719B.txt"},
    {0x0100EB60202C8000ULL,"671DB2118A8BBCB5","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100EB60202C8000%20Kalanoro/atmosphere/contents/0100EB60202C8000/cheats/671DB2118A8BBCB5.txt"},
    {0x0100F7E00C70E000ULL,"0C00FC37B0610FBD","https://raw.githubusercontent.com/bad1dea/NXCheats/54fc9698d30291e1a785706f6cbc121667fbd02f/0100F7E00C70E000%20Hogwarts%20Legacy/atmosphere/contents/0100F7E00C70E000/cheats/0C00FC37B0610FBD.txt"},
};
}


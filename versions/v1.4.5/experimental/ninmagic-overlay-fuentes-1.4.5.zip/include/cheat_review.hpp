#pragma once
#include "model.hpp"
namespace nc {
// Empty means no known review block, not proof that an author's code works.
// Names, sources and selection state do not alter the fingerprint decision.
std::string blockedCheatReason(const Game &game,const Cheat &cheat);
}

#pragma once
#include "model.hpp"
#include <cstddef>
#include <string>
#include <vector>
namespace nc::overlay {
struct PublishedItem {
    size_t index=0;
    std::string name,label,detail,source,blockedReason;
    bool selected=false;
    CheatState liveState=CheatState::Unknown;
};
struct Snapshot {
    Game game;
    std::vector<PublishedItem> items;
    std::vector<std::string> selectedNames;
    size_t totalItems=0,selectedCount=0,firstItem=0,highlighted=0;
    bool initialized=false,busy=false,searching=false,ready=false,cacheAvailable=false;
    bool ownActive=false,liveChecked=false,canApply=false;
    LookupState lookupState=LookupState::NotChecked;
    std::string lookupDetail,blockedSelectionReason;
    std::string status="Preparando los cheats publicados...",error,liveDetail,lastAction;
    bool lastActionKnown=false,lastActionOk=false,lastActionRemove=false;
};
bool init(std::string&error);
void shutdown();
Snapshot snapshot();
bool refresh();
// Explicit online lookup for the running title/build. Never activates codes.
bool search();
bool move(int delta);
bool toggle(size_t visibleIndex);
bool apply();
bool remove();
void cancel();
}

#pragma once
#include "memory_scan_guard.hpp"
#include "platform_internal.hpp"
#include <array>
#include <cstring>

namespace nc::native::scan {
// Only the expensive independent loader proof is cached. A complete dmnt
// metadata response is fetched on EVERY verify call and its PID/TID/full BID
// and MAIN/HEAP/ALIAS extents are compared, including
// all three checks around each query/read. Mapping permissions are never cached.
// Atmosphere 1.12.1 GetCheatProcessMetadata calls EnsureCheatProcess, which
// checks the debug handle and current application PID without attaching:
// https://github.com/Atmosphere-NX/Atmosphere/blob/1.12.1/stratosphere/dmnt/source/cheat/impl/dmnt_cheat_api.cpp#L222-L240
// https://github.com/Atmosphere-NX/Atmosphere/blob/1.12.1/stratosphere/dmnt/source/cheat/impl/dmnt_cheat_api.cpp#L294-L301
constexpr uint64_t ReadProofBytes=1024*1024,ReadProofNs=250000000;
struct ReadPolicyMetrics {
    uint64_t metadataCalls=0,fullProofCalls=0,completedReads=0,completedBytes=0;
    uint64_t metadataNs=0,fullProofNs=0;
};
struct ReadProofSource {
    virtual ~ReadProofSource()=default;
    virtual bool metadata(Metadata&,std::string&)=0;
    virtual bool fullProof(const ScanIdentity&,std::string&)=0;
    virtual uint64_t nowNs()=0;
};
class ReadPolicy {
    ScanIdentity bound;
    std::array<uint8_t,32> build{};
    bool established=false;
    uint64_t lastProof=0,bytesSinceProof=0;
    ReadPolicyMetrics counters;
    static unsigned digit(char c){return c>='0'&&c<='9'?unsigned(c-'0'):c>='a'&&c<='f'?unsigned(c-'a'+10):unsigned(c-'A'+10);}
    static uint64_t elapsed(uint64_t start,uint64_t end){return end>=start?end-start:0;}
    bool fresh(const ScanIdentity&expected,ReadProofSource&source,std::string&error){
        Metadata current{};const auto started=source.nowNs();++counters.metadataCalls;
        const bool ok=source.metadata(current,error);counters.metadataNs+=elapsed(started,source.nowNs());
        if(!ok){invalidate();return false;}
        if(current.pid!=expected.pid||current.title!=expected.title||current.mainBase!=expected.mainBase||current.mainSize!=expected.mainSize||current.heapBase!=expected.heapBase||current.heapSize!=expected.heapSize||current.aliasBase!=expected.aliasBase||current.aliasSize!=expected.aliasSize||std::memcmp(current.build,build.data(),build.size())){
            invalidate();error="El proceso, Build ID o intervalo MAIN/HEAP/ALIAS cambió durante la lectura.";return false;
        }return true;
    }
public:
    void invalidate(){established=false;bound={};lastProof=bytesSinceProof=0;}
    void reset(){invalidate();counters={};}
    const ReadPolicyMetrics&metrics()const{return counters;}
    bool verify(const ScanIdentity&expected,ReadProofSource&source,std::string&error){
        error.clear();if(!valid(expected)){invalidate();error="La identidad de lectura no es válida.";return false;}
        const bool changed=!established||!same(bound,expected);
        if(changed){invalidate();for(size_t i=0;i<build.size();++i)build[i]=uint8_t((digit(expected.fullBuildId[i*2])<<4)|digit(expected.fullBuildId[i*2+1]));}
        if(!fresh(expected,source,error))return false;
        const uint64_t now=source.nowNs();
        if(changed||bytesSinceProof>=ReadProofBytes||now<lastProof||now-lastProof>=ReadProofNs){
            const auto started=source.nowNs();++counters.fullProofCalls;
            const bool proof=source.fullProof(expected,error);counters.fullProofNs+=elapsed(started,source.nowNs());
            if(!proof){invalidate();return false;}
            // The full proof itself spans several IPC calls. Recheck metadata
            // before returning, so its result cannot mask a switch mid-proof.
            if(!fresh(expected,source,error))return false;
            bound=expected;established=true;lastProof=source.nowNs();bytesSinceProof=0;
        }return true;
    }
    void completed(size_t size){
        if(!established||!size||size>MaxRead){invalidate();return;}
        ++counters.completedReads;counters.completedBytes+=size;bytesSinceProof+=size;
    }
};
}

#include <switch.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include "catalog.hpp"
#include "cheats.hpp"
#include "diagnostics.hpp"
#include "gameplay.hpp"
#include "platform.hpp"
#include "ui.hpp"
#include "memory_scan_guard.hpp"

namespace {
enum class Kind { Init, Scan, Search, Sync, Prepare, Apply, Remove, Refresh, OpenGenerator, StartMemoryScan, FilterMemoryScan, UndoMemoryScan, TestMemoryScan, RemoveMemoryTest, CheckAppUpdate, PrepareAppUpdate, InstallAppUpdate };
struct Job {
    Kind kind=Kind::Init;Thread thread{};bool active=false,ok=false;
    std::atomic<bool> done{false};
    nc::Environment env;nc::Catalog catalog;std::vector<nc::Game> games;
    nc::Game game;nc::Pack pack;nc::Outcome outcome;nc::ExistingContent existing;
    std::string error;
    nc::ScanSession memoryScan;
    nc::ScanCompare comparison=nc::ScanCompare::Changed;
    nc::AppUpdateInfo appUpdate;
    std::string scanValue,scanDetail,appUpdateDetail,recoveryError;
    int candidate=0,purpose=0;
    bool unknown=true,resumed=false;
} job;
constexpr const char *AppPath="sdmc:/switch/ninmagic-cheats/ninmagic-cheats.nro";
bool resumeScanner(const nc::Game &game) {
    nc::ScanIdentity identity;std::string error;
    return game.running&&nc::peekScanProcess(game,identity,error)&&nc::loadScanSession(identity,job.memoryScan,error)&&job.memoryScan.ready;
}
bool scanProcessStillSame(nc::ScanIdentity &identity) {
    if(!nc::peekScanProcess(job.pack.game,identity,job.error)){job.memoryScan.ready=false;return false;}
    if(!nc::native::scan::same(identity,job.memoryScan.identity)){job.error="El juego se reinició o cambió su memoria. Inicia una búsqueda nueva; no se reutilizarán estas direcciones.";job.memoryScan.ready=false;return false;}
    return true;
}
// A failed recheck must never bind the old codes to a new build.
bool sameBuild(nc::Game &game,std::string &error) {
    nc::Game current=game;
    if(!nc::resolveBuild(current,job.env,error)||!current.buildVerified||current.buildId!=game.buildId||(!game.fullBuildId.empty()&&current.fullBuildId!=game.fullBuildId)) {
        error="El Build ID cambió o no se pudo comprobar. Vuelve a buscar cheats para este juego. "+error;
        for(auto &c:job.pack.cheats)c.liveState=nc::CheatState::Unknown;
        job.pack.liveChecked=false;job.pack.livePid=0;job.pack.liveDetail=error;return false;
    }
    game=std::move(current);return true;
}
void readState(const char *event) {
    std::string detail;nc::readLiveState(job.pack,detail);
    nc::logCheatDiagnostic(event,job.pack,detail);
}
void work(void *) {
    struct ReadSession {ReadSession(){nc::resetScanReadSession();}~ReadSession(){nc::resetScanReadSession();}} readSession;
    job.outcome={};
    switch(job.kind) {
    case Kind::Init: {
        job.ok=nc::platformInit(job.env,job.error);
        if(job.ok)job.ok=nc::scanGames(job.games,job.env,job.error);
        std::string cacheError;nc::loadCatalog(job.catalog,cacheError);
        for(const auto &game:job.games)if(game.running) {
            nc::Game opened=game;std::string why;
            if(nc::resolveBuild(opened,job.env,why)&&resumeScanner(opened)) {
                job.pack=nc::findCheats(opened,job.catalog);nc::gameplayOnly(job.pack);job.resumed=true;break;
            }
        }
        std::string updateError;
        if(!job.resumed)job.env.network=nc::refreshCatalog(job.catalog,false,updateError);
        if(!job.env.network)job.catalog.detail+=" · Sin actualización: "+updateError;
        if(!job.recoveryError.empty())job.appUpdateDetail=job.recoveryError;
        else if(!job.resumed&&!nc::checkAppUpdate(job.appUpdate,updateError))job.appUpdateDetail=updateError;
        break;
    }
    case Kind::Scan:job.ok=nc::scanGames(job.games,job.env,job.error);break;
    case Kind::Search:
        nc::resolveBuild(job.game,job.env,job.error);
        job.pack=nc::findCheats(job.game,job.catalog);nc::gameplayOnly(job.pack);
        if(!job.error.empty())job.pack.detail=job.error+" "+job.pack.detail;
        readState("buscar");job.ok=true;break;
    case Kind::Sync:
        job.ok=nc::syncCatalog(job.catalog,job.error);job.env.network=job.ok;
        job.outcome.ok=job.ok;
        job.outcome.message=job.ok?"Catálogo actualizado. "+std::to_string(job.catalog.entries.size())+" archivos de versiones disponibles. Los nuevos cheats aparecerán al seleccionar el juego.":job.error+" Se conserva el catálogo anterior.";
        break;
    case Kind::Prepare: {
        job.ok=sameBuild(job.pack.game,job.error);
        std::vector<nc::Cheat> chosen;
        if(job.ok)job.ok=nc::selectedCheats(job.pack,chosen,job.error);
        bool exists=false;
        if(job.ok)job.ok=nc::inspectInstalledCheats(job.pack.game,exists,job.error);
        job.existing={};job.existing.game=job.pack.game;job.existing.exists=job.existing.cheats=exists;
        if(job.ok)job.ok=nc::inspectActive(job.pack.game,job.existing.activeCheats,job.error);
        job.pack.liveHydrated=true;readState("revisar");break;
    }
    case Kind::Apply: {
        const bool approvedRunning=job.pack.game.running;
        if(!sameBuild(job.pack.game,job.error)){job.outcome.message=job.error;break;}
        if(job.pack.game.running!=approvedRunning){job.outcome.message="El juego se abrió o cerró después de confirmar. Vuelve a revisar la selección.";break;}
        bool exists=false;unsigned active=0;
        if(!nc::inspectInstalledCheats(job.pack.game,exists,job.error)||!nc::inspectActive(job.pack.game,active,job.error)){job.outcome.message=job.error;break;}
        if(exists!=job.existing.exists||active!=job.existing.activeCheats){job.outcome.message="Los cheats anteriores cambiaron después de revisarlos. Vuelve a pulsar Y y confirma de nuevo.";break;}
        job.outcome=job.pack.game.running?nc::applyLive(job.pack):nc::installPack(job.pack);
        job.ok=job.outcome.ok;job.pack.liveHydrated=true;readState("aplicar");
        nc::logCheatDiagnostic("resultado-aplicar",job.pack,job.outcome.message);break;
    }
    case Kind::Remove: {
        const bool approvedRunning=job.pack.game.running;
        if(!sameBuild(job.pack.game,job.error)){job.outcome.message=job.error;break;}
        if(job.pack.game.running!=approvedRunning){job.outcome.message="El juego se abrió o cerró después de confirmar. Vuelve a revisar la retirada.";break;}
        if(job.pack.game.running)job.outcome=nc::removeLive(job.pack.game);
        else {
            job.outcome=nc::restorePack(job.pack.game);
            if(job.outcome.ok) {
                if(!job.outcome.previousContent.empty()||!job.outcome.previousPatches.empty()) {
                    job.outcome.ok=false;
                    job.outcome.message+=" La copia antigua incluye archivos externos de la versión con mods. Su recuperación queda pendiente; conserva la copia indicada y usa aquella versión para completar la recuperación.";
                } else if(!nc::finishPackRecovery(job.pack.game,job.outcome.transactionId,job.error)) {
                    job.outcome.ok=false;job.outcome.message+=" "+job.error;
                }
            }
        }
        job.ok=job.outcome.ok;job.pack.liveHydrated=true;readState("retirar");
        nc::logCheatDiagnostic("resultado-retirar",job.pack,job.outcome.message);break;
    }
    case Kind::Refresh:
        job.pack.liveHydrated=true;job.ok=sameBuild(job.pack.game,job.error);
        if(job.ok)job.ok=nc::readLiveState(job.pack,job.error);
        else {for(auto &c:job.pack.cheats)c.liveState=nc::CheatState::Unknown;job.pack.liveChecked=false;job.pack.liveDetail=job.error;}
        nc::logCheatDiagnostic("leer-estado",job.pack,job.error);break;
    case Kind::OpenGenerator: {
        job.ok=nc::resolveBuild(job.game,job.env,job.error);
        job.pack=nc::findCheats(job.game,job.catalog);nc::gameplayOnly(job.pack);job.memoryScan={};
        if(job.unknown)job.memoryScan.type=nc::ScanValueType::U8;
        if(job.ok)job.resumed=resumeScanner(job.game);
        if(!job.ok)job.scanDetail=job.error;
        else if(!job.game.running)job.scanDetail="Abre el juego y entra por Álbum sin cerrarlo para buscar valores.";
        job.ok=true;break;
    }
    case Kind::StartMemoryScan: {
        nc::ScanIdentity identity;std::vector<nc::ScanRegion> regions;
        job.ok=nc::getScanProcess(job.pack.game,identity,job.error)&&nc::enumerateScanRegions(identity,regions,job.error);
        if(job.ok)job.ok=job.unknown?nc::startUnknownScan(identity,regions,job.memoryScan.type,nc::readScanMemory,job.memoryScan,job.error):nc::startExactScan(identity,regions,job.memoryScan.type,job.scanValue,nc::readScanMemory,job.memoryScan,job.error);
        job.scanDetail=job.ok?"Lectura guardada. Vuelve al juego, cambia el valor y regresa por Álbum para comparar.":job.error;
        break;
    }
    case Kind::FilterMemoryScan: {
        nc::ScanIdentity identity;job.ok=scanProcessStillSame(identity);
        if(job.ok)job.ok=nc::refineScan(identity,job.comparison,job.scanValue,nc::readScanMemory,job.memoryScan,job.error);
        job.scanDetail=job.ok?"Comparación guardada. Una coincidencia todavía necesita una prueba dentro del juego.":job.error;break;
    }
    case Kind::UndoMemoryScan: {
        nc::ScanIdentity identity;job.ok=scanProcessStillSame(identity);
        if(job.ok)job.ok=nc::restorePreviousScan(identity,job.memoryScan,job.error);
        if(job.ok){nc::ScanIdentity after;job.ok=scanProcessStillSame(after);}
        job.scanDetail=job.ok?"Paso anterior recuperado. No se activó ningún código. Revisa qué cambió antes de volver a comparar.":job.error;break;
    }
    case Kind::TestMemoryScan: {
        if(!job.memoryScan.ready||job.memoryScan.baseline||job.memoryScan.rounds<3||job.memoryScan.candidates.size()!=1){job.outcome.message="Primero reduce la búsqueda a una coincidencia tras al menos dos comparaciones dentro del juego.";break;}
        nc::ScanIdentity identity;if(!scanProcessStillSame(identity)){job.outcome.message=job.error;break;}
        const auto &candidate=job.memoryScan.candidates[0];uint8_t bytes[4]{};
        const size_t width=job.memoryScan.type==nc::ScanValueType::U8?1:job.memoryScan.type==nc::ScanValueType::U16?2:4;
        if(!nc::readScanMemory(identity,candidate.address,bytes,width,job.error)){job.outcome.message=job.error;break;}
        uint32_t observed=0;for(size_t i=0;i<width;++i)observed|=uint32_t(bytes[i])<<(8*i);
        if(observed!=candidate.valueBits){job.outcome.message="El candidato cambió después de la última lectura. Compara otra vez antes de probarlo.";break;}
        const char *names[]={"Salud","Municion","Vidas","Magia","Objetos","Dinero","Movimiento","Valor"};
        nc::Cheat cheat;
        if(!nc::scanCandidateCheat(job.memoryScan,0,job.scanValue,std::string("NinMagic prueba ")+names[std::clamp(job.purpose,0,7)],cheat,job.error)){job.outcome.message=job.error;break;}
        nc::Pack test;test.game=job.pack.game;test.compatible=true;test.sessionOnly=true;test.sessionBinding=identity;test.cheats.push_back(std::move(cheat));
        job.outcome=nc::applyLive(test);job.ok=job.outcome.ok;
        if(job.ok)job.outcome.message+=" Es una prueba de esta sesión. Vuelve al juego para comprobar qué modifica; L permite retirarla. No es un cheat portátil verificado.";
        nc::logCheatDiagnostic("prueba-creador",test,job.outcome.message);break;
    }
    case Kind::RemoveMemoryTest: {
        nc::ScanIdentity identity;
        if(!scanProcessStillSame(identity)){job.outcome.message=job.error;break;}
        job.outcome=nc::removeLive(job.pack.game);job.ok=job.outcome.ok;break;
    }
    case Kind::CheckAppUpdate:
        job.ok=nc::checkAppUpdate(job.appUpdate,job.error);job.appUpdateDetail=job.ok?"":job.error;break;
    case Kind::PrepareAppUpdate:
        job.ok=nc::prepareAppUpdate(job.appUpdate,AppPath,job.error);
        if(!job.ok)job.appUpdateDetail=job.error;
        break;
    case Kind::InstallAppUpdate:
        job.ok=nc::installPreparedAppUpdate(job.appUpdate,AppPath,job.error);
        job.outcome.ok=job.ok;job.outcome.message=job.ok?"Nueva versión instalada y verificada. Cierra NinMagic y vuelve a abrirla. Se conserva una copia de la versión anterior.":job.error;break;
    }
    job.done.store(true,std::memory_order_release);
}
bool start(Kind kind,nc::View &v) {
    job.kind=kind;job.env=v.env;job.catalog=v.catalog;job.error.clear();job.ok=false;job.done.store(false);
    job.resumed=false;job.memoryScan=v.scan;job.comparison=v.scanCompare;job.scanValue=v.scanValue;job.candidate=v.scanSelected;job.purpose=v.scanPurpose;job.unknown=v.scanUnknown;job.scanDetail.clear();job.appUpdate=v.appUpdate;job.appUpdateDetail.clear();
    if(kind==Kind::StartMemoryScan||kind==Kind::FilterMemoryScan||kind==Kind::UndoMemoryScan||kind==Kind::TestMemoryScan||kind==Kind::RemoveMemoryTest)job.pack=v.pack;
    Result rc=threadCreate(&job.thread,work,nullptr,nullptr,512*1024,0x2c,-2);
    if(R_SUCCEEDED(rc)){rc=threadStart(&job.thread);if(R_FAILED(rc))threadClose(&job.thread);}
    if(R_FAILED(rc)){v.outcome={};v.outcome.message="No se pudo iniciar la operación.";v.screen=nc::Screen::Result;return false;}
    job.active=true;appletSetAutoSleepDisabled(true);return true;
}
std::vector<size_t> visible(const nc::View &v) {
    std::vector<size_t> out;for(size_t i=0;i<v.pack.cheats.size();++i)if(!v.pack.cheats[i].master)out.push_back(i);return out;
}
void editValue(nc::View &v) {
    SwkbdConfig keyboard{};if(R_FAILED(swkbdCreate(&keyboard,0))){v.scanDetail="No se pudo abrir el teclado de la consola.";return;}
    swkbdConfigMakePresetDefault(&keyboard);swkbdConfigSetHeaderText(&keyboard,"Valor observado o para fijar");
    swkbdConfigSetType(&keyboard,SwkbdType_NumPad);swkbdConfigSetLeftOptionalSymbolKey(&keyboard,"-");swkbdConfigSetRightOptionalSymbolKey(&keyboard,".");
    swkbdConfigSetSubText(&keyboard,"Usa el número visible o el valor del candidato; no se inventa una cantidad para los puntos.");
    swkbdConfigSetInitialText(&keyboard,v.scanValue.c_str());swkbdConfigSetStringLenMax(&keyboard,32);swkbdConfigSetStringLenMin(&keyboard,1);
    char input[128]{};if(R_SUCCEEDED(swkbdShow(&keyboard,input,sizeof(input))))v.scanValue=input;swkbdClose(&keyboard);
}
}
int main(int,char**) {
    nc::recoverAppUpdate(AppPath,job.recoveryError);
    const Result rom=romfsInit();
    bool romMounted=R_SUCCEEDED(rom);
    if(R_FAILED(rom)||!nc::uiInit("romfs:")) {
        consoleInit(nullptr);std::printf("ninmagic-cheats: faltan recursos. Copia el NRO completo.\nPulsa + para salir.\n");
        PadState p;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&p);
        while(appletMainLoop()){padUpdate(&p);if(padGetButtonsDown(&p)&HidNpadButton_Plus)break;consoleUpdate(nullptr);}
        consoleExit(nullptr);if(R_SUCCEEDED(rom))romfsExit();return 1;
    }
    Framebuffer fb{};Result rc=framebufferCreate(&fb,nwindowGetDefault(),1280,720,PIXEL_FORMAT_RGBA_8888,2);
    if(R_FAILED(rc)){nc::uiExit();romfsExit();return 1;}
    if(R_FAILED(framebufferMakeLinear(&fb))){framebufferClose(&fb);nc::uiExit();romfsExit();return 1;}
    PadState pad;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&pad);
    nc::View view;view.scan.type=nc::ScanValueType::U8;view.status="Detectando juegos y actualizando el catálogo por Internet...";
    start(Kind::Init,view);bool quit=false;uint64_t repeatStart=0,lastRepeat=0,lastDirection=0;
    while(appletMainLoop()&&!quit) {
        padUpdate(&pad);const auto down=padGetButtonsDown(&pad),held=padGetButtons(&pad);
        const uint64_t now=armTicksToNs(armGetSystemTick());
        if(job.active&&job.done.load(std::memory_order_acquire)) {
            threadWaitForExit(&job.thread);threadClose(&job.thread);job.active=false;appletSetAutoSleepDisabled(false);
            view.env=job.env;view.catalog=job.catalog;
            view.appUpdate=job.appUpdate;view.appUpdateDetail=job.appUpdateDetail;
            if(job.kind==Kind::Init||job.kind==Kind::Scan) {
                view.games=std::move(job.games);view.selected=std::clamp(view.selected,0,std::max(0,int(view.games.size())-1));
                if(job.ok){view.screen=nc::Screen::Library;view.status=view.catalog.entries.empty()?"Y actualiza el catálogo. Con Internet también se actualiza al abrir.":job.kind==Kind::Init?(job.env.network?"Catálogo comprobado por Internet. Elige un juego para ver sus cheats.":"Sin actualización por Internet. Catálogo guardado disponible; Y vuelve a comprobar."):"Biblioteca actualizada. Elige un juego para ver sus cheats.";
                    if(job.resumed){view.pack=std::move(job.pack);view.scan=std::move(job.memoryScan);view.scanSelected=0;view.scanPurpose=7;view.scanDetail="Búsqueda recuperada del mismo proceso. La finalidad se muestra como Otro valor; compara el cambio que hiciste en el juego.";view.screen=nc::Screen::ScanResults;}}
                else {view.returnScreen=0;view.outcome={};view.outcome.message=job.error;view.screen=nc::Screen::Result;}
            } else if(job.kind==Kind::Search) {
                view.pack=std::move(job.pack);view.filter=0;view.cheatSelected=0;view.restore=false;view.screen=nc::Screen::Cheats;
                if(!view.games.empty())view.games[view.selected]=view.pack.game;
            } else if(job.kind==Kind::Prepare) {
                view.pack=std::move(job.pack);view.existing=job.existing;view.liveRequested=view.pack.game.running;
                if(job.ok)view.screen=nc::Screen::Confirm;
                else {view.outcome={};view.outcome.message=job.error;view.screen=nc::Screen::Result;view.returnScreen=1;}
            } else if(job.kind==Kind::Refresh) {
                view.pack=std::move(job.pack);view.screen=nc::Screen::Cheats;
            } else if(job.kind==Kind::OpenGenerator) {
                view.pack=std::move(job.pack);view.scan=std::move(job.memoryScan);view.scanSelected=0;view.scanDetail=job.scanDetail;
                if(job.resumed)view.scanPurpose=7;
                view.screen=job.resumed?nc::Screen::ScanResults:nc::Screen::ScanSetup;
            } else if(job.kind==Kind::StartMemoryScan||job.kind==Kind::FilterMemoryScan||job.kind==Kind::UndoMemoryScan) {
                view.scan=std::move(job.memoryScan);view.scanSelected=0;view.scanDetail=job.scanDetail;
                if(job.ok&&(job.kind==Kind::StartMemoryScan||job.kind==Kind::UndoMemoryScan))view.scanCompare=view.scanUnknown?nc::ScanCompare::Changed:nc::ScanCompare::Exact;
                view.screen=job.ok||view.scan.ready?nc::Screen::ScanResults:nc::Screen::ScanSetup;
            } else if(job.kind==Kind::TestMemoryScan||job.kind==Kind::RemoveMemoryTest) {
                view.scan=std::move(job.memoryScan);view.outcome=std::move(job.outcome);view.returnScreen=2;view.screen=nc::Screen::Result;
            } else if(job.kind==Kind::CheckAppUpdate) {
                view.screen=nc::Screen::AppUpdate;
            } else if(job.kind==Kind::PrepareAppUpdate) {
                if(!job.ok)view.screen=nc::Screen::AppUpdate;
                else {
                    if(romMounted){romfsExit();romMounted=false;}
                    view.screen=nc::Screen::Busy;view.status="Instalando la descarga verificada y conservando el NRO anterior...";start(Kind::InstallAppUpdate,view);
                }
            } else if(job.kind==Kind::InstallAppUpdate) {
                view.outcome=std::move(job.outcome);view.returnScreen=4;view.screen=nc::Screen::Result;
            } else {
                if(job.kind==Kind::Apply||job.kind==Kind::Remove)view.pack=std::move(job.pack);
                view.outcome=std::move(job.outcome);view.screen=nc::Screen::Result;view.returnScreen=job.kind==Kind::Sync?0:1;
            }
        }
        if(!job.active) {
            using nc::Screen;
            const uint64_t up=HidNpadButton_Up|HidNpadButton_StickLUp,downKey=HidNpadButton_Down|HidNpadButton_StickLDown;
            const uint64_t direction=(held&up)?up:(held&downKey)?downKey:0;
            bool move=(down&(up|downKey))!=0;
            if(direction!=lastDirection){repeatStart=now;lastRepeat=now;lastDirection=direction;}
            if(direction&&now-repeatStart>350000000ULL&&now-lastRepeat>85000000ULL){move=true;lastRepeat=now;}
            const int delta=(held&up)?-1:1;
            if(down&HidNpadButton_Plus)quit=true;
            else if(view.screen==Screen::Library) {
                if(move&&!view.games.empty())view.selected=(view.selected+delta+int(view.games.size()))%int(view.games.size());
                if(down&HidNpadButton_Minus)view.screen=Screen::Help;
                else if(down&HidNpadButton_L){view.restore=false;view.screen=Screen::Busy;view.status="Buscando una versión nueva de NinMagic...";start(Kind::CheckAppUpdate,view);}
                else if(down&HidNpadButton_Y){view.restore=false;view.screen=Screen::Busy;view.status="Buscando publicaciones nuevas y comprobando el catálogo...";start(Kind::Sync,view);}
                else if(down&HidNpadButton_X){view.screen=Screen::Loading;view.status="Actualizando los juegos instalados...";start(Kind::Scan,view);}
                else if((down&HidNpadButton_ZR)&&!view.games.empty()){
                    view.restore=false;job.game=view.games[view.selected];view.screen=Screen::Loading;view.status="Comprobando el juego para abrir el creador guiado...";start(Kind::OpenGenerator,view);
                }
                else if((down&HidNpadButton_A)&&!view.games.empty()){
                    job.game=view.games[view.selected];view.screen=Screen::Loading;view.status="Comprobando el Build ID y buscando cheats de jugabilidad...";start(Kind::Search,view);
                }
            } else if(view.screen==Screen::Cheats) {
                const auto rows=visible(view);
                if(move&&!rows.empty())view.cheatSelected=(view.cheatSelected+delta+int(rows.size()))%int(rows.size());
                if(down&HidNpadButton_B)view.screen=Screen::Library;
                else if(down&HidNpadButton_ZR){view.restore=false;job.game=view.pack.game;view.screen=Screen::Loading;view.status="Recuperando el creador del juego abierto...";start(Kind::OpenGenerator,view);}
                else if(down&HidNpadButton_X){job.pack=view.pack;view.screen=Screen::Busy;view.status="Leyendo el estado real del motor, sin cambiar la selección...";start(Kind::Refresh,view);}
                else if(down&HidNpadButton_L){view.restore=true;view.liveRequested=view.pack.game.running;view.screen=Screen::Confirm;}
                else if((down&HidNpadButton_Y)&&nc::selectedCount(view.pack)) {
                    view.restore=false;job.pack=view.pack;view.screen=Screen::Busy;view.status="Comprobando la versión y los cheats anteriores...";start(Kind::Prepare,view);
                } else if((down&HidNpadButton_A)&&!rows.empty()) {
                    auto &c=view.pack.cheats[rows[view.cheatSelected]];c.selected=!c.selected;
                }
            } else if(view.screen==Screen::Confirm) {
                if(down&HidNpadButton_B)view.screen=Screen::Cheats;
                else if(down&HidNpadButton_A){
                    job.pack=view.pack;job.existing=view.existing;view.screen=Screen::Busy;
                    view.status=view.restore?"Retirando los cheats de NinMagic...":"Aplicando la selección al juego comprobado...";
                    start(view.restore?Kind::Remove:Kind::Apply,view);
                }
            } else if(view.screen==Screen::Result) {
                if(down&(HidNpadButton_A|HidNpadButton_B))view.screen=view.returnScreen==4?Screen::AppUpdate:view.returnScreen==2?Screen::ScanResults:view.returnScreen==1?Screen::Cheats:Screen::Library;
            } else if(view.screen==Screen::ScanSetup) {
                if(down&HidNpadButton_B)view.screen=Screen::Cheats;
                else if(down&HidNpadButton_R)view.scanPurpose=(view.scanPurpose+1)%8;
                else if(down&HidNpadButton_L){view.scanUnknown=!view.scanUnknown;if(view.scanUnknown&&!view.scan.ready)view.scan.type=nc::ScanValueType::U8;}
                else if(down&HidNpadButton_A)editValue(view);
                else if(down&HidNpadButton_X){const auto type=static_cast<nc::ScanValueType>((static_cast<unsigned>(view.scan.type)+1)%4);view.scan={};view.scan.type=type;}
                else if(down&HidNpadButton_Y){
                    if(!view.pack.game.running)view.scanDetail="Abre este juego y vuelve desde Álbum sin cerrarlo.";
                    else {view.scanConfirmStart=true;view.screen=Screen::ScanConfirm;}
                }
            } else if(view.screen==Screen::ScanResults) {
                if(move&&!view.scan.candidates.empty()&&view.scan.candidates.size()<=20)view.scanSelected=(view.scanSelected+delta+static_cast<int>(view.scan.candidates.size()))%static_cast<int>(view.scan.candidates.size());
                if(down&HidNpadButton_B)view.screen=Screen::ScanSetup;
                else if(down&(HidNpadButton_Left|HidNpadButton_Right))view.scanCompare=static_cast<nc::ScanCompare>((static_cast<unsigned>(view.scanCompare)+(down&HidNpadButton_Left?4:1))%5);
                else if(down&HidNpadButton_X)editValue(view);
                else if(down&HidNpadButton_ZL){view.screen=Screen::Busy;view.status="Comprobando y recuperando el paso anterior de esta misma búsqueda...";start(Kind::UndoMemoryScan,view);}
                else if(down&HidNpadButton_Y){view.screen=Screen::Busy;view.status="Comparando la memoria del mismo proceso con la lectura anterior...";start(Kind::FilterMemoryScan,view);}
                else if(down&HidNpadButton_L){view.restore=true;view.screen=Screen::Busy;view.status="Retirando los códigos que NinMagic activó en esta sesión...";start(Kind::RemoveMemoryTest,view);}
                else if(down&HidNpadButton_A){
                    if(view.scan.ready&&!view.scan.baseline&&view.scan.candidates.size()==1&&view.scan.rounds>=3){
                        view.scanValue=nc::scanValueText(view.scan.type,view.scan.candidates[0].valueBits);view.scanSelected=0;view.scanConfirmStart=false;view.restore=false;view.screen=Screen::ScanConfirm;
                    }else view.scanDetail="Primero deja una sola coincidencia y realiza al menos dos comparaciones dentro del juego.";
                }
            } else if(view.screen==Screen::ScanConfirm) {
                if(down&HidNpadButton_B)view.screen=view.scanConfirmStart?Screen::ScanSetup:Screen::ScanResults;
                else if((down&HidNpadButton_X)&&!view.scanConfirmStart)editValue(view);
                else if(down&HidNpadButton_A){view.restore=false;view.screen=Screen::Busy;view.status=view.scanConfirmStart?"Leyendo MAIN/HEAP y Heap validado en ALIAS. La primera referencia amplia puede tardar; la búsqueda no modifica los valores...":"Comprobando el candidato, la sesión y la ausencia de otros cheats activos antes de la prueba...";start(view.scanConfirmStart?Kind::StartMemoryScan:Kind::TestMemoryScan,view);}
            } else if(view.screen==Screen::AppUpdate) {
                if(down&HidNpadButton_B)view.screen=Screen::Library;
                else if(down&HidNpadButton_X){if(view.appUpdate.installed)view.appUpdateDetail="Cierra y vuelve a abrir NinMagic para ejecutar la versión nueva antes de volver a comprobar.";else {view.screen=Screen::Busy;view.status="Comprobando el canal de actualizaciones de NinMagic...";start(Kind::CheckAppUpdate,view);}}
                else if((down&HidNpadButton_A)&&view.appUpdate.configured&&view.appUpdate.available&&!view.appUpdate.installed){view.restore=false;view.screen=Screen::Busy;view.status="Descargando y verificando el NRO antes de sustituir la aplicación...";start(Kind::PrepareAppUpdate,view);}
            } else if(view.screen==Screen::Help) {
                if(down&(HidNpadButton_B|HidNpadButton_A|HidNpadButton_Minus))view.screen=Screen::Library;
            }
        }
        u32 stride=0;auto *pixels=static_cast<uint32_t*>(framebufferBegin(&fb,&stride));nc::uiDraw(pixels,int(stride/4),view);framebufferEnd(&fb);++view.frame;
    }
    if(job.active){threadWaitForExit(&job.thread);threadClose(&job.thread);}
    std::string exitDetail;nc::readLiveState(view.pack,exitDetail);nc::logCheatDiagnostic("salir",view.pack,exitDetail);
    appletSetAutoSleepDisabled(false);nc::catalogExit();nc::platformExit();nc::uiExit();framebufferClose(&fb);if(romMounted)romfsExit();return 0;
}

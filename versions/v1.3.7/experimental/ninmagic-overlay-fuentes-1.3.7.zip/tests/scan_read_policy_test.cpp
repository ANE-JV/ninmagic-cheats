#include "scan_read_policy.hpp"
#include <array>
#include <cstdlib>
#include <iostream>

using namespace nc;
using namespace nc::native;
using namespace nc::native::scan;
namespace {
unsigned scenarios=0,checks=0;
void require(bool value,const char*text){++checks;if(!value){std::cerr<<"FAIL: "<<text<<'\n';std::exit(1);}}
#define CHECK(value) require((value),#value)
ScanIdentity identity(){return {55,0x0100B51020B68000ULL,"0123456789ABCDEF"+std::string(48,'0'),0x10000000,0x10000,0x20000000,0x10000,0x3000000000ULL,0x1000000000ULL};}
Metadata wireMetadata(const ScanIdentity&i){Metadata m;m.pid=i.pid;m.title=i.title;m.mainBase=i.mainBase;m.mainSize=i.mainSize;m.heapBase=i.heapBase;m.heapSize=i.heapSize;m.aliasBase=i.aliasBase;m.aliasSize=i.aliasSize;for(size_t n=0;n<32;++n)m.build[n]=uint8_t(std::strtoul(i.fullBuildId.substr(n*2,2).c_str(),nullptr,16));return m;}
struct Fake:ReadProofSource {
    ScanIdentity id=identity();Metadata current=wireMetadata(id);
    uint64_t clock=0,metadataDuration=0,proofDuration=0;
    unsigned calls=0,proofs=0,changeAt=0,field=0;
    bool metadataFail=false,proofFail=false,changeInProof=false;
    void change(){switch(field){case 0:++current.pid;break;case 1:++current.title;break;case 2:current.build[31]^=1;break;case 3:++current.mainBase;break;case 4:++current.mainSize;break;case 5:++current.heapBase;break;case 6:++current.heapSize;break;case 7:++current.aliasBase;break;default:++current.aliasSize;break;}}
    bool metadata(Metadata&m,std::string&error)override{++calls;clock+=metadataDuration;if(changeAt&&calls>=changeAt)change();if(metadataFail){error="metadata failed";return false;}m=current;return true;}
    bool fullProof(const ScanIdentity&,std::string&error)override{++proofs;clock+=proofDuration;if(changeInProof)change();if(proofFail){error="full proof failed";return false;}return true;}
    uint64_t nowNs()override{return clock;}
};
struct Reader:Access {
    ReadPolicy policy;Fake source;
    Mapping mapping{identity().aliasBase,0x200000,3,5};
    unsigned queries=0,reads=0;bool queryFail=false,readFail=false,changeOnQuery=false,changeOnRead=false;
    bool verify(const ScanIdentity&i,std::string&error)override{return policy.verify(i,source,error);}
    bool query(uint64_t,Mapping&m,std::string&error)override{++queries;if(changeOnQuery)source.change();if(queryFail){error="query failed";return false;}m=mapping;return true;}
    bool read(uint64_t,void*out,size_t size,std::string&error)override{++reads;std::memset(out,0xA5,size);if(changeOnRead)source.change();if(readFail){error="read failed";return false;}return true;}
    bool run(const ScanIdentity&id,void*out,size_t size,std::string&error){const bool ok=checkedRead(id,id.aliasBase,out,size,*this,error);if(ok)policy.completed(size);else policy.invalidate();return ok;}
};
bool zero(const std::array<uint8_t,8>&bytes){return std::all_of(bytes.begin(),bytes.end(),[](uint8_t b){return b==0;});}
}
int main(){const auto id=identity();std::string error;
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));CHECK(r.source.calls==4&&r.source.proofs==1&&r.queries==1&&r.reads==1&&bytes[0]==0xA5);CHECK(r.policy.metrics().completedReads==1&&r.policy.metrics().completedBytes==8);CHECK(r.run(id,bytes.data(),bytes.size(),error));CHECK(r.source.calls==7&&r.source.proofs==1&&r.queries==2&&r.reads==2);++scenarios;}
    // Every component of the fresh wire metadata invalidates a cached proof
    // before a second query or value read can happen.
    for(unsigned field=0;field<9;++field){Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.source.field=field;r.source.changeAt=5;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.queries==1&&r.reads==1);r.source.changeAt=0;r.source.current=wireMetadata(id);CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,MaxRead> bytes{};for(unsigned i=0;i<16;++i)CHECK(r.run(id,bytes.data(),bytes.size(),error));CHECK(r.source.proofs==1&&r.source.calls==49);CHECK(r.run(id,bytes.data(),bytes.size(),error));CHECK(r.source.proofs==2&&r.source.calls==53&&r.policy.metrics().completedBytes==17*MaxRead);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.source.clock=ReadProofNs-1;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==1);r.source.clock=ReadProofNs;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};r.source.clock=1000;CHECK(r.run(id,bytes.data(),bytes.size(),error));r.source.clock=500;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};r.source.proofFail=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.queries==0&&r.reads==0);r.source.proofFail=false;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};r.source.metadataFail=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.queries==0&&r.source.proofs==0);r.source.metadataFail=false;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==1);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};r.source.changeInProof=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.source.calls==2&&r.queries==0&&r.reads==0);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.changeOnQuery=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.reads==1);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.changeOnRead=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.reads==2);++scenarios;}
    for(unsigned type:{0u,4u,6u}){Reader r;std::array<uint8_t,8> bytes{};r.mapping.type=type;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.reads==0);++scenarios;}
    for(unsigned permission:{1u,5u,7u,0x10000003u}){Reader r;std::array<uint8_t,8> bytes{};r.mapping.permission=permission;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes)&&r.reads==0);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.queryFail=true;CHECK(!r.run(id,bytes.data(),bytes.size(),error));r.queryFail=false;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.readFail=true;bytes.fill(1);CHECK(!r.run(id,bytes.data(),bytes.size(),error)&&zero(bytes));r.readFail=false;CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};CHECK(r.run(id,bytes.data(),bytes.size(),error));r.policy.reset();CHECK(r.policy.metrics().metadataCalls==0&&r.policy.metrics().completedBytes==0);CHECK(r.run(id,bytes.data(),bytes.size(),error)&&r.source.proofs==2);CHECK(r.policy.metrics().metadataCalls==4&&r.policy.metrics().fullProofCalls==1);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};r.source.metadataDuration=3;r.source.proofDuration=10;CHECK(r.run(id,bytes.data(),bytes.size(),error));CHECK(r.policy.metrics().metadataNs==12&&r.policy.metrics().fullProofNs==10);++scenarios;}
    {Reader r;std::array<uint8_t,8> bytes{};auto bad=id;bad.aliasBase=0;CHECK(!r.run(bad,bytes.data(),bytes.size(),error)&&r.source.calls==0&&r.queries==0&&r.reads==0);++scenarios;}
    std::cout<<"scan read policy: "<<scenarios<<" scenarios, "<<checks<<" checks PASS\n";return 0;
}

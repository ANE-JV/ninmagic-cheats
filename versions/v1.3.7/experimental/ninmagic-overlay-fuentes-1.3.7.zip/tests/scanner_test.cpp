#define NC_SCANNER_TEST
#include "../source/scanner.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace fs=std::filesystem;
namespace {
unsigned checks=0,scenarios=0;fs::path sandbox,current;
void require(bool ok,const char *message){++checks;if(!ok)throw std::runtime_error(message);}
#define CHECK(v) require((v),#v)
struct Fixture {
    nc::ScanIdentity id{42,0x01006BB00C6F0000ULL,std::string(64,'A'),0x10000000,4096,0x20000000,4096};
    std::vector<uint8_t> main=std::vector<uint8_t>(4096),heap=std::vector<uint8_t>(4096),alias;
    std::vector<nc::ScanRegion> regions{{id.mainBase,id.mainSize,true},{id.heapBase,id.heapSize,true}};
    unsigned calls=0;int failAt=-1;uint64_t bytesRead=0;size_t maxRead=0;
    nc::ScanReader reader(){return [this](const nc::ScanIdentity &identity,uint64_t address,void *out,size_t count,std::string &error){++calls;bytesRead+=count;maxRead=std::max(maxRead,count);if(!nc::sameIdentity(identity,id)||(failAt>=0&&int(calls)>=failAt)){error="fixture process changed or read interrupted";return false;}for(auto entry:{std::pair<uint64_t,std::vector<uint8_t>*>(id.mainBase,&main),{id.heapBase,&heap},{id.aliasBase,&alias}})if(address>=entry.first&&count<=entry.second->size()&&address-entry.first<=entry.second->size()-count){std::memcpy(out,entry.second->data()+size_t(address-entry.first),count);return true;}error="fixture outside memory";return false;};}
    void value(uint64_t address,uint32_t bits,unsigned width=4){const bool inAlias=id.aliasSize&&address>=id.aliasBase&&address-id.aliasBase<id.aliasSize;auto &bytes=inAlias?alias:address>=id.heapBase?heap:main;uint64_t base=inAlias?id.aliasBase:address>=id.heapBase?id.heapBase:id.mainBase;CHECK(address>=base&&address-base+width<=bytes.size());for(unsigned i=0;i<width;++i)bytes[size_t(address-base)+i]=uint8_t(bits>>(i*8));}
    void floating(uint64_t address,float number){uint32_t bits;std::memcpy(&bits,&number,4);value(address,bits);}
};
void next(){current=sandbox/("case-"+std::to_string(++scenarios));fs::create_directory(current);setenv("NC_SCANNER_ROOT",current.generic_string().c_str(),1);nc::setScanObserver({});nc::markerFailure={};nc::ioStats={};}
std::string read(const fs::path &path){std::ifstream f(path,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void put(const fs::path &path,const std::string &text){std::ofstream f(path,std::ios::binary);f.write(text.data(),std::streamsize(text.size()));CHECK(bool(f));}
void patchByte(const fs::path &path,size_t index){auto bytes=read(path);CHECK(index<bytes.size());bytes[index]^=1;put(path,bytes);}
std::vector<uint8_t> legacyMetadata(nc::Stored stored,unsigned version=1){CHECK(version>=1&&version<=3);auto data=nc::serialize(stored);data.resize(data.size()-4);data.erase(data.begin()+192,data.begin()+204);if(version<3)data.erase(data.begin()+136,data.begin()+152);if(version==1)data.erase(data.begin()+164,data.begin()+176);data[6]=char('0'+version);data[8]=uint8_t(version);data[9]=data[10]=data[11]=0;nc::put32(data,uint32_t(crc32(0,data.data(),uInt(data.size()))));return data;}
void twoThenZero(Fixture &f,nc::ScanSession &session){std::string error;f.value(f.id.mainBase+4,10);f.value(f.id.mainBase+8,10);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"10",f.reader(),session,error)&&session.candidateCount==2);f.value(f.id.mainBase+4,9);f.value(f.id.mainBase+8,9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==2&&session.rounds==2);CHECK(nc::refineScan(f.id,nc::ScanCompare::Increased,"",f.reader(),session,error)&&session.candidateCount==0&&session.rounds==3&&!session.baseline);}
void sparsePool(Fixture&f,nc::ScanSession&session,size_t bytes=2*1024*1024,size_t count=25000,bool legacy=false){
    std::string error;f.main.assign(bytes,10);f.id.mainSize=bytes;f.regions={{f.id.mainBase,f.id.mainSize,true}};
    CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));
    if(legacy){nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));const auto data=legacyMetadata(stored,3);CHECK(nc::writeFile(nc::file(stored.slot,".dat"),data.data(),data.size()));CHECK(nc::loadScanSession(f.id,session,error)&&session.storage==nc::ScanStorage::DenseSnapshot);}
    std::fill(f.main.begin(),f.main.begin()+count,9);
    CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::SparseDisk&&session.candidateCount==count);
}
void cleanup(){const auto resolved=fs::weakly_canonical(sandbox),parent=fs::weakly_canonical(fs::temp_directory_path());CHECK(resolved.parent_path()==parent&&resolved.filename().string().find("ninmagic-scanner-test-")==0);fs::remove_all(resolved);}
}
int main(){sandbox=fs::temp_directory_path()/("ninmagic-scanner-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{fs::create_directory(sandbox);std::string error;nc::ScanSession session;
    next();{Fixture f;f.value(f.id.mainBase+1,7,1);f.value(f.id.heapBase+2,7,1);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error));CHECK(session.ready&&!session.baseline&&session.rounds==1&&session.candidates.size()==2);CHECK(session.candidates[0].address==f.id.mainBase+1&&session.candidates[1].address==f.id.heapBase+2);CHECK(session.coveredBytes==8192&&session.totalBytes==8192&&!session.partial);nc::ScanSession resumed;CHECK(nc::loadScanSession(f.id,resumed,error)&&nc::sameSession(session,resumed));}
    next();{Fixture f;f.value(f.id.mainBase+2,500,2);f.value(f.id.mainBase+6,500,2);CHECK(nc::startExactScan(f.id,{{f.id.mainBase+1,7,true}},nc::ScanValueType::U16,"500",f.reader(),session,error));CHECK(session.coveredBytes==6&&session.candidates.size()==2);CHECK(session.candidates[0].address==f.id.mainBase+2&&session.candidates[1].address==f.id.mainBase+6);}
    next();{Fixture f;f.value(f.id.mainBase+8,100);f.value(f.id.heapBase+12,100);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"100",f.reader(),session,error));CHECK(session.candidates.size()==2);f.value(f.id.mainBase+8,90);f.value(f.id.heapBase+12,120);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));CHECK(session.rounds==2&&session.candidates.size()==1&&session.candidates[0].valueBits==90);f.value(f.id.mainBase+8,80);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));CHECK(session.rounds==3&&session.candidates[0].valueBits==80);nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"100","Prueba experimental",cheat,error));CHECK(cheat.opcodes==std::vector<uint32_t>({0x04000000,8,100}));CHECK(cheat.selected&&!cheat.master&&cheat.source.find("experimental")!=std::string::npos);CHECK(cheat.group.find("42")!=std::string::npos);}
    next();{Fixture f;f.value(f.id.mainBase+64,100);f.value(f.id.heapBase+68,200);CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error));CHECK(session.baseline&&session.candidates.empty()&&session.rounds==1);nc::ScanSession resumed;CHECK(nc::loadScanSession(f.id,resumed,error)&&resumed.baseline);session=resumed;f.value(f.id.mainBase+64,75);f.value(f.id.heapBase+68,250);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));CHECK(!session.baseline&&session.rounds==2&&session.candidates.size()==1&&session.candidates[0].address==f.id.mainBase+64);CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.candidates.size()==1);f.value(f.id.mainBase+64,60);CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidates[0].valueBits==60);f.value(f.id.mainBase+64,80);CHECK(nc::refineScan(f.id,nc::ScanCompare::Increased,"",f.reader(),session,error)&&session.candidates.size()==1);CHECK(nc::refineScan(f.id,nc::ScanCompare::Exact,"80",f.reader(),session,error)&&session.candidates.size()==1);}
    next();{Fixture f;f.floating(f.id.mainBase,12.5f);f.floating(f.id.heapBase+4,12.5f);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::F32,"12.5",f.reader(),session,error)&&session.candidates.size()==2);CHECK(nc::scanValueText(nc::ScanValueType::F32,session.candidates[0].valueBits)=="12.5");f.floating(f.id.mainBase,11.5f);f.value(f.id.heapBase+4,0x7fc00000);CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidates.size()==1);CHECK(nc::scanValueText(nc::ScanValueType::F32,0x7f800000)=="No finito");const auto previous=session;CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::F32,"NaN",f.reader(),session,error)&&nc::sameSession(previous,session));CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::F32,"1e1000",f.reader(),session,error));CHECK(nc::matches(nc::ScanValueType::F32,nc::ScanCompare::Unchanged,0,0x80000000,0));}
    next();{Fixture f;CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"17",f.reader(),session,error));CHECK(session.candidates.empty()&&session.ready);for(const std::string value:{"-1","4294967296","12x","0x","","+1"})CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,value,f.reader(),session,error));CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"256",f.reader(),session,error));CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::U16,"65536",f.reader(),session,error));f.value(f.id.mainBase+4,8);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"08",f.reader(),session,error)&&session.candidates.size()==1);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"0x8",f.reader(),session,error)&&session.candidates.size()==1);}
    next();{Fixture f;f.value(f.id.heapBase+40,500);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U16,"500",f.reader(),session,error));nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"600","Prueba HEAP",cheat,error));CHECK(cheat.opcodes==std::vector<uint32_t>({0x02100000,40,600}));CHECK(!nc::scanCandidateCheat(session,1,"600","Fuera",cheat,error));CHECK(!nc::scanCandidateCheat(session,0,"600","[Cabecera]",cheat,error));CHECK(!nc::scanCandidateCheat(session,0,"600",std::string(64,'x'),cheat,error));CHECK(!nc::scanCandidateCheat(session,0,"70000","Valor fuera",cheat,error));}
    next();{Fixture f;f.value(f.id.mainBase+4,77);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"77",f.reader(),session,error));for(unsigned mutation=0;mutation<5;++mutation){auto wrong=f.id;if(mutation==0)++wrong.pid;else if(mutation==1)++wrong.title;else if(mutation==2)wrong.fullBuildId[63]='B';else if(mutation==3)++wrong.mainBase;else ++wrong.heapSize;nc::ScanSession out;CHECK(!nc::loadScanSession(wrong,out,error));unsigned before=f.calls;CHECK(!nc::refineScan(wrong,nc::ScanCompare::Changed,"",f.reader(),session,error)&&f.calls==before);}}
    next();{Fixture f;f.main.assign(30000,7);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};f.value(f.id.mainBase+1,99,1);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"99",f.reader(),session,error));CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error));CHECK(session.streamed&&session.baseline&&session.candidateCount==29999&&session.candidates.empty());nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));f.main[25000]=6;CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidates.size()==1&&session.candidates[0].address==f.id.mainBase+25000);}
    next();{Fixture f;f.main.resize(30000,1);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),2);CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.streamed&&session.candidateCount==30000);nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&loaded.baseline&&loaded.streamed);session=loaded;f.main[15000]=3;CHECK(nc::refineScan(f.id,nc::ScanCompare::Exact,"3",f.reader(),session,error)&&session.candidates.size()==1&&session.candidates[0].address==f.id.mainBase+15000);}
    next();{Fixture f;f.value(f.id.mainBase,33);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"33",f.reader(),session,error));auto old=session;f.failAt=int(f.calls)+1;CHECK(!nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&nc::sameSession(old,session));CHECK(!nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error)&&nc::sameSession(old,session));nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(old,loaded));}
    next();{Fixture f;CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error));char slot=nc::activeSlot();patchByte(nc::file(slot,".snapshot"),0);f.value(f.id.mainBase,1);auto old=session;CHECK(!nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error));CHECK(error.find("CRC")!=std::string::npos&&nc::sameSession(old,session));}
    next();{Fixture f;CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"123",f.reader(),session,error));patchByte(nc::file(nc::activeSlot(),".dat"),32);nc::ScanSession loaded;CHECK(!nc::loadScanSession(f.id,loaded,error));}
    next();{Fixture f;f.value(f.id.mainBase+4,99);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"99",f.reader(),session,error));nc::Stored malicious;malicious.slot=nc::activeSlot();malicious.session=session;malicious.session.candidates[0].address=f.id.mainBase+f.id.mainSize+4;auto data=nc::serialize(malicious);CHECK(nc::writeFile(nc::file(malicious.slot,".dat"),data.data(),data.size()));nc::ScanSession loaded;CHECK(!nc::loadScanSession(f.id,loaded,error));}
    next();{Fixture f;auto id=f.id;id.heapSize=4ULL*1024*1024*1024;nc::ScanSession bounded;CHECK(nc::prepare(id,{{id.heapBase,id.heapSize,true}},nc::ScanValueType::U32,bounded,error));CHECK(bounded.partial&&bounded.coveredBytes==nc::ScanMaxBytes&&bounded.totalBytes==id.heapSize&&bounded.regions.size()==1);CHECK(!nc::prepare(id,{{id.mainBase,128,true},{id.mainBase+64,128,true}},nc::ScanValueType::U32,bounded,error));CHECK(!nc::prepare(id,{{id.heapBase+id.heapSize-2,8,true}},nc::ScanValueType::U32,bounded,error));CHECK(!nc::prepare(id,{{UINT64_MAX-3,8,true}},nc::ScanValueType::U32,bounded,error));CHECK(nc::prepare(id,{{0x123,99,false},{id.mainBase,128,true}},nc::ScanValueType::U32,bounded,error)&&bounded.coveredBytes==128);}
    next();{Fixture f;f.value(f.id.mainBase+4,44);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"44",f.reader(),session,error));auto stale=session;CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error));CHECK(!nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),stale,error));nc::Cheat cheat;CHECK(!nc::scanCandidateCheat(stale,0,"44","Anterior",cheat,error));}
    next();{Fixture f;CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"45",f.reader(),session,error));auto old=session;char inactive=nc::activeSlot()=='a'?'b':'a';fs::create_directory(nc::file(inactive,".dat.pending"));CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"46",f.reader(),session,error)&&nc::sameSession(old,session));nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(old,loaded));}
    next();{Fixture f;f.main.resize(nc::Chunk+32);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};f.value(f.id.mainBase+nc::Chunk-4,73);f.value(f.id.mainBase+nc::Chunk,73);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"73",f.reader(),session,error)&&session.candidates.size()==2&&f.calls==2);auto old=session;f.failAt=int(f.calls)+2;CHECK(!nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error)&&nc::sameSession(old,session));nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(old,loaded));CHECK(!fs::exists(nc::file(nc::activeSlot()=='a'?'b':'a',".snapshot.pending")));}
    next();{Fixture f;f.id.heapSize=0;f.id.mainSize=(1ULL<<40)+4096;const uint64_t address=f.id.mainBase+(1ULL<<40);auto sparse=[&](const nc::ScanIdentity &,uint64_t at,void *out,size_t bytes,std::string &){CHECK(at==address&&bytes==4);uint8_t value[4]={77,0,0,0};std::memcpy(out,value,4);return true;};CHECK(nc::startExactScan(f.id,{{address,4,true}},nc::ScanValueType::U32,"77",sparse,session,error));nc::Cheat cheat;CHECK(!nc::scanCandidateCheat(session,0,"77","Fuera de 40 bits",cheat,error)&&cheat.opcodes.empty());}
    next();{Fixture f;f.main.assign(40000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.begin()+30000,9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.streamed&&session.candidateCount==30000);std::fill(f.main.begin(),f.main.begin()+25000,8);std::fill(f.main.begin()+30000,f.main.end(),9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.streamed&&session.candidateCount==25000&&session.rounds==3);nc::ScanSession resumed;CHECK(nc::loadScanSession(f.id,resumed,error)&&nc::sameSession(session,resumed));session=resumed;f.main[123]=7;std::fill(f.main.begin()+30000,f.main.end(),8);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));CHECK(!session.baseline&&!session.streamed&&session.candidateCount==1&&session.candidates.size()==1&&session.candidates[0].address==f.id.mainBase+123&&session.candidates[0].valueBits==7&&session.rounds==4);}
    next();{Fixture f;f.main.assign(40000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));auto old=session;const auto mask=nc::file(nc::activeSlot(),".mask"),original=read(mask),marker=read(current/"active.txt");patchByte(mask,12);f.main[99]=8;CHECK(!nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&error.find("CRC")!=std::string::npos);CHECK(nc::sameSession(old,session)&&read(current/"active.txt")==marker);put(mask,original);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1);}
    next();{Fixture f;f.main.assign(65550,4);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,3,true},{f.id.mainBase+16,65534,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),3);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==65537&&session.streamed);CHECK(fs::file_size(nc::file(nc::activeSlot(),".mask"))==8193);f.main[65549]=2;CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1&&session.candidates[0].address==f.id.mainBase+65549);}
    next();{Fixture f;f.main.resize(120000);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};float ten=10,nine=9;for(size_t at=0;at<f.main.size();at+=4)std::memcpy(f.main.data()+at,&ten,4);CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::F32,f.reader(),session,error));for(size_t at=0;at<f.main.size();at+=4)std::memcpy(f.main.data()+at,&nine,4);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==30000&&session.streamed);f.floating(f.id.mainBase+100,8.5f);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1&&nc::scanValueText(session.type,session.candidates[0].valueBits)=="8.5");}
    next();{Fixture f;f.value(f.id.mainBase+4,50);CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error));nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));auto bytes=legacyMetadata(stored);CHECK(nc::writeFile(nc::file(stored.slot,".dat"),bytes.data(),bytes.size()));nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&loaded.baseline&&!loaded.streamed&&loaded.candidateCount==0);session=loaded;f.value(f.id.mainBase+4,40);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1);CHECK(read(nc::file(nc::activeSlot(),".dat"))[6]=='4');}
    next();{Fixture f;f.value(f.id.mainBase+4,80);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"80",f.reader(),session,error));nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));auto bytes=legacyMetadata(stored);CHECK(nc::writeFile(nc::file(stored.slot,".dat"),bytes.data(),bytes.size()));CHECK(nc::loadScanSession(f.id,session,error)&&session.candidateCount==1);f.value(f.id.mainBase+4,70);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1&&session.candidates[0].valueBits==70);}
    next();{Fixture f;f.main.assign(150000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};f.main[5]=88;CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"88",f.reader(),session,error));const auto old=session;uint64_t seen=0;nc::setScanObserver([&](uint64_t done,uint64_t total){CHECK(total==f.id.mainSize&&done>=seen);seen=done;return done<nc::Chunk;});CHECK(!nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error)&&seen==nc::Chunk&&error.find("cancelada")!=std::string::npos);nc::setScanObserver({});nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(old,loaded)&&nc::sameSession(old,session));CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),9);const auto reference=session;nc::setScanObserver([](uint64_t done,uint64_t){return done==0;});CHECK(!nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&nc::sameSession(reference,session));nc::setScanObserver({});CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.streamed);const auto pooled=session;f.main[100]=8;nc::setScanObserver([](uint64_t done,uint64_t){return done==0;});CHECK(!nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&nc::sameSession(pooled,session));nc::setScanObserver({});CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1);}
    next();{Fixture f;f.main.assign(30000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));const auto old=session;const char slot=nc::activeSlot();const auto marker=read(current/"active.txt"),snapshot=read(nc::file(slot,".snapshot"));std::fill(f.main.begin(),f.main.end(),9);char inactive=slot=='a'?'b':'a';fs::create_directory(nc::file(inactive,".dat.pending"));CHECK(!nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));CHECK(nc::sameSession(old,session)&&read(current/"active.txt")==marker&&read(nc::file(slot,".snapshot"))==snapshot);CHECK(fs::remove(nc::file(inactive,".dat.pending")));CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==30000);CHECK(nc::clearScanSession(error)&&!fs::exists(nc::file('a',".mask"))&&!fs::exists(nc::file('b',".mask")));}
    next();{Fixture f;f.main.assign(30000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));const auto old=session;auto marker=read(current/"active.txt");std::fill(f.main.begin(),f.main.end(),9);unsigned completed=0;nc::setScanObserver([&](uint64_t done,uint64_t total){return done!=total||++completed<5;});CHECK(!nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&completed==5);CHECK(nc::sameSession(old,session)&&read(current/"active.txt")==marker);nc::setScanObserver({});nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(old,loaded));CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==30000);}
    next();{Fixture f;f.main.assign(20001,7);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error)&&session.streamed&&session.candidateCount==20001);f.main[0]=8;CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&!session.streamed&&!session.baseline&&session.candidateCount==20000&&session.candidates.size()==20000);unsigned calls=f.calls;CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&f.calls==calls+1);}
    next();{Fixture f;twoThenZero(f,session);const auto beforeA=read(nc::file('a',".dat")),beforeB=read(nc::file('b',".dat"));const auto calls=f.calls;CHECK(nc::restorePreviousScan(f.id,session,error)&&session.candidateCount==2&&session.rounds==2&&session.candidates.size()==2);CHECK(f.calls==calls&&read(nc::file('a',".dat"))==beforeA&&read(nc::file('b',".dat"))==beforeB);nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));auto restored=session;CHECK(!nc::restorePreviousScan(f.id,session,error)&&nc::sameSession(restored,session)&&f.calls==calls);}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;const auto marker=read(current/"active.txt");const auto previous=nc::activeSlot()=='a'?'b':'a';patchByte(nc::file(previous,".dat"),32);const auto calls=f.calls;CHECK(!nc::restorePreviousScan(f.id,session,error)&&nc::sameSession(zero,session));CHECK(read(current/"active.txt")==marker&&f.calls==calls);}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;const auto marker=read(current/"active.txt");const auto calls=f.calls;for(unsigned mutation=0;mutation<5;++mutation){auto other=f.id;if(mutation==0)++other.pid;else if(mutation==1)++other.title;else if(mutation==2)other.fullBuildId[63]='B';else if(mutation==3)++other.mainBase;else ++other.heapSize;CHECK(!nc::restorePreviousScan(other,session,error)&&nc::sameSession(zero,session)&&read(current/"active.txt")==marker&&f.calls==calls);}}
    next();{Fixture f;twoThenZero(f,session);const auto previous=nc::activeSlot()=='a'?'b':'a';nc::Stored altered;CHECK(nc::loadStoredAt(f.id,previous,altered,error));altered.session.type=nc::ScanValueType::U16;auto bytes=nc::serialize(altered);CHECK(nc::writeFile(nc::file(previous,".dat"),bytes.data(),bytes.size()));const auto zero=session;const auto marker=read(current/"active.txt");CHECK(!nc::restorePreviousScan(f.id,session,error)&&nc::sameSession(zero,session)&&read(current/"active.txt")==marker);}
    next();{Fixture f;f.value(f.id.mainBase+4,50);CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error));f.value(f.id.mainBase+4,40);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error));const auto before=session;const char previous=nc::activeSlot()=='a'?'b':'a';patchByte(nc::file(previous,".snapshot"),0);const auto calls=f.calls;const auto marker=read(current/"active.txt");CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("CRC")!=std::string::npos);CHECK(nc::sameSession(before,session)&&f.calls==calls&&read(current/"active.txt")==marker);}
    next();{Fixture f;f.main.assign(30000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.streamed);const auto pooled=session;patchByte(nc::file(nc::activeSlot(),".mask"),1);const auto calls=f.calls;CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("CRC")!=std::string::npos&&nc::sameSession(pooled,session)&&f.calls==calls);}
    next();{Fixture f;f.main.assign(30000,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.end(),9);CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.streamed);f.main[123]=8;CHECK(nc::refineScan(f.id,nc::ScanCompare::Decreased,"",f.reader(),session,error)&&session.candidateCount==1);const char previous=nc::activeSlot()=='a'?'b':'a';const auto mask=nc::file(previous,".mask"),original=read(mask);patchByte(mask,1);const auto before=session;CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("CRC")!=std::string::npos&&nc::sameSession(before,session));put(mask,original);const auto calls=f.calls;CHECK(nc::restorePreviousScan(f.id,session,error)&&session.streamed&&session.candidateCount==30000&&session.rounds==2&&f.calls==calls);}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;const auto marker=read(current/"active.txt");unsigned completed=0;nc::setScanObserver([&](uint64_t done,uint64_t total){return done!=total||++completed<2;});CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("cancelada")!=std::string::npos&&completed==2);CHECK(nc::sameSession(zero,session)&&read(current/"active.txt")==marker);nc::setScanObserver({});CHECK(nc::restorePreviousScan(f.id,session,error)&&session.candidateCount==2);}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;const auto marker=read(current/"active.txt");bool once=true;nc::markerFailure=[&](const std::string &from,const std::string &to){if(once&&from==nc::scanRoot()+"/active.pending"&&to==nc::scanRoot()+"/active.txt"){once=false;return true;}return false;};CHECK(!nc::restorePreviousScan(f.id,session,error)&&!once&&nc::sameSession(zero,session));CHECK(read(current/"active.txt")==marker);nc::markerFailure={};nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(zero,loaded));CHECK(nc::restorePreviousScan(f.id,session,error)&&session.candidateCount==2);}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;const auto marker=read(current/"active.txt"),priorA=read(nc::file('a',".dat")),priorB=read(nc::file('b',".dat"));const auto calls=f.calls;CHECK(!nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&error.find("anterior")!=std::string::npos&&error.find("CRC")==std::string::npos);CHECK(nc::sameSession(zero,session)&&read(current/"active.txt")==marker&&read(nc::file('a',".dat"))==priorA&&read(nc::file('b',".dat"))==priorB&&f.calls==calls);nc::Cheat cheat;CHECK(!nc::scanCandidateCheat(session,0,"10","No probar cero",cheat,error)&&cheat.opcodes.empty());CHECK(nc::restorePreviousScan(f.id,session,error)&&session.candidateCount==2);CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error)&&session.rounds==1);}
    next();{Fixture f;CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U32,f.reader(),session,error));put(current/"unrelated.txt","keep me");CHECK(nc::clearScanSession(error));CHECK(!fs::exists(nc::file('a',".snapshot"))&&!fs::exists(nc::file('b',".snapshot"))&&read(current/"unrelated.txt")=="keep me");nc::ScanSession loaded;CHECK(!nc::loadScanSession(f.id,loaded,error));CHECK(nc::clearScanSession(error));}
    next();{Fixture f;twoThenZero(f,session);const auto zero=session;nc::Stored previous;const char slot=nc::activeSlot()=='a'?'b':'a';CHECK(nc::loadStoredAt(f.id,slot,previous,error));previous.session.candidates.clear();previous.session.candidateCount=0;const auto bytes=nc::serialize(previous);CHECK(nc::writeFile(nc::file(slot,".dat"),bytes.data(),bytes.size()));const auto marker=read(current/"active.txt");const auto calls=f.calls;CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("también tiene cero")!=std::string::npos);CHECK(nc::sameSession(zero,session)&&read(current/"active.txt")==marker&&f.calls==calls);}
    // Alias-backed Heap pages are read through the same bounded stream. Values
    // eliminated before an unchanged comparison must never reappear.
    next();{
        Fixture f;f.id.aliasBase=0x1000000000ULL;f.id.aliasSize=64ULL*1024*1024*1024;
        f.alias.assign(40000,10);f.regions.push_back({f.id.aliasBase,f.alias.size(),true});
        CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));
        CHECK(read(nc::file(nc::activeSlot(),".dat"))[6]=='4');
        std::fill(f.alias.begin(),f.alias.begin()+30000,9);
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.streamed&&session.candidateCount==30000);
        nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));session=loaded;
        std::fill(f.alias.begin(),f.alias.begin()+29999,8);f.alias[35000]=9;
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.candidateCount==1&&!session.baseline);
        CHECK(session.candidates.front().address==f.id.aliasBase+29999&&session.candidates.front().valueBits==9);
        f.alias[29999]=7;CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==1&&session.rounds==4);
        nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"9","Prueba alias",cheat,error));
        CHECK(cheat.opcodes==std::vector<uint32_t>({0x01200000,29999,9}));
        CHECK(nc::loadScanSession(f.id,loaded,error)&&loaded.identity.aliasBase==f.id.aliasBase&&loaded.identity.aliasSize==f.id.aliasSize);
    }
    next();{
        Fixture f;f.id.aliasBase=0x1000000000ULL;f.id.aliasSize=64ULL*1024*1024*1024;
        const uint64_t address=f.id.aliasBase+0x100000008ULL;
        auto reader=[&](const nc::ScanIdentity&id,uint64_t at,void*out,size_t size,std::string&){CHECK(nc::sameIdentity(id,f.id)&&at==address&&size==4);const uint8_t bytes[]={77,0,0,0};std::memcpy(out,bytes,4);return true;};
        CHECK(nc::startExactScan(f.id,{{address,4,true}},nc::ScanValueType::U32,"77",reader,session,error));
        nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"88","Alias alto",cheat,error));
        CHECK(cheat.opcodes==std::vector<uint32_t>({0x04200001,8,88}));
    }
    next();{
        Fixture f;f.id.aliasBase=0x1000000000ULL;f.id.aliasSize=64ULL*1024*1024*1024;f.alias.resize(16);f.floating(f.id.aliasBase+4,12.5f);
        CHECK(nc::startExactScan(f.id,{{f.id.aliasBase,16,true}},nc::ScanValueType::F32,"12.5",f.reader(),session,error));
        nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"12.5","Alias decimal",cheat,error));
        CHECK(cheat.opcodes==std::vector<uint32_t>({0x04200000,4,0x41480000}));
    }
    next();{
        Fixture f;f.id.aliasBase=0x1000000000ULL;f.id.aliasSize=64ULL*1024*1024*1024;f.alias.assign(32,5);
        CHECK(nc::startExactScan(f.id,{{f.id.aliasBase,32,true}},nc::ScanValueType::U8,"5",f.reader(),session,error));
        const auto before=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(nc::activeSlot(),".dat"));const auto calls=f.calls;
        auto changed=f.id;++changed.aliasBase;
        CHECK(!nc::refineScan(changed,nc::ScanCompare::Changed,"",f.reader(),session,error)&&error.find("ALIAS")!=std::string::npos);
        CHECK(f.calls==calls&&nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata);
        f.failAt=int(f.calls)+1;CHECK(!nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error));
        CHECK(nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata);
    }
    next();{
        Fixture f;nc::ScanSession prepared;auto id=f.id;id.aliasBase=0x1000000000ULL;
        CHECK(!nc::prepare(id,f.regions,nc::ScanValueType::U8,prepared,error));
        id=f.id;id.aliasSize=0x1000;CHECK(!nc::prepare(id,f.regions,nc::ScanValueType::U8,prepared,error));
        id=f.id;id.aliasBase=UINT64_MAX-7;id.aliasSize=16;CHECK(!nc::prepare(id,f.regions,nc::ScanValueType::U8,prepared,error));
        id=f.id;id.aliasBase=id.mainBase;id.aliasSize=16;CHECK(!nc::prepare(id,f.regions,nc::ScanValueType::U8,prepared,error));
        id=f.id;id.aliasBase=id.heapBase;id.aliasSize=16;CHECK(!nc::prepare(id,f.regions,nc::ScanValueType::U8,prepared,error));
        id=f.id;id.aliasBase=0x1000000000ULL;id.aliasSize=0x10000;
        CHECK(!nc::prepare(id,{{id.aliasBase+id.aliasSize-1,2,true}},nc::ScanValueType::U8,prepared,error));
        CHECK(!nc::prepare(id,{{id.aliasBase-1,2,true}},nc::ScanValueType::U8,prepared,error));
    }
    for(unsigned version:{1u,2u}){next();
        Fixture f;f.value(f.id.mainBase+4,44);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"44",f.reader(),session,error));
        nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));auto bytes=legacyMetadata(stored,version);
        CHECK(nc::writeFile(nc::file(stored.slot,".dat"),bytes.data(),bytes.size()));
        nc::ScanSession legacy;CHECK(nc::loadScanSession(f.id,legacy,error)&&!legacy.identity.aliasBase&&!legacy.identity.aliasSize);
        const auto metadata=read(nc::file(stored.slot,".dat")),marker=read(current/"active.txt");auto expanded=f.id;expanded.aliasBase=0x1000000000ULL;expanded.aliasSize=64ULL*1024*1024*1024;
        nc::ScanSession rejected;CHECK(!nc::loadScanSession(expanded,rejected,error)&&error.find("ALIAS")!=std::string::npos);
        CHECK(!nc::refineScan(expanded,nc::ScanCompare::Changed,"",f.reader(),legacy,error));
        CHECK(read(nc::file(stored.slot,".dat"))==metadata&&read(current/"active.txt")==marker&&legacy.candidateCount==1);
    }
    next();{
        Fixture f;f.value(f.id.mainBase+4,77);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"77",f.reader(),session,error));
        const auto previous=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(nc::activeSlot(),".dat"));
        // Reproduce the measured size/extent shape with sanitized addresses:
        // 5,799,936 MAIN bytes plus 1,737,072,640 Alias Heap bytes, no HEAP
        // pages. A short cancelled stream proves bounded IO without making a
        // 1.6 GiB fixture or claiming a full real-device scan was exercised.
        auto id=f.id;id.mainSize=0x30A6000;id.heapBase=0x100000000ULL;id.heapSize=8ULL*1024*1024*1024;id.aliasBase=0x1000000000ULL;id.aliasSize=64ULL*1024*1024*1024;
        const uint64_t mapped=1737072640;
        const std::vector<nc::ScanRegion> regions={{id.mainBase,2ULL*1024*1024,true},{id.mainBase+4ULL*1024*1024,904ULL*4096,true},{id.aliasBase+0x10000,mapped,true}};
        nc::ScanSession scope;CHECK(nc::prepare(id,regions,nc::ScanValueType::U8,scope,error));
        CHECK(!scope.partial&&scope.coveredBytes==1742872576&&scope.coveredBytes>512ULL*1024*1024&&scope.coveredBytes<nc::ScanMaxBytes);
        CHECK(nc::maskBytes(scope)==scope.coveredBytes/8);
        unsigned reads=0;uint64_t seenTotal=0;
        auto reader=[&](const nc::ScanIdentity&actual,uint64_t address,void*out,size_t bytes,std::string&){++reads;CHECK(nc::sameIdentity(actual,id)&&bytes<=nc::Chunk&&nc::belongs(id,address,bytes));std::memset(out,0,bytes);return true;};
        nc::setScanObserver([&](uint64_t done,uint64_t total){seenTotal=total;return done<2*nc::Chunk;});
        CHECK(!nc::startUnknownScan(id,regions,nc::ScanValueType::U8,reader,session,error)&&error.find("cancelada")!=std::string::npos);
        nc::setScanObserver({});CHECK(reads==2&&seenTotal==scope.coveredBytes&&nc::sameSession(previous,session));
        CHECK(read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata);
        CHECK(!fs::exists(nc::file(nc::activeSlot()=='a'?'b':'a',".snapshot.pending")));
    }
    next();{
        Fixture f;auto id=f.id;id.aliasBase=0x1000000000ULL;id.aliasSize=64ULL*1024*1024*1024;
        nc::Stored stored;CHECK(nc::prepare(id,{{id.aliasBase,4ULL*1024*1024*1024,true}},nc::ScanValueType::U8,stored.session,error));
        CHECK(stored.session.partial&&stored.session.coveredBytes==4ULL*1024*1024*1024-nc::Chunk);
        CHECK(stored.session.coveredBytes%nc::Chunk==0&&stored.session.coveredBytes<UINT32_MAX);
        CHECK(nc::maskBytes(stored.session)==512ULL*1024*1024-nc::Chunk/8&&nc::maskBytes(stored.session)<512ULL*1024*1024);
        stored.session.baseline=stored.session.streamed=stored.session.ready=true;stored.session.storage=nc::ScanStorage::DenseSnapshot;stored.session.rounds=2;stored.session.candidateCount=stored.session.coveredBytes;
        nc::Stored decoded;CHECK(nc::deserialize(nc::serialize(stored),decoded)&&decoded.session.candidateCount==stored.session.candidateCount&&decoded.session.identity.aliasSize==id.aliasSize);
        ++stored.session.candidateCount;CHECK(!nc::deserialize(nc::serialize(stored),decoded));
    }
    next();{
        Fixture f;f.value(f.id.mainBase+4,77);CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U32,"77",f.reader(),session,error));
        const auto previous=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(nc::activeSlot(),".dat"));
        auto id=f.id;id.aliasBase=0x1000000000ULL;id.aliasSize=64ULL*1024*1024*1024;
        const uint64_t mapped=3ULL*1024*1024*1024;const std::vector<nc::ScanRegion> regions={{id.aliasBase,mapped,true}};
        nc::ScanSession scope;CHECK(nc::prepare(id,regions,nc::ScanValueType::U8,scope,error));
        CHECK(!scope.partial&&scope.coveredBytes==mapped&&scope.totalBytes==mapped&&nc::maskBytes(scope)==384ULL*1024*1024);
        unsigned reads=0;uint64_t seenTotal=0;
        auto reader=[&](const nc::ScanIdentity&actual,uint64_t address,void*out,size_t bytes,std::string&){++reads;CHECK(nc::sameIdentity(actual,id)&&bytes==nc::Chunk&&address==id.aliasBase+uint64_t(reads-1)*nc::Chunk);std::memset(out,7,bytes);return true;};
        nc::setScanObserver([&](uint64_t done,uint64_t total){seenTotal=total;return done<2*nc::Chunk;});
        CHECK(!nc::startUnknownScan(id,regions,nc::ScanValueType::U8,reader,session,error)&&error.find("cancelada")!=std::string::npos);
        nc::setScanObserver({});CHECK(reads==2&&seenTotal==mapped&&nc::sameSession(previous,session));
        CHECK(read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata);
        CHECK(!fs::exists(nc::file(nc::activeSlot()=='a'?'b':'a',".snapshot.pending")));
    }
    next();{
        Fixture f;f.id.aliasBase=0x1000000000ULL;f.id.aliasSize=64ULL*1024*1024*1024;f.alias.assign(16,0);f.alias[3]=7;
        CHECK(nc::startExactScan(f.id,{{f.id.aliasBase,16,true}},nc::ScanValueType::U8,"7",f.reader(),session,error));
        const auto path=nc::file(nc::activeSlot(),".dat"),original=read(path),marker=read(current/"active.txt");
        patchByte(path,136);const auto corrupted=read(path);nc::ScanSession loaded;
        CHECK(!nc::loadScanSession(f.id,loaded,error)&&read(path)==corrupted&&read(current/"active.txt")==marker);
        put(path,original);CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));
        nc::Stored altered;CHECK(nc::loadStored(f.id,altered,error));altered.session.candidates.front().address=f.id.aliasBase+f.id.aliasSize;
        const auto bytes=nc::serialize(altered);CHECK(nc::writeFile(path,bytes.data(),bytes.size()));
        CHECK(!nc::loadScanSession(f.id,loaded,error)&&read(current/"active.txt")==marker);
    }
    next();{
        Fixture f;const size_t bytes=4*1024*1024;f.main.assign(bytes,127);f.id.mainSize=bytes;f.regions={{f.id.mainBase,bytes,true}};std::fill(f.main.begin(),f.main.begin()+30000,7);
        CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error));
        CHECK(session.storage==nc::ScanStorage::UniformMask&&session.candidateCount==30000&&session.uniformBits==7);
        CHECK(f.bytesRead==bytes&&f.calls==64&&nc::ioStats.snapshotRead==0&&nc::ioStats.snapshotWrite==0&&nc::ioStats.recordsWrite==0);
        CHECK(nc::ioStats.maskWrite==bytes/8&&fs::file_size(nc::file(nc::activeSlot(),".mask"))==bytes/8&&!fs::exists(nc::file(nc::activeSlot(),".snapshot")));
        std::cout<<"metrics exact_int: scope="<<bytes<<" memory_read="<<f.bytesRead<<" calls="<<f.calls<<" snapshot_write="<<nc::ioStats.snapshotWrite<<" mask_write="<<nc::ioStats.maskWrite<<'\n';
        nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));session=loaded;
        f.main[42]=6;f.bytesRead=0;f.calls=0;nc::ioStats={};bool consistentProgress=true;uint64_t lastProgress=0;
        nc::setScanObserver([&](uint64_t done,uint64_t total){if(total!=30000||done<lastProgress||done>total)consistentProgress=false;lastProgress=done;return true;});
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::UniformMask&&session.candidateCount==29999);
        nc::setScanObserver({});CHECK(consistentProgress&&lastProgress==30000);
        CHECK(f.bytesRead<=30000&&f.calls==8&&nc::ioStats.snapshotRead==0&&nc::ioStats.snapshotWrite==0&&nc::ioStats.maskRead==bytes/8&&nc::ioStats.maskWrite==bytes/8);
        f.main[123]=9;CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::Memory&&session.candidateCount==1&&session.candidates.front().valueBits==9);
        nc::ioStats={};CHECK(nc::restorePreviousScan(f.id,session,error)&&session.storage==nc::ScanStorage::UniformMask&&session.candidateCount==29999&&nc::ioStats.snapshotRead==0);
    }
    next();{
        Fixture f;f.main.assign(1024*1024,127);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};f.main[123]=7;
        CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error)&&session.storage==nc::ScanStorage::Memory&&session.candidateCount==1);
        CHECK(nc::ioStats.snapshotWrite==0&&nc::ioStats.maskWrite==0&&nc::ioStats.recordsWrite==0);
        CHECK(!fs::exists(nc::file(nc::activeSlot(),".snapshot"))&&!fs::exists(nc::file(nc::activeSlot(),".mask"))&&!fs::exists(nc::file(nc::activeSlot(),".records")));
    }
    next();{
        Fixture f;f.main.assign(1024*1024,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};
        CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));const char oldSlot=stored.slot;
        const auto legacy=legacyMetadata(stored,3);CHECK(nc::writeFile(nc::file(oldSlot,".dat"),legacy.data(),legacy.size()));CHECK(nc::loadScanSession(f.id,session,error));
        // Exact does not depend on old values, so even an irrelevant damaged
        // old snapshot must not be read/replaced by this successful filter.
        patchByte(nc::file(oldSlot,".snapshot"),0);const auto oldData=read(nc::file(oldSlot,".dat")),oldSnapshot=read(nc::file(oldSlot,".snapshot"));
        std::fill(f.main.begin(),f.main.begin()+30000,9);nc::ioStats={};f.bytesRead=0;f.calls=0;
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Exact,"9",f.reader(),session,error)&&session.storage==nc::ScanStorage::UniformMask&&session.candidateCount==30000);
        CHECK(nc::ioStats.snapshotRead==0&&nc::ioStats.snapshotWrite==0&&nc::ioStats.maskWrite==f.main.size()/8);
        CHECK(read(nc::file(oldSlot,".dat"))==oldData&&read(nc::file(oldSlot,".snapshot"))==oldSnapshot);
        const auto before=session;const auto marker=read(current/"active.txt");CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("CRC")!=std::string::npos&&nc::sameSession(before,session)&&read(current/"active.txt")==marker);
    }
    next();{
        Fixture f;sparsePool(f,session,16*1024*1024,30000,true);
        CHECK(fs::file_size(nc::file(nc::activeSlot(),".records"))==360000&&!fs::exists(nc::file(nc::activeSlot(),".snapshot")));
        nc::ScanSession loaded;CHECK(nc::loadScanSession(f.id,loaded,error)&&nc::sameSession(session,loaded));session=loaded;
        f.bytesRead=0;f.calls=0;nc::ioStats={};
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::SparseDisk&&session.candidateCount==30000);
        CHECK(f.bytesRead==30000&&f.calls==8&&f.maxRead<=nc::Chunk);
        CHECK(nc::ioStats.recordsRead==360000&&nc::ioStats.recordsWrite==360000&&nc::ioStats.snapshotRead==0&&nc::ioStats.snapshotWrite==0&&nc::ioStats.maskRead==0&&nc::ioStats.maskWrite==0);
        std::cout<<"metrics sparse: scope="<<session.coveredBytes<<" memory_read="<<f.bytesRead<<" calls="<<f.calls<<" records_read="<<nc::ioStats.recordsRead<<" records_write="<<nc::ioStats.recordsWrite<<'\n';
        f.main[123]=8;CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==1&&session.storage==nc::ScanStorage::Memory);
        nc::ioStats={};CHECK(nc::restorePreviousScan(f.id,session,error)&&session.storage==nc::ScanStorage::SparseDisk&&session.candidateCount==30000&&nc::ioStats.recordsRead==360000&&nc::ioStats.snapshotRead==0);
        f.main[40000]=9;CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==1&&session.candidates.front().address==f.id.mainBase+123);
    }
    next();{
        Fixture f;f.main.resize(1024*1024);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};
        const uint32_t one=0x3f800000;for(size_t at=0;at<f.main.size();at+=4)std::memcpy(f.main.data()+at,&one,4);
        for(size_t i=0;i<30000;++i){const uint32_t zero=i%2?0x80000000u:0;std::memcpy(f.main.data()+i*4,&zero,4);}
        CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::F32,"0",f.reader(),session,error)&&session.storage==nc::ScanStorage::SparseDisk&&session.candidateCount==30000);
        nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));nc::RecordReader input(stored.session);CHECK(input.open(nc::file(stored.slot,".records")));nc::ScanCandidate candidate;uint64_t index=0;
        CHECK(input.next(candidate,index,error)&&candidate.valueBits==0);CHECK(input.next(candidate,index,error)&&candidate.valueBits==0x80000000u);
        f.value(f.id.mainBase+4,0);CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.candidateCount==30000&&session.storage!=nc::ScanStorage::UniformMask);
        for(size_t at=0;at<f.main.size();at+=4)std::memcpy(f.main.data()+at,&one,4);
        f.value(f.id.mainBase+12,0x80000000u);
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Exact,"0",f.reader(),session,error)&&session.candidateCount==1&&session.candidates.front().valueBits==0x80000000u);
        nc::Cheat cheat;CHECK(nc::scanCandidateCheat(session,0,"-0","Cero observado",cheat,error)&&cheat.opcodes.back()==0x80000000u);
    }
    for(unsigned corruption=0;corruption<6;++corruption){next();
        Fixture f;sparsePool(f,session);nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));const auto path=nc::file(stored.slot,".records");auto records=read(path);
        if(corruption==0)records[8]^=1; // Valid U8 data but wrong whole-file CRC.
        else if(corruption==1)records.replace(12,8,records.substr(0,8)); // Duplicate address with recomputed CRC.
        else if(corruption==2){const uint64_t outside=f.id.mainBase+f.id.mainSize;for(unsigned i=0;i<8;++i)records[i]=char(outside>>(8*i));}
        else if(corruption==3)records[9]=1; // Out-of-width raw bits.
        else if(corruption==4)records.resize(records.size()-1);
        else{stored.session.type=nc::ScanValueType::U16;session=stored.session;} // Odd address under a different typed metadata row.
        put(path,records);
        if(corruption!=0&&corruption!=4){stored.recordsCrc=uint32_t(crc32(0,reinterpret_cast<const uint8_t*>(records.data()),uInt(records.size())));const auto bytes=nc::serialize(stored);CHECK(nc::writeFile(nc::file(stored.slot,".dat"),bytes.data(),bytes.size()));}
        const auto before=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(stored.slot,".dat")),badRecords=read(path);
        CHECK(!nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error));
        CHECK(nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(stored.slot,".dat"))==metadata&&read(path)==badRecords);
        CHECK(!fs::exists(nc::file(stored.slot=='a'?'b':'a',".records.pending")));
    }
    next();{
        Fixture f;sparsePool(f,session);const auto before=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(nc::activeSlot(),".dat")),records=read(nc::file(nc::activeSlot(),".records"));
        nc::setScanObserver([](uint64_t done,uint64_t){return done<4096;});
        CHECK(!nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&error.find("cancelada")!=std::string::npos);nc::setScanObserver({});
        CHECK(nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata&&read(nc::file(nc::activeSlot(),".records"))==records);
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Unchanged,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::SparseDisk);
    }
    next();{
        Fixture f;sparsePool(f,session);f.main[123]=8;CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==1);
        const auto before=session;const auto marker=read(current/"active.txt");patchByte(nc::file(nc::activeSlot()=='a'?'b':'a',".records"),8);const auto calls=f.calls;
        CHECK(!nc::restorePreviousScan(f.id,session,error)&&error.find("CRC")!=std::string::npos&&nc::sameSession(before,session)&&read(current/"active.txt")==marker&&f.calls==calls);
    }
    next();{
        Fixture f;f.main.assign(2*1024*1024,10);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};std::fill(f.main.begin(),f.main.begin()+100000,7);
        CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error)&&session.storage==nc::ScanStorage::UniformMask);
        std::fill(f.main.begin(),f.main.begin()+95000,8);
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::DenseSnapshot&&session.candidateCount==95000);
        CHECK(fs::file_size(nc::file(nc::activeSlot(),".snapshot"))==f.main.size());
        f.main[123]=9;f.main[100001]=8;
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==1&&session.candidates.front().address==f.id.mainBase+123);
    }
    for(unsigned extra:{0u,1u}){next();
        Fixture f;sparsePool(f,session,480024,20001);CHECK(session.storage==nc::ScanStorage::SparseDisk);
        CHECK(session.candidateCount*12==session.coveredBytes/2);
        if(extra){CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.begin()+20002,8);CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.candidateCount==20002&&session.storage==nc::ScanStorage::DenseSnapshot);}
    }
    next();{
        Fixture f;f.main.assign(2*1024*1024,127);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};f.main[0]=77;
        CHECK(nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"77",f.reader(),session,error));const auto before=session;
        const auto marker=read(current/"active.txt"),metadata=read(nc::file(nc::activeSlot(),".dat"));std::fill(f.main.begin(),f.main.begin()+30000,7);nc::ioStats={};
        nc::setScanObserver([](uint64_t done,uint64_t total){return done!=total||nc::ioStats.maskWrite<nc::Chunk;});
        CHECK(!nc::startExactScan(f.id,f.regions,nc::ScanValueType::U8,"7",f.reader(),session,error)&&error.find("cancelada")!=std::string::npos);nc::setScanObserver({});
        CHECK(nc::ioStats.maskWrite>=nc::Chunk&&nc::ioStats.maskWrite<2*nc::Chunk);
        CHECK(nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(nc::activeSlot(),".dat"))==metadata);
        CHECK(!fs::exists(nc::file(nc::activeSlot()=='a'?'b':'a',".mask.pending")));
    }
    for(bool corruptMask:{false,true}){next();
        Fixture f;f.main.assign(1024*1024,0);f.id.mainSize=f.main.size();f.regions={{f.id.mainBase,f.id.mainSize,true}};
        CHECK(nc::startUnknownScan(f.id,f.regions,nc::ScanValueType::U8,f.reader(),session,error));std::fill(f.main.begin(),f.main.begin()+50000,1);
        CHECK(nc::refineScan(f.id,nc::ScanCompare::Changed,"",f.reader(),session,error)&&session.storage==nc::ScanStorage::DenseSnapshot&&session.streamed&&session.candidateCount==50000);
        nc::Stored stored;CHECK(nc::loadStored(f.id,stored,error));const auto legacy=legacyMetadata(stored,3);CHECK(nc::writeFile(nc::file(stored.slot,".dat"),legacy.data(),legacy.size()));CHECK(nc::loadScanSession(f.id,session,error));
        std::fill(f.main.begin(),f.main.begin()+30000,7);f.main[70000]=7;
        // Swap one live/dead bit so the popcount remains valid. Only the
        // persisted mask CRC can reject the revived address in this case.
        if(corruptMask){patchByte(nc::file(stored.slot,".mask"),0);patchByte(nc::file(stored.slot,".mask"),70000/8);}
        const auto before=session;const auto marker=read(current/"active.txt"),metadata=read(nc::file(stored.slot,".dat")),mask=read(nc::file(stored.slot,".mask"));nc::ioStats={};
        const bool ok=nc::refineScan(f.id,nc::ScanCompare::Exact,"7",f.reader(),session,error);
        CHECK(nc::ioStats.snapshotRead==0&&nc::ioStats.snapshotWrite==0&&nc::ioStats.maskRead==f.main.size()/8);
        if(corruptMask){CHECK(!ok&&error.find("CRC")!=std::string::npos&&nc::sameSession(before,session)&&read(current/"active.txt")==marker&&read(nc::file(stored.slot,".dat"))==metadata&&read(nc::file(stored.slot,".mask"))==mask);}
        else{CHECK(ok&&session.storage==nc::ScanStorage::UniformMask&&session.candidateCount==30000);CHECK(read(nc::file(stored.slot,".dat"))==metadata&&read(nc::file(stored.slot,".mask"))==mask);}
    }
    cleanup();std::cout<<"scanner: "<<scenarios<<" guided memory, persistence and bounds scenarios passed ("<<checks<<" checks)\n";return 0;
}catch(const std::exception &ex){std::cerr<<"FAILED: "<<ex.what()<<"\nFixtures retained: "<<sandbox<<'\n';return 1;}}

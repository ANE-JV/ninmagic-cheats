// Compile this translation unit alone: including the production source gives
// direct coverage of its private ZIP/path validation without test hooks in NRO.
#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>

namespace nc {
bool validBuild(const std::string &s) {return hex16(s)&&upper(s)!="0000000000000000";}
bool parseCheats(const std::string &s,const std::string &source,std::vector<Cheat> &out,std::string &error) {
    if(s.find("[Good]")==std::string::npos){error="fixture parse failure";return false;}
    Cheat c;c.name="Good";c.source=source;c.opcodes={0x04000000,0,0xD503201F};out.push_back(c);return true;
}
}
namespace {
unsigned checks=0;
void require(bool ok,const char *message) {++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
}
int main(int argc,char **argv) {
    require(argc==2,"fixture directory argument");
    std::filesystem::path base=std::filesystem::absolute(argv[1]);
    std::string dir=(base/"cache").generic_string();setenv("NC_CATALOG_ROOT",dir.c_str(),1);
    uint64_t title=0;std::string build;
    require(nc::memberIdentity("contents/01007300020FA000/cheats/4B159F0F7A360669.txt",title,build)&&title==0x01007300020FA000ULL,"release ZIP path");
    require(nc::memberIdentity("repo-main/titles/01007300020fa000/cheats/4b159f0f7a360669.TXT",title,build)&&build=="4B159F0F7A360669","source ZIP case canonicalization");
    for(const std::string path:{"/contents/01007300020FA000/cheats/4B159F0F7A360669.txt","../titles/01007300020FA000/cheats/4B159F0F7A360669.txt","contents/01007300020FA000/../4B159F0F7A360669.txt","C:/contents/01007300020FA000/cheats/4B159F0F7A360669.txt","titles\\01007300020FA000\\cheats\\4B159F0F7A360669.txt","titles/0100000000000001/cheats/4B159F0F7A360669.txt","titles/01007300020FA000/cheats/0000000000000000.txt","titles/01007300020FA000/cheats/4B159F0F7A36066Z.txt","titles/01007300020FA000/cheats/4B159F0F7A360669.bin","titles/01007300020FA000/cheats/4B159F0F7A360669.txt/evil"})require(!nc::memberIdentity(path,title,build),"reject unsafe or unrelated ZIP member");
    require(nc::safeUrl("https://example.com/cheats.zip?key=value"),"valid HTTPS mirror");
    for(const std::string url:{"http://example.com/a.zip","file:///tmp/a.zip","https://u:p@example.com/a.zip","https://example.com/a.zip\n","https://example.com\\a.zip","https:///a.zip"})require(!nc::safeUrl(url),"reject invalid URL");
    nc::Catalog catalog;std::string error;
    if(!nc::loadSlot('a',catalog,error))std::cerr<<"Slot error: "<<error<<"\n";
    bool loaded=nc::loadCatalog(catalog,error);
    if(!loaded)std::cerr<<"Cache error: "<<error<<" Root: "<<dir<<"\n";
    require(loaded&&catalog.entries.size()==2,"load both original cheat databases offline");
    require(catalog.generalReady&&catalog.graphicsReady&&catalog.stamp=="2026-10-26 00:00 UTC","both cheat sources and timestamp");
    nc::Game game;game.id=0x01007300020FA000ULL;game.buildId="4B159F0F7A360669";game.buildVerified=true;
    auto pack=nc::findCheats(game,catalog);
    require(pack.compatible&&pack.cheats.size()==2,"exact BID from both cheat sources");
    require(pack.cheats[0].group!=pack.cheats[1].group,"source master groups remain separated");
    game.buildVerified=false;pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.cheats.empty()&&pack.availableBuilds.size()==1,"unverified BID cannot apply");
    game.buildVerified=true;game.buildId="4B159F0F7A360660";pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.cheats.empty()&&pack.availableBuilds.size()==1,"other game version not substituted");
    game.id=0x01007300020FA001ULL;pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.availableBuilds.empty(),"other Title ID not substituted");
    std::vector<nc::CatalogEntry> entries;
    require(!nc::indexArchive((base/"duplicate.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"duplicate identity rejected");
    error.clear();require(!nc::indexArchive((base/"crc.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"CRC error rejected before cache commit");
    error.clear();require(!nc::indexArchive((base/"empty.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"empty catalog rejected");
    error.clear();require(!nc::indexArchive((base/"traversal.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"traversal-only ZIP rejected");
    // Invalid active slot must fall back to the untouched complete slot.
    std::filesystem::create_directories(base/"cache"/"catalog-b");
    std::filesystem::copy_file(base/"cache"/"catalog-a"/"general.zip",base/"cache"/"catalog-b"/"general.zip",std::filesystem::copy_options::overwrite_existing);
    std::filesystem::copy_file(base/"cache"/"catalog-a"/"complete.txt",base/"cache"/"catalog-b"/"complete.txt",std::filesystem::copy_options::overwrite_existing);
    std::ofstream(base/"cache"/"active.txt")<<"b\n";
    error.clear();require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==2&&error.empty(),"half-downloaded update never replaces previous two-source cache");
    std::ofstream(base/"cache"/"sources.ini")<<"general_url=http://bad.example/x.zip\n";
    std::string general,graphics;
    require(!nc::sourceUrls(general,graphics,error),"HTTP config rejected");
    std::ofstream(base/"cache"/"sources.ini")<<"general_url=https://mirror.example/general.zip\ngraphics_url=https://mirror.example/graphics.zip\n";
    error.clear();require(nc::sourceUrls(general,graphics,error)&&general=="https://mirror.example/general.zip"&&graphics=="https://mirror.example/graphics.zip","custom HTTPS mirrors for both cheat databases");
    // Simulate HTTPS without a network, exercising the real merge and cache
    // commit code. A failed second source must not acknowledge new releases.
    std::filesystem::remove(base/"cache"/"sources.ini");
    std::ofstream(base/"cache"/"active.txt")<<"a\n";
    nc::CheatRelease oldRelease;oldRelease.id=1;oldRelease.tag="old";oldRelease.published="2026-01-01T00:00:00Z";
    nc::ReleaseAsset asset;asset.id=10;asset.size=std::filesystem::file_size(base/"new.zip");asset.name="contents_complete.zip";asset.updated="2026-10-26T00:00:00Z";asset.url="https://github.com/HamletDuFromage/switch-cheats-db/releases/download/new/contents_complete.zip";
    nc::CheatRelease newRelease;newRelease.id=2;newRelease.tag="new";newRelease.published="2026-10-26T00:00:00Z";newRelease.assets={asset};
    const auto jsonRelease=[](const nc::CheatRelease &r){std::string s="{\"id\":"+std::to_string(r.id)+",\"tag_name\":\""+r.tag+"\",\"published_at\":\""+r.published+"\",\"draft\":false,\"assets\":[";for(size_t i=0;i<r.assets.size();++i){if(i)s+=",";const auto &a=r.assets[i];s+="{\"id\":"+std::to_string(a.id)+",\"size\":"+std::to_string(a.size)+",\"name\":\""+a.name+"\",\"browser_download_url\":\""+a.url+"\",\"updated_at\":\""+a.updated+"\",\"digest\":null}";}return s+"]}";};
    nc::SeenMap manifest;manifest[oldRelease.id]={oldRelease.published,nc::cheatReleaseSignature(oldRelease)};
    require(nc::writeSmall(dir+"/catalog-a/releases-seen.txt",nc::seenText(manifest)),"write historical baseline fixture");
    nc::RemoteStamp remote{"\"unchanged\"","Mon, 26 Oct 2026 00:00:00 GMT","123"};
    require(nc::writeSmall(dir+"/catalog-a/remote-graphics.txt",nc::stampText(nc::GraphicsUrl,remote)),"write HTTP validator fixture");
    std::string published="["+jsonRelease(oldRelease)+"]";unsigned zipGets=0;bool failGraphics=false;
    nc::testNetworkReady=true;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &failure,nc::RemoteStamp *stamp,bool head){
        if(stamp)*stamp=remote;
        if(head)return true;
        if(url.rfind("https://api.github.com/",0)==0)return nc::writeSmall(path,published);
        ++zipGets;
        if(failGraphics&&url==nc::GraphicsUrl){failure="synthetic interrupted HTTPS";return false;}
        const auto input=url==asset.url?base/"new.zip":base/"cache"/"catalog-a"/"graphics.zip";
        std::filesystem::copy_file(input,path,std::filesystem::copy_options::overwrite_existing);return true;
    };
    error.clear();require(nc::refreshCatalog(catalog,false,error)&&zipGets==0&&nc::activeSlot()=='a',"unchanged release signatures and HEAD skip ZIP downloads");
    published="["+jsonRelease(oldRelease)+","+jsonRelease(newRelease)+"]";
    failGraphics=true;error.clear();require(!nc::refreshCatalog(catalog,true,error)&&nc::activeSlot()=='a',"interrupted second source preserves active cache");
    nc::SeenMap afterFailure;require(nc::readSeen(dir+"/catalog-a/releases-seen.txt",afterFailure)&&afterFailure.size()==1,"failed commit does not acknowledge new publication");
    failGraphics=false;error.clear();require(nc::refreshCatalog(catalog,false,error)&&nc::activeSlot()=='b',"new release commits atomically after successful validated merge");
    require(catalog.entries.size()==3,"new merge retains older BID and both original sources");
    nc::SeenMap afterSuccess;require(nc::readSeen(dir+"/catalog-b/releases-seen.txt",afterSuccess)&&afterSuccess.size()==2,"seen release advances only inside committed slot");
    unsigned previousGets=zipGets;error.clear();require(nc::refreshCatalog(catalog,false,error)&&zipGets==previousGets,"second launch rechecks metadata without fetching unchanged ZIPs");
    std::string pendingJson="["+jsonRelease(oldRelease)+","+jsonRelease(newRelease);
    for(unsigned i=3;i<=12;++i){auto nextRelease=newRelease;nextRelease.id=i;nextRelease.published="2026-10-27T00:00:00Z";pendingJson+=","+jsonRelease(nextRelease);}published=pendingJson+"]";
    error.clear();require(!nc::refreshCatalog(catalog,false,error)&&error.find("pendientes")!=std::string::npos,"bounded batch reports unfinished release history honestly");
    nc::SeenMap partial;require(nc::readSeen(dir+"/catalog-a/releases-seen.txt",partial)&&partial.size()==10,"bounded commit acknowledges downloaded releases only");
    nc::testTransfer={};nc::testNetworkReady=false;
    std::cout<<"catalog: "<<checks<<" ZIP, cache and compatibility checks passed\n";
}

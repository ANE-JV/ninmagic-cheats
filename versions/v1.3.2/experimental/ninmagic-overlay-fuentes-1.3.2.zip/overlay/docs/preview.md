# Vistas de desarrollo del overlay

`preview/` contiene seis vistas de la misma lógica de dibujo que usa el overlay: menú, HUD pasivo, preparación, confirmación de lectura, comparaciones y confirmación experimental.

El adaptador de `tools/mock/tesla.hpp` sustituye únicamente el renderer y los servicios de consola para poder inspeccionar el diseño en el PC. Usa los glifos DejaVu existentes como aproximación a las fuentes compartidas de Switch; no reproduce sus métricas con exactitud. El damero representa transparencia, no una captura del juego. Datos, valores y estados son ejemplos; estas imágenes no prueban ejecución en hardware.

Desde la carpeta principal `ninmagic-cheats`:

```powershell
g++ -std=c++20 -O2 -Wall -Wextra -Werror -Ioverlay/tools/mock -Ioverlay/include -Iinclude overlay/tools/preview.cpp -o "$env:TEMP/ninmagic-overlay-preview.exe"
& "$env:TEMP/ninmagic-overlay-preview.exe" romfs overlay/docs/preview
python tools/convert_preview.py overlay/docs/preview
```

El ejecutable también comprueba 19 límites de entrada de la UI: el HUD ignora botones del juego; leer, probar y retirar requieren su confirmación; cancelar no solicita la operación; la edición del valor se conserva hasta la confirmación de prueba. Los servicios de memoria están sustituidos por contadores: no se lee ni escribe la consola.

Los builds de Switch no incluyen `tools/mock/`.

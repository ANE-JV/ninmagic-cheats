#pragma once
// Host-only drawing adapter for the actual overlay UI. Production builds never
// include this directory. DejaVu bitmap metrics approximate shared Switch fonts.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
#include "ui_text.hpp"
using u16=uint16_t;using u32=uint32_t;using u64=uint64_t;using s32=int32_t;
struct HidTouchState{};struct HidAnalogStickState{};
constexpr u64 HidNpadButton_A=1,HidNpadButton_B=2,HidNpadButton_X=4,HidNpadButton_Y=8,HidNpadButton_Up=16,HidNpadButton_Down=32,HidNpadButton_Left=64,HidNpadButton_Right=128,HidNpadButton_Minus=256;
inline int romfsInit(){return 0;}inline void romfsExit(){}
#define R_SUCCEEDED(x) ((x)>=0)
namespace tsl {
struct Color {unsigned r,g,b,a;constexpr Color(unsigned r_,unsigned g_,unsigned b_,unsigned a_):r(r_),g(g_),b(b_),a(a_){};};
namespace cfg {inline unsigned ScreenWidth=1920,ScreenHeight=1080,LayerWidth=672,LayerHeight=1080;}
namespace gfx {
class Renderer {
    std::vector<uint8_t>font;std::array<uint8_t,224>advances{};
    std::vector<Color>pixels=std::vector<Color>(448*720,Color{0,0,0,0});
    void pixel(int x,int y,Color c){if(x<0||x>=448||y<0||y>=720)return;auto&d=pixels[size_t(y)*448+size_t(x)];const unsigned inv=15-c.a;d=Color{(d.r*inv+c.r*c.a)/15,(d.g*inv+c.g*c.a)/15,(d.b*inv+c.b*c.a)/15,std::min(15u,d.a+c.a)};}
public:
    static Renderer&get(){static Renderer r;return r;}
    static int setLayerPos(s32,s32){return 0;}
    bool loadFont(const std::string&path){std::ifstream f(path,std::ios::binary);std::vector<uint8_t>b((std::istreambuf_iterator<char>(f)),{});if(b.size()!=183040)return false;std::copy(b.begin()+32,b.begin()+256,advances.begin());font.assign(b.begin()+256,b.end());return true;}
    void drawRect(s32 x,s32 y,s32 w,s32 h,Color c){for(int yy=std::max(0,y);yy<std::min(720,y+h);++yy)for(int xx=std::max(0,x);xx<std::min(448,x+w);++xx)pixel(xx,yy,c);}
    void fillScreen(Color c){std::fill(pixels.begin(),pixels.end(),c);}
    void clearScreen(){fillScreen(Color{0,0,0,0});}
    void drawBitmap(s32 x,s32 y,s32 w,s32 h,const uint8_t*b){for(int yy=0;yy<h;++yy)for(int xx=0;xx<w;++xx){const auto p=(size_t(yy)*w+xx)*4;pixel(x+xx,y+yy,Color{unsigned(b[p]>>4),unsigned(b[p+1]>>4),unsigned(b[p+2]>>4),unsigned(b[p+3]>>4)});}}
    std::pair<u32,u32>drawString(const char*s,bool,s32 x,s32 y,float size,Color c,int=0){int at=x,maximum=x;const int px=std::max(1,int(size)),h=(34*px+12)/24;for(auto cp:nc::ui_text::displayCodepoints(s)){const auto index=cp-32;for(int yy=0;yy<h;++yy)for(int xx=0;xx<px;++xx){const auto alpha=font.empty()?0:font[index*24*34+size_t(yy*34/h)*24+size_t(xx*24/px)];if(alpha&&c.a){auto ink=c;ink.a=ink.a*alpha/255;pixel(at+xx,y-26*px/24+yy,ink);}}at+=(advances[index]*px+12)/24;maximum=std::max(maximum,at);}return {u32(maximum-x),u32(px)};}
    std::string limitStringLength(const std::string&s,bool,float size,s32 max){if(drawString(s.c_str(),false,0,0,size,Color{0,0,0,0}).first<=unsigned(std::max(0,max)))return s;auto cps=nc::ui_text::displayCodepoints(s);const auto encode=[](const std::vector<uint32_t>&v){std::string out;for(auto cp:v)if(cp<128)out+=char(cp);else{out+=char(0xC0|(cp>>6));out+=char(0x80|(cp&63));}return out;};while(!cps.empty()&&drawString((encode(cps)+"...").c_str(),false,0,0,size,Color{0,0,0,0}).first>unsigned(std::max(0,max)))cps.pop_back();return encode(cps)+"...";}
    bool save(const std::string&path){FILE*f=std::fopen(path.c_str(),"wb");if(!f)return false;std::fprintf(f,"P6\n448 720\n255\n");for(size_t i=0;i<pixels.size();++i){auto p=pixels[i];const unsigned base=((i/448/24+i%448/24)%2)?27:32;unsigned char b[3]={static_cast<unsigned char>((p.r*17*p.a+base*(15-p.a))/15),static_cast<unsigned char>((p.g*17*p.a+base*(15-p.a))/15),static_cast<unsigned char>((p.b*17*p.a+base*(15-p.a))/15)};std::fwrite(b,1,3,f);}std::fclose(f);return true;}
};
}
namespace elm {class Element {public:virtual~Element()=default;virtual void draw(gfx::Renderer*)=0;virtual void layout(u16,u16,u16,u16)=0;void setBoundaries(u16,u16,u16,u16){}};}
class Gui {public:virtual~Gui()=default;virtual elm::Element*createUI()=0;virtual void update(){};virtual bool handleInput(u64,u64,const HidTouchState&,HidAnalogStickState,HidAnalogStickState){return false;}};
class Overlay {public:virtual~Overlay()=default;virtual void initServices(){};virtual void exitServices(){};virtual void onShow(){};virtual void onHide(){};virtual std::unique_ptr<Gui>loadInitialGui()=0;static Overlay*get(){return active;}void hide(){onHide();}void close(){};template<class T>std::unique_ptr<Gui>initially(){return std::make_unique<T>();}inline static Overlay*active=nullptr;};
namespace hlp {inline void requestForeground(bool){}}
template<class T>int loop(int,char**){return 0;}
}

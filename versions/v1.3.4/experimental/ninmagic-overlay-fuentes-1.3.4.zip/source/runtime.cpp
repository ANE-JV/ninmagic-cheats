#include "platform_internal.hpp"
#include "cheats.hpp"
#include "memory_scan_guard.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <set>

namespace nc::native {
std::string buildString(const uint8_t *bytes) {
    static constexpr char h[]="0123456789ABCDEF";std::string s;
    for(unsigned i=0;i<8;++i){s+=h[bytes[i]>>4];s+=h[bytes[i]&15];}return s;
}
namespace {
std::string upper(std::string s){for(char&c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
std::string fullBuildString(const uint8_t*bytes){const char*h="0123456789ABCDEF";std::string out;for(unsigned i=0;i<32;++i){out+=h[bytes[i]>>4];out+=h[bytes[i]&15];}return out;}
bool matchesGame(const Metadata&m,const Game&g){return m.pid&&m.title==g.id&&buildString(m.build)==upper(g.buildId)&&(g.fullBuildId.empty()||fullBuildString(m.build)==upper(g.fullBuildId));}
ScanIdentity scanIdentity(const Metadata&m){ScanIdentity i;i.pid=m.pid;i.title=m.title;i.fullBuildId=fullBuildString(m.build);i.mainBase=m.mainBase;i.mainSize=m.mainSize;i.heapBase=m.heapBase;i.heapSize=m.heapSize;return i;}
bool matchesSession(const Metadata&m,const Pack&p){return !p.sessionOnly||scan::same(p.sessionBinding,scanIdentity(m));}
bool sessionStatic(const Definition&d,const ScanIdentity&i){
    if(!scan::valid(i)||d.count!=3)return false;
    const uint32_t word=d.codes[0],width=(word>>24)&15,region=(word>>20)&15;
    if((word>>28)!=0||(width!=1&&width!=2&&width!=4)||region>1||(word&0x000FFF00u))return false;
    const uint64_t offset=(uint64_t(word&255)<<32)|d.codes[1];
    const auto size=region?i.heapSize:i.mainSize;
    return offset<size&&width<=size-offset&&(width==4||d.codes[2]<(uint32_t(1)<<(width*8)));
}
void unknownState(Pack&p,const std::string&detail){for(auto&c:p.cheats)c.liveState=CheatState::Unknown;p.liveChecked=false;p.livePid=0;p.liveDetail=detail;}
bool same(const Definition&a,const Definition&b) {
    return a.count==b.count&&a.count>0&&a.count<=256&&std::equal(a.codes,a.codes+a.count,b.codes);
}
bool sameOwned(const Definition&a,const Definition&b) {
    return same(a,b)&&std::memcmp(a.name,b.name,sizeof(a.name))==0;
}
Definition definition(const Cheat&c) {
    Definition d{};std::memcpy(d.name,c.name.data(),std::min(c.name.size(),sizeof(d.name)-1));
    d.count=static_cast<uint32_t>(c.opcodes.size());std::copy(c.opcodes.begin(),c.opcodes.end(),d.codes);return d;
}
}
bool readCheckedState(Pack&pack,Runtime&runtime,std::string&error) {
    error.clear();unknownState(pack,{});
    auto fail=[&](const std::string&reason){error=reason;unknownState(pack,reason);return false;};
    if(!pack.game.buildVerified||pack.game.id<0x0100000000010000ULL||!validBuild(pack.game.buildId))return fail("No se confirmó el estado: falta verificar el juego y su Build ID.");
    Metadata initial{};
    if(!runtime.metadata(initial))return fail("No se pudo leer el motor de cheats del juego abierto. Estado sin confirmar.");
    if(!matchesGame(initial,pack.game)||!matchesSession(initial,pack))return fail("El proceso del motor no coincide con este juego y Build ID o con la sesión de búsqueda. Estado sin confirmar.");
    std::vector<Entry> entries;
    if(!runtime.entries(entries)||entries.size()>128)return fail("No se pudo leer el inventario del motor. Estado sin confirmar.");
    std::set<uint32_t> ids;size_t enabledWords=0,loadedWords=0,enabledEntries=0;
    for(const auto&e:entries) {
        if(e.id>=128||e.enabled>1||!e.definition.count||e.definition.count>256||!ids.insert(e.id).second||std::find(e.definition.name,e.definition.name+sizeof(e.definition.name),'\0')==e.definition.name+sizeof(e.definition.name))return fail("El inventario del motor no es válido. Estado sin confirmar.");
        loadedWords+=e.definition.count;if(e.enabled){enabledWords+=e.definition.count;++enabledEntries;}
    }
    for(const auto&c:pack.cheats)if(c.opcodes.empty()||c.opcodes.size()>256||c.name.empty()||c.name.size()>63)return fail("Un cheat del catálogo no permite comprobar su estado en el motor.");
    Metadata after{};
    if(!runtime.metadata(after)||!matchesGame(after,pack.game)||!matchesSession(after,pack)||after.pid!=initial.pid||std::memcmp(after.build,initial.build,sizeof(initial.build)))return fail("El proceso o Build ID cambió durante la lectura. Estado sin confirmar.");
    std::vector<bool> enabled(pack.cheats.size(),false);unsigned missingMasters=0,aliases=0;
    for(size_t i=0;i<pack.cheats.size();++i) {
        auto&c=pack.cheats[i];const auto def=definition(c);bool loaded=false,nameEnabled=false;
        for(const auto&e:entries)if((c.master?e.id==0:e.id!=0)&&same(e.definition,def)) {
            loaded=true;enabled[i]=enabled[i]||e.enabled;
            if(e.enabled&&std::string(e.definition.name)==c.name)nameEnabled=true;
        }
        c.liveState=!loaded?CheatState::NotLoaded:enabled[i]?CheatState::Enabled:CheatState::Disabled;
        if(enabled[i]&&!nameEnabled)++aliases;
        if(!c.master&&enabled[i]) {
            const auto group=c.group.empty()?c.source:c.group;bool mastersOk=true;
            for(const auto&master:pack.cheats)if(master.master&&(master.group.empty()?master.source:master.group)==group) {
                const auto needed=definition(master);
                if(std::none_of(entries.begin(),entries.end(),[&](const Entry&e){return e.id==0&&e.enabled&&same(e.definition,needed);}))mastersOk=false;
            }
            if(!mastersOk){c.liveState=CheatState::Unknown;++missingMasters;}
        }
    }
    if(enabledWords>0x400)for(auto&c:pack.cheats)c.liveState=CheatState::Unknown;
    if(!pack.liveHydrated) {
        // The checkbox is the user's selection; the state badge is separate.
        // Seed it from actual enable bits once, then preserve later user edits.
        for(size_t i=0;i<pack.cheats.size();++i)pack.cheats[i].selected=!pack.cheats[i].master&&enabled[i];
        pack.liveHydrated=true;
    }
    pack.liveChecked=true;pack.livePid=initial.pid;
    pack.liveDetail="Motor: "+std::to_string(entries.size())+" entradas, "+std::to_string(enabledEntries)+" habilitadas; "+std::to_string(enabledWords)+"/"+std::to_string(loadedWords)+" palabras activas/cargadas.";
    if(enabledWords>0x400)pack.liveDetail+=" Supera 1024 palabras activas y no puede ejecutar el conjunto.";
    else if(missingMasters)pack.liveDetail+=" Hay cheats habilitados cuyo maestro no coincide; su efecto no está confirmado.";
    else if(aliases)pack.liveDetail+=" Hay códigos iguales con otro nombre en el motor.";
    return true;
}
Outcome applyChecked(const Pack &pack,Runtime &runtime,LiveReceipt *receipt) {
    Outcome out;
    std::vector<Cheat> chosen;
    if(!selectedCheats(pack,chosen,out.message))return out;
    Metadata initial{};
    if(!runtime.metadata(initial)||!matchesGame(initial,pack.game)||!matchesSession(initial,pack)) {
        out.message="El juego en ejecución no coincide con este Title ID y Build ID. Instala los cheats para el próximo inicio.";return out;
    }
    std::vector<Definition> desired;Definition requiredMaster{};
    for(const auto&c:chosen) {
        if(c.opcodes.empty()||c.opcodes.size()>256||c.name.empty()||c.name.size()>63) {
            out.message="Un cheat excede los límites del motor de Atmosphere.";return out;
        }
        auto d=definition(c);
        if(c.master) {
            if(requiredMaster.count&&!same(requiredMaster,d)){out.message="Las fuentes seleccionadas necesitan códigos maestros distintos. Aplica una fuente cada vez.";return out;}
            requiredMaster=d;
        } else if(std::none_of(desired.begin(),desired.end(),[&](const Definition&x){return same(x,d);})) desired.push_back(d);
    }
    if(pack.sessionOnly&&(requiredMaster.count||desired.size()!=1||!sessionStatic(desired.front(),pack.sessionBinding))){out.message="La prueba experimental requiere un único valor estático MAIN/HEAP de esta sesión, sin maestro ni instrucciones de registros.";return out;}
    const auto sessionEntriesSafe=[&](const std::vector<Entry>&entries) {
        if(!pack.sessionOnly)return true;
        if(entries.size()>128)return false;
        std::set<uint32_t> known;
        for(const auto&e:entries)if(e.id>=128||e.enabled>1||!e.definition.count||e.definition.count>256||!known.insert(e.id).second||std::find(e.definition.name,e.definition.name+sizeof(e.definition.name),'\0')==e.definition.name+sizeof(e.definition.name)||e.id==0||(e.enabled&&!same(e.definition,desired.front())))return false;
        return true;
    };
    std::vector<Entry> existing;
    if(!runtime.entries(existing)||existing.size()>128){out.message="No se pudieron leer los cheats activos del juego.";return out;}
    Definition previousMaster{};bool hasMaster=false;
    std::set<uint32_t> ids;
    for(const auto&e:existing) {
        if(e.id>=128||e.enabled>1||e.definition.count==0||e.definition.count>256||!ids.insert(e.id).second||std::find(e.definition.name,e.definition.name+sizeof(e.definition.name),'\0')==e.definition.name+sizeof(e.definition.name)){out.message="El inventario de cheats activos no es válido.";return out;}
        if(e.id==0){hasMaster=true;previousMaster=e.definition;}
    }
    if(!sessionEntriesSafe(existing)){out.message="Hay otros cheats o un maestro en el motor. Retíralos antes de probar el candidato; no se desactivaron automáticamente.";return out;}
    auto combined=chosen;
    for(const auto&e:existing)if(e.id!=0&&e.enabled) {
        Cheat c;c.name="Activo: "+std::string(e.definition.name,std::find(e.definition.name,e.definition.name+sizeof(e.definition.name),'\0'));
        c.opcodes.assign(e.definition.codes,e.definition.codes+e.definition.count);combined.push_back(std::move(c));
    }
    std::string conflict;
    if(!validateWriteConflicts(combined,conflict)) {
        out.message="Un cheat ya activo entra en conflicto con la selección. Cierra el juego y revisa los cheats instalados. "+conflict;return out;
    }
    if(requiredMaster.count&&hasMaster&&!same(requiredMaster,previousMaster)) {
        out.message="Ya hay un código maestro diferente en ejecución. Reinicia el juego con los cheats instalados.";return out;
    }
    // Atmosphere's VM concatenates every enabled entry into one program of
    // at most 0x400 words. IPC success alone does not mean this program loads.
    size_t enabledWords=0;
    for(const auto&e:existing)if(e.enabled)enabledWords+=e.definition.count;
    for(const auto&d:desired) {
        const auto old=std::find_if(existing.begin(),existing.end(),[&](const Entry&e){return e.id!=0&&same(e.definition,d);});
        if(old==existing.end()||!old->enabled)enabledWords+=d.count;
    }
    if(requiredMaster.count&&!hasMaster)enabledWords+=requiredMaster.count;
    if(enabledWords>0x400) {
        out.message="El conjunto activo superaría las 1024 palabras del motor de Atmosphere y no se ejecutaría. Retira otros cheats o reduce la selección.";return out;
    }
    size_t newCount=0;
    for(const auto&d:desired)if(std::none_of(existing.begin(),existing.end(),[&](const Entry&e){return e.id!=0&&same(e.definition,d);}))++newCount;
    const size_t regularCount=existing.size()-(hasMaster?1:0);
    if(regularCount+newCount>127){out.message="El motor no tiene espacio para tantos cheats. Reduce la selección o reinicia el juego.";return out;}
    struct Action {uint32_t id;bool added;bool enable;};std::vector<Action> actions;
    bool masterAdded=false;
    auto unchanged=[&]() {
        Metadata now{};return runtime.metadata(now)&&now.pid==initial.pid&&matchesGame(now,pack.game)&&matchesSession(now,pack)&&std::memcmp(now.build,initial.build,sizeof(initial.build))==0;
    };
    const auto mutationSafe=[&]() {
        if(!unchanged())return false;
        if(!pack.sessionOnly)return true;
        std::vector<Entry> current;return runtime.entries(current)&&sessionEntriesSafe(current)&&unchanged();
    };
    auto rollback=[&]() {
        if(!unchanged())return false;
        bool ok=true;
        for(auto i=actions.rbegin();i!=actions.rend();++i) {
            if(!unchanged())return false;
            if(i->added)ok=runtime.remove(i->id)&&ok;
            else if(i->enable)ok=runtime.toggle(i->id)&&ok;
        }
        if(masterAdded&&unchanged())ok=runtime.remove(0)&&ok;
        return ok;
    };
    auto fail=[&]() {
        const bool restored=rollback();
        out.message=restored?"No se completó la activación. Se revirtieron las entradas nuevas del motor; reinicia el juego, porque los valores ya escritos no se restauran automáticamente.":"No se completó la activación; reinicia el juego para descartar cambios parciales del motor y valores ya escritos.";
        return out;
    };
    for(const auto&d:desired) {
        auto found=std::find_if(existing.begin(),existing.end(),[&](const Entry&e){return e.id!=0&&same(e.definition,d);});
        if(found!=existing.end()) {actions.push_back({found->id,false,false});continue;}
        if(!mutationSafe())return fail();
        uint32_t id=0;if(!runtime.add(d,id))return fail();
        if(id==0||id>=128||ids.count(id))return fail();
        ids.insert(id);actions.push_back({id,true,false});
    }
    if(requiredMaster.count&&!hasMaster) {
        if(!mutationSafe()||!runtime.master(requiredMaster))return fail();
        masterAdded=true;
    }
    for(auto&a:actions) {
        if(!a.added) {
            auto old=std::find_if(existing.begin(),existing.end(),[&](const Entry&e){return e.id==a.id;});
            if(old!=existing.end()&&old->enabled)continue;
        }
        if(!mutationSafe()||!runtime.toggle(a.id))return fail();
        a.enable=true;
    }
    std::vector<Entry> verified;
    if(!unchanged()||!runtime.entries(verified)||!sessionEntriesSafe(verified)||!unchanged())return fail();
    size_t verifiedWords=0;
    for(const auto&e:verified)if(e.enabled) {
        if(!e.definition.count||e.definition.count>256)return fail();
        verifiedWords+=e.definition.count;
    }
    if(verifiedWords>0x400)return fail();
    for(const auto&d:desired)if(std::none_of(verified.begin(),verified.end(),[&](const Entry&e){return e.id!=0&&e.enabled&&same(e.definition,d);}))return fail();
    if(requiredMaster.count&&std::none_of(verified.begin(),verified.end(),[&](const Entry&e){return e.id==0&&e.enabled&&same(e.definition,requiredMaster);}))return fail();
    if(receipt) {
        if(!receipt->valid||receipt->pid!=initial.pid||receipt->title!=initial.title||receipt->buildId!=pack.game.buildId) {
            *receipt={};receipt->valid=true;receipt->pid=initial.pid;receipt->title=initial.title;receipt->buildId=pack.game.buildId;
        }
        // An entry removed or replaced by another client no longer belongs to
        // this receipt. A newly allocated reused ID gets a fresh ownership row.
        receipt->changes.erase(std::remove_if(receipt->changes.begin(),receipt->changes.end(),[&](const LiveChange&c){
            return std::none_of(existing.begin(),existing.end(),[&](const Entry&e){return e.id==c.id&&sameOwned(e.definition,c.definition);});
        }),receipt->changes.end());
        if(receipt->masterAdded&&std::none_of(existing.begin(),existing.end(),[&](const Entry&e){return e.id==0&&sameOwned(e.definition,receipt->master);}))receipt->masterAdded=false;
        for(const auto&a:actions)if(a.added||a.enable) {
            auto old=std::find_if(receipt->changes.begin(),receipt->changes.end(),[&](const LiveChange&c){return c.id==a.id;});
            if(old!=receipt->changes.end())continue;
            auto entry=std::find_if(verified.begin(),verified.end(),[&](const Entry&e){return e.id==a.id;});
            if(entry!=verified.end())receipt->changes.push_back({a.id,a.added,entry->definition});
        }
        if(masterAdded){receipt->masterAdded=true;receipt->master=requiredMaster;}
        if(masterAdded||!receipt->masterAdded)receipt->observed=verified;
        else for(const auto&a:actions)if(a.added) {
            auto entry=std::find_if(verified.begin(),verified.end(),[&](const Entry&e){return e.id==a.id;});
            if(entry!=verified.end()) {
                auto observed=std::find_if(receipt->observed.begin(),receipt->observed.end(),[&](const Entry&e){return e.id==a.id;});
                if(observed==receipt->observed.end())receipt->observed.push_back(*entry);else *observed=*entry;
            }
        }
    }
    out.ok=out.live=true;out.count=static_cast<unsigned>(desired.size());
    out.message=pack.sessionOnly?"Prueba experimental habilitada solo para esta sesión. Comprueba el efecto dentro del juego; no se ha demostrado qué representa el valor.":"Cheats activados en el juego en ejecución. Los demás cheats del motor conservan su estado.";return out;
}
Outcome undoChecked(const Game&game,Runtime&runtime,LiveReceipt&receipt) {
    Outcome out;out.live=true;
    if(!receipt.valid||receipt.title!=game.id||receipt.buildId!=game.buildId||(!receipt.masterAdded&&receipt.changes.empty())) {
        out.message="Esta sesión no tiene cheats propios que retirar del motor para este juego. Puedes retirar los archivos instalados y reiniciar el juego.";return out;
    }
    auto identity=[&]() {
        Metadata now{};return runtime.metadata(now)&&now.pid==receipt.pid&&now.title==receipt.title&&buildString(now.build)==receipt.buildId;
    };
    auto processChanged=[&]() {
        Metadata now{};
        if(runtime.metadata(now)&&(now.pid!=receipt.pid||now.title!=receipt.title||buildString(now.build)!=receipt.buildId)) {
            receipt={};out.message="El proceso del juego cambió o se cerró. No se modificó el motor de otro proceso.";
        } else out.message="No se pudo verificar el proceso del juego. Se conserva el recibo; cierra y abre el juego para detener sus cheats.";
        return out;
    };
    if(!identity())return processChanged();
    auto read=[&](std::vector<Entry>&entries) {
        if(!runtime.entries(entries)||entries.size()>128)return false;
        std::set<uint32_t> seen;
        for(const auto&e:entries)if(e.id>=128||!e.definition.count||e.definition.count>256||!seen.insert(e.id).second)return false;
        return true;
    };
    auto foreignNew=[&](const std::vector<Entry>&entries) {
        if(!receipt.masterAdded)return false;
        for(const auto&e:entries)if(e.id!=0) {
            auto known=std::find_if(receipt.observed.begin(),receipt.observed.end(),[&](const Entry&old){return old.id==e.id&&sameOwned(old.definition,e.definition);});
            if(known==receipt.observed.end())return true;
        }
        return false;
    };
    std::vector<Entry> entries;
    if(!read(entries)){out.message="No se pudo revisar el motor antes de retirar cheats. Cierra y abre el juego.";return out;}
    for(const auto&c:receipt.changes) {
        auto found=std::find_if(entries.begin(),entries.end(),[&](const Entry&e){return e.id==c.id;});
        if(found!=entries.end()&&!sameOwned(found->definition,c.definition)){out.message="Otro programa cambió una entrada que esta sesión había aplicado. No se modificó el motor; cierra y abre el juego.";return out;}
    }
    if(receipt.masterAdded) {
        auto master=std::find_if(entries.begin(),entries.end(),[](const Entry&e){return e.id==0;});
        if(master!=entries.end()&&!sameOwned(master->definition,receipt.master)){out.message="Otro programa cambió el código maestro. No se modificó el motor; cierra y abre el juego.";return out;}
        if(foreignNew(entries)){out.message="Hay cheats nuevos de otro programa que podrían depender del maestro. Cierra y abre el juego para retirarlos con seguridad.";return out;}
    }
    while(!receipt.changes.empty()) {
        if(!identity())return processChanged();
        if(!read(entries)){out.message="No se completó la retirada del motor. Cierra y abre el juego para reiniciar sus valores.";return out;}
        const auto c=receipt.changes.back();
        auto entry=std::find_if(entries.begin(),entries.end(),[&](const Entry&e){return e.id==c.id;});
        if(entry!=entries.end()) {
            if(!sameOwned(entry->definition,c.definition)){out.message="Una entrada cambió durante la retirada. Cierra y abre el juego para reiniciar sus valores.";return out;}
            if(!identity())return processChanged();
            if(c.added?!runtime.remove(c.id):(entry->enabled&&!runtime.toggle(c.id))){out.message="No se completó la retirada del motor. Cierra y abre el juego para reiniciar sus valores.";return out;}
            if(!identity())return processChanged();
            if(!read(entries)){out.message="No se pudo verificar la retirada del motor. Cierra y abre el juego para reiniciar sus valores.";return out;}
            auto after=std::find_if(entries.begin(),entries.end(),[&](const Entry&e){return e.id==c.id;});
            if(after!=entries.end()&&(c.added||!sameOwned(after->definition,c.definition)||after->enabled)) {
                out.message="El motor no confirmó la retirada de una entrada. Cierra y abre el juego para reiniciar sus valores.";return out;
            }
            ++out.count;
        }
        receipt.changes.pop_back();
    }
    if(receipt.masterAdded) {
        if(!identity())return processChanged();
        if(!read(entries)||foreignNew(entries)){out.message="No se pudo retirar el maestro sin afectar otros cheats. Cierra y abre el juego.";return out;}
        auto master=std::find_if(entries.begin(),entries.end(),[](const Entry&e){return e.id==0;});
        if(master!=entries.end()) {
            if(!sameOwned(master->definition,receipt.master)){out.message="El maestro cambió durante la retirada. Cierra y abre el juego.";return out;}
            if(!identity())return processChanged();
            if(!runtime.remove(0)){out.message="No se pudo retirar el maestro del motor. Cierra y abre el juego.";return out;}
            if(!identity())return processChanged();
            if(!read(entries)||std::any_of(entries.begin(),entries.end(),[](const Entry&e){return e.id==0;})) {
                out.message="No se pudo verificar la retirada del maestro. Cierra y abre el juego.";return out;
            }
        }
        receipt.masterAdded=false;
    }
    receipt={};out.ok=true;
    out.message="Cheats retirados del motor. Cierra y abre el juego para reiniciar sus valores; los cambios guardados no se revierten.";return out;
}
}

"""Package the experimental overlay together with its corresponding source."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from verify_nro import verify

ROOT = Path(__file__).resolve().parent.parent
VERSION = "1.3.5"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    binary = ROOT / "dist/overlay/ninmagic-creator.ovl"
    report = verify(binary, expected_version=VERSION, expected_title="NinMagic Creador")
    guide = ROOT / "docs/overlay-guide.md"
    license_file = ROOT / "overlay/deps/libtesla/LICENSE"
    source_zip = ROOT / f"dist/ninmagic-overlay-fuentes-{VERSION}.zip"
    source_files = []
    for directory in ("source", "include", "overlay", "assets", "romfs", "tests"):
        for path in (ROOT / directory).rglob("*"):
            relative = path.relative_to(ROOT)
            if not path.is_file() or any(part in {".git", "build", "__pycache__"} for part in relative.parts):
                continue
            if path.suffix in {".exe", ".o", ".elf", ".ovl", ".nro", ".nacp", ".ppm"}:
                continue
            if path.is_symlink():
                raise ValueError(f"Unexpected source link: {relative}")
            source_files.append(path)
    source_files += [ROOT / name for name in ("Makefile", "README.md", "tools/build-overlay.ps1", "tools/verify_nro.py", "tools/package_overlay.py", "docs/overlay-guide.md")]
    # Include all third-party notices used by the native backend.
    source_files += list((ROOT / "third_party").glob("*-LICENSE.txt"))
    with zipfile.ZipFile(source_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(source_files)):
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(source_zip) as archive:
        if archive.testzip() is not None:
            raise ValueError("Corresponding source ZIP CRC failed")
    package = ROOT / f"dist/ninmagic-overlay-{VERSION}-experimental.zip"
    payload = {
        "switch/.overlays/ninmagic-creator.ovl": binary.read_bytes(),
        "LEEME-OVERLAY.txt": guide.read_bytes(),
        "LICENCIA-GPL-2.txt": license_file.read_bytes(),
        source_zip.name: source_zip.read_bytes(),
    }
    with zipfile.ZipFile(package, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in payload.items():
            archive.writestr(name, content)
    with zipfile.ZipFile(package) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(payload):
            raise ValueError("Overlay ZIP CRC/inventory failed")
        for name, content in payload.items():
            if archive.read(name) != content:
                raise ValueError("Overlay ZIP content differs")
    report.update({
        "experimental": True, "hardware_tested": False,
        "firmware_23_compatibility_verified": False,
        "package": {"file": package.name, "sha256": digest(package)},
        "corresponding_source": {"file": source_zip.name, "sha256": digest(source_zip), "files": len(set(source_files))},
        "requires_existing_compatible_overlay_loader": True,
        "automatic_health_identification": False,
        "automatic_candidate_activation": False,
    })
    validation = ROOT / "dist/overlay/package-verification.json"
    validation.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    desktop = Path.home() / "Desktop" / f"ninmagic-cheats-{VERSION}"
    desktop.mkdir(parents=True, exist_ok=True)
    for path in (package, source_zip, validation, binary):
        destination = desktop / path.name
        shutil.copy2(path, destination)
        if digest(path) != digest(destination):
            raise ValueError("PC overlay copy mismatch")
    shutil.copy2(guide, desktop / "LEEME-OVERLAY.txt")
    print(json.dumps({"desktop": str(desktop), "overlay_sha256": report["sha256"], "package_sha256": digest(package), "source_files": len(set(source_files)), "hardware_tested": False}, indent=2))


if __name__ == "__main__":
    main()

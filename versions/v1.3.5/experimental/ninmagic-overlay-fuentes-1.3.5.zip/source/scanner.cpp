#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "scanner.hpp"
#include "model.hpp"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr size_t Chunk=64*1024,MaxRegions=4096,MaxMetadata=1024*1024;
struct Stored {ScanSession session;uint32_t snapshotCrc=0,maskCrc=0;char slot='a';};
std::function<bool(uint64_t,uint64_t)> observer;
#ifdef NC_SCANNER_TEST
std::function<bool(const std::string&,const std::string&)> markerFailure;
#endif
std::string scanRoot(){
#ifdef NC_SCANNER_TEST
    const char *value=std::getenv("NC_SCANNER_ROOT");return value?value:"scanner-test";
#elif defined(NC_SCANNER_OVERLAY)
    return "sdmc:/config/NinMagicCheats/scanner-overlay";
#else
    return "sdmc:/config/NinMagicCheats/scanner";
#endif
}
bool pathStat(const std::string &path,struct stat &st){return lstat(path.c_str(),&st)==0;}
bool regularFile(const std::string &path,uint64_t maximum){struct stat st{};return pathStat(path,st)&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=maximum;}
bool directory(const std::string &path){struct stat st{};if(pathStat(path,st))return S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);if(errno!=ENOENT)return false;
#ifdef _WIN32
    return mkdir(path.c_str())==0;
#else
    return mkdir(path.c_str(),0777)==0;
#endif
}
bool ensureRoot(std::string &error){
#ifndef NC_SCANNER_TEST
    if(!directory("sdmc:/config")||!directory("sdmc:/config/NinMagicCheats")){error="No se puede abrir la carpeta de NinMagic Cheats.";return false;}
#endif
    if(!directory(scanRoot())){error="No se puede abrir la carpeta privada del buscador.";return false;}return true;
}
bool removeKnown(const std::string &path){struct stat st{};if(!pathStat(path,st))return errno==ENOENT;return S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&unlink(path.c_str())==0;}
std::string file(char slot,const char *suffix){return scanRoot()+"/session-"+slot+suffix;}
bool readFile(const std::string &path,std::vector<uint8_t> &data,size_t limit){data.clear();if(!regularFile(path,limit))return false;FILE *f=fopen(path.c_str(),"rb");if(!f)return false;std::array<uint8_t,4096> buffer{};size_t count;while((count=fread(buffer.data(),1,buffer.size(),f))){if(data.size()+count>limit){fclose(f);return false;}data.insert(data.end(),buffer.begin(),buffer.begin()+count);}bool ok=!ferror(f);fclose(f);return ok;}
bool closeWritten(FILE *f){bool ok=fflush(f)==0;if(ok)ok=fsync(fileno(f))==0;if(fclose(f)!=0)ok=false;return ok;}
bool observe(uint64_t done,uint64_t total,std::string &error){if(!observer||observer(done,total))return true;error="Búsqueda cancelada. Se conserva la búsqueda anterior.";return false;}
bool writeFile(const std::string &path,const void *data,size_t size){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;FILE *f=fopen(path.c_str(),"wb");if(!f)return false;bool ok=fwrite(data,1,size,f)==size;return closeWritten(f)&&ok;}
char activeSlot(){std::vector<uint8_t> bytes;for(const char *name:{"active.txt","active.previous"})if(readFile(scanRoot()+"/"+name,bytes,8)&&bytes.size()==2&&(bytes[0]=='a'||bytes[0]=='b')&&bytes[1]=='\n')return char(bytes[0]);return 'a';}
unsigned width(ScanValueType type){switch(type){case ScanValueType::U8:return 1;case ScanValueType::U16:return 2;case ScanValueType::U32:case ScanValueType::F32:return 4;}return 0;}
std::string upper(std::string value){for(char &c:value)if(c>='a'&&c<='f')c=char(c-'a'+'A');return value;}
bool hexBuild(const std::string &value){return value.size()==64&&value.find_first_not_of("0123456789abcdefABCDEF")==std::string::npos&&value.find_first_not_of('0')!=std::string::npos;}
bool endOf(uint64_t start,uint64_t size,uint64_t &end){if(!size||start>UINT64_MAX-size)return false;end=start+size;return true;}
bool contained(uint64_t start,uint64_t size,uint64_t base,uint64_t length){uint64_t end=0,limit=0;return endOf(start,size,end)&&endOf(base,length,limit)&&start>=base&&end<=limit;}
bool identityValid(const ScanIdentity &id){uint64_t a=0,b=0;if(!id.pid||id.title<0x0100000000010000ULL||!hexBuild(id.fullBuildId))return false;if(!endOf(id.mainBase,id.mainSize,a))return false;if(id.heapSize&&!endOf(id.heapBase,id.heapSize,b))return false;if(id.heapSize&&id.mainBase<b&&id.heapBase<a)return false;return true;}
bool sameIdentity(const ScanIdentity &a,const ScanIdentity &b){return a.pid==b.pid&&a.title==b.title&&upper(a.fullBuildId)==upper(b.fullBuildId)&&a.mainBase==b.mainBase&&a.mainSize==b.mainSize&&a.heapBase==b.heapBase&&a.heapSize==b.heapSize;}
bool belongs(const ScanIdentity &id,uint64_t address,uint64_t size){return contained(address,size,id.mainBase,id.mainSize)||contained(address,size,id.heapBase,id.heapSize);}
bool parseValue(ScanValueType type,const std::string &text,uint32_t &bits,std::string &error){
    std::string value=text;auto first=value.find_first_not_of(" \t\r\n");if(first==std::string::npos){error="Escribe el valor que aparece en el juego.";return false;}value=value.substr(first,value.find_last_not_of(" \t\r\n")-first+1);char *end=nullptr;errno=0;
    if(type==ScanValueType::F32){float number=std::strtof(value.c_str(),&end);if(errno==ERANGE||end!=value.c_str()+value.size()||!std::isfinite(number)){error="El valor decimal debe ser un número finito de 32 bits.";return false;}std::memcpy(&bits,&number,4);return true;}
    if(!width(type)||value[0]=='-'||value[0]=='+'){error="El valor entero debe ser positivo o cero.";return false;}
    int base=value.size()>2&&value[0]=='0'&&(value[1]=='x'||value[1]=='X')?16:10;unsigned long long number=std::strtoull(value.c_str(),&end,base);uint64_t maximum=width(type)==1?255:width(type)==2?65535:UINT32_MAX;
    if(errno==ERANGE||end!=value.c_str()+value.size()||number>maximum){error="El valor no cabe en el tipo de número elegido.";return false;}bits=uint32_t(number);return true;
}
uint32_t bitsAt(const uint8_t *bytes,unsigned size){uint32_t value=0;for(unsigned i=0;i<size;++i)value|=uint32_t(bytes[i])<<(i*8);return value;}
bool finiteBits(uint32_t bits){float number;std::memcpy(&number,&bits,4);return std::isfinite(number);}
bool matches(ScanValueType type,ScanCompare compare,uint32_t before,uint32_t after,uint32_t target){
    if(type==ScanValueType::F32){if(!finiteBits(after)||(compare!=ScanCompare::Exact&&!finiteBits(before)))return false;float a,b,t;std::memcpy(&a,&before,4);std::memcpy(&b,&after,4);std::memcpy(&t,&target,4);switch(compare){case ScanCompare::Exact:return b==t;case ScanCompare::Changed:return b!=a;case ScanCompare::Unchanged:return b==a;case ScanCompare::Increased:return b>a;case ScanCompare::Decreased:return b<a;}}
    switch(compare){case ScanCompare::Exact:return after==target;case ScanCompare::Changed:return after!=before;case ScanCompare::Unchanged:return after==before;case ScanCompare::Increased:return after>before;case ScanCompare::Decreased:return after<before;}return false;
}
bool prepare(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,ScanSession &session,std::string &error){
    if(!identityValid(identity)||!width(type)){error="El proceso o su Build ID no se han verificado.";return false;}if(regions.empty()||regions.size()>MaxRegions){error="La lista de regiones de memoria no es válida.";return false;}
    auto sorted=regions;std::sort(sorted.begin(),sorted.end(),[](const auto &a,const auto &b){return a.address<b.address;});session={};session.identity=identity;session.identity.fullBuildId=upper(identity.fullBuildId);session.type=type;uint64_t previousEnd=0;const unsigned size=width(type);
    for(const auto &region:sorted){if(!region.writable||!region.size)continue;uint64_t end=0;if(!endOf(region.address,region.size,end)||!belongs(identity,region.address,region.size)||region.address<previousEnd){error="Las regiones escribibles se solapan o quedan fuera de MAIN/HEAP.";return false;}previousEnd=end;uint64_t begin=region.address;if(begin%size){uint64_t add=size-begin%size;if(begin>UINT64_MAX-add){error="Dirección de memoria fuera de rango.";return false;}begin+=add;}end-=end%size;if(begin>=end)continue;const uint64_t bytes=end-begin;if(session.totalBytes>UINT64_MAX-bytes){error="Tamaño de memoria fuera de rango.";return false;}session.totalBytes+=bytes;const uint64_t accepted=std::min(bytes,ScanMaxBytes-session.coveredBytes);if(accepted){session.regions.push_back({begin,accepted,true});session.coveredBytes+=accepted;}}
    session.partial=session.coveredBytes<session.totalBytes;if(!session.coveredBytes){error="No hay memoria escribible de MAIN/HEAP en el intervalo elegido.";return false;}return true;
}
bool candidateInside(const ScanSession &session,const ScanCandidate &candidate){unsigned bytes=width(session.type);if(!bytes||candidate.address%bytes)return false;return std::any_of(session.regions.begin(),session.regions.end(),[&](const auto &r){return contained(candidate.address,bytes,r.address,r.size);});}
void collectCandidate(ScanSession &session,uint64_t address,uint32_t bits){++session.candidateCount;if(session.candidateCount<=ScanMaxCandidates)session.candidates.push_back({address,bits});else if(session.candidateCount==ScanMaxCandidates+1)session.candidates.clear();}
uint64_t maskBytes(const ScanSession &s){return (s.coveredBytes/width(s.type)+7)/8;}
class MaskWriter {
    FILE *handle=nullptr;std::array<uint8_t,8192> buffer{};size_t used=0;uint8_t byte=0;unsigned bit=0;uint32_t crc=0;
    bool flush(){if(!used)return true;if(fwrite(buffer.data(),1,used,handle)!=used)return false;crc=uint32_t(crc32(crc,buffer.data(),uInt(used)));used=0;return true;}
public:
    ~MaskWriter(){if(handle)fclose(handle);}
    void close(){if(handle){fclose(handle);handle=nullptr;}}
    bool open(const std::string &path){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;handle=fopen(path.c_str(),"wb");return handle;}
    bool put(bool value){if(value)byte|=uint8_t(1u<<bit);if(++bit==8){buffer[used++]=byte;byte=0;bit=0;if(used==buffer.size())return flush();}return true;}
    bool finish(uint32_t &result){if(bit)buffer[used++]=byte;bool ok=flush();FILE *f=handle;handle=nullptr;if(!closeWritten(f))ok=false;result=crc;return ok;}
};
class MaskReader {
    FILE *handle=nullptr;std::array<uint8_t,8192> buffer{};size_t at=0,count=0;uint8_t byte=0;unsigned bits=0;uint32_t crc=0;uint64_t readBytes=0;
public:
    ~MaskReader(){if(handle)fclose(handle);}
    bool open(const std::string &path){handle=fopen(path.c_str(),"rb");return handle;}
    bool get(bool &value){if(!bits){if(at==count){count=fread(buffer.data(),1,buffer.size(),handle);at=0;if(!count)return false;readBytes+=count;crc=uint32_t(crc32(crc,buffer.data(),uInt(count)));}byte=buffer[at++];bits=8;}value=byte&1;byte>>=1;--bits;return true;}
    bool finish(uint32_t expected,uint64_t size){return !byte&&at==count&&readBytes==size&&crc==expected&&fgetc(handle)==EOF&&!ferror(handle);}
};
void put32(std::vector<uint8_t> &out,uint32_t value){for(unsigned i=0;i<4;++i)out.push_back(uint8_t(value>>(i*8)));}
void put64(std::vector<uint8_t> &out,uint64_t value){for(unsigned i=0;i<8;++i)out.push_back(uint8_t(value>>(i*8)));}
class Decoder{const std::vector<uint8_t>&data;size_t at=0;public:explicit Decoder(const std::vector<uint8_t>&d):data(d){}bool bytes(void *target,size_t n){if(n>data.size()-at)return false;std::memcpy(target,data.data()+at,n);at+=n;return true;}bool u32(uint32_t&v){uint8_t b[4];if(!bytes(b,4))return false;v=bitsAt(b,4);return true;}bool u64(uint64_t&v){uint8_t b[8];if(!bytes(b,8))return false;v=0;for(unsigned i=0;i<8;++i)v|=uint64_t(b[i])<<(i*8);return true;}bool done()const{return at==data.size();}};
std::vector<uint8_t> serialize(const Stored &stored){const auto &s=stored.session;std::vector<uint8_t> data={'N','M','C','S','C','N','2',0};put32(data,2);put32(data,(s.baseline?1:0)|(s.partial?2:0)|(s.streamed?4:0));put32(data,unsigned(s.type));put32(data,s.rounds);put64(data,s.identity.pid);put64(data,s.identity.title);data.insert(data.end(),s.identity.fullBuildId.begin(),s.identity.fullBuildId.end());for(uint64_t value:{s.identity.mainBase,s.identity.mainSize,s.identity.heapBase,s.identity.heapSize,s.coveredBytes,s.totalBytes})put64(data,value);put32(data,unsigned(s.regions.size()));put32(data,unsigned(s.candidates.size()));put32(data,stored.snapshotCrc);put32(data,stored.maskCrc);put64(data,s.candidateCount);for(const auto &r:s.regions){put64(data,r.address);put64(data,r.size);}for(const auto &c:s.candidates){put64(data,c.address);put32(data,c.valueBits);}put32(data,uint32_t(crc32(0,data.data(),uInt(data.size()))));return data;}
bool deserialize(std::vector<uint8_t> data,Stored &stored){
    if(data.size()<176||data.size()>MaxMetadata)return false;
    uint32_t crc=bitsAt(data.data()+data.size()-4,4);data.resize(data.size()-4);if(crc32(0,data.data(),uInt(data.size()))!=crc)return false;Decoder input(data);char magic[8];uint32_t version=0,flags=0,type=0,regions=0,count=0;auto &s=stored.session;s={};char build[64];
    if(!input.bytes(magic,8)||(std::memcmp(magic,"NMCSCN1\0",8)!=0&&std::memcmp(magic,"NMCSCN2\0",8)!=0)||!input.u32(version)||(version!=1&&version!=2)||magic[6]!=char('0'+version)||!input.u32(flags)||flags>(version==1?3u:7u)||!input.u32(type)||type>3||!input.u32(s.rounds)||!s.rounds||!input.u64(s.identity.pid)||!input.u64(s.identity.title)||!input.bytes(build,64))return false;
    s.identity.fullBuildId.assign(build,64);s.type=ScanValueType(type);s.baseline=flags&1;s.partial=flags&2;s.streamed=flags&4;
    if(!input.u64(s.identity.mainBase)||!input.u64(s.identity.mainSize)||!input.u64(s.identity.heapBase)||!input.u64(s.identity.heapSize)||!input.u64(s.coveredBytes)||!input.u64(s.totalBytes)||!input.u32(regions)||!input.u32(count)||!input.u32(stored.snapshotCrc))return false;
    if(version==2){if(!input.u32(stored.maskCrc)||!input.u64(s.candidateCount))return false;}else{s.candidateCount=s.baseline?0:count;stored.maskCrc=0;}
    if(!regions||regions>MaxRegions||count>ScanMaxCandidates||!identityValid(s.identity)||s.identity.fullBuildId!=upper(s.identity.fullBuildId)||!s.coveredBytes||s.coveredBytes>ScanMaxBytes||s.coveredBytes>s.totalBytes||s.partial!=(s.coveredBytes<s.totalBytes)||(s.baseline&&count)||s.candidateCount>s.coveredBytes/width(s.type)||(s.streamed&&(!s.baseline||s.candidateCount<=ScanMaxCandidates))||(!s.streamed&&s.candidateCount!=(s.baseline?0:count)))return false;
    uint64_t previousEnd=0,sum=0;const unsigned step=width(s.type);for(uint32_t i=0;i<regions;++i){ScanRegion r;r.writable=true;uint64_t end=0;if(!input.u64(r.address)||!input.u64(r.size)||!r.size||r.address%step||r.size%step||!endOf(r.address,r.size,end)||!belongs(s.identity,r.address,r.size)||r.address<previousEnd||r.size>ScanMaxBytes-sum)return false;previousEnd=end;sum+=r.size;s.regions.push_back(r);}if(sum!=s.coveredBytes)return false;
    uint64_t previous=0;for(uint32_t i=0;i<count;++i){ScanCandidate c;if(!input.u64(c.address)||!input.u32(c.valueBits)||!candidateInside(s,c)||(i&&c.address<=previous)||(s.type==ScanValueType::F32&&!finiteBits(c.valueBits))||(step<4&&c.valueBits>=(1u<<(step*8))))return false;previous=c.address;s.candidates.push_back(c);}s.ready=input.done();return s.ready;
}
bool loadStoredAt(const ScanIdentity &identity,char slot,Stored &stored,std::string &error){
    if(!identityValid(identity)){error="El juego abierto no tiene un proceso y Build ID verificados.";return false;}stored.slot=slot;std::vector<uint8_t> bytes;if(!readFile(file(stored.slot,".dat"),bytes,MaxMetadata)||!deserialize(std::move(bytes),stored)){error="No hay una búsqueda guardada válida. Inicia una búsqueda nueva.";return false;}if(!sameIdentity(stored.session.identity,identity)){error="El proceso del juego cambió o se reinició. Inicia una búsqueda nueva; no se reutilizarán sus direcciones.";return false;}
    if(stored.session.baseline){struct stat st{};if(!regularFile(file(stored.slot,".snapshot"),ScanMaxBytes)||!pathStat(file(stored.slot,".snapshot"),st)||uint64_t(st.st_size)!=stored.session.coveredBytes){error="La referencia de memoria guardada está incompleta.";return false;}if(stored.session.streamed&&(!regularFile(file(stored.slot,".mask"),ScanMaxBytes/8)||!pathStat(file(stored.slot,".mask"),st)||uint64_t(st.st_size)!=maskBytes(stored.session))){error="La lista de coincidencias guardada está incompleta.";return false;}}return true;
}
bool loadStored(const ScanIdentity &identity,Stored &stored,std::string &error){return loadStoredAt(identity,activeSlot(),stored,error);}
bool sameSession(const ScanSession &a,const ScanSession &b){if(!a.ready||!sameIdentity(a.identity,b.identity)||a.type!=b.type||a.rounds!=b.rounds||a.baseline!=b.baseline||a.streamed!=b.streamed||a.partial!=b.partial||a.coveredBytes!=b.coveredBytes||a.totalBytes!=b.totalBytes||a.candidateCount!=b.candidateCount||a.regions.size()!=b.regions.size()||a.candidates.size()!=b.candidates.size())return false;for(size_t i=0;i<a.regions.size();++i)if(a.regions[i].address!=b.regions[i].address||a.regions[i].size!=b.regions[i].size||a.regions[i].writable!=b.regions[i].writable)return false;for(size_t i=0;i<a.candidates.size();++i)if(a.candidates[i].address!=b.candidates[i].address||a.candidates[i].valueBits!=b.candidates[i].valueBits)return false;return true;}
bool renameMarker(const std::string &from,const std::string &to){
#ifdef NC_SCANNER_TEST
    if(markerFailure&&markerFailure(from,to)){errno=EIO;return false;}
#endif
    return rename(from.c_str(),to.c_str())==0;
}
bool activateSlot(char slot,std::string &error,uint64_t total){
    if(!observe(total,total,error))return false;
    for(const char *name:{"active.txt","active.previous","active.pending"}){struct stat st{};auto path=scanRoot()+"/"+name;if(pathStat(path,st)&&!regularFile(path,8)){error="Un marcador del buscador tiene una ruta o tamaño no admitidos.";return false;}}
    const std::string marker=std::string(1,slot)+"\n";if(!writeFile(scanRoot()+"/active.pending",marker.data(),marker.size())){error="No se pudo confirmar el nuevo estado del buscador.";return false;}if(!observe(total,total,error))return false;if(!removeKnown(scanRoot()+"/active.previous")){error="No se pudo conservar el marcador anterior.";return false;}bool had=regularFile(scanRoot()+"/active.txt",8);if(had&&!renameMarker(scanRoot()+"/active.txt",scanRoot()+"/active.previous")){error="No se pudo conservar el estado anterior del buscador.";return false;}if(!renameMarker(scanRoot()+"/active.pending",scanRoot()+"/active.txt")){bool recovered=!had||renameMarker(scanRoot()+"/active.previous",scanRoot()+"/active.txt");error=recovered?"No se pudo activar la nueva búsqueda; se conserva la anterior.":"No se pudo restaurar el marcador; se conserva active.previous para recuperar la búsqueda anterior.";return false;}return true;
}
bool commit(Stored &stored,std::string &error,uint64_t total){
    if(!observe(total,total,error))return false;
    auto data=serialize(stored);const std::string pending=file(stored.slot,".dat.pending");if(!writeFile(pending,data.data(),data.size())||!removeKnown(file(stored.slot,".dat"))||rename(pending.c_str(),file(stored.slot,".dat").c_str())!=0){error="No se pudo guardar la búsqueda. Se conserva la búsqueda activa anterior.";return false;}return activateSlot(stored.slot,error,total);
}
bool validReader(const ScanReader &reader,std::string &error){if(reader)return true;error="No se ha conectado el lector de memoria del proceso.";return false;}
class DenseOutput {
    FILE *snapshot=nullptr;uint32_t crc=0;bool withMask=false;
public:
    std::string snapshotPath,maskPath;MaskWriter mask;
    explicit DenseOutput(char slot):snapshotPath(file(slot,".snapshot.pending")),maskPath(file(slot,".mask.pending")){}
    ~DenseOutput(){if(snapshot)fclose(snapshot);mask.close();removeKnown(snapshotPath);removeKnown(maskPath);}
    bool open(bool enableMask){withMask=enableMask;struct stat st{};if(pathStat(snapshotPath,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;snapshot=fopen(snapshotPath.c_str(),"wb");return snapshot&&(!withMask||mask.open(maskPath));}
    bool write(const uint8_t *data,size_t count){if(fwrite(data,1,count,snapshot)!=count)return false;crc=uint32_t(crc32(crc,data,uInt(count)));return true;}
    bool finish(Stored &stored){FILE *f=snapshot;snapshot=nullptr;if(!closeWritten(f))return false;stored.snapshotCrc=crc;return !withMask||mask.finish(stored.maskCrc);}
};
bool publishDense(Stored &stored,DenseOutput &output,bool initial,std::string &error){
    auto &s=stored.session;s.streamed=!initial&&s.candidateCount>ScanMaxCandidates;s.baseline=initial||s.streamed;s.ready=true;
    if(!observe(s.coveredBytes,s.coveredBytes,error))return false;
    if(s.baseline){if(!removeKnown(file(stored.slot,".snapshot"))||rename(output.snapshotPath.c_str(),file(stored.slot,".snapshot").c_str())!=0){error="No se pudo confirmar la referencia de memoria.";return false;}if(s.streamed&&(!removeKnown(file(stored.slot,".mask"))||rename(output.maskPath.c_str(),file(stored.slot,".mask").c_str())!=0)){error="No se pudo confirmar la lista de coincidencias.";return false;}}
    else{stored.snapshotCrc=stored.maskCrc=0;}
    return commit(stored,error,s.coveredBytes);
}
bool initialScan(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,const std::string &value,bool unknown,const ScanReader &reader,ScanSession &session,std::string &error){
    error.clear();uint32_t target=0;Stored next;if(!validReader(reader,error)||(!unknown&&!parseValue(type,value,target,error))||!prepare(identity,regions,type,next.session,error)||!ensureRoot(error)||!observe(0,next.session.coveredBytes,error))return false;next.slot=activeSlot()=='a'?'b':'a';DenseOutput output(next.slot);if(!output.open(!unknown)){error="No se puede crear la referencia temporal; comprueba el espacio de la microSD.";return false;}std::array<uint8_t,Chunk> data{};const unsigned step=width(type);uint64_t done=0;
    for(const auto &r:next.session.regions)for(uint64_t offset=0;offset<r.size;){size_t count=size_t(std::min<uint64_t>(Chunk,r.size-offset));if(!reader(next.session.identity,r.address+offset,data.data(),count,error))return false;if(!output.write(data.data(),count)){error="No se pudo escribir la referencia; la búsqueda anterior se conserva.";return false;}if(!unknown)for(size_t at=0;at<count;at+=step){uint32_t bits=bitsAt(data.data()+at,step);bool match=matches(type,ScanCompare::Exact,0,bits,target);if(!output.mask.put(match)){error="No se pudo guardar la lista de coincidencias.";return false;}if(match)collectCandidate(next.session,r.address+offset+at,bits);}offset+=count;done+=count;if(!observe(done,next.session.coveredBytes,error))return false;}
    if(!output.finish(next)){error="No se pudo cerrar la referencia de memoria.";return false;}next.session.rounds=1;if(!publishDense(next,output,unknown,error))return false;session=std::move(next.session);return true;
}
bool sameScope(const ScanSession &a,const ScanSession &b){if(a.type!=b.type||a.coveredBytes!=b.coveredBytes||a.totalBytes!=b.totalBytes||a.partial!=b.partial||a.regions.size()!=b.regions.size())return false;for(size_t i=0;i<a.regions.size();++i)if(a.regions[i].address!=b.regions[i].address||a.regions[i].size!=b.regions[i].size||a.regions[i].writable!=b.regions[i].writable)return false;return true;}
uint64_t storedBytes(const Stored &s){return s.session.baseline?s.session.coveredBytes+(s.session.streamed?maskBytes(s.session):0):0;}
bool validateStoredData(const Stored &stored,uint64_t &done,uint64_t total,std::string &error){
    if(!stored.session.baseline)return true;
    std::array<uint8_t,Chunk> data{};
    for(bool mask:{false,true}){
        if(mask&&!stored.session.streamed)continue;
        const uint64_t expected=mask?maskBytes(stored.session):stored.session.coveredBytes;
        const auto path=file(stored.slot,mask?".mask":".snapshot");
        if(!regularFile(path,expected)){error="Los datos de una comparación no son un archivo regular completo.";return false;}
        FILE *input=fopen(path.c_str(),"rb");if(!input){error="No se pueden abrir los datos de la comparación.";return false;}
        uint64_t bytes=0,matches=0;uint32_t crc=0;uint8_t last=0;size_t n=0;bool ok=true;
        while((n=fread(data.data(),1,data.size(),input))){
            if(n>expected-bytes){error="Los datos de la comparación cambiaron de tamaño.";ok=false;break;}
            bytes+=n;crc=uint32_t(crc32(crc,data.data(),uInt(n)));last=data[n-1];
            if(mask)for(size_t i=0;i<n;++i)matches+=unsigned(__builtin_popcount(unsigned(data[i])));
            done+=n;if(!observe(done,total,error)){ok=false;break;}
        }
        if(ferror(input)&&ok){error="No se pudo leer por completo la comparación.";ok=false;}fclose(input);if(!ok)return false;
        if(bytes!=expected){error="Los datos guardados de la comparación están incompletos.";return false;}
        if(crc!=(mask?stored.maskCrc:stored.snapshotCrc)){error="La comparación no supera su comprobación CRC; no se ha recuperado.";return false;}
        const unsigned used=unsigned((stored.session.coveredBytes/width(stored.session.type))%8);
        if(mask&&(matches!=stored.session.candidateCount||(used&&(last&uint8_t(0xffu<<used))))){error="La lista de coincidencias guardada no es válida.";return false;}
    }
    return true;
}
}

void setScanObserver(std::function<bool(uint64_t,uint64_t)> callback){observer=std::move(callback);}
bool startExactScan(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,const std::string &value,const ScanReader &reader,ScanSession &session,std::string &error){
    return initialScan(identity,regions,type,value,false,reader,session,error);
}
bool startUnknownScan(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,const ScanReader &reader,ScanSession &session,std::string &error){
    return initialScan(identity,regions,type,"",true,reader,session,error);
}
bool refineScan(const ScanIdentity &identity,ScanCompare compare,const std::string &value,const ScanReader &reader,ScanSession &session,std::string &error){
    error.clear();if(unsigned(compare)>unsigned(ScanCompare::Decreased)||!validReader(reader,error)){if(error.empty())error="Comparación de memoria no válida.";return false;}Stored previous;if(!loadStored(identity,previous,error))return false;if(!sameSession(session,previous.session)){error="La búsqueda guardada cambió. Recárgala antes de filtrar.";return false;}if(session.ready&&!session.baseline&&!session.candidateCount){error="No quedan coincidencias. Recupera la comparación anterior o inicia una búsqueda nueva; no se ha guardado otro filtro vacío.";return false;}uint32_t target=0;if(compare==ScanCompare::Exact&&!parseValue(session.type,value,target,error))return false;if(previous.session.rounds==UINT32_MAX){error="Inicia una búsqueda nueva.";return false;}Stored next;next.slot=previous.slot=='a'?'b':'a';next.session=previous.session;next.session.candidates.clear();next.session.candidateCount=0;next.session.baseline=next.session.streamed=false;next.session.rounds++;const unsigned step=width(session.type);
    if(previous.session.baseline){if(!observe(0,session.coveredBytes,error))return false;FILE *snapshot=fopen(file(previous.slot,".snapshot").c_str(),"rb");if(!snapshot){error="No se puede abrir la referencia guardada.";return false;}MaskReader mask;DenseOutput output(next.slot);bool ok=output.open(true)&&(!session.streamed||mask.open(file(previous.slot,".mask")));std::array<uint8_t,Chunk> old{},current{};uint32_t crc=0;uint64_t done=0,oldCandidates=0;
        for(const auto &r:session.regions){if(!ok)break;for(uint64_t offset=0;offset<r.size;){size_t count=size_t(std::min<uint64_t>(Chunk,r.size-offset));if(fread(old.data(),1,count,snapshot)!=count){error="La referencia de memoria está incompleta.";ok=false;break;}crc=uint32_t(crc32(crc,old.data(),uInt(count)));if(!reader(identity,r.address+offset,current.data(),count,error)||!output.write(current.data(),count)){ok=false;break;}for(size_t at=0;at<count;at+=step){bool alive=true;if(session.streamed&&!mask.get(alive)){error="La lista de coincidencias está incompleta.";ok=false;break;}if(alive)++oldCandidates;uint32_t now=bitsAt(current.data()+at,step);bool match=alive&&matches(session.type,compare,bitsAt(old.data()+at,step),now,target);if(!output.mask.put(match)){ok=false;break;}if(match)collectCandidate(next.session,r.address+offset+at,now);}if(!ok)break;offset+=count;done+=count;if(!observe(done,session.coveredBytes,error)){ok=false;break;}}}
        if(ok&&(fgetc(snapshot)!=EOF||ferror(snapshot)||crc!=previous.snapshotCrc)){error="La referencia de memoria no supera su comprobación CRC. Inicia una búsqueda nueva.";ok=false;}fclose(snapshot);if(ok&&session.streamed&&(!mask.finish(previous.maskCrc,maskBytes(session))||oldCandidates!=session.candidateCount)){error="La lista de coincidencias no supera su comprobación CRC.";ok=false;}if(!ok){if(error.empty())error="No se pudo guardar toda la comparación; la búsqueda anterior se conserva.";return false;}if(!output.finish(next)){error="No se pudo cerrar la comparación de memoria.";return false;}if(!publishDense(next,output,false,error))return false;
    }else{
        if(!observe(0,session.candidates.size(),error))return false;
        std::array<uint8_t,Chunk> data{};
        for(size_t i=0;i<session.candidates.size();){const uint64_t address=session.candidates[i].address;auto region=std::find_if(session.regions.begin(),session.regions.end(),[&](const auto &r){return contained(address,step,r.address,r.size);});if(region==session.regions.end()){error="Candidato fuera de las regiones guardadas.";return false;}uint64_t limit=address+std::min<uint64_t>(Chunk,region->address+region->size-address);size_t j=i+1;while(j<session.candidates.size()&&session.candidates[j].address+step<=limit)++j;size_t bytes=size_t(session.candidates[j-1].address+step-address);if(!reader(identity,address,data.data(),bytes,error))return false;for(size_t k=i;k<j;++k){const auto &candidate=session.candidates[k];uint32_t now=bitsAt(data.data()+size_t(candidate.address-address),step);if(matches(session.type,compare,candidate.valueBits,now,target))collectCandidate(next.session,candidate.address,now);}i=j;if(!observe(i,session.candidates.size(),error))return false;}
        if(!commit(next,error,session.candidates.size()))return false;
    }
    session=std::move(next.session);return true;
}
bool loadScanSession(const ScanIdentity &identity,ScanSession &session,std::string &error){error.clear();Stored stored;if(!loadStored(identity,stored,error))return false;session=std::move(stored.session);return true;}
bool restorePreviousScan(const ScanIdentity &identity,ScanSession &session,std::string &error){
    error.clear();if(!ensureRoot(error))return false;Stored current,previous;if(!loadStored(identity,current,error))return false;if(!sameSession(session,current.session)){error="La búsqueda guardada cambió. Recárgala antes de recuperar el filtro anterior.";return false;}
    if(!loadStoredAt(identity,current.slot=='a'?'b':'a',previous,error)){error="No se puede recuperar la comparación anterior: "+error;return false;}
    if(previous.session.rounds>=current.session.rounds||!sameScope(previous.session,current.session)){error="No hay una comparación anterior de esta misma búsqueda que se pueda recuperar.";return false;}
    if(!previous.session.baseline&&!previous.session.candidateCount){error="El paso anterior también tiene cero coincidencias. Ya no conserva aquellos candidatos; inicia una búsqueda nueva.";return false;}
    uint64_t done=0,total=std::max<uint64_t>(1,storedBytes(current)+storedBytes(previous));if(!observe(0,total,error)||!validateStoredData(current,done,total,error)||!validateStoredData(previous,done,total,error))return false;
    if(!activateSlot(previous.slot,error,total))return false;
    session=std::move(previous.session);return true;
}
bool clearScanSession(std::string &error){error.clear();const std::vector<std::string> paths={scanRoot()+"/active.txt",scanRoot()+"/active.previous",scanRoot()+"/active.pending",file('a',".dat"),file('b',".dat"),file('a',".dat.pending"),file('b',".dat.pending"),file('a',".snapshot"),file('b',".snapshot"),file('a',".snapshot.pending"),file('b',".snapshot.pending"),file('a',".mask"),file('b',".mask"),file('a',".mask.pending"),file('b',".mask.pending")};for(const auto &path:paths){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La carpeta del buscador contiene una ruta no admitida; no se ha borrado.";return false;}}for(const auto &path:paths)if(!removeKnown(path)){error="No se pudo borrar por completo la sesión privada del buscador.";return false;}return true;}
bool scanCandidateCheat(const ScanSession &session,size_t index,const std::string &value,const std::string &name,Cheat &cheat,std::string &error){
    error.clear();Stored stored;if(!loadStored(session.identity,stored,error))return false;if(!sameSession(session,stored.session)||session.baseline||!session.ready||index>=session.candidates.size()){error="No hay un candidato válido en esta sesión.";return false;}if(name.empty()||name.size()>63||name.find_first_of("[]{}\r\n")!=std::string::npos||std::any_of(name.begin(),name.end(),[](unsigned char c){return c<32||c==127;})){error="Usa un nombre de 1 a 63 bytes sin corchetes ni saltos de línea.";return false;}uint32_t bits=0;if(!parseValue(session.type,value,bits,error))return false;const auto &candidate=session.candidates[index];bool heap=contained(candidate.address,width(session.type),session.identity.heapBase,session.identity.heapSize);uint64_t offset=candidate.address-(heap?session.identity.heapBase:session.identity.mainBase);if(offset>0xffffffffffULL){error="El desplazamiento no cabe en una escritura estática de Atmosphère.";return false;}Cheat next;next.name=name;next.source="NinMagic Scanner · experimental";next.group="NinMagicScan:"+hexId(session.identity.title)+":"+session.identity.fullBuildId+":"+std::to_string(session.identity.pid);next.opcodes={uint32_t(width(session.type)<<24)|(heap?0x00100000u:0u)|uint32_t(offset>>32),uint32_t(offset),bits};next.selected=true;cheat=std::move(next);return true;
}
std::string scanValueText(ScanValueType type,uint32_t bits){if(type==ScanValueType::F32){float number;std::memcpy(&number,&bits,4);if(!std::isfinite(number))return "No finito";char text[32];std::snprintf(text,sizeof(text),"%.9g",double(number));return text;}if(type==ScanValueType::U8)bits&=255;if(type==ScanValueType::U16)bits&=65535;return std::to_string(bits);}
}

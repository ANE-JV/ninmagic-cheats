#pragma once
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace nc {
struct Cheat;
struct ScanIdentity {
    uint64_t pid=0,title=0;
    std::string fullBuildId;
    uint64_t mainBase=0,mainSize=0,heapBase=0,heapSize=0;
};
struct ScanRegion {uint64_t address=0,size=0;bool writable=false;};
enum class ScanValueType { U8, U16, U32, F32 };
enum class ScanCompare { Exact, Changed, Unchanged, Increased, Decreased };
struct ScanCandidate {uint64_t address=0;uint32_t valueBits=0;};
struct ScanSession {
    ScanIdentity identity;
    ScanValueType type=ScanValueType::U32;
    std::vector<ScanRegion> regions;
    std::vector<ScanCandidate> candidates;
    // Raw initial reference: baseline=true,streamed=false,count=0. A large
    // filtered pool: baseline=true,streamed=true,count>ScanMaxCandidates with
    // no RAM candidates. Sparse results expose every surviving candidate.
    uint64_t coveredBytes=0,totalBytes=0,candidateCount=0;
    unsigned rounds=0;
    bool baseline=false,partial=false,ready=false,streamed=false;
};
using ScanReader=std::function<bool(const ScanIdentity&,uint64_t,void*,size_t,std::string&)>;
constexpr uint64_t ScanMaxBytes=512ULL*1024*1024;
// Materialization threshold, not a limit on matches retained on microSD.
constexpr size_t ScanMaxCandidates=20000;
// Worker-thread only. Return false to cancel before commit; memory remains
// read-only and the preceding session stays active. Progress units are bytes
// for dense scans and candidate count for sparse refinement.
void setScanObserver(std::function<bool(uint64_t,uint64_t)> callback);
// Native provider in platform.cpp: these routines do not write memory.
struct Game;
bool getScanProcess(const Game&,ScanIdentity&,std::string&);
bool enumerateScanRegions(const ScanIdentity&,std::vector<ScanRegion>&,std::string&);
bool readScanMemory(const ScanIdentity&,uint64_t,void*,size_t,std::string&);

// The scan covers writable MAIN/HEAP regions, in address order, up to 512 MiB.
// partial/coveredBytes/totalBytes must be shown when full coverage is impossible.
// A rejected operation preserves the preceding persistent session.
bool startExactScan(const ScanIdentity&,const std::vector<ScanRegion>&,ScanValueType,const std::string &value,const ScanReader&,ScanSession&,std::string&);
bool startUnknownScan(const ScanIdentity&,const std::vector<ScanRegion>&,ScanValueType,const ScanReader&,ScanSession&,std::string&);
bool refineScan(const ScanIdentity&,ScanCompare,const std::string &value,const ScanReader&,ScanSession&,std::string&);
bool loadScanSession(const ScanIdentity&,ScanSession&,std::string&);
// Explicit one-step filter undo. Validates both persisted slots, their full
// CRCs and the same process/scope before changing only the active marker.
// Does not read game memory, generate a cheat or reactivate any code.
bool restorePreviousScan(const ScanIdentity&,ScanSession&,std::string&);
bool clearScanSession(std::string&);
// Experimental session-specific write; no claim of life/ammo semantics or
// pointer stability. Main must require the user's effect verification first.
bool scanCandidateCheat(const ScanSession&,size_t,const std::string &value,const std::string &name,Cheat&,std::string&);
std::string scanValueText(ScanValueType,uint32_t bits);
}

#include "controller.hpp"
#include "catalog.hpp"
#include "cheats.hpp"
#include "https_lite.hpp"
#include "platform.hpp"
#include "published_cache.hpp"
#include "options.hpp"
#include <switch.h>
#include <algorithm>
#include <atomic>
#include <utility>
namespace nc::overlay { namespace {
enum class Action {None,Refresh,Search,Move,Toggle,Apply,Remove};
struct Command {Action action=Action::None;Game expected;int delta=0;size_t index=0;};
Mutex mutex{};UEvent wake{};Thread worker{};
bool created=false,services=false,workerAvailable=false,cacheReady=false,dirtyContext=false;
std::atomic<bool> stopping{false},cancelled{false};
Snapshot view;Command pending;Environment environment;Game current,dirtyGame;
Pack pack;std::vector<size_t> visible;size_t highlighted=0;uint64_t cacheStamp=0;
struct Guard {Guard(){mutexLock(&mutex);}~Guard(){mutexUnlock(&mutex);}};
bool sameGame(const Game&a,const Game&b){return a.id&&a.id==b.id&&a.fullBuildId==b.fullBuildId&&a.buildId==b.buildId;}
void owned(){Guard guard;view.ownActive=dirtyContext||hasLiveOwnership(current);}
void publish(const std::string&status,const std::string&error={}){
    Guard guard;view.game=current;view.cacheAvailable=cacheReady;view.ready=cacheReady&&pack.compatible&&!visible.empty();view.totalItems=visible.size();view.selectedCount=0;view.selectedNames.clear();view.items.clear();view.highlighted=highlighted;view.firstItem=visible.empty()?0:(highlighted/8)*8;view.liveChecked=pack.liveChecked;view.liveDetail=pack.liveDetail;
    for(auto index:visible)if(pack.cheats[index].selected){++view.selectedCount;if(view.selectedNames.size()<4)view.selectedNames.push_back(cheatLabel(pack.cheats[index]));}
    for(size_t row=view.firstItem;row<visible.size()&&row<view.firstItem+8;++row){const auto&c=pack.cheats[visible[row]];PublishedItem item;item.index=row;item.name=c.name;item.label=cheatLabel(c);item.detail=explainCheat(c);item.source=c.source;item.selected=c.selected;item.liveState=c.liveState;view.items.push_back(std::move(item));}
    view.canApply=view.ready&&view.selectedCount&&!dirtyContext;view.status=status;view.error=error;
    if(dirtyContext){const std::string warning=" Hay códigos pendientes con un recibo sólo en memoria. Usa Retirar; si no es posible, cierra y abre el juego.";view.status+=warning;if(view.error.empty())view.error=warning;}
}
bool findGame(std::string&error){Game next;const bool ok=detectRunningGame(next,environment,error);current=std::move(next);return ok;}
bool reloadServices(std::string&error){if(dirtyContext){error="Primero retira los códigos pendientes; se conserva su recibo en memoria.";return false;}platformExit();services=platformInit(environment,error);{Guard guard;view.initialized=services;}return services;}
void state(){if(!cacheReady)return;std::string error;if(!readLiveState(pack,error)){pack.liveChecked=false;pack.liveDetail=error;for(auto&c:pack.cheats)c.liveState=CheatState::Unknown;}}
void clearPrepared(){pack={};visible.clear();highlighted=0;cacheReady=false;cacheStamp=0;}
bool loadPrepared(std::string&error){
    if(!loadPublishedCache(current,pack,error,&cacheStamp))return false;
    cacheReady=true;for(size_t i=0;i<pack.cheats.size();++i)if(!pack.cheats[i].master)visible.push_back(i);state();return true;
}
bool refreshPack(std::string&error){
    clearPrepared();
    if(!dirtyContext&&!reloadServices(error))return false;
    if(!findGame(error))return false;
    if(!loadPrepared(error)){error="No se pudo usar una lista guardada válida para este juego. X busca o actualiza sus cheats online.";return false;}return true;
}
bool verifiedRunning(const Game&game){
    return game.running&&game.buildVerified&&game.id>=0x0100000000010000ULL&&validBuild(game.buildId)&&
        game.fullBuildId.size()==64&&game.fullBuildId.find_first_not_of("0123456789ABCDEF")==std::string::npos&&game.fullBuildId.substr(0,16)==game.buildId;
}
bool searchPack(std::string&status,std::string&error){
    const auto aborted=[](){return cancelled.load()||stopping.load();};
    if(dirtyContext){error="Primero retira los códigos pendientes; se conserva su recibo en memoria y no se abrió la red.";return false;}
    if(aborted()){error="Consulta online cancelada. Se conserva la lista guardada.";return false;}
    clearPrepared();
    if(!services&&!reloadServices(error))return false;
    if(!findGame(error))return false;
    if(!verifiedRunning(current)){error="No se pudo verificar el Title ID y Build ID completos del juego. X permite reintentar la comprobación.";return false;}
    const Game requested=current;
    // A normal receipt is durable. An uncertain RAM-only receipt was rejected
    // above, before releasing any platform service or ownership state.
    platformExit();services=false;{Guard guard;view.initialized=false;}
    publish("Consultando fuentes online para el juego y Build ID comprobados...");
    Pack found;std::vector<CheatSourceReport> reports;std::string sourceError;bool complete=false;
    {
        struct NetworkGuard {~NetworkGuard(){catalogExit();https_lite::shutdown();}} network;
        complete=findPublishedGameDirect(requested,true,found,reports,sourceError,aborted);
        logSourceReports(requested,reports,sourceError);
    }
    // The TLS/BSD pool must be gone before loading the native receipt again.
    if(stopping.load()){error="Consulta online cancelada al salir. Se conserva la lista guardada.";return false;}
    services=platformInit(environment,error);{Guard guard;view.initialized=services;}
    if(!services){if(error.empty())error="No se pudieron reabrir los servicios del juego. Se conserva la lista guardada.";return false;}
    if(!findGame(error))return false;
    if(!verifiedRunning(current)||!sameGame(requested,current)){error="El juego o su Build ID cambió durante la consulta. No se sustituyó la lista guardada. X vuelve a comprobar el juego.";return false;}
    const bool wasCancelled=cancelled.load();
    const bool options=found.compatible&&std::any_of(found.cheats.begin(),found.cheats.end(),[](const Cheat&c){return !c.master;});
    bool saved=false;std::string saveError;
    if(!wasCancelled&&(complete||options)){
        if(!sameGame(found.game,requested)){saveError="Las fuentes devolvieron una identidad distinta; no se sustituyó la lista guardada.";}
        else if(options){saved=savePublishedCache(found,saveError);}
        else {Pack empty;empty.game=current;empty.detail=found.detail;saved=savePublishedCache(empty,saveError);}
    }
    // Do not keep the query Pack while decoding the prepared list.
    found={};reports.clear();std::string cacheError;const bool loaded=loadPrepared(cacheError);
    if(wasCancelled)error="Consulta online cancelada. ";
    else if(!saveError.empty())error=saveError+" ";
    else if(!complete)error=(sourceError.empty()?"No se completó la consulta de todas las fuentes.":sourceError)+" ";
    else if(!saved)error="No se pudo preparar la lista consultada. ";
    else if(!loaded)error="No se pudo volver a leer la lista preparada. ";
    if(!error.empty()){
        error+=loaded?(saved?"Se muestran las opciones guardadas de las fuentes disponibles.":"Se conserva y utiliza la lista guardada de este juego y Build ID."):
            saved?"La respuesta se guardó, pero no pudo verificarse para mostrarla. "+cacheError:
            "La lista anterior no se sustituyó por una respuesta vacía incompleta. "+cacheError;
        return false;
    }
    status=visible.empty()?"Consulta online completada. No se encontraron cheats publicados compatibles con este Build ID.":
        "Cheats publicados actualizados para este juego y Build ID. Marca y confirma las opciones que quieras habilitar.";
    return true;
}
void lastAction(bool ok,bool removed,const std::string&message){Guard guard;view.lastActionKnown=true;view.lastActionOk=ok;view.lastActionRemove=removed;view.lastAction=message;}
void perform(const Command&command){
    std::string error,status;bool ok=false;
    if(command.action==Action::Refresh){ok=refreshPack(error);status=!cacheReady?"X busca cheats publicados para el juego abierto.":visible.empty()?"No se encontraron opciones compatibles en la última consulta guardada. X vuelve a buscar online.":"Lista guardada cargada. X busca o actualiza online; marcar no activa códigos.";}
    else if(command.action==Action::Search){ok=searchPack(status,error);}
    else if(command.action==Action::Move){if(!visible.empty()){const auto count=static_cast<int64_t>(visible.size());const auto next=static_cast<int64_t>(highlighted)+command.delta;highlighted=size_t((next%count+count)%count);}ok=true;status="Revisa y marca los cheats que quieres habilitar.";}
    else if(command.action==Action::Toggle){if(cacheReady&&command.index<visible.size()){auto&c=pack.cheats[visible[command.index]];c.selected=!c.selected;pack.liveHydrated=true;highlighted=command.index;ok=true;status="Selección local actualizada. Revisa y confirma para habilitarla.";}else error="No hay una opción publicada válida para seleccionar.";}
    else if(command.action==Action::Apply){
        if(cancelled.load()||stopping.load())error="Aplicación cancelada antes de cambiar el motor.";
        else if(dirtyContext)error="Primero retira los códigos pendientes; no se reconectó el motor.";
        else if(!cacheReady||!pack.compatible||pack.sessionOnly||std::none_of(pack.cheats.begin(),pack.cheats.end(),[](const Cheat&c){return !c.master&&c.selected;}))error="Marca al menos un cheat publicado y revisa la selección.";
        else if(reloadServices(error)&&findGame(error)){
            if(!sameGame(command.expected,current)||!sameGame(pack.game,current))error="Cambió el juego o su Build ID. Pulsa detectar antes de aplicar.";
            else if(checkPublishedCache(current,cacheStamp,error)&&!cancelled.load()&&!stopping.load()){
                pack.game=current;pack.sessionOnly=false;const auto result=applyLive(pack);ok=result.ok;status=result.message;
                if(!ok&&(result.liveEffect==LiveEffect::Enabled||result.liveEffect==LiveEffect::Uncertain)){dirtyContext=true;dirtyGame=current;const auto rollback=removeLive(dirtyGame);const bool removed=rollback.ok&&rollback.liveEffect==LiveEffect::Removed;dirtyContext=!removed;error=result.message+" "+(removed?"Se retiraron los códigos propios del motor. Reinicia el juego para restablecer sus valores.":"No se pudo confirmar la retirada: "+rollback.message);}
                else if(!ok)error=result.message;
            }
        }
        if(!ok&&error.empty())error="No se aplicaron los cheats; vuelve a revisar el juego y la selección.";
        lastAction(ok,false,ok?status:error);pack.liveHydrated=true;state();
    }else if(command.action==Action::Remove){
        bool noOp=false;
        if(cancelled.load()||stopping.load())error="Retirada cancelada antes de cambiar el motor.";
        else if(dirtyContext||reloadServices(error)){
            const Game target=dirtyContext?dirtyGame:command.expected;const auto result=removeLive(target);ok=result.ok;noOp=ok&&result.liveEffect==LiveEffect::NoOwned&&!dirtyContext;
            if(dirtyContext&&result.liveEffect==LiveEffect::NoOwned){ok=false;error="No se pudo confirmar la retirada previa. Se conserva el recibo; cierra y abre el juego.";}
            else if(ok&&result.liveEffect==LiveEffect::Removed){dirtyContext=false;dirtyGame={};}
            else if(result.liveEffect==LiveEffect::Uncertain||result.liveEffect==LiveEffect::Enabled){dirtyContext=true;dirtyGame=target;}
            if(ok)status=result.message;else if(error.empty())error=result.message;
        }
        if(!ok&&error.empty())error="No se pudo retirar el código propio.";
        if(!noOp)lastAction(ok,ok,ok?status:error);
        pack.liveHydrated=true;state();
    }
    if(!ok&&error.empty())error="No se pudo completar la operación.";
    owned();publish(ok?status:error,ok?std::string{}:error);
}
void run(void*){
    std::string error;const bool sm=R_SUCCEEDED(smInitialize());const bool mounted=sm&&R_SUCCEEDED(fsdevMountSdmc());
    if(sm&&mounted)services=platformInit(environment,error);else error="No se pudieron abrir los servicios y la microSD.";
    {Guard guard;workerAvailable=sm&&mounted;view.initialized=services;view.busy=services;}
    if(services){Command initial;initial.action=Action::Refresh;perform(initial);}else publish(error,error);
    {Guard guard;view.busy=false;}
    while(!stopping.load()){waitSingle(waiterForUEvent(&wake),UINT64_MAX);if(stopping.load())break;Command command;{Guard guard;command=std::move(pending);pending={};}if(command.action!=Action::None&&(services||command.action==Action::Refresh||command.action==Action::Search))perform(command);{Guard guard;view.busy=false;view.searching=false;}}
    if(services&&dirtyContext)removeLive(dirtyGame);
    catalogExit();https_lite::shutdown();platformExit();services=false;pack={};visible.clear();current={};dirtyGame={};dirtyContext=false;cacheReady=false;cacheStamp=0;
    if(mounted)fsdevUnmountDevice("sdmc");
    if(sm)smExit();
}
bool enqueue(Command command){{Guard guard;const bool recovery=command.action==Action::Refresh||command.action==Action::Search;if(!created||stopping.load()||view.busy||(!view.initialized&&!(workerAvailable&&recovery)))return false;command.expected=view.game;pending=std::move(command);view.busy=true;view.searching=pending.action==Action::Search;view.error.clear();view.status=view.searching?"Consultando cheats publicados online...":"Procesando cheats publicados...";cancelled.store(false);}ueventSignal(&wake);return true;}
}}
namespace nc::overlay {
bool init(std::string&error){error.clear();if(created)return true;mutexInit(&mutex);ueventCreate(&wake,true);stopping.store(false);cancelled.store(false);view={};view.busy=true;Result rc=threadCreate(&worker,run,nullptr,nullptr,0x40000,0x3B,-2);if(R_FAILED(rc)){error="No se pudo reservar el hilo del overlay.";view.busy=false;return false;}rc=threadStart(&worker);if(R_FAILED(rc)){threadClose(&worker);error="No se pudo iniciar el overlay.";view.busy=false;return false;}created=true;return true;}
void shutdown(){if(!created)return;stopping.store(true);cancelled.store(true);ueventSignal(&wake);threadWaitForExit(&worker);threadClose(&worker);created=false;Guard guard;workerAvailable=false;view.initialized=false;view.busy=false;view.searching=false;pending={};}
Snapshot snapshot(){Guard guard;return view;}
bool refresh(){Command c;c.action=Action::Refresh;return enqueue(std::move(c));}
bool search(){Command c;c.action=Action::Search;return enqueue(std::move(c));}
bool move(int delta){Command c;c.action=Action::Move;c.delta=delta;return enqueue(std::move(c));}
bool toggle(size_t index){Command c;c.action=Action::Toggle;c.index=index;return enqueue(std::move(c));}
bool apply(){Command c;c.action=Action::Apply;return enqueue(std::move(c));}
bool remove(){Command c;c.action=Action::Remove;return enqueue(std::move(c));}
void cancel(){cancelled.store(true);}
}

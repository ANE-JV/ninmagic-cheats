#include "controller.hpp"
#define main ninmagic_overlay_entry
#include "../source/main.cpp"
#undef main

namespace {unsigned refreshCalls=0,searchCalls=0,moveCalls=0,toggleCalls=0,applyCalls=0,removeCalls=0,cancelCalls=0;size_t toggledIndex=0;bool accept=true;}
namespace nc::overlay {
bool init(std::string&){return true;}void shutdown(){}Snapshot snapshot(){return state;}
bool refresh(){++refreshCalls;return accept;}
bool search(){++searchCalls;if(accept){state.busy=state.searching=true;state.status="Consultando fuentes online para el Build ID del juego abierto...";}return accept;}
bool move(int delta){++moveCalls;if(!accept||!state.totalItems)return false;state.highlighted=size_t((int(state.highlighted)+delta+int(state.totalItems))%int(state.totalItems));return true;}
bool toggle(size_t index){++toggleCalls;if(!accept)return false;for(auto&i:state.items)if(i.index==index){i.selected=!i.selected;if(i.selected)++state.selectedCount;else if(state.selectedCount)--state.selectedCount;state.selectedNames.clear();for(const auto&row:state.items)if(row.selected&&state.selectedNames.size()<4)state.selectedNames.push_back(row.label);toggledIndex=index;return true;}return false;}
bool apply(){++applyCalls;if(!accept)return false;state.busy=true;return true;}
bool remove(){++removeCalls;if(!accept)return false;state.busy=true;return true;}
void cancel(){++cancelCalls;}
}
namespace {
nc::overlay::Snapshot fixture(){
    nc::overlay::Snapshot s;s.initialized=s.ready=s.cacheAvailable=s.liveChecked=s.canApply=true;s.game.running=s.game.buildVerified=s.game.versionKnown=true;s.game.name="The Legend of Zelda: Link's Awakening";s.game.version="1.0.0";s.game.id=0x01006BB00C6F0000ULL;s.game.buildId="A1B2C3D4E5F6789";s.game.fullBuildId=s.game.buildId+std::string(48,'0');s.status="Cheats publicados listos. Marca tu selección y revisa con Y.";
    const char*names[]={"Infinite / Max Hearts Press ZR","9999 Rupees Press L","Infinite Ammo","Invulnerable","Infinite Items","Infinite Magic","Max Money","Infinite Lives"};
    const char*labels[]={"Corazones infinitos / máximos · pulsar ZR","9999 rupias · pulsar L","Munición infinita","Invencibilidad","Objetos infinitos","Magia infinita","Dinero al máximo","Vidas infinitas"};
    for(size_t i=0;i<8;++i){nc::overlay::PublishedItem item;item.index=i;item.name=names[i];item.label=labels[i];item.source="HamletDuFromage";item.detail=i==0?"Mantén ZR para reponer el valor según las condiciones del autor.":"Respeta las condiciones originales del cheat y comprueba su efecto dentro del juego.";item.liveState=i==0?nc::CheatState::Enabled:i==1?nc::CheatState::Disabled:nc::CheatState::NotLoaded;s.items.push_back(item);}s.totalItems=s.items.size();return s;
}
}
int main(int argc,char**argv){
    if(argc!=3)return 1;
    auto&r=Renderer::get();if(!r.loadFont(std::string(argv[1])+"/font.bin"))return 2;
    FILE*f=std::fopen((std::string(argv[1])+"/logo.rgba").c_str(),"rb");if(f){std::array<uint8_t,1024>b{};hasLogo=true;for(unsigned y=0;y<64;++y){if(std::fseek(f,long(y*4096),SEEK_SET)||std::fread(b.data(),1,b.size(),f)!=b.size()){hasLogo=false;break;}for(unsigned x=0;x<64;++x)for(unsigned c=0;c<4;++c)logo[(y*64+x)*4+c]=b[x*16+c];}std::fclose(f);}
    const auto save=[&](const char*name){return r.save(std::string(argv[2])+"/"+name+".ppm");};
    state=fixture();header(&r);drawList(&r);if(!save("01-published-cheats"))return 3;
    state.items[1].selected=true;state.selectedCount=1;state.selectedNames={state.items[1].label};state.highlighted=1;header(&r);drawList(&r);if(!save("02-prepared-versus-on"))return 3;
    header(&r);drawConfirmApply(&r);if(!save("03-confirm-selection"))return 3;
    state=fixture();for(auto&i:state.items)i.selected=true;state.selectedCount=8;for(size_t i=0;i<4;++i)state.selectedNames.push_back(state.items[i].label);header(&r);drawConfirmApply(&r);if(!save("04-confirm-many"))return 3;
    header(&r);drawConfirmRemove(&r);if(!save("05-confirm-withdrawal"))return 3;
    state.highlighted=0;header(&r);drawDetails(&r);if(!save("06-original-conditions"))return 3;
    state=fixture();state.ready=state.cacheAvailable=state.canApply=false;state.items.clear();state.totalItems=0;state.status="No hay un catálogo guardado para este juego y Build ID.";header(&r);drawList(&r);if(!save("07-cache-missing"))return 3;
    state.cacheAvailable=state.ready=true;state.status="El catálogo no contiene cheats compatibles para esta versión.";header(&r);drawList(&r);if(!save("08-no-compatible-cheats"))return 3;
    state=fixture();state.liveChecked=false;state.liveDetail="No se pudo comprobar el estado actual del motor.";header(&r);drawList(&r);if(!save("09-state-unconfirmed"))return 3;
    state=fixture();state.busy=true;state.status="Comprobando el proceso y aplicando los cheats marcados...";header(&r);drawList(&r);if(!save("10-operation-busy"))return 3;
    state.busy=false;state.lastActionKnown=state.lastActionOk=true;state.lastAction="Los cheats marcados se habilitaron en el motor. Conserva los botones y condiciones del autor dentro del juego.";header(&r);drawResult(&r);if(!save("11-applied-result"))return 3;
    state.lastActionOk=false;state.lastAction="El juego o Build ID cambió desde la revisión. No se aplicaron los cheats. Busca o actualiza con X.";header(&r);drawResult(&r);if(!save("12-error-result"))return 3;
    state.lastActionOk=state.lastActionRemove=true;state.lastAction="Se retiraron los códigos añadidos por NinMagic y se recuperaron los estados anteriores registrados. Reinicia el juego si un valor ya cambió.";header(&r);drawResult(&r);if(!save("13-withdrawn-result"))return 3;
    state=fixture();header(&r);drawHelp(&r);if(!save("14-help"))return 3;
    state.game={};state.items.clear();state.ready=state.cacheAvailable=state.canApply=false;state.totalItems=0;state.status="No hay un juego real abierto para comprobar sus cheats.";header(&r);drawList(&r);if(!save("15-open-game"))return 3;
    state=fixture();state.items[0].name="Infinite Max Hearts Press ZR - Hold to refill health; release to stop. Player 1 only.";header(&r);drawDetails(&r);if(!save("16-long-conditions"))return 3;
    NinMagicOverlay overlay;tsl::Overlay::active=&overlay;NinMagicGui gui;unsigned checks=0;
    const auto check=[&](bool ok){++checks;if(!ok){std::fprintf(stderr,"Published overlay guard failed: %u\n",checks);std::exit(4);}};
    const auto press=[&](u64 keys){gui.handleInput(keys,0,{},{},{});};
    const auto visible=[&](const std::string&s){return std::find(r.visibleText.begin(),r.visibleText.end(),s)!=r.visibleText.end();};
    state=fixture();page=Page::List;message.clear();check(applyCalls==0&&removeCalls==0);
    check(!state.items[0].selected&&checkedState(state.items[0])==nc::CheatState::Enabled);press(HidNpadButton_A);check(toggleCalls==1&&toggledIndex==0&&state.items[0].selected&&applyCalls==0&&checkedState(state.items[0])==nc::CheatState::Enabled);press(HidNpadButton_A);check(!state.items[0].selected&&checkedState(state.items[0])==nc::CheatState::Enabled&&applyCalls==0);
    press(HidNpadButton_Y);check(page==Page::List&&applyCalls==0);press(HidNpadButton_A);press(HidNpadButton_Y);check(page==Page::ConfirmApply&&applyCalls==0);press(HidNpadButton_B|HidNpadButton_A);check(page==Page::List&&applyCalls==0);
    press(HidNpadButton_Y);state.canApply=false;press(HidNpadButton_A);check(page==Page::List&&applyCalls==0);state.canApply=true;press(HidNpadButton_Y);press(HidNpadButton_A);check(applyCalls==1&&awaitingResult&&state.busy);const auto priorToggle=toggleCalls,priorRefresh=refreshCalls;press(HidNpadButton_A|HidNpadButton_Y|HidNpadButton_X|HidNpadButton_L);check(applyCalls==1&&removeCalls==0&&toggleCalls==priorToggle&&refreshCalls==priorRefresh);
    overlay.closed=false;press(HidNpadButton_Plus);check(!overlay.closed);overlay.hidden=false;press(HidNpadButton_B);check(overlay.hidden&&state.busy);
    state.busy=false;state.lastActionKnown=state.lastActionOk=true;state.status=state.lastAction="Marcados habilitados.";gui.update();check(page==Page::Result&&!awaitingResult&&resultMessage==state.status);press(HidNpadButton_A);check(page==Page::Result&&applyCalls==1);press(HidNpadButton_B);check(page==Page::List);
    press(HidNpadButton_L);check(page==Page::ConfirmRemove&&removeCalls==0);press(HidNpadButton_B);check(removeCalls==0&&page==Page::List);press(HidNpadButton_L);press(HidNpadButton_A);check(removeCalls==1&&awaitingResult&&state.busy);state.busy=false;state.lastActionRemove=state.lastActionOk=state.lastActionKnown=true;state.status=state.lastAction="Retirada completada.";gui.update();check(page==Page::Result&&state.lastActionRemove);press(HidNpadButton_B);
    press(HidNpadButton_X);check(searchCalls==1&&refreshCalls==priorRefresh&&state.busy&&state.searching&&applyCalls==1&&removeCalls==1);state.busy=state.searching=false;gui.update();press(HidNpadButton_Down);check(moveCalls==1&&state.highlighted==1);press(HidNpadButton_R);check(page==Page::Details);press(HidNpadButton_A);check(applyCalls==1);press(HidNpadButton_B);press(HidNpadButton_Minus);check(page==Page::Help);press(HidNpadButton_A);check(applyCalls==1);press(HidNpadButton_B);
    const bool previousSide=rightSide;press(HidNpadButton_ZL);check(rightSide!=previousSide&&applyCalls==1&&removeCalls==1);
    state=fixture();state.items[0].index=37;state.highlighted=37;state.firstItem=37;state.totalItems=100;press(HidNpadButton_A);check(toggledIndex==37&&applyCalls==1);
    state=fixture();state.ready=state.cacheAvailable=state.canApply=false;state.items.clear();state.totalItems=0;press(HidNpadButton_A|HidNpadButton_Y);check(page==Page::List&&applyCalls==1);header(&r);drawList(&r);check(visible("BUSCA LOS CHEATS DE ESTE JUEGO"));
    state=fixture();state.liveChecked=false;check(checkedState(state.items[0])==nc::CheatState::Unknown);header(&r);drawList(&r);check(visible("ESTADO: SIN COMPROBAR")&&!visible("ON"));
    state=fixture();page=Page::List;state.lastActionKnown=state.lastActionOk=true;state.lastAction="Aplicación anterior conservada.";overlay.onShow();check(state.lastAction=="Aplicación anterior conservada."&&applyCalls==1);overlay.closed=false;press(HidNpadButton_Plus);check(overlay.closed&&cancelCalls==0);
    const std::string digits="1082130432";const int width=int(measure(&r,digits,24));check(fitLabel(&r,digits,24,width)==digits);const auto cropped=fitLabel(&r,"Munición y energía",20,100);check(nc::ui_text::validUtf8(cropped)&&measure(&r,cropped,20)<=100);const auto legacy=r.legacyLimitCalls;label(&r,digits,23,418,24,cyan);check(r.lastDrawn==digits&&r.legacyLimitCalls==legacy);check(measure(&r,stateLabel(nc::CheatState::Unknown),11)<=102);
    state=fixture();page=Page::List;resultKnown=false;const auto beforePendingRefresh=refreshCalls;press(HidNpadButton_L);press(HidNpadButton_A);overlay.onShow();check(awaitingResult&&state.busy&&refreshCalls==beforePendingRefresh);
    state.busy=false;state.status="No hay cheats propios que retirar.";state.error.clear();overlay.onShow();check(!awaitingResult&&page==Page::Result&&resultKnown&&resultOk&&resultRemove&&resultMessage==state.status&&!state.lastActionKnown&&refreshCalls==beforePendingRefresh);header(&r);drawResult(&r);check(visible("INFORME DE RETIRADA"));if(!save("17-neutral-first-withdrawal"))return 3;
    for(const bool previousOk:{false,true}){state=fixture();state.lastActionKnown=true;state.lastActionOk=previousOk;state.lastAction=previousOk?"Éxito anterior.":"Error anterior.";const auto history=state.lastAction;page=Page::List;press(HidNpadButton_L);press(HidNpadButton_A);state.busy=false;state.status="No hay cheats propios que retirar.";state.error.clear();gui.update();check(page==Page::Result&&resultOk&&resultMessage==state.status&&state.lastAction==history&&state.lastActionOk==previousOk);header(&r);drawResult(&r);check(visible("INFORME DE RETIRADA")&&!visible(history));}if(!save("18-neutral-with-history"))return 3;
    state=fixture();state.lastActionKnown=state.lastActionOk=true;state.lastAction="Éxito anterior.";page=Page::List;press(HidNpadButton_L);press(HidNpadButton_A);state.busy=false;state.error="Error actual de retirada.";state.status=state.error;gui.update();check(page==Page::Result&&!resultOk&&resultMessage==state.error&&state.lastAction=="Éxito anterior.");
    state=fixture();page=Page::List;message.clear();const auto beforeOnlineApply=applyCalls,beforeOnlineRemove=removeCalls,beforeOnlineRefresh=refreshCalls,beforeOnlineSearch=searchCalls,beforeOnlineToggle=toggleCalls;
    state.ready=state.cacheAvailable=state.canApply=false;state.items.clear();state.totalItems=0;press(HidNpadButton_X);check(searchCalls==beforeOnlineSearch+1&&refreshCalls==beforeOnlineRefresh&&state.busy&&state.searching&&applyCalls==beforeOnlineApply&&removeCalls==beforeOnlineRemove);header(&r);drawList(&r);check(visible("BUSCANDO CHEATS ONLINE"));if(!save("19-online-without-cache"))return 3;
    press(HidNpadButton_A|HidNpadButton_Y|HidNpadButton_L);check(applyCalls==beforeOnlineApply&&removeCalls==beforeOnlineRemove&&toggleCalls==beforeOnlineToggle);overlay.hidden=false;press(HidNpadButton_B);check(overlay.hidden&&state.busy&&state.searching);overlay.onShow();check(refreshCalls==beforeOnlineRefresh&&searchCalls==beforeOnlineSearch+1);const auto beforeCancel=cancelCalls;press(HidNpadButton_X);check(cancelCalls==beforeCancel+1&&applyCalls==beforeOnlineApply&&removeCalls==beforeOnlineRemove);
    state.busy=state.searching=false;state.error="Consulta cancelada. Puedes volver a intentarlo con X.";const auto beforeSearchFinish=refreshCalls;overlay.onShow();check(!awaitingSearch&&message.empty()&&refreshCalls==beforeSearchFinish&&page==Page::List);header(&r);drawList(&r);if(!save("22-search-cancelled"))return 3;
    state=fixture();state.busy=state.searching=true;state.status="Consultando fuentes online para el Build ID del juego abierto...";header(&r);drawList(&r);check(visible("BUSCANDO CHEATS ONLINE")&&visible("CONSULTANDO FUENTES ONLINE"));if(!save("20-online-with-saved-list"))return 3;
    state.busy=state.searching=false;state.error="Sin conexión. Se conserva la lista guardada para este juego y Build ID.";header(&r);drawList(&r);if(!save("21-offline-saved-list"))return 3;gui.update();check(page==Page::List&&applyCalls==beforeOnlineApply&&removeCalls==beforeOnlineRemove);
    const auto beforeLocalRefresh=refreshCalls,beforeLocalSearch=searchCalls;overlay.onShow();check(refreshCalls==beforeLocalRefresh+1&&searchCalls==beforeLocalSearch&&applyCalls==beforeOnlineApply);accept=false;press(HidNpadButton_X);check(searchCalls==beforeLocalSearch+1&&!state.busy&&applyCalls==beforeOnlineApply&&!message.empty());accept=true;
    state=fixture();state.ready=state.canApply=false;state.items.clear();state.totalItems=0;state.game.buildVerified=false;state.game.buildId.clear();state.game.fullBuildId.clear();state.game.running=false;state.error="No se pudo comprobar el Build ID de este juego.";message.clear();header(&r);drawList(&r);check(visible("BUILD ID SIN COMPROBAR")&&!visible("SIN CHEATS COMPATIBLES")&&!visible("JUEGO CERRADO"));if(!save("23-build-unverified"))return 3;
    std::printf("PASS published overlay UI: %u input/text guards; 23 mock previews generated\n",checks);return 0;
}

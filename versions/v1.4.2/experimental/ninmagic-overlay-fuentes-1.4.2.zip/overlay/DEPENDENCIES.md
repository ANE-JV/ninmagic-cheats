# Dependencies of the experimental overlay

The complete source of libtesla is vendored in `deps/libtesla`, including its
original example, README, copyright notices and GPL version 2 license. Upstream:
https://github.com/WerWolv/libtesla/tree/f766e9b607a05e9756843cbd62b3bfb98be1646c

Pinned commit: `f766e9b607a05e9756843cbd62b3bfb98be1646c` (2023-05-27).
Its bundled `stb_truetype.h` retains the upstream dual public-domain/MIT terms.
This dependency was chosen for its small, self-contained header implementation;
the existing loader and menu remain separately installed components.

Local change, 2026-10-26: add public static `Renderer::setLayerPos` in
`include/tesla.hpp`. It validates screen bounds and moves the existing VI layer
on the render thread, allowing a left or right panel without rebuilding it.
The rest of this dependency is the pinned upstream source.

Build tools used: devkitA64 GCC 16.1.0, libnx 4.12.0-1, the installed devkitPro
zlib. `tools/build-overlay.ps1` stages only local source/assets and builds the
overlay with section garbage collection; it neither installs dependencies nor
reads or writes a connected console. Scanner and native backend sources come
from this source package. Distribute the corresponding source package, including
this vendored dependency and its license, together with the overlay binary.

The scanner runs on its own thread when the panel is hidden. Returning to the
loader menu or loading another overlay unloads this executable: the worker is
cancelled and joined first. This is not a resident system module. Scanner
snapshots use `config/NinMagicCheats/scanner-overlay`, separate from the NRO.
The live-activation receipt is shared with the NRO so either frontend can undo
NinMagic activations. Do not operate both frontends simultaneously.

The default recent nx-ovlloader budget is 4 MiB shared between executable/data
and heap. This build is optimized for size and uses a 256 KiB scanner stack,
64 KiB I/O chunks and at most 20,000 in-memory candidates; larger result pools
are streamed to the SD card. Actual compatibility and remaining heap still
depend on the installed loader. A successful build is not a console crash test.

Primary lifecycle references:
- https://github.com/WerWolv/libtesla/blob/f766e9b607a05e9756843cbd62b3bfb98be1646c/include/tesla.hpp
- https://github.com/ppkantorski/nx-ovlloader/blob/v2.0.2/source/main.c
- https://github.com/ppkantorski/Ultrahand-Overlay/releases/tag/v2.5.3

The maintained loader v2.0.2 uses a 4 MiB default on HOS 21 and later. Ultrahand
v2.5.3 was built with the same libnx release used here. Neither statement is a
claim that this new overlay has already been tested on firmware 23.

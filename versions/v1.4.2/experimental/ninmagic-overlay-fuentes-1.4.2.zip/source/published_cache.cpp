#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "published_cache.hpp"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __SWITCH__
#include <switch.h>
#endif
namespace nc { namespace {
using Bytes=std::vector<uint8_t>;
#ifdef NC_PUBLISHED_CACHE_TEST
std::function<bool(const std::string&,const std::string&)> publishedRenameFailure;
#endif
int cacheRename(const std::string&from,const std::string&to){
#ifdef NC_PUBLISHED_CACHE_TEST
    if(publishedRenameFailure&&publishedRenameFailure(from,to)){errno=EIO;return -1;}
#endif
    return std::rename(from.c_str(),to.c_str());
}
std::string base(){
#ifdef NC_PUBLISHED_CACHE_TEST
    const char*p=std::getenv("NC_PUBLISHED_CACHE_ROOT");return p?p:"";
#else
    return "sdmc:";
#endif
}
std::string upper(std::string s){for(char&c:s)if(c>='a'&&c<='f')c=char(c-'a'+'A');return s;}
bool identity(const Game&g){const auto b=upper(g.fullBuildId);return g.id>=0x0100000000010000ULL&&g.buildVerified&&b.size()==64&&b.find_first_not_of("0123456789ABCDEF")==std::string::npos&&b.substr(0,16)!=std::string(16,'0')&&b.substr(0,16)!=std::string(16,'F')&&upper(g.buildId)==b.substr(0,16);}
bool text(const std::string&s,size_t limit,bool empty=true){return (empty||!s.empty())&&s.size()<=limit&&std::none_of(s.begin(),s.end(),[](unsigned char c){return c<32||c==127;});}
bool directories(bool create,bool&present,std::string&error){present=true;const auto root=base();if(root.empty()){error="No se ha configurado la caché de cheats publicados.";return false;}
#ifdef NC_PUBLISHED_CACHE_TEST
    struct stat baseStat{};if(lstat(root.c_str(),&baseStat)==0&&S_ISLNK(baseStat.st_mode)){error="La raíz de la caché es un enlace.";return false;}
#endif
    for(const auto&p:std::array<std::string,4>{root+"/",root+"/config",root+"/config/NinMagicCheats",root+"/config/NinMagicCheats/published"}){struct stat st{};if(lstat(p.c_str(),&st)!=0){if(errno==ENOENT&&!create){present=false;return true;}if(errno!=ENOENT||p==root+"/"||mkdir(p.c_str(),0700)!=0||lstat(p.c_str(),&st)!=0){error="No se pudo abrir la carpeta de cheats publicados.";return false;}}if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)){error="La caché contiene una carpeta no admitida.";return false;}}return true;}
std::string path(const Game&g){return base()+"/config/NinMagicCheats/published/"+hexId(g.id)+"-"+upper(g.fullBuildId)+".bin";}
bool regular(const std::string&p,bool&exists){struct stat st{};exists=false;if(lstat(p.c_str(),&st)!=0)return errno==ENOENT;exists=true;return S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode);}
bool syncDevice(){
#ifdef __SWITCH__
    return R_SUCCEEDED(fsdevCommitDevice("sdmc"));
#else
    return true;
#endif
}
void u32(Bytes&b,uint32_t x){for(unsigned n=0;n<4;++n)b.push_back(uint8_t(x>>(8*n)));}
void u64(Bytes&b,uint64_t x){for(unsigned n=0;n<8;++n)b.push_back(uint8_t(x>>(8*n)));}
void str(Bytes&b,const std::string&s){u32(b,uint32_t(s.size()));b.insert(b.end(),s.begin(),s.end());}
uint32_t number(const uint8_t*p){uint32_t x=0;for(unsigned n=0;n<4;++n)x|=uint32_t(p[n])<<(8*n);return x;}
struct Reader {const Bytes&b;size_t at=0;bool bytes(void*p,size_t n){if(n>b.size()-at)return false;std::memcpy(p,b.data()+at,n);at+=n;return true;}bool get32(uint32_t&v){uint8_t p[4];if(!bytes(p,4))return false;v=number(p);return true;}bool get64(uint64_t&v){uint8_t p[8];if(!bytes(p,8))return false;v=0;for(unsigned n=0;n<8;++n)v|=uint64_t(p[n])<<(8*n);return true;}bool string(std::string&s,size_t max,bool empty=true){uint32_t n=0;if(!get32(n)||n>max||n>b.size()-at)return false;s.assign(reinterpret_cast<const char*>(b.data()+at),n);at+=n;return text(s,max,empty);}};
bool published(const Cheat&c){return text(c.name,63,false)&&c.name.find_first_of("[]{}") ==std::string::npos&&text(c.source,256)&&text(c.group,256)&&c.source.find("NinMagic Scanner")==std::string::npos&&c.group.find("NinMagicScan:")!=0&&!c.opcodes.empty()&&c.opcodes.size()<=256&&c.categories&&!(c.categories&~15u);}
bool validPack(const Pack&p,std::string&error){if(!identity(p.game)||p.sessionOnly||p.sessionBinding.pid||p.sessionBinding.title||p.sessionBinding.mainBase||p.sessionBinding.mainSize||p.sessionBinding.heapBase||p.sessionBinding.heapSize||p.sessionBinding.aliasBase||p.sessionBinding.aliasSize||!p.sessionBinding.fullBuildId.empty()){error="Solo se pueden guardar cheats publicados de un juego con Build ID completo verificado.";return false;}if((!p.compatible&&!p.cheats.empty())||p.cheats.size()>PublishedCacheMaxEntries||!text(p.game.name,256)||!text(p.game.author,128)||!text(p.game.version,64)){error="La lista publicada no es compatible o supera el límite de la caché.";return false;}size_t words=0;for(const auto&c:p.cheats){if(!published(c)||c.opcodes.size()>PublishedCacheMaxWords-words){error="La lista publicada contiene una definición no admitida o demasiado grande.";return false;}words+=c.opcodes.size();}return true;}
bool decode(Bytes data,const Game&game,Pack&out){if(data.size()<100||data.size()>PublishedCacheMaxBytes)return false;const auto crc=number(data.data()+data.size()-4);data.resize(data.size()-4);if(crc32(0,data.data(),uInt(data.size()))!=crc)return false;Reader r{data};char magic[8],bid[64];uint32_t version=0,flags=0,count=0,words=0,versionKnown=0;uint64_t title=0;Pack p;
    if(!r.bytes(magic,8)||std::memcmp(magic,"NMCPC001",8)||!r.get32(version)||version!=1||!r.get32(flags)||flags>1||!r.get64(title)||!r.bytes(bid,64)||title!=game.id||std::string(bid,64)!=upper(game.fullBuildId))return false;
    Game cached;cached.id=title;cached.buildVerified=true;cached.fullBuildId.assign(bid,64);cached.buildId=cached.fullBuildId.substr(0,16);
    if(!r.string(cached.name,256)||!r.string(cached.author,128)||!r.string(cached.version,64)||!r.get32(cached.contentVersion)||!r.get32(versionKnown)||versionKnown>1||!r.get32(count)||count>PublishedCacheMaxEntries||!r.get32(words)||words>PublishedCacheMaxWords||(!flags&&count))return false;
    p.game=game;if(p.game.name.empty())p.game.name=cached.name;if(p.game.author.empty())p.game.author=cached.author;if(p.game.version.empty())p.game.version=cached.version;p.compatible=flags;p.cheats.reserve(count);size_t total=0;
    for(uint32_t i=0;i<count;++i){Cheat c;uint32_t master=0,n=0;if(!r.string(c.name,63,false)||!r.string(c.source,256)||!r.string(c.group,256)||!r.get32(c.categories)||!r.get32(master)||master>1||!r.get32(n)||!n||n>256||n>PublishedCacheMaxWords-total)return false;c.master=master;c.opcodes.reserve(n);for(uint32_t j=0;j<n;++j){uint32_t x=0;if(!r.get32(x))return false;c.opcodes.push_back(x);}total+=n;if(!published(c))return false;p.cheats.push_back(std::move(c));}
    if(r.at!=data.size()||total!=words)return false;
    p.detail=p.cheats.empty()?"No hay opciones publicadas compatibles en la última consulta de NinMagic.":"Cheats publicados preparados por NinMagic para este Build ID.";out=std::move(p);return true;
}
}}
namespace nc {
bool savePublishedCache(const Pack&pack,std::string&error){error.clear();if(!validPack(pack,error))return false;Bytes data={'N','M','C','P','C','0','0','1'};u32(data,1);u32(data,pack.compatible?1:0);u64(data,pack.game.id);const auto bid=upper(pack.game.fullBuildId);data.insert(data.end(),bid.begin(),bid.end());str(data,pack.game.name);str(data,pack.game.author);str(data,pack.game.version);u32(data,pack.game.contentVersion);u32(data,pack.game.versionKnown?1:0);u32(data,uint32_t(pack.cheats.size()));size_t words=0;for(const auto&c:pack.cheats)words+=c.opcodes.size();u32(data,uint32_t(words));for(const auto&c:pack.cheats){str(data,c.name);str(data,c.source);str(data,c.group);u32(data,c.categories);u32(data,c.master?1:0);u32(data,uint32_t(c.opcodes.size()));for(auto x:c.opcodes)u32(data,x);}u32(data,uint32_t(crc32(0,data.data(),uInt(data.size()))));if(data.size()>PublishedCacheMaxBytes){error="La caché de este juego supera 256 KiB. Usa la aplicación NRO.";return false;}
    bool present=false;if(!directories(true,present,error))return false;const auto target=path(pack.game),pending=target+".pending",previous=target+".previous";bool had=false,exists=false;if(!regular(target,had)||!regular(pending,exists)||!regular(previous,exists)){error="La ruta de la caché no es un archivo regular.";return false;}int flags=O_CREAT|O_TRUNC|O_WRONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(pending.c_str(),flags,0600);if(fd<0){error="No se pudo crear la caché temporal.";return false;}FILE*f=fdopen(fd,"wb");if(!f){close(fd);error="No se pudo abrir la caché temporal.";return false;}bool ok=fwrite(data.data(),1,data.size(),f)==data.size();if(fflush(f)!=0||fsync(fileno(f))!=0)ok=false;if(fclose(f)!=0)ok=false;if(!ok||!syncDevice()){unlink(pending.c_str());error="No se pudo guardar por completo la caché; se conserva la anterior.";return false;}
    bool currentVerified=false;
    if(had){Pack checked;std::string ignored;currentVerified=loadPublishedCache(pack.game,checked,ignored);}
    if(had&&currentVerified){
        if(exists&&unlink(previous.c_str())!=0){error="No se pudo preparar el respaldo de la caché.";return false;}
        if(cacheRename(target,previous)!=0){error="No se pudo conservar la caché anterior.";return false;}
    }else if(had&&unlink(target.c_str())!=0){error="No se pudo apartar la caché dañada.";return false;}
    // A previous-only file is the last recovery copy. A corrupt current file
    // must never replace it, even when promotion of the new file fails.
    if(cacheRename(pending,target)!=0){if(had&&currentVerified)cacheRename(previous,target);error="No se pudo activar la caché nueva. Abre NinMagic de nuevo.";return false;}
    if(!syncDevice()){error="La caché nueva no pudo confirmarse en la microSD. Abre NinMagic de nuevo.";return false;}return true;
}
bool loadPublishedCache(const Game&game,Pack&pack,std::string&error,uint64_t*stamp){error.clear();if(!identity(game)){error="No se verificó el Build ID completo del juego abierto.";return false;}bool present=false;if(!directories(false,present,error))return false;if(!present){error="Abre NinMagic, consulta los cheats de este juego y vuelve al overlay.";return false;}const auto target=path(game);bool exists=false;if(!regular(target,exists)||!exists){error="No hay una caché válida para este juego y Build ID. Ábrelo en NinMagic.";return false;}int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(target.c_str(),flags);if(fd<0){error="No se pudo abrir la caché de cheats publicados.";return false;}struct stat st{};if(fstat(fd,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<4||uint64_t(st.st_size)>PublishedCacheMaxBytes){close(fd);error="La caché tiene un tamaño no admitido. Actualízala desde NinMagic.";return false;}Bytes data(size_t(st.st_size));FILE*f=fdopen(fd,"rb");if(!f){close(fd);error="No se pudo leer la caché.";return false;}const bool ok=fread(data.data(),1,data.size(),f)==data.size()&&fgetc(f)==EOF&&!ferror(f);fclose(f);const auto value=(uint64_t(data.size())<<32)|number(data.data()+data.size()-4);if(!ok||!decode(std::move(data),game,pack)){error="La caché está incompleta, alterada o pertenece a otro Build ID. Actualízala desde NinMagic.";return false;}if(stamp)*stamp=value;return true;
}
bool checkPublishedCache(const Game&game,uint64_t stamp,std::string&error){error.clear();bool present=false,exists=false;if(!identity(game)||!stamp||!directories(false,present,error)||!present||!regular(path(game),exists)||!exists){error="La caché publicada ya no está disponible. Pulsa detectar o abre NinMagic.";return false;}int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(path(game).c_str(),flags);if(fd<0){error="No se pudo verificar la caché.";return false;}struct stat st{};if(fstat(fd,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<4||uint64_t(st.st_size)!=(stamp>>32)){close(fd);error="La lista publicada cambió. Pulsa detectar antes de aplicarla.";return false;}FILE*f=fdopen(fd,"rb");if(!f){close(fd);return false;}std::array<uint8_t,4096>buffer{};uint64_t left=uint64_t(st.st_size)-4;uint32_t crc=0;bool ok=true;while(left){const auto n=size_t(std::min<uint64_t>(left,buffer.size()));if(fread(buffer.data(),1,n,f)!=n){ok=false;break;}crc=uint32_t(crc32(crc,buffer.data(),uInt(n)));left-=n;}uint8_t tail[4]{};ok=ok&&fread(tail,1,4,f)==4&&fgetc(f)==EOF&&!ferror(f)&&crc==number(tail)&&crc==uint32_t(stamp);fclose(f);if(!ok)error="La lista publicada cambió o está alterada. Pulsa detectar antes de aplicarla.";return ok;}
}

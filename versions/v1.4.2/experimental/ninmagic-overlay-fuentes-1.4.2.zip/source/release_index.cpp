#include "release_index.hpp"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <set>

namespace nc {
namespace {
class Reader {
    const std::string &text;size_t at=0;
    void ws(){while(at<text.size()&&std::isspace(static_cast<unsigned char>(text[at])))++at;}
    bool character(char c){ws();if(at==text.size()||text[at]!=c)return false;++at;return true;}
    bool literal(const char *s){ws();size_t n=std::char_traits<char>::length(s);if(text.compare(at,n,s))return false;at+=n;return true;}
    bool number(uint64_t &value){ws();size_t start=at;value=0;while(at<text.size()&&text[at]>='0'&&text[at]<='9'){unsigned n=text[at++]-'0';if(value>(UINT64_MAX-n)/10)return false;value=value*10+n;}return at>start;}
    bool string(std::string &value){
        value.clear();if(!character('"'))return false;
        while(at<text.size()){unsigned char c=text[at++];if(c=='"')return true;if(c<32)return false;
            if(c=='\\'){if(at==text.size())return false;char e=text[at++];if(e=='"'||e=='\\'||e=='/')value+=e;else if(e=='b')value+='\b';else if(e=='f')value+='\f';else if(e=='n')value+='\n';else if(e=='r')value+='\r';else if(e=='t')value+='\t';else if(e=='u'){
                uint32_t code=0;for(unsigned n=0;n<4;++n){if(at==text.size()||!std::isxdigit(static_cast<unsigned char>(text[at])))return false;unsigned char h=text[at++];code=(code<<4)|(h<='9'?h-'0':std::tolower(h)-'a'+10);}if(code<128)value+=char(code);else if(code<2048){value+=char(0xc0|(code>>6));value+=char(0x80|(code&63));}else{value+=char(0xe0|(code>>12));value+=char(0x80|((code>>6)&63));value+=char(0x80|(code&63));}
            }else return false;}else value+=char(c);
            if(value.size()>2*1024*1024)return false;
        }return false;
    }
    bool skip(unsigned depth=0){
        if(depth>32)return false;
        ws();if(at==text.size())return false;
        if(text[at]=='"'){std::string s;return string(s);}if(text[at]=='{'){++at;if(character('}'))return true;do{std::string key;if(!string(key)||!character(':')||!skip(depth+1))return false;if(character('}'))return true;}while(character(','));return false;}
        if(text[at]=='['){++at;if(character(']'))return true;do{if(!skip(depth+1))return false;if(character(']'))return true;}while(character(','));return false;}
        if(text[at]=='t')return literal("true");
        if(text[at]=='f')return literal("false");
        if(text[at]=='n')return literal("null");
        uint64_t ignored=0;return number(ignored);
    }
    bool asset(ReleaseAsset &asset){
        if(!character('{'))return false;
        std::set<std::string> keys;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="id"){if(!number(asset.id))return false;}else if(key=="size"){if(!number(asset.size))return false;}
            else if(key=="name"){if(!string(asset.name))return false;}else if(key=="browser_download_url"){if(!string(asset.url))return false;}
            else if(key=="updated_at"){if(!string(asset.updated))return false;}else if(key=="digest"){if(!literal("null")&&!string(asset.digest))return false;}else if(!skip())return false;
            if(character('}'))break;
            if(!character(','))return false;
        }while(true);
        return asset.id&&asset.name.size()<=128&&asset.url.size()<=2048&&asset.updated.size()<=64;
    }
    bool release(CheatRelease &release){
        if(!character('{'))return false;
        std::set<std::string> keys;bool draft=false;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="id"){if(!number(release.id))return false;}else if(key=="tag_name"){if(!string(release.tag))return false;}
            else if(key=="published_at"){if(!literal("null")&&!string(release.published))return false;}
            else if(key=="draft"){if(literal("true"))draft=true;else if(!literal("false"))return false;}
            else if(key=="assets") {if(!character('['))return false;if(!character(']')){do{ReleaseAsset one;if(!asset(one))return false;if(one.name=="contents.zip"||one.name=="contents_complete.zip")release.assets.push_back(std::move(one));if(release.assets.size()>8)return false;if(character(']'))break;if(!character(','))return false;}while(true);}}
            else if(!skip())return false;
            if(character('}'))break;
            if(!character(','))return false;
        }while(true);
        if(draft)release.published.clear();
        return release.id&&release.tag.size()<=256&&release.published.size()<=64;
    }
public:
    explicit Reader(const std::string &value):text(value){}
    bool parse(std::vector<CheatRelease> &releases){
        if(!character('['))return false;
        if(!character(']')){do{CheatRelease one;if(!release(one))return false;if(!one.published.empty())releases.push_back(std::move(one));if(releases.size()>100)return false;if(character(']'))break;if(!character(','))return false;}while(true);}
        ws();return at==text.size();
    }
};
}
bool parseCheatReleases(const std::string &json,std::vector<CheatRelease> &releases,std::string &error){
    releases.clear();error.clear();if(json.empty()||json.size()>8*1024*1024||!Reader(json).parse(releases)){releases.clear();error="El índice de lanzamientos no es válido o supera sus límites.";return false;}
    for(const auto &release:releases){std::set<std::string> names;for(const auto &asset:release.assets)if(!names.insert(asset.name).second||!asset.size||asset.url.rfind("https://github.com/HamletDuFromage/switch-cheats-db/releases/download/",0)!=0){releases.clear();error="Un archivo del índice de lanzamientos no es válido.";return false;}}
    return true;
}
std::string cheatReleaseSignature(const CheatRelease &release){
    uint64_t hash=14695981039346656037ULL;auto add=[&](const std::string &s){for(unsigned char c:s){hash^=c;hash*=1099511628211ULL;}hash^=0;hash*=1099511628211ULL;};
    add(std::to_string(release.id));add(release.published);auto assets=release.assets;std::sort(assets.begin(),assets.end(),[](const auto &a,const auto &b){return a.name<b.name;});
    for(const auto &asset:assets){add(asset.name);add(std::to_string(asset.id));add(std::to_string(asset.size));add(asset.updated);add(asset.digest);add(asset.url);}
    char result[17];std::snprintf(result,sizeof(result),"%016llx",static_cast<unsigned long long>(hash));return result;
}
}

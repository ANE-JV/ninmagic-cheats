#include "options.hpp"
#include <algorithm>
#include <cctype>
#include <set>

namespace nc {
namespace {
enum class Effect {
    Health,MaxHealth,StableHealth,Lives,MaxLives,Ammo,Reload,Invincible,God,
    Stamina,MP,Magic,SP,Energy,Items,Inventory,Money,MaxMoney,Gold,
    Fps60,Fps30,Fps120,Fps90,Fps,Resolution,Graphics,Speed,Experience,Damage,None
};
struct Rule {std::vector<std::string> words;const char *label;Effect effect;};
struct Word {size_t first=0,last=0;std::string value;};
struct Match {size_t first=0,last=0;const Rule *rule=nullptr;};
struct Hotkey {std::string label,effect,button;uint32_t mask=0,write=0,value=0;unsigned order=0;};
bool namedPrefix(const std::string &name,const std::string &prefix,std::string &suffix) {
    if(name.size()<prefix.size())return false;
    for(size_t i=0;i<prefix.size();++i)if(std::tolower(static_cast<unsigned char>(name[i]))!=std::tolower(static_cast<unsigned char>(prefix[i])))return false;
    if(name.size()>prefix.size()&&std::isalnum(static_cast<unsigned char>(name[prefix.size()])))return false;
    suffix=name.substr(prefix.size());return true;
}
Hotkey namedHotkey(const Cheat &cheat) {
    std::string suffix;
    if(namedPrefix(cheat.name,"Infinite / Max Hearts Press ZR",suffix))return {"Corazones infinitos/máximos · pulsar ZR"+suffix,"Corazones (pulsar ZR)","ZR",0x200,0x01000000,0x50,static_cast<unsigned>(Effect::Health)};
    if(namedPrefix(cheat.name,"9999 Rupees Press L",suffix))return {"9999 rupias · pulsar L"+suffix,"9999 rupias (pulsar L)","L",0x40,0x02000000,0x270f,static_cast<unsigned>(Effect::Money)};
    return {};
}
bool simpleHeldWrite(const Cheat &cheat,const Hotkey &hotkey) {
    return cheat.opcodes.size()==5&&cheat.opcodes[0]==(0x80000000u|hotkey.mask)&&cheat.opcodes[1]==hotkey.write&&cheat.opcodes[3]==hotkey.value&&cheat.opcodes[4]==0x20000000;
}
const std::vector<Rule> &rules() {
    static const std::vector<Rule> value={
        {{"hp","is","not","reduced"},"La vida no se reduce",Effect::StableHealth},
        {{"health","does","not","decrease"},"La vida no disminuye",Effect::StableHealth},
        {{"infinite","health"},"Vida infinita",Effect::Health},{{"infinite","hp"},"Vida infinita",Effect::Health},
        {{"inf","health"},"Vida infinita",Effect::Health},{{"inf","hp"},"Vida infinita",Effect::Health},
        {{"unlimited","health"},"Vida infinita",Effect::Health},{{"unlimited","hp"},"Vida infinita",Effect::Health},
        {{"hp","inf"},"Vida infinita",Effect::Health},{{"health","inf"},"Vida infinita",Effect::Health},
        {{"hp","infinite"},"Vida infinita",Effect::Health},{{"health","infinite"},"Vida infinita",Effect::Health},
        {{"infhp"},"Vida infinita",Effect::Health},{{"infinitehp"},"Vida infinita",Effect::Health},
        {{"vida","infinita"},"Vida infinita",Effect::Health},
        {{"infinite","life"},"Vida infinita",Effect::Health},{{"inf","life"},"Vida infinita",Effect::Health},
        {{"max","hp"},"Vida máxima",Effect::MaxHealth},{{"hp","max"},"Vida máxima",Effect::MaxHealth},
        {{"max","health"},"Vida máxima",Effect::MaxHealth},{{"maximum","health"},"Vida máxima",Effect::MaxHealth},
        {{"vida","maxima"},"Vida máxima",Effect::MaxHealth},
        {{"infinite","lives"},"Vidas infinitas",Effect::Lives},{{"inf","lives"},"Vidas infinitas",Effect::Lives},
        {{"unlimited","lives"},"Vidas infinitas",Effect::Lives},{{"vidas","infinitas"},"Vidas infinitas",Effect::Lives},
        {{"max","lives"},"Vidas máximas",Effect::MaxLives},
        {{"infinite","ammunition"},"Munición infinita",Effect::Ammo},{{"infinite","ammo"},"Munición infinita",Effect::Ammo},
        {{"inf","ammo"},"Munición infinita",Effect::Ammo},{{"inf","ammunition"},"Munición infinita",Effect::Ammo},
        {{"unlimited","ammo"},"Munición infinita",Effect::Ammo},{{"unlimited","ammunition"},"Munición infinita",Effect::Ammo},
        {{"infinite","bullets"},"Balas infinitas",Effect::Ammo},{{"infammo"},"Munición infinita",Effect::Ammo},
        {{"ammo","infinite"},"Munición infinita",Effect::Ammo},{{"ammo","inf"},"Munición infinita",Effect::Ammo},
        {{"municion","infinita"},"Munición infinita",Effect::Ammo},
        {{"no","reload"},"Sin recargar",Effect::Reload},{{"sin","recargar"},"Sin recargar",Effect::Reload},
        {{"invincibility"},"Invencibilidad",Effect::Invincible},{{"invincible"},"Invencibilidad",Effect::Invincible},
        {{"invulnerability"},"Invulnerabilidad",Effect::Invincible},{{"invulnerable"},"Invulnerabilidad",Effect::Invincible},
        {{"invencibilidad"},"Invencibilidad",Effect::Invincible},{{"invulnerabilidad"},"Invulnerabilidad",Effect::Invincible},
        {{"god","mode"},"Modo dios",Effect::God},{{"modo","dios"},"Modo dios",Effect::God},
        {{"infinite","stamina"},"Resistencia infinita",Effect::Stamina},{{"inf","stamina"},"Resistencia infinita",Effect::Stamina},
        {{"resistencia","infinita"},"Resistencia infinita",Effect::Stamina},
        {{"infinite","mp"},"MP infinitos",Effect::MP},{{"inf","mp"},"MP infinitos",Effect::MP},
        {{"mp","inf"},"MP infinitos",Effect::MP},{{"mp","infinitos"},"MP infinitos",Effect::MP},
        {{"infinite","magic"},"Magia infinita",Effect::Magic},{{"inf","magic"},"Magia infinita",Effect::Magic},
        {{"infinite","sp"},"SP infinitos",Effect::SP},{{"inf","sp"},"SP infinitos",Effect::SP},
        {{"infinite","energy"},"Energía infinita",Effect::Energy},{{"inf","energy"},"Energía infinita",Effect::Energy},
        {{"infinite","items"},"Objetos infinitos",Effect::Items},{{"inf","items"},"Objetos infinitos",Effect::Items},
        {{"unlimited","inventory"},"Inventario ilimitado",Effect::Inventory},
        {{"infinite","money"},"Dinero infinito",Effect::Money},{{"inf","money"},"Dinero infinito",Effect::Money},
        {{"unlimited","money"},"Dinero infinito",Effect::Money},{{"max","money"},"Dinero máximo",Effect::MaxMoney},
        {{"infinite","gold"},"Oro infinito",Effect::Gold},{{"inf","gold"},"Oro infinito",Effect::Gold},
        {{"60","fps"},"60 FPS",Effect::Fps60},{{"60fps"},"60 FPS",Effect::Fps60},
        {{"30","fps"},"30 FPS",Effect::Fps30},{{"30fps"},"30 FPS",Effect::Fps30},
        {{"120","fps"},"120 FPS",Effect::Fps120},{{"120fps"},"120 FPS",Effect::Fps120},
        {{"90","fps"},"90 FPS",Effect::Fps90},{{"90fps"},"90 FPS",Effect::Fps90},
        {{"uncap","fps"},"Deslimitar FPS",Effect::Fps},{{"unlocked","framerate"},"Framerate sin límite",Effect::Fps},
        {{"framerate"},"Framerate",Effect::Fps},{{"fps"},"FPS",Effect::Fps},
        {{"dynamic","resolution"},"Resolución dinámica",Effect::Resolution},{{"render","scale"},"Escala de renderizado",Effect::Resolution},
        {{"resolution"},"Resolución",Effect::Resolution},{{"resolucion"},"Resolución",Effect::Resolution},{{"drs"},"DRS",Effect::Resolution},
        {{"disable","bloom"},"Desactivar bloom",Effect::Graphics},{{"enable","bloom"},"Activar bloom",Effect::Graphics},
        {{"disable","shadows"},"Desactivar sombras",Effect::Graphics},{{"enable","shadows"},"Activar sombras",Effect::Graphics},
        {{"disable","motion","blur"},"Desactivar desenfoque de movimiento",Effect::Graphics},
        {{"motion","blur"},"Desenfoque de movimiento",Effect::Graphics},{{"ambient","occlusion"},"Oclusión ambiental",Effect::Graphics},
        {{"depth","of","field"},"Profundidad de campo",Effect::Graphics},{{"anti","aliasing"},"Suavizado de bordes",Effect::Graphics},
        {{"graphics"},"Gráficos",Effect::Graphics},{{"graficos"},"Gráficos",Effect::Graphics},
        {{"shadows"},"Sombras",Effect::Graphics},{{"bloom"},"Bloom",Effect::Graphics},{{"fxaa"},"FXAA",Effect::Graphics},
        {{"game","speed"},"Velocidad del juego",Effect::Speed},
        {{"exp","multiplier"},"Multiplicador de experiencia",Effect::Experience},{{"experience","multiplier"},"Multiplicador de experiencia",Effect::Experience},
        {{"no","damage"},"Sin daño",Effect::Damage},
        {{"disable"},"Desactivar",Effect::None},{{"enable"},"Activar",Effect::None},{{"press"},"pulsar",Effect::None}
    };
    return value;
}
char folded(unsigned char next) {
    switch(next){case 0x81:case 0xa1:return 'a';case 0x89:case 0xa9:return 'e';case 0x8d:case 0xad:return 'i';case 0x93:case 0xb3:return 'o';case 0x9a:case 0xba:case 0x9c:case 0xbc:return 'u';case 0x91:case 0xb1:return 'n';default:return 0;}
}
std::vector<Word> words(const std::string &name) {
    std::vector<Word> result;Word word;bool active=false;
    auto finish=[&](){if(active){result.push_back(word);word={};active=false;}};
    for(size_t p=0;p<name.size();) {
        unsigned char c=name[p];char value=0;size_t count=1;
        if(c<128&&std::isalnum(c))value=char(std::tolower(c));
        else if(c==0xc3&&p+1<name.size()){value=folded(static_cast<unsigned char>(name[p+1]));count=2;}
        if(value){if(!active){word.first=p;active=true;}word.value+=value;word.last=p+count;p+=count;continue;}
        finish();
        if(p+2<name.size()&&name.compare(p,3,"\xe2\x88\x9e")==0){result.push_back({p,p+3,"inf"});p+=3;}else ++p;
    }
    finish();return result;
}
bool gap(const std::string &name,size_t a,size_t b) {
    if(b<a||b-a>8)return false;
    for(size_t p=a;p<b;++p)if(name[p]!=' '&&name[p]!='\t'&&name[p]!='.'&&name[p]!='_'&&name[p]!='-')return false;
    return true;
}
std::vector<Match> matches(const std::string &name,const std::vector<Word> &tokens) {
    std::vector<Match> found;
    for(size_t p=0;p<tokens.size();) {
        const Rule *best=nullptr;
        for(const auto &rule:rules()) {
            if(rule.words.size()>tokens.size()-p||(best&&rule.words.size()<=best->words.size()))continue;
            bool same=true;
            for(size_t n=0;same&&n<rule.words.size();++n)same=tokens[p+n].value==rule.words[n]&&(n==0||gap(name,tokens[p+n-1].last,tokens[p+n].first));
            if(same)best=&rule;
        }
        if(best){found.push_back({p,p+best->words.size()-1,best});p+=best->words.size();}else ++p;
    }
    return found;
}
bool has(const std::vector<Word> &tokens,const std::string &value){return std::any_of(tokens.begin(),tokens.end(),[&](const Word &w){return w.value==value;});}
bool turnedOff(const std::vector<Word> &tokens,const Match &match) {
    // OFF immediately around a named effect is a separate selectable reset
    // option. Do not advertise it as an available infinite-health ON code.
    auto off=[](const std::string &s){return s=="off"||s=="disable"||s=="disabled"||s=="no"||s=="desactivado"||s=="desactivar";};
    return (match.first>0&&off(tokens[match.first-1].value))||(match.last+1<tokens.size()&&off(tokens[match.last+1].value));
}
std::string effectName(Effect value) {
    switch(value) {
    case Effect::Health:return "Vida infinita";case Effect::MaxHealth:return "Vida máxima";case Effect::StableHealth:return "Vida que no se reduce";
    case Effect::Lives:return "Vidas infinitas";case Effect::MaxLives:return "Vidas máximas";case Effect::Ammo:return "Munición infinita";
    case Effect::Reload:return "Sin recargar";case Effect::Invincible:return "Invencibilidad";case Effect::God:return "Modo dios";
    case Effect::Stamina:return "Resistencia infinita";case Effect::MP:return "MP infinitos";case Effect::Magic:return "Magia infinita";
    case Effect::SP:return "SP infinitos";case Effect::Energy:return "Energía infinita";case Effect::Items:return "Objetos infinitos";
    case Effect::Inventory:return "Inventario ilimitado";case Effect::Money:return "Dinero infinito";case Effect::MaxMoney:return "Dinero máximo";case Effect::Gold:return "Oro infinito";
    case Effect::Fps60:return "60 FPS";case Effect::Fps30:return "30 FPS";case Effect::Fps120:return "120 FPS";case Effect::Fps90:return "90 FPS";case Effect::Fps:return "FPS";
    case Effect::Resolution:return "Resolución";case Effect::Graphics:return "Gráficos";case Effect::Speed:return "Velocidad del juego";case Effect::Experience:return "Experiencia";case Effect::Damage:return "Sin daño";
    case Effect::None:return {};
    }
    return {};
}
bool resolutionValue(const std::string &value) {
    if(value.size()>=4&&value.size()<=5&&value.back()=='p')return std::all_of(value.begin(),value.end()-1,[](unsigned char c){return c>='0'&&c<='9';});
    auto x=value.find('x');if(x<3||x>4||x==std::string::npos||value.size()-x-1<3||value.size()-x-1>4)return false;
    return std::all_of(value.begin(),value.begin()+x,[](unsigned char c){return c>='0'&&c<='9';})&&std::all_of(value.begin()+x+1,value.end(),[](unsigned char c){return c>='0'&&c<='9';});
}
}
std::string cheatLabel(const Cheat &cheat) {
    if(cheat.name.empty())return "Opción sin nombre";
    if(cheat.master)return cheat.name;
    const auto hotkey=namedHotkey(cheat);if(!hotkey.label.empty())return hotkey.label;
    const auto tokens=words(cheat.name);const auto found=matches(cheat.name,tokens);std::string label;size_t copied=0;
    for(const auto &match:found){const auto &first=tokens[match.first],&last=tokens[match.last];label+=cheat.name.substr(copied,first.first-copied);label+=match.rule->label;copied=last.last;}
    label+=cheat.name.substr(copied);return label;
}
std::string explainCheat(const Cheat &cheat) {
    if(cheat.master)return "Código maestro que acompaña a las opciones de su fuente.";
    const auto hotkey=namedHotkey(cheat);
    if(!hotkey.label.empty()) {
        if(simpleHeldWrite(cheat,hotkey))return "Mantén "+hotkey.button+" dentro del juego para "+(hotkey.mask==0x200?std::string("reponer los corazones"):std::string("fijar las rupias en 9999"))+". Al soltarlo dejan de reponerse automáticamente. Conserva las condiciones del nombre original.";
        return "El nombre del autor indica pulsar "+hotkey.button+" dentro del juego. Conserva las condiciones del nombre original: "+cheat.name;
    }
    const auto tokens=words(cheat.name);const auto found=matches(cheat.name,tokens);
    if(std::none_of(found.begin(),found.end(),[](const Match &match){return match.rule->effect!=Effect::None;}))return "Nombre original: "+cheat.name;
    return "Opción indicada por su autor: "+cheatLabel(cheat)+". Conserva las condiciones y botones del nombre original.";
}
std::vector<std::string> optionEffects(const Pack &pack,const std::vector<ModEntry> &mods) {
    std::set<std::pair<unsigned,std::string>> effects;bool unknown=false;
    for(const auto &cheat:pack.cheats)if(!cheat.master) {
        const auto hotkey=namedHotkey(cheat);if(!hotkey.effect.empty()){effects.emplace(hotkey.order,hotkey.effect);continue;}
        const auto tokens=words(cheat.name);const auto found=matches(cheat.name,tokens);bool recognized=false;
        for(const auto &match:found) {
            if(match.rule->effect==Effect::None)continue;
            recognized=true;
            auto name=effectName(match.rule->effect);
            // These are category chips. Disabling depth-of-field does not mean
            // "disabling graphics", nor does disabling DRS remove resolution.
            if(match.rule->effect!=Effect::Resolution&&match.rule->effect!=Effect::Graphics&&match.rule->effect!=Effect::Fps&&turnedOff(tokens,match))name="Desactivar "+name;
            if((match.rule->effect==Effect::Health||match.rule->effect==Effect::MaxHealth||match.rule->effect==Effect::Invincible)&&(has(tokens,"enemy")||has(tokens,"enemies")))name+=" (enemigos)";
            effects.emplace(static_cast<unsigned>(match.rule->effect),name);
        }
        if(std::any_of(tokens.begin(),tokens.end(),[](const Word &word){return resolutionValue(word.value);})){effects.emplace(static_cast<unsigned>(Effect::Resolution),"Resolución");recognized=true;}
        if(!recognized)unknown=true;
    }
    std::vector<std::string> result;for(const auto &effect:effects)result.push_back(effect.second);
    if(unknown)result.emplace_back("Trucos generales");
    if(!mods.empty())result.emplace_back("Mods publicados");
    return result;
}
}

#include "live_receipt.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <set>
#include <utility>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __SWITCH__
extern "C" {
#include <switch/runtime/devices/fs_dev.h>
}
#endif

namespace nc::native {
namespace {
constexpr size_t MaxBytes=512*1024,HeaderSize=28;
constexpr char Magic[8]={'N','M','C','L','I','V','E','1'};
#ifdef NC_LIVE_RECEIPT_TEST
std::string sdRoot;
#else
const std::string sdRoot="sdmc:";
#endif
using Bytes=std::vector<uint8_t>;
std::string directoryPath(){return sdRoot+"/config/NinMagicCheats";}
std::array<std::string,3> paths(){const auto p=directoryPath()+"/live.bin";return {p,p+".pending",p+".backup"};}
bool directories(bool create,bool&present,std::string&error) {
    present=true;
    if(sdRoot.empty()){error="Falta la carpeta de recibos de activación.";return false;}
    for(const auto&p:std::array<std::string,3>{sdRoot+"/",sdRoot+"/config",directoryPath()}) {
        struct stat s{};
        if(lstat(p.c_str(),&s)!=0) {
            if(errno==ENOENT&&!create){present=false;return true;}
            if(errno!=ENOENT||p==sdRoot+"/"||mkdir(p.c_str(),0700)!=0){error="No se pudo abrir la carpeta privada de recibos de activación.";return false;}
            if(lstat(p.c_str(),&s)!=0){error="No se pudo verificar la carpeta de recibos.";return false;}
        }
        if(S_ISLNK(s.st_mode)||!S_ISDIR(s.st_mode)){error="La carpeta de recibos contiene un enlace o una ruta no admitida.";return false;}
    }
    return true;
}
bool regular(const std::string&p,bool&exists,std::string&error) {
    exists=false;struct stat s{};
    if(lstat(p.c_str(),&s)!=0){if(errno==ENOENT)return true;error="No se pudo comprobar un recibo de activación.";return false;}
    exists=true;
    if(S_ISLNK(s.st_mode)||!S_ISREG(s.st_mode)||s.st_size<0||uint64_t(s.st_size)>MaxBytes){error="Un recibo de activación tiene un tipo o tamaño no admitido.";return false;}
    return true;
}
bool readFile(const std::string&p,Bytes&data,bool&exists,std::string&error) {
    data.clear();if(!regular(p,exists,error)||!exists)return !exists&&error.empty();
    int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=open(p.c_str(),flags);if(fd<0){error="No se pudo leer el recibo de activación.";return false;}
    struct stat s{};bool ok=fstat(fd,&s)==0&&S_ISREG(s.st_mode)&&s.st_size>=0&&uint64_t(s.st_size)<=MaxBytes;
    std::array<uint8_t,4096> buffer{};
    const size_t expected=ok?size_t(s.st_size):0;if(ok)data.reserve(expected);
    while(ok&&data.size()<expected) {const auto n=::read(fd,buffer.data(),std::min(buffer.size(),expected-data.size()));if(n<=0){ok=false;break;}data.insert(data.end(),buffer.begin(),buffer.begin()+n);}
    if(ok){uint8_t extra=0;ok=::read(fd,&extra,1)==0;}
    if(close(fd)!=0)ok=false;
    if(!ok){data.clear();error="No se pudo leer por completo el recibo de activación.";return false;}return true;
}
void u32(Bytes&b,uint32_t v){for(unsigned i=0;i<4;++i){b.push_back(uint8_t(v));v>>=8;}}
void u64(Bytes&b,uint64_t v){for(unsigned i=0;i<8;++i){b.push_back(uint8_t(v));v>>=8;}}
uint32_t crc(const Bytes&b) {
    uint32_t c=0xffffffff;
    for(size_t i=0;i<b.size();++i)if(i<24||i>=28){c^=b[i];for(unsigned n=0;n<8;++n)c=(c>>1)^(0xedb88320u&uint32_t(-int32_t(c&1)));}
    return c^0xffffffff;
}
struct Reader {
    const Bytes&b;size_t at=0;bool ok=true;
    uint32_t word(){uint32_t v=0;for(unsigned i=0;i<4;++i){if(at>=b.size()){ok=false;return 0;}v|=uint32_t(b[at++])<<(i*8);}return v;}
    uint64_t wide(){uint64_t lo=word();return lo|(uint64_t(word())<<32);}
    bool raw(void*out,size_t n){if(at>b.size()||n>b.size()-at){ok=false;return false;}std::memcpy(out,b.data()+at,n);at+=n;return true;}
};
bool definitionValid(const Definition&d) {
    if(!d.count||d.count>256)return false;
    const auto end=std::find(d.name,d.name+sizeof(d.name),'\0');if(end==d.name||end==d.name+sizeof(d.name))return false;
    return std::none_of(d.name,end,[](unsigned char c){return c<32||c==127;});
}
bool sameDefinition(const Definition&a,const Definition&b){return a.count==b.count&&a.count<=256&&std::memcmp(a.name,b.name,sizeof(a.name))==0&&std::equal(a.codes,a.codes+a.count,b.codes);}
bool valid(const LiveReceipt&r) {
    if(!r.valid||!r.pid||r.title<0x0100000000010000ULL||r.buildId.size()!=16||r.buildId=="0000000000000000"||r.changes.size()>127||r.observed.size()>128)return false;
    for(char c:r.buildId)if(!((c>='0'&&c<='9')||(c>='A'&&c<='F')))return false;
    if(r.masterAdded&&!definitionValid(r.master))return false;
    std::set<uint32_t> seen;
    for(const auto&e:r.observed)if(e.id>=128||e.enabled>1||!definitionValid(e.definition)||!seen.insert(e.id).second)return false;
    seen.clear();
    for(const auto&c:r.changes) {
        if(!c.id||c.id>=128||!definitionValid(c.definition)||!seen.insert(c.id).second)return false;
        if(std::none_of(r.observed.begin(),r.observed.end(),[&](const Entry&e){return e.id==c.id&&sameDefinition(e.definition,c.definition);}))return false;
    }
    if(r.masterAdded&&std::none_of(r.observed.begin(),r.observed.end(),[&](const Entry&e){return e.id==0&&sameDefinition(e.definition,r.master);}))return false;
    return true;
}
void putDefinition(Bytes&b,const Definition&d){b.insert(b.end(),d.name,d.name+sizeof(d.name));u32(b,d.count);for(size_t i=0;i<d.count;++i)u32(b,d.codes[i]);}
bool getDefinition(Reader&reader,Definition&d) {
    d={};if(!reader.raw(d.name,sizeof(d.name)))return false;d.count=reader.word();if(!reader.ok||d.count>256)return false;
    for(size_t i=0;i<d.count;++i)d.codes[i]=reader.word();
    return reader.ok&&definitionValid(d);
}
Bytes encode(const LiveReceipt&r,uint64_t generation) {
    size_t encodedSize=HeaderSize+44;
    if(r.masterAdded)encodedSize+=68+size_t(r.master.count)*4;
    for(const auto&c:r.changes)encodedSize+=76+size_t(c.definition.count)*4;
    for(const auto&e:r.observed)encodedSize+=76+size_t(e.definition.count)*4;
    Bytes b;b.reserve(encodedSize);b.insert(b.end(),Magic,Magic+8);u32(b,1);u64(b,generation);u32(b,0);u32(b,0);
    u32(b,1u|(r.masterAdded?2u:0u));u64(b,r.pid);u64(b,r.title);b.insert(b.end(),r.buildId.begin(),r.buildId.end());u32(b,static_cast<uint32_t>(r.changes.size()));u32(b,static_cast<uint32_t>(r.observed.size()));
    if(r.masterAdded)putDefinition(b,r.master);
    for(const auto&c:r.changes){u32(b,c.id);u32(b,c.added?1:0);putDefinition(b,c.definition);}
    for(const auto&e:r.observed){u32(b,e.id);u32(b,e.enabled);putDefinition(b,e.definition);}
    const auto size=uint32_t(b.size()-HeaderSize);for(unsigned i=0;i<4;++i)b[20+i]=uint8_t(size>>(i*8));
    const auto sum=crc(b);for(unsigned i=0;i<4;++i)b[24+i]=uint8_t(sum>>(i*8));return b;
}
bool decode(const Bytes&b,LiveReceipt&r,uint64_t&generation) {
    r={};generation=0;if(b.size()<HeaderSize||b.size()>MaxBytes||std::memcmp(b.data(),Magic,8))return false;
    Reader reader{b,8};if(reader.word()!=1)return false;generation=reader.wide();const auto size=reader.word(),sum=reader.word();
    if(!reader.ok||!generation||size!=b.size()-HeaderSize||sum!=crc(b))return false;
    const auto flags=reader.word();if((flags&~3u)||!(flags&1))return false;r.valid=true;r.masterAdded=(flags&2)!=0;r.pid=reader.wide();r.title=reader.wide();
    char build[16];if(!reader.raw(build,sizeof(build)))return false;r.buildId.assign(build,sizeof(build));
    const auto changes=reader.word(),observed=reader.word();if(!reader.ok||changes>127||observed>128)return false;
    r.changes.reserve(changes);r.observed.reserve(observed);
    if(r.masterAdded&&!getDefinition(reader,r.master))return false;
    for(uint32_t i=0;i<changes;++i){LiveChange c;c.id=reader.word();const auto added=reader.word();if(added>1||!getDefinition(reader,c.definition))return false;c.added=added!=0;r.changes.push_back(c);}
    for(uint32_t i=0;i<observed;++i){Entry e;e.id=reader.word();const auto enabled=reader.word();if(enabled>1||!getDefinition(reader,e.definition))return false;e.enabled=uint8_t(enabled);r.observed.push_back(e);}
    return reader.ok&&reader.at==b.size()&&valid(r);
}
struct Candidate {uint64_t generation=0;bool exists=false,valid=false;};
bool candidates(std::array<Candidate,3>&all,int&best,std::string&error,LiveReceipt*selected=nullptr) {
    best=-1;const auto names=paths();bool any=false;
    for(size_t i=0;i<all.size();++i) {
        // Read/decode one file at a time. Only load() retains the current best
        // decoded receipt; save() needs just generation and existence metadata.
        Bytes data;LiveReceipt receipt;
        if(!readFile(names[i],data,all[i].exists,error))return false;
        any|=all[i].exists;
        if(all[i].exists)all[i].valid=decode(data,receipt,all[i].generation);
        if(all[i].valid&&(best<0||all[i].generation>all[size_t(best)].generation)){best=int(i);if(selected)*selected=std::move(receipt);}
    }
    if(best<0&&any){error="El recibo de activación está dañado o incompleto. Cierra el juego antes de volver a aplicar cheats.";return false;}return true;
}
bool eraseFile(const std::string&p,std::string&error){bool exists=false;if(!regular(p,exists,error))return false;if(exists&&std::remove(p.c_str())!=0){error="No se pudo retirar un recibo temporal de activación.";return false;}return true;}
bool commit(std::string&error) {
#ifdef __SWITCH__
    if(fsdevCommitDevice("sdmc")!=0){error="No se pudo confirmar el recibo de activación en la microSD.";return false;}
#else
    (void)error;
#endif
    return true;
}
bool recoverMain(const std::array<Candidate,3>&all,int best,std::string&error) {
    if(best<=0)return true;
    const auto p=paths();
    if(best==1) {
        if(!eraseFile(p[2],error))return false;
        if(all[0].exists&&std::rename(p[0].c_str(),p[2].c_str())!=0){error="No se pudo apartar el recibo anterior.";return false;}
        if(std::rename(p[1].c_str(),p[0].c_str())!=0){error="No se pudo recuperar el recibo pendiente.";return false;}
    } else {
        if(!eraseFile(p[1],error))return false;
        if(all[0].exists&&std::rename(p[0].c_str(),p[1].c_str())!=0){error="No se pudo apartar el recibo dañado.";return false;}
        if(std::rename(p[2].c_str(),p[0].c_str())!=0){error="No se pudo recuperar la copia del recibo.";return false;}
    }
    return true;
}
bool writeNew(const std::string&p,const Bytes&data,std::string&error) {
    int flags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=open(p.c_str(),flags,0600);if(fd<0){error="No se pudo crear el recibo pendiente.";return false;}
    bool ok=true;size_t at=0;
    while(at<data.size()){auto n=::write(fd,data.data()+at,data.size()-at);if(n<=0){ok=false;break;}at+=size_t(n);}
    if(ok&&fsync(fd)!=0)ok=false;
    if(close(fd)!=0)ok=false;
    if(!ok){error="No se pudo guardar por completo el recibo de activación.";return false;}
    Bytes saved;bool exists=false;
    if(!readFile(p,saved,exists,error)||!exists||saved!=data){error="No se pudo verificar el recibo guardado.";return false;}return true;
}
}
bool loadLiveReceipt(LiveReceipt&receipt,std::string&error) {
    receipt={};error.clear();bool present=false;if(!directories(false,present,error))return false;if(!present)return true;
    std::array<Candidate,3> all;LiveReceipt selected;int best=-1;if(!candidates(all,best,error,&selected))return false;
    if(best>=0)receipt=std::move(selected);
    return true;
}
bool saveLiveReceipt(const LiveReceipt&receipt,std::string&error) {
    error.clear();if(!valid(receipt)){error="El recibo de activación contiene datos no válidos.";return false;}
    bool present=false;if(!directories(true,present,error))return false;
    std::array<Candidate,3> all;int best=-1;if(!candidates(all,best,error))return false;
    const auto generation=best<0?0:all[size_t(best)].generation;if(generation==std::numeric_limits<uint64_t>::max()){error="El contador de recibos está agotado.";return false;}
    if(!recoverMain(all,best,error))return false;
    const auto names=paths();
    const auto data=encode(receipt,generation+1);if(data.size()>MaxBytes){error="El recibo de activación excede su tamaño permitido.";return false;}
    if(!eraseFile(names[1],error)||!writeNew(names[1],data,error)||!eraseFile(names[2],error))return false;
    bool mainExists=false;if(!regular(names[0],mainExists,error))return false;
    if(mainExists&&std::rename(names[0].c_str(),names[2].c_str())!=0){error="No se pudo guardar la copia anterior del recibo.";return false;}
    if(std::rename(names[1].c_str(),names[0].c_str())!=0){error="No se pudo activar el nuevo recibo de activación; conserva sus archivos de recuperación.";return false;}
    Bytes saved;bool exists=false;
    if(!readFile(names[0],saved,exists,error)||!exists||saved!=data){error="La comprobación final del recibo de activación falló.";return false;}return commit(error);
}
bool clearLiveReceipt(std::string&error) {
    error.clear();bool present=false;if(!directories(false,present,error))return false;if(!present)return true;
    const auto names=paths();for(size_t i=0;i<names.size();++i){bool exists=false;if(!regular(names[i],exists,error))return false;}
    return eraseFile(names[1],error)&&eraseFile(names[2],error)&&eraseFile(names[0],error)&&commit(error);
}
#ifdef NC_LIVE_RECEIPT_TEST
void setLiveReceiptTestRoot(const std::string&root){sdRoot=root;}
#endif
}

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "mods.hpp"
#include "catalog.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fcntl.h>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr size_t MaxTree=8*1024*1024,MaxPayload=2*1024*1024;
const char *Primary="ADEMOLA200/Switch-Emulator-Mod-Database";
const char *Optimizer="medinacristofer034-art/SwitchOptimizerMods";
struct Repo {const char *name,*branch,*file;};
const Repo Repos[]={{Primary,"develop","ademola.json"},{Optimizer,"main","optimizer.json"}};
std::string root() {
#ifdef NC_MODS_TEST
    const char *s=std::getenv("NC_MODS_ROOT");return s?s:"mods-test";
#else
    return "sdmc:/config/NinMagicCheats";
#endif
}
std::string upper(std::string s){for(char &c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hex(const std::string &s,size_t count){return s.size()==count&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}
bool pathValid(const std::string &s) {
    if(s.empty()||s.size()>1024||s[0]=='/'||s.back()=='/'||s.find('\\')!=std::string::npos)return false;
    size_t start=0;
    for(unsigned char c:s)if(c<32||c==127)return false;
    while(start<s.size()){auto end=s.find('/',start);auto part=s.substr(start,end==std::string::npos?end:end-start);if(part.empty()||part=="."||part=="..")return false;if(end==std::string::npos)break;start=end+1;}
    return true;
}
struct Raw {std::string path,sha,type;uint64_t size=0;};
class TreeJson {
    const std::string &s;size_t p=0;
    void ws(){while(p<s.size()&&std::isspace(static_cast<unsigned char>(s[p])))++p;}
    bool character(char c){ws();if(p==s.size()||s[p]!=c)return false;++p;return true;}
    static void utf8(std::string &out,uint32_t cp){if(cp<128)out+=char(cp);else if(cp<2048){out+=char(0xc0|(cp>>6));out+=char(0x80|(cp&63));}else if(cp<65536){out+=char(0xe0|(cp>>12));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}else{out+=char(0xf0|(cp>>18));out+=char(0x80|((cp>>12)&63));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}}
    bool codepoint(uint32_t &value){value=0;for(unsigned n=0;n<4;++n){if(p==s.size()||!std::isxdigit(static_cast<unsigned char>(s[p])))return false;unsigned char c=s[p++];value=(value<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);}return true;}
    bool string(std::string &out) {
        out.clear();if(!character('"'))return false;
        while(p<s.size()) {
            unsigned char c=s[p++];if(c=='"')return true;if(c<32)return false;
            if(c=='\\') {
                if(p==s.size())return false;
                char e=s[p++];
                if(e=='"'||e=='\\'||e=='/')out+=e;
                else if(e=='b')out+='\b';else if(e=='f')out+='\f';else if(e=='n')out+='\n';else if(e=='r')out+='\r';else if(e=='t')out+='\t';
                else if(e=='u'){uint32_t cp=0;if(!codepoint(cp))return false;if(cp>=0xd800&&cp<=0xdbff){if(p+2>s.size()||s.substr(p,2)!="\\u")return false;p+=2;uint32_t low=0;if(!codepoint(low)||low<0xdc00||low>0xdfff)return false;cp=0x10000+((cp-0xd800)<<10)+(low-0xdc00);}else if(cp>=0xdc00&&cp<=0xdfff)return false;utf8(out,cp);}else return false;
            }else out+=char(c);
            if(out.size()>8192)return false;
        }
        return false;
    }
    bool number(uint64_t &value){ws();size_t start=p;value=0;while(p<s.size()&&s[p]>='0'&&s[p]<='9'){unsigned n=s[p++]-'0';if(value>(UINT64_MAX-n)/10)return false;value=value*10+n;}return p>start;}
    bool literal(const char *value){ws();size_t n=std::char_traits<char>::length(value);if(s.compare(p,n,value))return false;p+=n;return true;}
    bool skip(unsigned depth=0) {
        if(depth>32)return false;
        ws();if(p==s.size())return false;
        if(s[p]=='"'){std::string ignored;return string(ignored);}
        if(s[p]=='{'){++p;ws();if(character('}'))return true;do{std::string key;if(!string(key)||!character(':')||!skip(depth+1))return false;if(character('}'))return true;}while(character(','));return false;}
        if(s[p]=='['){++p;ws();if(character(']'))return true;do{if(!skip(depth+1))return false;if(character(']'))return true;}while(character(','));return false;}
        if(s[p]=='t')return literal("true");
        if(s[p]=='f')return literal("false");
        if(s[p]=='n')return literal("null");
        uint64_t ignored=0;return number(ignored);
    }
    bool item(Raw &out) {
        if(!character('{'))return false;
        std::set<std::string> keys;
        if(character('}'))return false;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="path"){if(!string(out.path))return false;}else if(key=="sha"){if(!string(out.sha))return false;}else if(key=="type"){if(!string(out.type))return false;}else if(key=="size"){if(!number(out.size))return false;}else if(!skip())return false;
            if(character('}'))return pathValid(out.path)&&hex(out.sha,40)&&!out.type.empty()&&(out.type!="blob"||keys.count("size"));
        }while(character(','));return false;
    }
public:
    explicit TreeJson(const std::string &text):s(text){}
    bool parse(std::string &revision,std::vector<Raw> &items) {
        if(!character('{'))return false;
        bool tree=false,truncated=false,haveTruncated=false;std::set<std::string> keys;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="sha"){if(!string(revision))return false;}
            else if(key=="truncated"){haveTruncated=true;if(literal("true"))truncated=true;else if(!literal("false"))return false;}
            else if(key=="tree"){if(!character('['))return false;tree=true;if(!character(']')){do{Raw raw;if(!item(raw)||items.size()>=30000)return false;items.push_back(std::move(raw));if(character(']'))break;if(!character(','))return false;}while(true);}}
            else if(!skip())return false;
            if(character('}'))break;
            if(!character(','))return false;
        }while(true);
        ws();return p==s.size()&&tree&&haveTruncated&&!truncated&&hex(revision,40);
    }
};
uint64_t titleFromPath(const std::string &path,bool *ambiguous=nullptr) {
    std::set<uint64_t> ids;
    for(size_t p=0;p+16<=path.size();++p){if(p&&std::isxdigit(static_cast<unsigned char>(path[p-1])))continue;if(p+16<path.size()&&std::isxdigit(static_cast<unsigned char>(path[p+16])))continue;std::string token=upper(path.substr(p,16));if(token.rfind("0100",0)||!hex(token,16))continue;uint64_t id=0;for(unsigned char c:token)id=(id<<4)|(c<='9'?c-'0':c-'A'+10);if(id>=0x0100000000010000ULL)ids.insert(id);}
    if(ambiguous)*ambiguous=ids.size()>1;
    return ids.size()==1?*ids.begin():0;
}
ModFormat format(const std::string &path) {
    std::string value=upper(path);if(value.size()>=7&&value.substr(value.size()-7)==".PCHTXT")return ModFormat::Pchtxt;
    if(value.size()>=4&&value.substr(value.size()-4)==".IPS")return ModFormat::Ips;
    if(value.find("/ROMFS/")!=std::string::npos)return ModFormat::Romfs;
    for(const char *suffix:{".ZIP",".RAR",".7Z"})if(value.size()>=std::char_traits<char>::length(suffix)&&value.substr(value.size()-std::char_traits<char>::length(suffix))==suffix)return ModFormat::Archive;
    return ModFormat::Unsupported;
}
std::string top(const std::string &path){return path.substr(0,path.find('/'));}
std::string displayName(const std::string &path,ModFormat kind) {
    if(kind==ModFormat::Archive){auto slash=path.find_last_of('/');return path.substr(slash==std::string::npos?0:slash+1);}
    std::vector<std::string> parts;size_t start=path.find('/');if(start==std::string::npos)return path;++start;
    while(start<path.size()){auto end=path.find('/',start);std::string part=path.substr(start,end==std::string::npos?end:end-start);std::string cap=upper(part);
        bool generic=cap=="EXEFS"||cap=="EXEFS_PATCHES"||cap=="TITLES"||cap=="CONTENTS"||cap=="ATMOSPHERE";
        if(!generic&&!titleFromPath(part))parts.push_back(part);
        if(end==std::string::npos)break;
        start=end+1;
    }
    if(parts.empty())return path;
    auto &last=parts.back();auto dot=last.find_last_of('.');if(kind==ModFormat::Pchtxt&&dot!=std::string::npos)last.resize(dot);
    if(kind==ModFormat::Ips&&dot!=std::string::npos&&hex(last.substr(0,dot),dot))parts.pop_back();
    std::string result;for(const auto &part:parts){if(!result.empty())result+=" / ";result+=part;}return result.empty()?path:result;
}
std::string normalized(std::string value) {
    std::string out;for(unsigned char c:value)if(std::isalnum(c)&&c<128)out+=char(std::tolower(c));
    for(const std::string suffix:{"optimization","mods","mod"})if(out.size()>suffix.size()&&out.substr(out.size()-suffix.size())==suffix)out.resize(out.size()-suffix.size());
    auto version=out.find("v1");if(version==std::string::npos)version=out.find("v2");if(version==std::string::npos)version=out.find("v4");if(version!=std::string::npos)out.resize(version);
    return out;
}
bool dir(const std::string &path,bool create,std::string &error) {
    struct stat st{};if(lstat(path.c_str(),&st)!=0){if(errno!=ENOENT||!create){error="No existe la carpeta de mods.";return false;}
#ifdef _WIN32
        if(mkdir(path.c_str())!=0){error="No se pudo crear la carpeta de mods.";return false;}
#else
        if(mkdir(path.c_str(),0777)!=0){error="No se pudo crear la carpeta de mods.";return false;}
#endif
        if(lstat(path.c_str(),&st)!=0)return false;
    }
    if(S_ISLNK(st.st_mode)||!S_ISDIR(st.st_mode)){error="La carpeta de mods contiene una ruta no admitida.";return false;}return true;
}
bool ensureRoot(std::string &error) {
#ifndef NC_MODS_TEST
    if(!dir("sdmc:/config",true,error))return false;
#endif
    return dir(root(),true,error);
}
bool regular(const std::string &path,size_t maximum){struct stat st{};return lstat(path.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=maximum;}
bool read(const std::string &path,std::string &data,size_t maximum,std::string &error) {
    if(!regular(path,maximum)){error="Falta un archivo válido del catálogo de mods.";return false;}
    FILE *f=fopen(path.c_str(),"rb");if(!f){error="No se puede leer el catálogo de mods.";return false;}
    data.clear();std::array<char,16384> buffer{};size_t n;bool ok=true;
    while((n=fread(buffer.data(),1,buffer.size(),f))){if(data.size()+n>maximum){ok=false;break;}data.append(buffer.data(),n);}
    if(ferror(f))ok=false;
    if(fclose(f)!=0)ok=false;
    if(!ok)error="La lectura del catálogo quedó incompleta.";
    return ok;
}
bool write(const std::string &path,const std::string &data,std::string &error) {
    struct stat st{};if(lstat(path.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="El registro de mods no es un archivo regular.";return false;}
    FILE *f=fopen(path.c_str(),"wb");if(!f){error="No se pudo guardar el catálogo de mods.";return false;}
    bool ok=fwrite(data.data(),1,data.size(),f)==data.size()&&fflush(f)==0&&fsync(fileno(f))==0;if(fclose(f)!=0)ok=false;if(!ok)error="No se pudo confirmar la escritura del catálogo.";return ok;
}
char active(){std::string s,e;return read(root()+"/mods-active.txt",s,8,e)&&!s.empty()&&s[0]=='b'?'b':'a';}
bool slot(char value,ModsCatalog &out,std::string &error) {
    std::string path=root()+"/mods-"+value,marker;if(!dir(path,false,error)||!read(path+"/complete.txt",marker,128,error)||marker.rfind("NMMODS1",0)!=0)return false;
    ModsCatalog all;
    for(const auto &repo:Repos){std::string json;ModsCatalog one;if(!read(path+"/"+repo.file,json,MaxTree,error)||!parseModsTree(json,one,error,repo.name))return false;all.entries.insert(all.entries.end(),one.entries.begin(),one.entries.end());if(!all.revision.empty())all.revision+=" / ";all.revision+=one.revision;}
    all.ready=true;all.stamp=marker.substr(marker.find('\n')+1);while(!all.stamp.empty()&&(all.stamp.back()=='\r'||all.stamp.back()=='\n'))all.stamp.pop_back();all.detail=std::to_string(all.entries.size())+" archivos de dos fuentes de mods";out=std::move(all);return true;
}
std::string encode(const std::string &path){std::string result;const char *digits="0123456789ABCDEF";for(unsigned char c:path){if(std::isalnum(c)||c=='-'||c=='_'||c=='.'||c=='~'||c=='/')result+=char(c);else{result+='%';result+=digits[c>>4];result+=digits[c&15];}}return result;}
uint32_t rotate(uint32_t value,unsigned bits){return (value<<bits)|(value>>(32-bits));}
std::string gitBlobSha(const std::string &bytes) {
    std::string header="blob "+std::to_string(bytes.size());header+='\0';
    std::vector<uint8_t> data(header.begin(),header.end());data.insert(data.end(),bytes.begin(),bytes.end());uint64_t length=uint64_t(data.size())*8;
    data.push_back(0x80);while(data.size()%64!=56)data.push_back(0);for(int n=7;n>=0;--n)data.push_back(uint8_t(length>>(n*8)));
    uint32_t h[]={0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0};
    for(size_t block=0;block<data.size();block+=64){uint32_t words[80]{};for(unsigned n=0;n<16;++n)for(unsigned b=0;b<4;++b)words[n]=(words[n]<<8)|data[block+n*4+b];for(unsigned n=16;n<80;++n)words[n]=rotate(words[n-3]^words[n-8]^words[n-14]^words[n-16],1);uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];
        for(unsigned n=0;n<80;++n){uint32_t f=n<20?((b&c)|(~b&d)):n<40?(b^c^d):n<60?((b&c)|(b&d)|(c&d)):(b^c^d);uint32_t k=n<20?0x5a827999:n<40?0x6ed9eba1:n<60?0x8f1bbcdc:0xca62c1d6;uint32_t next=rotate(a,5)+f+e+k+words[n];e=d;d=c;c=rotate(b,30);b=a;a=next;}h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;}
    std::string result;const char *digits="0123456789abcdef";for(uint32_t word:h)for(int n=7;n>=0;--n)result+=digits[(word>>(n*4))&15];return result;
}
}
bool parseModsTree(const std::string &json,ModsCatalog &catalog,std::string &error,const std::string &repository) {
    catalog={};error.clear();if(repository!=Primary&&repository!=Optimizer){error="Fuente de mods no admitida.";return false;}
    std::vector<Raw> items;std::string revision;if(json.empty()||json.size()>MaxTree||!TreeJson(json).parse(revision,items)){error="El índice de mods está incompleto, truncado o no es JSON válido.";return false;}
    std::map<std::string,std::set<uint64_t>> titleGroups;std::set<std::string> paths;
    for(const auto &item:items){if(!paths.insert(item.path).second){error="El índice de mods contiene rutas duplicadas.";return false;}if(item.type=="blob"){uint64_t id=titleFromPath(item.path);if(id)titleGroups[top(item.path)].insert(id);}}
    for(const auto &item:items)if(item.type=="blob") {
        const auto kind=format(item.path);if(kind==ModFormat::Unsupported)continue;
        bool ambiguous=false;
        ModEntry entry;entry.path=item.path;entry.name=displayName(item.path,kind);entry.titleId=titleFromPath(item.path,&ambiguous);entry.blobSha=item.sha;entry.size=item.size;entry.format=kind;entry.revision=revision;entry.repository=repository;entry.source=repository==Primary?"ADEMOLA200":"SwitchOptimizerMods";
        auto group=titleGroups.find(top(item.path));if(!entry.titleId&&!ambiguous&&group!=titleGroups.end()&&group->second.size()==1)entry.titleId=*group->second.begin();
        if(kind==ModFormat::Ips){auto slash=item.path.find_last_of('/');std::string filename=item.path.substr(slash==std::string::npos?0:slash+1);filename.resize(filename.size()-4);if((filename.size()==16||filename.size()==32||filename.size()==40||filename.size()==64)&&hex(filename,filename.size()))entry.buildId=upper(filename);}
        if(repository==Optimizer)entry.detail="Fuente centrada en emuladores de PC. Paquete sin Build ID comprobable; revisión manual.";
        else if(kind==ModFormat::Romfs)entry.detail="Mod RomFS sin Build ID verificable: disponible para consultar; instalación automática bloqueada.";
        else if(kind==ModFormat::Archive)entry.detail="Paquete ZIP/RAR/7z sin verificar: consulta su contenido y compatibilidad; no se instalará automáticamente.";
        else entry.detail="Formato convertible a Atmosphère; funcionamiento en consola sin verificar. El Build ID se comprueba al preparar.";
        if(!entry.titleId)entry.detail+=" Title ID sin comprobar; coincidencia por nombre únicamente.";
        catalog.entries.push_back(std::move(entry));
    }
    if(catalog.entries.empty()){error="La fuente no contiene archivos de mods reconocidos.";return false;}
    catalog.revision=revision;catalog.ready=true;catalog.detail=std::to_string(catalog.entries.size())+" archivos de mods";return true;
}
bool loadModsCatalog(ModsCatalog &catalog,std::string &error) {
    char current=active();if(slot(current,catalog,error)){error.clear();return true;}if(slot(current=='a'?'b':'a',catalog,error)){error.clear();return true;}catalog={};error="No hay índice local de mods. Sincroniza para descargar las dos fuentes.";return false;
}
bool syncModsCatalog(ModsCatalog &catalog,std::string &error) {
    error.clear();if(!ensureRoot(error))return false;char current=active();ModsCatalog previous;
    if(!slot(current,previous,error)&&slot(current=='a'?'b':'a',previous,error))current=current=='a'?'b':'a';
    error.clear();
    char next=current=='a'?'b':'a';std::string path=root()+"/mods-"+next;if(!dir(path,true,error))return false;
    std::string marker=path+"/complete.txt";struct stat st{};if(lstat(marker.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="El cierre de caché de mods no es válido.";return false;}unlink(marker.c_str());
    for(const auto &repo:Repos){std::string target=path+"/"+repo.file;if(!catalogDownloadHttps(std::string("https://api.github.com/repos/")+repo.name+"/git/trees/"+repo.branch+"?recursive=1",target,error))return false;std::string data;ModsCatalog one;if(!read(target,data,MaxTree,error)||!parseModsTree(data,one,error,repo.name))return false;}
    time_t now=std::time(nullptr);struct tm when{};char stamp[40]="Actualizado";if(gmtime_r(&now,&when))std::strftime(stamp,sizeof(stamp),"%Y-%m-%d %H:%M UTC",&when);
    if(!write(marker,std::string("NMMODS1\n")+stamp+"\n",error)||!write(root()+"/mods-active.pending",std::string(1,next)+"\n",error))return false;
    unlink((root()+"/mods-active.previous").c_str());bool had=regular(root()+"/mods-active.txt",8);
    if(had&&rename((root()+"/mods-active.txt").c_str(),(root()+"/mods-active.previous").c_str())!=0){error="No se pudo conservar el índice anterior de mods.";return false;}
    if(rename((root()+"/mods-active.pending").c_str(),(root()+"/mods-active.txt").c_str())!=0){if(had)rename((root()+"/mods-active.previous").c_str(),(root()+"/mods-active.txt").c_str());error="No se pudo activar el nuevo índice de mods.";return false;}
    return slot(next,catalog,error);
}
std::vector<ModEntry> findMods(const Game &game,const ModsCatalog &catalog) {
    std::vector<ModEntry> result;const auto name=normalized(game.name);
    for(const auto &entry:catalog.entries)if(entry.titleId==game.id||(!entry.titleId&&!name.empty()&&normalized(top(entry.path))==name))result.push_back(entry);
    return result;
}
bool prepareMod(const Game &game,const ModEntry &entry,ModPayload &payload,std::string &error) {
    payload={};payload.game=game;payload.entry=entry;error.clear();
    if(!game.buildVerified||game.buildId.size()!=16||!hex(game.buildId,16)||entry.titleId!=game.id||!entry.titleId){error="Falta comprobar el Title ID y el Build ID exactos para este mod.";return false;}
    if(!hex(game.fullBuildId,64)||upper(game.fullBuildId).substr(0,16)!=upper(game.buildId)){error="Falta comprobar el Build ID completo del NSO antes de descargar el mod.";return false;}
    if(entry.repository!=Primary&&entry.repository!=Optimizer){error="Fuente de mods no admitida.";return false;}
    if(entry.format!=ModFormat::Pchtxt&&entry.format!=ModFormat::Ips){error=entry.detail;return false;}
    if(entry.repository==Optimizer){error="Esta fuente está orientada a emuladores y no declara compatibilidad con la consola.";return false;}
    if(!pathValid(entry.path)||!hex(entry.revision,40)||!hex(entry.blobSha,40)||entry.size==0||entry.size>MaxPayload){error="El archivo de mod no tiene metadatos válidos o es demasiado grande.";return false;}
    if(!ensureRoot(error)||!dir(root()+"/mod-files",true,error))return false;
    const std::string target=root()+"/mod-files/"+entry.blobSha+".bin";std::string bytes;
    // git/trees returns a tree object ID, not a commit usable as a raw-file ref.
    // Fetch the official branch, then bind its bytes to the indexed Git blob.
    // A changed branch fails the hash check until its index is synchronized.
    const std::string branch=entry.repository==Primary?"develop":"main";
    if(!read(target,bytes,MaxPayload,error)||bytes.size()!=entry.size||upper(gitBlobSha(bytes))!=upper(entry.blobSha)){error.clear();const std::string url="https://raw.githubusercontent.com/"+entry.repository+"/"+branch+"/"+encode(entry.path);if(!catalogDownloadHttps(url,target,error)||!read(target,bytes,MaxPayload,error)||bytes.size()!=entry.size){if(error.empty())error="El tamaño del mod no coincide con su índice.";return false;}}
    if(upper(gitBlobSha(bytes))!=upper(entry.blobSha)){error="El mod descargado no coincide con el hash Git de su índice. No se instalará.";return false;}
    return parseModPayload(game,entry,bytes,payload,error);
}
}

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "archive_merge.hpp"
#include <minizip/unzip.h>
#include <minizip/zip.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr uint64_t MaxArchive=64ull*1024*1024,MaxMember=2ull*1024*1024,MaxExpanded=256ull*1024*1024;
constexpr size_t MaxCheats=20000,MaxMembers=60000,MaxCredits=20000,MaxName=1024;
struct Input {std::string path;unzFile file=nullptr;struct stat before{};};
struct Inputs {std::vector<Input> items;~Inputs(){for(auto&i:items)if(i.file)unzClose(i.file);}};
struct Member {size_t input=0;unz64_file_pos position{};unz_file_info64 info{};std::string origin,output;uint64_t contentHash=0;bool credit=false;};
std::string upper(std::string s){for(char&c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hex16(const std::string&s){return s.size()==16&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}
bool components(const std::string&path,std::vector<std::string>&parts,bool&directory){
    parts.clear();directory=!path.empty()&&path.back()=='/';
    if(path.empty()||path.size()>MaxName||path.front()=='/'||path.find('\\')!=std::string::npos||std::any_of(path.begin(),path.end(),[](unsigned char c){return c<32||c==127;}))return false;
    size_t at=0;while(at<path.size()){auto end=path.find('/',at);auto p=path.substr(at,end==std::string::npos?end:end-at);if(p.empty()||p=="."||p==".."||(parts.empty()&&p.size()==2&&std::isalpha(static_cast<unsigned char>(p[0]))&&p[1]==':'))return false;parts.push_back(p);if(end==std::string::npos)break;at=end+1;}
    return !parts.empty();
}
bool diskPath(const std::string&path,bool missingLeaf,struct stat&last,std::string&error){
    if(path.empty()||path.size()>1536||path.find('\0')!=std::string::npos){error="Ruta de catálogo no válida.";return false;}
    std::string normalized=path;for(char&c:normalized)if(c=='\\')c='/';
    size_t at=0;std::string current;if(normalized[0]=='/'){current="/";at=1;}auto colon=normalized.find(':');if(colon!=std::string::npos){if(colon==0||normalized.find(':',colon+1)!=std::string::npos||colon+1>=normalized.size()||normalized[colon+1]!='/'){error="Ruta de dispositivo no válida.";return false;}current=normalized.substr(0,colon+2);at=colon+2;}
    while(at<normalized.size()){auto end=normalized.find('/',at);auto part=normalized.substr(at,end==std::string::npos?end:end-at);if(part.empty()||part=="."||part==".."){error="La ruta del catálogo contiene componentes no admitidos.";return false;}if(!current.empty()&&current.back()!='/')current+='/';current+=part;const bool final=end==std::string::npos;struct stat st{};if(lstat(current.c_str(),&st)!=0){if(final&&missingLeaf&&errno==ENOENT){last={};return true;}error="No se pudo comprobar la ruta del catálogo.";return false;}if(S_ISLNK(st.st_mode)||(!final&&!S_ISDIR(st.st_mode))||(final&&!S_ISREG(st.st_mode))){error="El catálogo o sus carpetas contienen un enlace o un tipo no admitido.";return false;}if(final){last=st;return true;}at=end+1;}
    error="Falta el nombre del archivo de catálogo.";return false;
}
std::string key(const std::vector<std::string>&p){size_t at=0;if(p.size()==5&&(p[1]=="contents"||p[1]=="titles"))at=1;if(p.size()!=at+4||(p[at]!="contents"&&p[at]!="titles")||!hex16(p[at+1])||p[at+2]!="cheats")return {};auto filename=p[at+3];if(filename.size()!=20||upper(filename.substr(16))!=".TXT"||!hex16(filename.substr(0,16)))return {};uint64_t tid=0;for(unsigned char c:upper(p[at+1]))tid=(tid<<4)|(c<='9'?c-'0':c-'A'+10);const auto bid=upper(filename.substr(0,16));if(tid<0x0100000000010000ULL||bid=="0000000000000000")return {};return "contents/"+upper(p[at+1])+"/cheats/"+bid+".txt";}
bool creditName(const std::vector<std::string>&p){const auto name=upper(p.back());auto dot=name.find_last_of('.');const auto ext=dot==std::string::npos?"":name.substr(dot);return ext==".TXT"||ext==".MD"||ext==".RST"||name=="LICENSE"||name=="COPYING"||name=="AUTHORS"||name=="NOTICE"||name=="CREDITS";}
bool verifyCurrent(unzFile file,const unz_file_info64&info,uint64_t&hash,std::string&error){if(unzOpenCurrentFile(file)!=UNZ_OK){error="No se pudo abrir un miembro del catálogo.";return false;}std::array<char,32768> buffer{};uint64_t size=0;hash=14695981039346656037ull;int n=0;while((n=unzReadCurrentFile(file,buffer.data(),unsigned(buffer.size())))>0){size+=uint64_t(n);if(size>MaxMember)break;for(int i=0;i<n;++i){hash^=uint8_t(buffer[size_t(i)]);hash*=1099511628211ull;}}const int closed=unzCloseCurrentFile(file);if(n<0||closed!=UNZ_OK||size!=info.uncompressed_size||size>MaxMember){error="Un archivo del catálogo tiene un tamaño o CRC incorrecto.";return false;}return true;}
bool memberBytes(Inputs&inputs,const Member&m,std::string&bytes,std::string&error){auto zip=inputs.items[m.input].file;if(unzGoToFilePos64(zip,&m.position)!=UNZ_OK||unzOpenCurrentFile(zip)!=UNZ_OK){error="No se pudo verificar un archivo de créditos repetido.";return false;}bytes.clear();std::array<char,16384> buffer{};int n=0;while((n=unzReadCurrentFile(zip,buffer.data(),unsigned(buffer.size())))>0){if(bytes.size()+size_t(n)>MaxMember)break;bytes.append(buffer.data(),size_t(n));}if(n<0||unzCloseCurrentFile(zip)!=UNZ_OK||bytes.size()!=m.info.uncompressed_size){error="Un archivo de créditos repetido no coincide con su CRC o tamaño.";return false;}return true;}
uint64_t creditIdentity(const Member&member){uint64_t hash=14695981039346656037ull;for(unsigned char c:member.origin){hash^=c;hash*=1099511628211ull;}hash*=1099511628211ull;for(unsigned i=0;i<8;++i){hash^=uint8_t(member.contentHash>>(i*8));hash*=1099511628211ull;}return hash;}
bool scan(Inputs&inputs,size_t index,std::map<std::string,Member>&cheats,std::vector<Member>&credits,std::map<std::string,std::vector<size_t>>&creditKeys,uint64_t&expanded,std::string&error){auto file=inputs.items[index].file;unz_global_info64 global{};if(unzGetGlobalInfo64(file,&global)!=UNZ_OK||global.number_entry>MaxMembers){error="El catálogo ZIP tiene demasiados miembros o una cabecera inválida.";return false;}if(!global.number_entry)return true;int result=unzGoToFirstFile(file);std::set<std::string> seen;
    for(uint64_t n=0;n<global.number_entry;++n){unz_file_info64 info{};std::array<char,MaxName+1> name{};if(result!=UNZ_OK||unzGetCurrentFileInfo64(file,&info,name.data(),uLong(name.size()),nullptr,0,nullptr,0)!=UNZ_OK||info.size_filename>MaxName||std::strlen(name.data())!=info.size_filename){error="Un miembro ZIP tiene un nombre inválido.";return false;}
        std::vector<std::string> parts;bool dir=false;if(!components(name.data(),parts,dir)){error="El ZIP contiene una ruta de miembro no admitida.";return false;}const unsigned kind=unsigned(info.external_fa>>16)&0170000u;const bool directory=dir||kind==0040000u||(info.external_fa&0x10u);if((kind&&kind!=0100000u&&kind!=0040000u)||(info.flag&0x41u)||(info.compression_method!=0&&info.compression_method!=8)||info.uncompressed_size>MaxMember||info.compressed_size>MaxArchive||(directory&&info.uncompressed_size)){error="El ZIP contiene enlaces, cifrado o un miembro no admitido.";return false;}if(info.uncompressed_size>MaxExpanded-expanded){error="Los catálogos superan 256 MiB de datos expandidos.";return false;}expanded+=info.uncompressed_size;
        Member member;member.input=index;member.origin=name.data();member.info=info;
        // Our canonical credit records keep their original path in the ZIP comment.
        // Reusing it preserves distinct empty author files and makes repeated unions stable.
        if(parts.size()==2&&parts[0]=="history-credits"&&info.size_file_comment&&info.size_file_comment<=MaxName){std::array<char,MaxName+1> comment{};if(unzGetCurrentFileInfo64(file,nullptr,nullptr,0,nullptr,0,comment.data(),uLong(comment.size()))!=UNZ_OK){error="No se pudieron leer los créditos del catálogo.";return false;}std::vector<std::string> original;bool originalDir=false;if(std::strlen(comment.data())==info.size_file_comment&&components(comment.data(),original,originalDir)&&!originalDir)member.origin=comment.data();}
        if(unzGetFilePos64(file,&member.position)!=UNZ_OK||!verifyCurrent(file,info,member.contentHash,error))return false;
        if(!directory){member.output=key(parts);if(!member.output.empty()){if(!info.uncompressed_size||!seen.insert(member.output).second){error="El catálogo contiene un cheat vacío o un TID/BID duplicado.";return false;}cheats[member.output]=member;if(cheats.size()>MaxCheats){error="La unión supera 20.000 archivos de cheats.";return false;}}
            else if(creditName(parts)){char digest[64];std::snprintf(digest,sizeof(digest),"%016llX-%08lX-%08llX",static_cast<unsigned long long>(creditIdentity(member)),static_cast<unsigned long>(info.crc),static_cast<unsigned long long>(info.uncompressed_size));auto&same=creditKeys[digest];bool duplicate=false;std::string candidate;
                if(!same.empty()){if(!memberBytes(inputs,member,candidate,error))return false;for(size_t old:same){if(credits[old].origin!=member.origin)continue;std::string prior;if(!memberBytes(inputs,credits[old],prior,error))return false;if(prior==candidate){duplicate=true;break;}}}
                if(!duplicate){if(credits.size()>=MaxCredits){error="El catálogo contiene demasiados archivos de créditos.";return false;}member.output="history-credits/"+std::string(digest)+(same.empty()?"":"-"+std::to_string(same.size()))+".txt";member.credit=true;same.push_back(credits.size());credits.push_back(std::move(member));}
                // Exact-byte credit comparisons may have moved this ZIP cursor.
                if(unzGoToFilePos64(file,&member.position)!=UNZ_OK){error="No se pudo volver al miembro de créditos revisado.";return false;}
            }}
        result=unzGoToNextFile(file);
    }
    if(result!=UNZ_END_OF_LIST_OF_FILE){error="El ZIP no terminó en su último miembro declarado.";return false;}return true;
}
struct Output{FILE*file=nullptr;bool failed=false;struct stat identity{};};
voidpf ZCALLBACK outputOpen(voidpf opaque,const void*,int){return opaque;}
uLong ZCALLBACK outputRead(voidpf,voidpf stream,void*buffer,uLong size){auto&o=*static_cast<Output*>(stream);return uLong(fread(buffer,1,size,o.file));}
uLong ZCALLBACK outputWrite(voidpf,voidpf stream,const void*buffer,uLong size){auto&o=*static_cast<Output*>(stream);const auto at=ftell(o.file);if(at<0||uint64_t(at)>MaxArchive||size>MaxArchive-uint64_t(at)){o.failed=true;return 0;}const auto n=fwrite(buffer,1,size,o.file);if(n!=size)o.failed=true;return uLong(n);}
ZPOS64_T ZCALLBACK outputTell(voidpf,voidpf stream){auto&o=*static_cast<Output*>(stream);const auto at=ftell(o.file);if(at<0){o.failed=true;return ZPOS64_T(-1);}return ZPOS64_T(at);}
long ZCALLBACK outputSeek(voidpf,voidpf stream,ZPOS64_T offset,int origin){auto&o=*static_cast<Output*>(stream);if(offset>MaxArchive){o.failed=true;return -1;}const int mode=origin==ZLIB_FILEFUNC_SEEK_SET?SEEK_SET:origin==ZLIB_FILEFUNC_SEEK_CUR?SEEK_CUR:origin==ZLIB_FILEFUNC_SEEK_END?SEEK_END:-1;if(mode<0||fseek(o.file,long(offset),mode)!=0){o.failed=true;return -1;}const auto at=ftell(o.file);if(at<0||uint64_t(at)>MaxArchive){o.failed=true;return -1;}return 0;}
int ZCALLBACK outputClose(voidpf,voidpf stream){auto&o=*static_cast<Output*>(stream);bool ok=fflush(o.file)==0&&fsync(fileno(o.file))==0;if(fclose(o.file)!=0)ok=false;o.file=nullptr;o.failed=o.failed||!ok;return o.failed?-1:0;}
int ZCALLBACK outputError(voidpf,voidpf stream){auto&o=*static_cast<Output*>(stream);return o.failed||!o.file||ferror(o.file);}
bool copyMember(zipFile output,Inputs&inputs,const Member&member,std::string&error){const auto input=inputs.items[member.input].file;unz_file_info64 info{};if(unzGoToFilePos64(input,&member.position)!=UNZ_OK||unzGetCurrentFileInfo64(input,&info,nullptr,0,nullptr,0,nullptr,0)!=UNZ_OK||info.crc!=member.info.crc||info.uncompressed_size!=member.info.uncompressed_size||unzOpenCurrentFile(input)!=UNZ_OK){error="Un miembro del catálogo cambió durante la unión.";return false;}zip_fileinfo metadata{};metadata.external_fa=0100644u<<16;metadata.dosDate=info.dosDate;bool opened=zipOpenNewFileInZip64(output,member.output.c_str(),&metadata,nullptr,0,nullptr,0,member.credit?member.origin.c_str():nullptr,Z_DEFLATED,Z_BEST_SPEED,0)==ZIP_OK;bool ok=opened;std::array<char,32768> buffer{};int n=0;uint64_t total=0;while(ok&&(n=unzReadCurrentFile(input,buffer.data(),unsigned(buffer.size())))>0){total+=uint64_t(n);ok=total<=MaxMember&&zipWriteInFileInZip(output,buffer.data(),unsigned(n))==ZIP_OK;}if(n<0||unzCloseCurrentFile(input)!=UNZ_OK||total!=info.uncompressed_size)ok=false;if(opened&&zipCloseFileInZip(output)!=ZIP_OK)ok=false;if(!ok)error="No se pudo copiar y verificar un miembro al catálogo combinado.";return ok;}
void removeOwnedOutput(const std::string&path,const Output&o){struct stat st{};if(lstat(path.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_dev==o.identity.st_dev&&st.st_ino==o.identity.st_ino)std::remove(path.c_str());}
}
bool mergeCheatArchives(const std::vector<std::string>&paths,const std::string&output,std::string&error){error.clear();if(paths.empty()||paths.size()>8){error="La unión necesita entre uno y ocho catálogos.";return false;}Inputs inputs;inputs.items.reserve(paths.size());std::map<std::string,Member> cheats;std::vector<Member> credits;std::map<std::string,std::vector<size_t>> creditKeys;uint64_t expanded=0;
    for(size_t i=0;i<paths.size();++i){Input input;input.path=paths[i];if(!diskPath(input.path,false,input.before,error)||input.before.st_size<0||uint64_t(input.before.st_size)>MaxArchive){if(error.empty())error="Un catálogo de entrada supera 64 MiB.";return false;}input.file=unzOpen64(input.path.c_str());if(!input.file){error="Un catálogo de entrada no es un ZIP válido.";return false;}inputs.items.push_back(input);if(!scan(inputs,i,cheats,credits,creditKeys,expanded,error))return false;}
    if(cheats.empty()){error="La unión de catálogos no contiene ningún cheat utilizable.";return false;}struct stat existing{};if(!diskPath(output,true,existing,error))return false;if(lstat(output.c_str(),&existing)==0||errno!=ENOENT){error="El catálogo de salida ya existe; no se sobrescribió.";return false;}int flags=O_RDWR|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=open(output.c_str(),flags,0600);if(fd<0){error="No se pudo crear el catálogo combinado.";return false;}Output out;if(fstat(fd,&out.identity)!=0){close(fd);error="No se pudo verificar el archivo nuevo de catálogo.";return false;}out.file=fdopen(fd,"w+b");if(!out.file){close(fd);removeOwnedOutput(output,out);error="No se pudo abrir la escritura del catálogo combinado.";return false;}zlib_filefunc64_def io{};io.zopen64_file=outputOpen;io.zread_file=outputRead;io.zwrite_file=outputWrite;io.ztell64_file=outputTell;io.zseek64_file=outputSeek;io.zclose_file=outputClose;io.zerror_file=outputError;io.opaque=&out;zipFile zip=zipOpen2_64(output.c_str(),APPEND_STATUS_CREATE,nullptr,&io);bool ok=zip!=nullptr;if(ok)for(const auto&entry:cheats)if(!copyMember(zip,inputs,entry.second,error)){ok=false;break;}if(ok)for(const auto&entry:credits)if(!copyMember(zip,inputs,entry,error)){ok=false;break;}if(zip&&zipClose(zip,"NinMagic canonical TID/BID union; later archives take precedence.")!=ZIP_OK)ok=false;if(out.file){if(fclose(out.file)!=0)ok=false;out.file=nullptr;}if(out.failed)ok=false;
    for(const auto&input:inputs.items){struct stat now{};if(!diskPath(input.path,false,now,error)||now.st_dev!=input.before.st_dev||now.st_ino!=input.before.st_ino||now.st_size!=input.before.st_size||now.st_mtime!=input.before.st_mtime){ok=false;if(error.empty())error="Un catálogo de entrada cambió durante la unión.";break;}}
    struct stat outputStat{};if(lstat(output.c_str(),&outputStat)!=0||!S_ISREG(outputStat.st_mode)||S_ISLNK(outputStat.st_mode)||outputStat.st_dev!=out.identity.st_dev||outputStat.st_ino!=out.identity.st_ino||outputStat.st_size<0||uint64_t(outputStat.st_size)>MaxArchive)ok=false;if(!ok){removeOwnedOutput(output,out);if(error.empty())error="No se pudo completar el catálogo combinado dentro de sus límites.";}return ok;
}
}

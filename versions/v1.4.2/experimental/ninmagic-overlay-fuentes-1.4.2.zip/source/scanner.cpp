#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "scanner.hpp"
#include "scan_delta.hpp"
#include "model.hpp"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <new>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr size_t Chunk=64*1024,MaxRegions=4096,MaxMetadata=1024*1024;
enum class RecordCodec { Fixed12, DeltaIndex };
struct Stored {ScanSession session;uint32_t snapshotCrc=0,maskCrc=0,recordsCrc=0;RecordCodec recordsCodec=RecordCodec::Fixed12;uint64_t recordsBytes=0;char slot='a';const std::vector<ScanCandidate>*borrowed=nullptr;};
std::function<bool(uint64_t,uint64_t)> observer;
ScanCoreStats coreStats;uint64_t callbackNs=0;
uint64_t tickNs(){return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());}
uint64_t since(uint64_t start){const auto now=tickNs();return now>=start?now-start:0;}
size_t payloadRead(void*data,size_t size,FILE*f){const auto t=tickNs();const auto n=fread(data,1,size,f);++coreStats.readCalls;coreStats.ioNs+=since(t);return n;}
size_t payloadWrite(const void*data,size_t size,FILE*f){const auto t=tickNs();const auto n=fwrite(data,1,size,f);++coreStats.writeCalls;coreStats.ioNs+=since(t);return n;}
struct ComparisonTimer {uint64_t started=tickNs(),io=coreStats.ioNs,callbacks=callbackNs;~ComparisonTimer(){const auto elapsed=since(started),other=(coreStats.ioNs-io)+(callbackNs-callbacks);if(elapsed>other)coreStats.comparisonNs+=elapsed-other;}};
#ifdef NC_SCANNER_TEST
std::function<bool(const std::string&,const std::string&)> markerFailure;
struct IoStats {uint64_t snapshotRead=0,snapshotWrite=0,maskRead=0,maskWrite=0,recordsRead=0,recordsWrite=0;};
IoStats ioStats;
#define NC_SCAN_IO(field,bytes) ((ioStats.field+=uint64_t(bytes)),(coreStats.field##Bytes+=uint64_t(bytes)))
#else
#define NC_SCAN_IO(field,bytes) (coreStats.field##Bytes+=uint64_t(bytes))
#endif
std::string scanRoot(){
#ifdef NC_SCANNER_TEST
    const char *value=std::getenv("NC_SCANNER_ROOT");return value?value:"scanner-test";
#elif defined(NC_SCANNER_OVERLAY)
    return "sdmc:/config/NinMagicCheats/scanner-overlay";
#else
    return "sdmc:/config/NinMagicCheats/scanner";
#endif
}
bool pathStat(const std::string &path,struct stat &st){return lstat(path.c_str(),&st)==0;}
bool regularFile(const std::string &path,uint64_t maximum){struct stat st{};return pathStat(path,st)&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=maximum;}
bool directory(const std::string &path){struct stat st{};if(pathStat(path,st))return S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);if(errno!=ENOENT)return false;
#ifdef _WIN32
    return mkdir(path.c_str())==0;
#else
    return mkdir(path.c_str(),0777)==0;
#endif
}
bool ensureRoot(std::string &error){
#ifndef NC_SCANNER_TEST
    if(!directory("sdmc:/config")||!directory("sdmc:/config/NinMagicCheats")){error="No se puede abrir la carpeta de NinMagic Cheats.";return false;}
#endif
    if(!directory(scanRoot())){error="No se puede abrir la carpeta privada del buscador.";return false;}return true;
}
bool removeKnown(const std::string &path){struct stat st{};if(!pathStat(path,st))return errno==ENOENT;return S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&unlink(path.c_str())==0;}
std::string file(char slot,const char *suffix){return scanRoot()+"/session-"+slot+suffix;}
bool readFile(const std::string &path,std::vector<uint8_t> &data,size_t limit){data.clear();if(!regularFile(path,limit))return false;struct stat allocation{};if(pathStat(path,allocation)&&allocation.st_size>0&&uint64_t(allocation.st_size)<=limit)data.reserve(size_t(allocation.st_size));FILE *f=fopen(path.c_str(),"rb");if(!f)return false;std::array<uint8_t,4096> buffer{};size_t count;while((count=fread(buffer.data(),1,buffer.size(),f))){if(data.size()+count>limit){fclose(f);return false;}data.insert(data.end(),buffer.begin(),buffer.begin()+count);}bool ok=!ferror(f);fclose(f);return ok;}
bool closeWritten(FILE *f){const auto t=tickNs();bool ok=fflush(f)==0;if(ok)ok=fsync(fileno(f))==0;if(fclose(f)!=0)ok=false;coreStats.ioNs+=since(t);return ok;}
bool observe(uint64_t done,uint64_t total,std::string &error){if(!observer)return true;const auto t=tickNs();const bool ok=observer(done,total);callbackNs+=since(t);if(ok)return true;error="Búsqueda cancelada. Se conserva la búsqueda anterior.";return false;}
bool writeFile(const std::string &path,const void *data,size_t size){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;FILE *f=fopen(path.c_str(),"wb");if(!f)return false;bool ok=fwrite(data,1,size,f)==size;return closeWritten(f)&&ok;}
char activeSlot(){std::vector<uint8_t> bytes;for(const char *name:{"active.txt","active.previous"})if(readFile(scanRoot()+"/"+name,bytes,8)&&bytes.size()==2&&(bytes[0]=='a'||bytes[0]=='b')&&bytes[1]=='\n')return char(bytes[0]);return 'a';}
unsigned width(ScanValueType type){switch(type){case ScanValueType::U8:return 1;case ScanValueType::U16:return 2;case ScanValueType::U32:case ScanValueType::F32:return 4;}return 0;}
std::string upper(std::string value){for(char &c:value)if(c>='a'&&c<='f')c=char(c-'a'+'A');return value;}
bool hexBuild(const std::string &value){return value.size()==64&&value.find_first_not_of("0123456789abcdefABCDEF")==std::string::npos&&value.find_first_not_of('0')!=std::string::npos;}
bool endOf(uint64_t start,uint64_t size,uint64_t &end){if(!size||start>UINT64_MAX-size)return false;end=start+size;return true;}
bool contained(uint64_t start,uint64_t size,uint64_t base,uint64_t length){uint64_t end=0,limit=0;return endOf(start,size,end)&&endOf(base,length,limit)&&start>=base&&end<=limit;}
bool identityValid(const ScanIdentity &id){
    uint64_t mainEnd=0,heapEnd=0,aliasEnd=0;
    if(!id.pid||id.title<0x0100000000010000ULL||!hexBuild(id.fullBuildId)||!endOf(id.mainBase,id.mainSize,mainEnd))return false;
    if(id.heapSize&&(!endOf(id.heapBase,id.heapSize,heapEnd)||(id.mainBase<heapEnd&&id.heapBase<mainEnd)))return false;
    // A missing alias span is retained only for legacy identities. Partial,
    // overflowing or overlapping spans cannot name an unambiguous VM base.
    if(!id.aliasBase&&!id.aliasSize)return true;
    if(!id.aliasBase||!id.aliasSize||!endOf(id.aliasBase,id.aliasSize,aliasEnd))return false;
    if(id.mainBase<aliasEnd&&id.aliasBase<mainEnd)return false;
    return !id.heapSize||id.heapBase>=aliasEnd||id.aliasBase>=heapEnd;
}
bool sameIdentity(const ScanIdentity &a,const ScanIdentity &b){return a.pid==b.pid&&a.title==b.title&&upper(a.fullBuildId)==upper(b.fullBuildId)&&a.mainBase==b.mainBase&&a.mainSize==b.mainSize&&a.heapBase==b.heapBase&&a.heapSize==b.heapSize&&a.aliasBase==b.aliasBase&&a.aliasSize==b.aliasSize;}
bool belongs(const ScanIdentity &id,uint64_t address,uint64_t size){return contained(address,size,id.mainBase,id.mainSize)||contained(address,size,id.heapBase,id.heapSize)||contained(address,size,id.aliasBase,id.aliasSize);}
bool parseValue(ScanValueType type,const std::string &text,uint32_t &bits,std::string &error){
    std::string value=text;auto first=value.find_first_not_of(" \t\r\n");if(first==std::string::npos){error="Escribe el valor que aparece en el juego.";return false;}value=value.substr(first,value.find_last_not_of(" \t\r\n")-first+1);char *end=nullptr;errno=0;
    if(type==ScanValueType::F32){float number=std::strtof(value.c_str(),&end);if(errno==ERANGE||end!=value.c_str()+value.size()||!std::isfinite(number)){error="El valor decimal debe ser un número finito de 32 bits.";return false;}std::memcpy(&bits,&number,4);return true;}
    if(!width(type)||value[0]=='-'||value[0]=='+'){error="El valor entero debe ser positivo o cero.";return false;}
    int base=value.size()>2&&value[0]=='0'&&(value[1]=='x'||value[1]=='X')?16:10;unsigned long long number=std::strtoull(value.c_str(),&end,base);uint64_t maximum=width(type)==1?255:width(type)==2?65535:UINT32_MAX;
    if(errno==ERANGE||end!=value.c_str()+value.size()||number>maximum){error="El valor no cabe en el tipo de número elegido.";return false;}bits=uint32_t(number);return true;
}
uint32_t bitsAt(const uint8_t *bytes,unsigned size){uint32_t value=0;for(unsigned i=0;i<size;++i)value|=uint32_t(bytes[i])<<(i*8);return value;}
bool finiteBits(uint32_t bits){float number;std::memcpy(&number,&bits,4);return std::isfinite(number);}
bool matches(ScanValueType type,ScanCompare compare,uint32_t before,uint32_t after,uint32_t target){
    if(type==ScanValueType::F32){if(!finiteBits(after)||(compare!=ScanCompare::Exact&&!finiteBits(before)))return false;float a,b,t;std::memcpy(&a,&before,4);std::memcpy(&b,&after,4);std::memcpy(&t,&target,4);switch(compare){case ScanCompare::Exact:return b==t;case ScanCompare::Changed:return b!=a;case ScanCompare::Unchanged:return b==a;case ScanCompare::Increased:return b>a;case ScanCompare::Decreased:return b<a;}}
    switch(compare){case ScanCompare::Exact:return after==target;case ScanCompare::Changed:return after!=before;case ScanCompare::Unchanged:return after==before;case ScanCompare::Increased:return after>before;case ScanCompare::Decreased:return after<before;}return false;
}
bool prepare(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,ScanSession &session,std::string &error){
    if(!identityValid(identity)||!width(type)){error="El proceso o su Build ID no se han verificado.";return false;}if(regions.empty()||regions.size()>MaxRegions){error="La lista de regiones de memoria no es válida.";return false;}
    auto sorted=regions;std::sort(sorted.begin(),sorted.end(),[](const auto &a,const auto &b){return a.address<b.address;});session={};session.identity=identity;session.identity.fullBuildId=upper(identity.fullBuildId);session.type=type;uint64_t previousEnd=0;const unsigned size=width(type);
    for(const auto &region:sorted){if(!region.writable||!region.size)continue;uint64_t end=0;if(!endOf(region.address,region.size,end)||!belongs(identity,region.address,region.size)||region.address<previousEnd){error="Las regiones escribibles se solapan o quedan fuera de MAIN/HEAP/ALIAS.";return false;}previousEnd=end;uint64_t begin=region.address;if(begin%size){uint64_t add=size-begin%size;if(begin>UINT64_MAX-add){error="Dirección de memoria fuera de rango.";return false;}begin+=add;}end-=end%size;if(begin>=end)continue;const uint64_t bytes=end-begin;if(session.totalBytes>UINT64_MAX-bytes){error="Tamaño de memoria fuera de rango.";return false;}session.totalBytes+=bytes;const uint64_t accepted=std::min(bytes,ScanMaxBytes-session.coveredBytes);if(accepted){session.regions.push_back({begin,accepted,true});session.coveredBytes+=accepted;}}
    session.partial=session.coveredBytes<session.totalBytes;if(!session.coveredBytes){error="No hay memoria escribible de MAIN/HEAP/ALIAS en el intervalo elegido.";return false;}return true;
}
bool candidateInside(const ScanSession &session,const ScanCandidate &candidate){unsigned bytes=width(session.type);if(!bytes||candidate.address%bytes)return false;const auto it=std::lower_bound(session.regions.begin(),session.regions.end(),candidate.address,[](const auto&r,uint64_t at){return r.address+r.size<=at;});return it!=session.regions.end()&&contained(candidate.address,bytes,it->address,it->size);}
void collectCandidate(ScanSession &session,uint64_t address,uint32_t bits){++session.candidateCount;if(session.candidateCount<=ScanMaterializeCandidates){if(session.candidates.empty())session.candidates.reserve(ScanMaterializeCandidates);session.candidates.push_back({address,bits});}else if(session.candidateCount==ScanMaterializeCandidates+1)std::vector<ScanCandidate>().swap(session.candidates);}
ScanSession metadataOnly(const ScanSession&s){ScanSession out;out.identity=s.identity;out.type=s.type;out.regions=s.regions;out.coveredBytes=s.coveredBytes;out.totalBytes=s.totalBytes;out.rounds=s.rounds;out.partial=s.partial;out.ready=s.ready;out.storage=s.storage;out.uniformBits=s.uniformBits;return out;}
uint64_t maskBytes(const ScanSession &s){return (s.coveredBytes/width(s.type)+7)/8;}
class MaskWriter {
    FILE *handle=nullptr;std::array<uint8_t,8192> buffer{};size_t used=0;uint8_t byte=0;unsigned bit=0;uint32_t crc=0;uint64_t zeroSinceCheckpoint=0;
    bool flush(){if(!used)return true;if(payloadWrite(buffer.data(),used,handle)!=used)return false;NC_SCAN_IO(maskWrite,used);crc=uint32_t(crc32(crc,buffer.data(),uInt(used)));used=0;return true;}
public:
    ~MaskWriter(){if(handle)fclose(handle);}
    void close(){if(handle){fclose(handle);handle=nullptr;}}
    bool open(const std::string &path){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;handle=fopen(path.c_str(),"wb");return handle;}
    bool put(bool value){if(value)byte|=uint8_t(1u<<bit);if(++bit==8){buffer[used++]=byte;byte=0;bit=0;if(used==buffer.size())return flush();}return true;}
    bool zeros(uint64_t count,const std::function<bool()>&checkpoint={}){
        while(bit&&count){if(!put(false))return false;--count;}
        uint64_t bytes=count/8;count%=8;
        while(bytes){const size_t n=size_t(std::min<uint64_t>(bytes,buffer.size()-used));std::memset(buffer.data()+used,0,n);used+=n;bytes-=n;zeroSinceCheckpoint+=n;if(used==buffer.size()&&!flush())return false;if(zeroSinceCheckpoint>=Chunk){zeroSinceCheckpoint=0;if(checkpoint&&!checkpoint())return false;}}
        while(count--){if(!put(false))return false;}return true;
    }
    bool finish(uint32_t &result){if(bit)buffer[used++]=byte;bool ok=flush();FILE *f=handle;handle=nullptr;if(!closeWritten(f))ok=false;result=crc;return ok;}
};
class MaskReader {
    FILE *handle=nullptr;std::array<uint8_t,8192> buffer{};size_t at=0,count=0;uint8_t byte=0;unsigned bits=0;uint32_t crc=0;uint64_t readBytes=0;
public:
    ~MaskReader(){if(handle)fclose(handle);}
    bool open(const std::string &path){handle=fopen(path.c_str(),"rb");return handle;}
    bool get(bool &value){if(!bits){if(at==count){count=payloadRead(buffer.data(),buffer.size(),handle);NC_SCAN_IO(maskRead,count);at=0;if(!count)return false;readBytes+=count;crc=uint32_t(crc32(crc,buffer.data(),uInt(count)));}byte=buffer[at++];bits=8;}value=byte&1;byte>>=1;--bits;return true;}
    bool nextSet(uint64_t remaining,uint64_t &skipped,bool &found,uint64_t done,uint64_t total,std::string &error){
        skipped=0;found=false;
        while(remaining){
            if(!bits){
                if(at==count){if(readBytes%Chunk==0&&!observe(done,total,error))return false;count=payloadRead(buffer.data(),buffer.size(),handle);NC_SCAN_IO(maskRead,count);at=0;if(!count)return false;readBytes+=count;crc=uint32_t(crc32(crc,buffer.data(),uInt(count)));}
                if(remaining>=64&&count-at>=8){uint64_t word=0;std::memcpy(&word,buffer.data()+at,8);if(!word){at+=8;remaining-=64;skipped+=64;continue;}}
                byte=buffer[at++];bits=8;
            }
            const unsigned take=unsigned(std::min<uint64_t>(remaining,bits));
            const unsigned valid=unsigned(byte)&((1u<<take)-1u);
            if(valid){const unsigned skip=unsigned(__builtin_ctz(valid));byte>>=skip+1;bits-=skip+1;skipped+=skip;found=true;return true;}
            byte>>=take;bits-=take;remaining-=take;skipped+=take;
        }return true;
    }
    bool finish(uint32_t expected,uint64_t size){return !byte&&at==count&&readBytes==size&&crc==expected&&fgetc(handle)==EOF&&!ferror(handle);}
};
void put32(std::vector<uint8_t> &out,uint32_t value){for(unsigned i=0;i<4;++i)out.push_back(uint8_t(value>>(i*8)));}
void put64(std::vector<uint8_t> &out,uint64_t value){for(unsigned i=0;i<8;++i)out.push_back(uint8_t(value>>(i*8)));}
class Decoder{const std::vector<uint8_t>&data;size_t at=0;public:explicit Decoder(const std::vector<uint8_t>&d):data(d){}bool bytes(void *target,size_t n){if(n>data.size()-at)return false;std::memcpy(target,data.data()+at,n);at+=n;return true;}bool u32(uint32_t&v){uint8_t b[4];if(!bytes(b,4))return false;v=bitsAt(b,4);return true;}bool u64(uint64_t&v){uint8_t b[8];if(!bytes(b,8))return false;v=0;for(unsigned i=0;i<8;++i)v|=uint64_t(b[i])<<(i*8);return true;}bool done()const{return at==data.size();}};
std::vector<uint8_t> serialize(const Stored &stored){const auto &s=stored.session;std::vector<uint8_t> data={'N','M','C','S','C','N','5',0};data.reserve(256+s.regions.size()*16+s.candidates.size()*12);put32(data,5);put32(data,(s.baseline?1:0)|(s.partial?2:0)|(s.streamed?4:0));put32(data,unsigned(s.type));put32(data,s.rounds);put64(data,s.identity.pid);put64(data,s.identity.title);data.insert(data.end(),s.identity.fullBuildId.begin(),s.identity.fullBuildId.end());for(uint64_t value:{s.identity.mainBase,s.identity.mainSize,s.identity.heapBase,s.identity.heapSize,s.identity.aliasBase,s.identity.aliasSize,s.coveredBytes,s.totalBytes})put64(data,value);put32(data,unsigned(s.regions.size()));put32(data,unsigned(s.candidates.size()));put32(data,stored.snapshotCrc);put32(data,stored.maskCrc);put64(data,s.candidateCount);put32(data,unsigned(s.storage));put32(data,s.uniformBits);put32(data,stored.recordsCrc);put32(data,unsigned(stored.recordsCodec));put64(data,stored.recordsBytes);for(const auto &r:s.regions){put64(data,r.address);put64(data,r.size);}for(const auto &c:s.candidates){put64(data,c.address);put32(data,c.valueBits);}put32(data,uint32_t(crc32(0,data.data(),uInt(data.size()))));return data;}
bool sameSessionState(const ScanSession&,const ScanSession&);
bool deserialize(std::vector<uint8_t> data,Stored &stored,const ScanSession*expected=nullptr){
    if(data.size()<176||data.size()>MaxMetadata)return false;
    uint32_t crc=bitsAt(data.data()+data.size()-4,4);data.resize(data.size()-4);if(crc32(0,data.data(),uInt(data.size()))!=crc)return false;Decoder input(data);char magic[8];uint32_t version=0,flags=0,type=0,regions=0,count=0;auto &s=stored.session;s={};char build[64];
    if(!input.bytes(magic,8)||std::memcmp(magic,"NMCSCN",6)!=0||magic[7]!=0||!input.u32(version)||(version<1||version>5)||magic[6]!=char('0'+version)||!input.u32(flags)||flags>(version==1?3u:7u)||!input.u32(type)||type>3||!input.u32(s.rounds)||!s.rounds||!input.u64(s.identity.pid)||!input.u64(s.identity.title)||!input.bytes(build,64))return false;
    s.identity.fullBuildId.assign(build,64);s.type=ScanValueType(type);s.baseline=flags&1;s.partial=flags&2;s.streamed=flags&4;
    if(!input.u64(s.identity.mainBase)||!input.u64(s.identity.mainSize)||!input.u64(s.identity.heapBase)||!input.u64(s.identity.heapSize))return false;
    if(version>=3&&(!input.u64(s.identity.aliasBase)||!input.u64(s.identity.aliasSize)))return false;
    if(!input.u64(s.coveredBytes)||!input.u64(s.totalBytes)||!input.u32(regions)||!input.u32(count)||!input.u32(stored.snapshotCrc))return false;
    if(version>=2){if(!input.u32(stored.maskCrc)||!input.u64(s.candidateCount))return false;}else{s.candidateCount=s.baseline?0:count;stored.maskCrc=0;}
    if(version>=4){uint32_t storage=0;if(!input.u32(storage)||storage>unsigned(ScanStorage::UniformMask)||!input.u32(s.uniformBits)||!input.u32(stored.recordsCrc))return false;s.storage=ScanStorage(storage);}
    else{s.storage=s.baseline?ScanStorage::DenseSnapshot:ScanStorage::Memory;s.uniformBits=stored.recordsCrc=0;}
    if(version>=5){uint32_t codec=0;if(!input.u32(codec)||codec>1||!input.u64(stored.recordsBytes))return false;stored.recordsCodec=RecordCodec(codec);}
    else{stored.recordsCodec=RecordCodec::Fixed12;stored.recordsBytes=s.storage==ScanStorage::SparseDisk?s.candidateCount*12:0;}
    if(!regions||regions>MaxRegions||count>ScanMaxCandidates||!identityValid(s.identity)||s.identity.fullBuildId!=upper(s.identity.fullBuildId)||!s.coveredBytes||s.coveredBytes>ScanMaxBytes||s.coveredBytes>s.totalBytes||s.partial!=(s.coveredBytes<s.totalBytes)||(s.baseline&&count)||s.candidateCount>s.coveredBytes/width(s.type)||(s.streamed&&(!s.baseline||s.candidateCount<=(version<5?ScanMaxCandidates:ScanMaterializeCandidates)))||(!s.streamed&&s.candidateCount!=(s.baseline?0:count)))return false;
    if((s.storage==ScanStorage::Memory)==s.baseline)return false;
    if((s.storage==ScanStorage::SparseDisk||s.storage==ScanStorage::UniformMask)&&!s.streamed)return false;
    if(s.storage==ScanStorage::SparseDisk){
        if((s.candidateCount>s.coveredBytes/24&&(version<5||s.candidateCount>ScanMaxCandidates))||stored.snapshotCrc||stored.maskCrc||s.uniformBits||stored.recordsBytes>ScanMaxBytes/2)return false;
        if(stored.recordsCodec==RecordCodec::Fixed12){if(stored.recordsBytes!=s.candidateCount*12)return false;}
        else if(stored.recordsBytes<12+s.candidateCount*(1+width(s.type))||stored.recordsBytes>12+s.candidateCount*(5+width(s.type)))return false;
    }else if(stored.recordsBytes||stored.recordsCodec!=RecordCodec::Fixed12)return false;
    if(s.storage==ScanStorage::UniformMask&&(s.type==ScanValueType::F32||stored.snapshotCrc||stored.recordsCrc||(width(s.type)<4&&s.uniformBits>=(1u<<(width(s.type)*8)))))return false;
    if(s.storage!=ScanStorage::UniformMask&&s.uniformBits)return false;
    s.regions.reserve(regions);
    uint64_t previousEnd=0,sum=0;const unsigned step=width(s.type);for(uint32_t i=0;i<regions;++i){ScanRegion r;r.writable=true;uint64_t end=0;if(!input.u64(r.address)||!input.u64(r.size)||!r.size||r.address%step||r.size%step||!endOf(r.address,r.size,end)||!belongs(s.identity,r.address,r.size)||r.address<previousEnd||r.size>ScanMaxBytes-sum)return false;previousEnd=end;sum+=r.size;s.regions.push_back(r);}if(sum!=s.coveredBytes)return false;
    const bool borrow=expected&&count==expected->candidates.size()&&s.storage==ScanStorage::Memory&&sameSessionState(*expected,s);stored.borrowed=borrow?&expected->candidates:nullptr;if(!borrow)s.candidates.reserve(count);
    uint64_t previous=0;for(uint32_t i=0;i<count;++i){ScanCandidate c;if(!input.u64(c.address)||!input.u32(c.valueBits)||!candidateInside(s,c)||(i&&c.address<=previous)||(s.type==ScanValueType::F32&&!finiteBits(c.valueBits))||(step<4&&c.valueBits>=(1u<<(step*8))))return false;previous=c.address;if(borrow){if(c.address!=expected->candidates[i].address||c.valueBits!=expected->candidates[i].valueBits)return false;}else s.candidates.push_back(c);}s.ready=input.done();return s.ready;
}
bool loadStoredAt(const ScanIdentity &identity,char slot,Stored &stored,std::string &error,const ScanSession*expected=nullptr){
    if(!identityValid(identity)){error="El juego abierto no tiene un proceso y Build ID verificados.";return false;}stored.slot=slot;std::vector<uint8_t> bytes;if(!readFile(file(stored.slot,".dat"),bytes,MaxMetadata)||!deserialize(std::move(bytes),stored,expected)){error="No hay una búsqueda guardada válida. Inicia una búsqueda nueva.";return false;}if(!sameIdentity(stored.session.identity,identity)){error="El proceso o el alcance MAIN/HEAP/ALIAS cambió. Inicia una búsqueda nueva; la anterior se conserva sin ampliar sus direcciones.";return false;}
    const auto &s=stored.session;struct stat st{};
    if(s.storage==ScanStorage::DenseSnapshot&&(!regularFile(file(stored.slot,".snapshot"),ScanMaxBytes)||!pathStat(file(stored.slot,".snapshot"),st)||uint64_t(st.st_size)!=s.coveredBytes)){error="La referencia de memoria guardada está incompleta.";return false;}
    if((s.storage==ScanStorage::UniformMask||(s.storage==ScanStorage::DenseSnapshot&&s.streamed))&&(!regularFile(file(stored.slot,".mask"),ScanMaxBytes/8)||!pathStat(file(stored.slot,".mask"),st)||uint64_t(st.st_size)!=maskBytes(s))){error="La lista de coincidencias guardada está incompleta.";return false;}
    if(s.storage==ScanStorage::SparseDisk&&(!regularFile(file(stored.slot,".records"),ScanMaxBytes/2)||!pathStat(file(stored.slot,".records"),st)||uint64_t(st.st_size)!=stored.recordsBytes)){error="Los candidatos guardados están incompletos.";return false;}
    return true;
}
bool loadStored(const ScanIdentity &identity,Stored &stored,std::string &error,const ScanSession*expected=nullptr){return loadStoredAt(identity,activeSlot(),stored,error,expected);}
bool sameSessionState(const ScanSession &a,const ScanSession &b){if(!a.ready||!sameIdentity(a.identity,b.identity)||a.type!=b.type||a.rounds!=b.rounds||a.baseline!=b.baseline||a.streamed!=b.streamed||a.partial!=b.partial||a.storage!=b.storage||a.uniformBits!=b.uniformBits||a.coveredBytes!=b.coveredBytes||a.totalBytes!=b.totalBytes||a.candidateCount!=b.candidateCount||a.regions.size()!=b.regions.size())return false;for(size_t i=0;i<a.regions.size();++i)if(a.regions[i].address!=b.regions[i].address||a.regions[i].size!=b.regions[i].size||a.regions[i].writable!=b.regions[i].writable)return false;return true;}
bool sameSession(const ScanSession &a,const ScanSession &b){if(!sameSessionState(a,b)||a.candidates.size()!=b.candidates.size())return false;for(size_t i=0;i<a.candidates.size();++i)if(a.candidates[i].address!=b.candidates[i].address||a.candidates[i].valueBits!=b.candidates[i].valueBits)return false;return true;}
bool renameMarker(const std::string &from,const std::string &to){
#ifdef NC_SCANNER_TEST
    if(markerFailure&&markerFailure(from,to)){errno=EIO;return false;}
#endif
    return rename(from.c_str(),to.c_str())==0;
}
bool activateSlot(char slot,std::string &error,uint64_t total){
    if(!observe(total,total,error))return false;
    for(const char *name:{"active.txt","active.previous","active.pending"}){struct stat st{};auto path=scanRoot()+"/"+name;if(pathStat(path,st)&&!regularFile(path,8)){error="Un marcador del buscador tiene una ruta o tamaño no admitidos.";return false;}}
    const std::string marker=std::string(1,slot)+"\n";if(!writeFile(scanRoot()+"/active.pending",marker.data(),marker.size())){error="No se pudo confirmar el nuevo estado del buscador.";return false;}if(!observe(total,total,error))return false;if(!removeKnown(scanRoot()+"/active.previous")){error="No se pudo conservar el marcador anterior.";return false;}bool had=regularFile(scanRoot()+"/active.txt",8);if(had&&!renameMarker(scanRoot()+"/active.txt",scanRoot()+"/active.previous")){error="No se pudo conservar el estado anterior del buscador.";return false;}if(!renameMarker(scanRoot()+"/active.pending",scanRoot()+"/active.txt")){bool recovered=!had||renameMarker(scanRoot()+"/active.previous",scanRoot()+"/active.txt");error=recovered?"No se pudo activar la nueva búsqueda; se conserva la anterior.":"No se pudo restaurar el marcador; se conserva active.previous para recuperar la búsqueda anterior.";return false;}return true;
}
bool commit(Stored &stored,std::string &error,uint64_t total){
    if(!observe(total,total,error))return false;
    auto data=serialize(stored);const std::string pending=file(stored.slot,".dat.pending");if(!writeFile(pending,data.data(),data.size())||!removeKnown(file(stored.slot,".dat"))||rename(pending.c_str(),file(stored.slot,".dat").c_str())!=0){error="No se pudo guardar la búsqueda. Se conserva la búsqueda activa anterior.";return false;}return activateSlot(stored.slot,error,total);
}
bool validReader(const ScanReader &reader,std::string &error){if(reader)return true;error="No se ha conectado el lector de memoria del proceso.";return false;}
class ScopeCursor {
    const ScanSession &session;size_t region=0;uint64_t prefix=0;
public:
    explicit ScopeCursor(const ScanSession&s):session(s){}
    bool locate(uint64_t address,uint64_t &index){
        const auto step=width(session.type);
        while(region<session.regions.size()&&address>=session.regions[region].address+session.regions[region].size){prefix+=session.regions[region].size/step;++region;}
        if(region==session.regions.size()||!contained(address,step,session.regions[region].address,session.regions[region].size)||address%step)return false;
        index=prefix+(address-session.regions[region].address)/step;return true;
    }
    bool address(uint64_t index,uint64_t &result){
        const auto step=width(session.type);
        while(region<session.regions.size()&&index>=prefix+session.regions[region].size/step){prefix+=session.regions[region].size/step;++region;}
        if(region==session.regions.size())return false;
        result=session.regions[region].address+(index-prefix)*step;return true;
    }
};
class RecordWriter {
    FILE*handle=nullptr;std::vector<uint8_t>buffer;size_t used=0,region=0;uint64_t bytes=0,prefix=0;uint32_t crc=0,previous=0;bool first=true;const ScanSession*session=nullptr;
    bool flush(){if(!used)return true;if(payloadWrite(buffer.data(),used,handle)!=used)return false;NC_SCAN_IO(recordsWrite,used);crc=uint32_t(crc32(crc,buffer.data(),uInt(used)));bytes+=used;used=0;return true;}
    bool byte(uint8_t value){buffer[used++]=value;return used!=buffer.size()||flush();}
public:
    ~RecordWriter(){abort();}
    bool open(const std::string&path,const ScanSession&s){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;handle=fopen(path.c_str(),"wb");if(!handle)return false;session=&s;buffer.resize(Chunk);for(uint8_t b:std::array<uint8_t,12>{'N','M','C','D','L','T','1',0,uint8_t(width(s.type)),0,0,0})if(!byte(b))return false;return true;}
    void abort(){if(handle){fclose(handle);handle=nullptr;}std::vector<uint8_t>().swap(buffer);}
    bool put(uint64_t address,uint32_t bits){
        if(!handle||!session)return false;
        const unsigned step=width(session->type);
        while(region<session->regions.size()&&address>=session->regions[region].address+session->regions[region].size){prefix+=session->regions[region].size/step;++region;}
        if(region==session->regions.size()||!contained(address,step,session->regions[region].address,session->regions[region].size)||address%step)return false;
        const uint64_t logical=prefix+(address-session->regions[region].address)/step;if(logical>UINT32_MAX||(!first&&logical<=previous))return false;
        uint8_t encoded[5];const auto n=scan_delta::encode(uint32_t(logical)-(first?0:previous),encoded);for(size_t i=0;i<n;++i)if(!byte(encoded[i]))return false;
        for(unsigned i=0;i<step;++i)if(!byte(uint8_t(bits>>(i*8))))return false;
        previous=uint32_t(logical);first=false;return true;
    }
    bool finish(uint32_t&result,uint64_t&size){if(!handle)return false;bool ok=flush();FILE*f=handle;handle=nullptr;if(!closeWritten(f))ok=false;result=crc;size=bytes;std::vector<uint8_t>().swap(buffer);return ok;}
};
class RecordReader {
    FILE*handle=nullptr;std::vector<uint8_t>buffer;size_t at=0,count=0;uint64_t bytes=0,rows=0,previous=0;uint32_t crc=0,ordinal=0;ScopeCursor scope;const Stored&stored;
    bool byte(uint8_t&value){if(at==count){count=payloadRead(buffer.data(),buffer.size(),handle);NC_SCAN_IO(recordsRead,count);at=0;if(!count)return false;bytes+=count;crc=uint32_t(crc32(crc,buffer.data(),uInt(count)));}value=buffer[at++];return true;}
public:
    explicit RecordReader(const Stored&s):scope(s.session),stored(s){}
    ~RecordReader(){if(handle)fclose(handle);}
    bool open(const std::string&path){handle=fopen(path.c_str(),"rb");if(!handle)return false;buffer.resize(Chunk);if(stored.recordsCodec==RecordCodec::DeltaIndex){const std::array<uint8_t,12>expected={'N','M','C','D','L','T','1',0,uint8_t(width(stored.session.type)),0,0,0};for(auto want:expected){uint8_t got=0;if(!byte(got)||got!=want)return false;}}return true;}
    bool next(ScanCandidate&value,uint64_t&index,std::string&error){
        const auto&s=stored.session;if(rows>=s.candidateCount)return false;uint8_t b=0;const unsigned step=width(s.type);
        if(stored.recordsCodec==RecordCodec::Fixed12){value.address=0;for(unsigned i=0;i<8;++i){if(!byte(b))goto invalid;value.address|=uint64_t(b)<<(i*8);}value.valueBits=0;for(unsigned i=0;i<4;++i){if(!byte(b))goto invalid;value.valueBits|=uint32_t(b)<<(i*8);}if((rows&&value.address<=previous)||!scope.locate(value.address,index))goto invalid;}
        else{
            scan_delta::Decoder decoded;do{if(!byte(b)||!decoded.put(b))goto invalid;}while(!decoded.done);
            uint32_t next=0;if(!scan_delta::advance(ordinal,decoded.value,rows==0,next)||uint64_t(next)>=s.coveredBytes/step||!scope.address(next,value.address))goto invalid;ordinal=next;index=next;
            value.valueBits=0;for(unsigned i=0;i<step;++i){if(!byte(b))goto invalid;value.valueBits|=uint32_t(b)<<(i*8);}
        }
        if((step<4&&value.valueBits>=(1u<<(step*8)))||(s.type==ScanValueType::F32&&!finiteBits(value.valueBits)))goto invalid;
        previous=value.address;++rows;return true;
    invalid:error="Los candidatos están truncados o no respetan orden, alcance y tipo.";return false;
    }
    bool finish(uint32_t expected){return handle&&rows==stored.session.candidateCount&&at==count&&bytes==stored.recordsBytes&&crc==expected&&fgetc(handle)==EOF&&!ferror(handle);}
    uint64_t consumedBytes()const{return bytes;}
};
class DenseOutput {
    FILE *snapshot=nullptr;uint32_t crc=0;bool withMask=false;
public:
    std::string snapshotPath,maskPath;MaskWriter mask;
    explicit DenseOutput(char slot):snapshotPath(file(slot,".snapshot.pending")),maskPath(file(slot,".mask.pending")){}
    ~DenseOutput(){if(snapshot)fclose(snapshot);mask.close();removeKnown(snapshotPath);removeKnown(maskPath);}
    bool open(bool enableMask){withMask=enableMask;struct stat st{};if(pathStat(snapshotPath,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;snapshot=fopen(snapshotPath.c_str(),"wb");return snapshot&&(!withMask||mask.open(maskPath));}
    bool write(const uint8_t *data,size_t count){if(payloadWrite(data,count,snapshot)!=count)return false;NC_SCAN_IO(snapshotWrite,count);crc=uint32_t(crc32(crc,data,uInt(count)));return true;}
    bool finish(Stored &stored){FILE *f=snapshot;snapshot=nullptr;if(!closeWritten(f))return false;stored.snapshotCrc=crc;return !withMask||mask.finish(stored.maskCrc);}
};
class MatchOutput {
    Stored &stored;bool uniform=false,sparse=false,maskOpen=false;uint64_t sparseLimit=0,maskAt=0,observerDone=0,observerTotal=0;
    RecordWriter records;MaskWriter mask;
    bool maskMatch(uint64_t index,std::string&error){if(index<maskAt||!mask.zeros(index-maskAt,[&]{return observe(observerDone,observerTotal,error);})||!mask.put(true))return false;maskAt=index+1;return true;}
public:
    explicit MatchOutput(Stored&s):stored(s),observerTotal(s.session.coveredBytes){}
    void progress(uint64_t done,uint64_t total){observerDone=done;observerTotal=total;}
    ~MatchOutput(){records.abort();mask.close();removeKnown(file(stored.slot,".records.pending"));if(uniform)removeKnown(file(stored.slot,".mask.pending"));}
    bool open(bool isUniform,bool allowSparse,std::string&error,bool forceSparse=false){
        uniform=isUniform;sparseLimit=stored.session.coveredBytes/24;if(forceSparse)sparseLimit=std::max<uint64_t>(sparseLimit,ScanMaxCandidates);
        if(uniform)return true;
        sparse=allowSparse&&sparseLimit>ScanMaterializeCandidates;
        if(sparse&&!records.open(file(stored.slot,".records.pending"),stored.session)){error="No se pudo crear la lista temporal de candidatos.";return false;}return true;
    }
    bool add(uint64_t address,uint32_t bits,uint64_t index,std::string&error){
        if(uniform){
            if(index>UINT32_MAX){error="Índice de candidato fuera del alcance.";return false;}
            if(maskOpen||stored.session.candidateCount>=ScanMaterializeCandidates){
                if(!maskOpen){if(!mask.open(file(stored.slot,".mask.pending"))){error="No se pudo crear la máscara temporal.";return false;}maskOpen=true;ScopeCursor scope(stored.session);for(const auto&early:stored.session.candidates){uint64_t ordinal=0;if(!scope.locate(early.address,ordinal)||!maskMatch(ordinal,error)){if(error.empty())error="No se pudo guardar la máscara de candidatos.";return false;}}}
                if(!maskMatch(index,error)){if(error.empty())error="No se pudo guardar la máscara de candidatos.";return false;}
            }
        }else if(sparse){
            if(stored.session.candidateCount>=sparseLimit){records.abort();if(!removeKnown(file(stored.slot,".records.pending"))){error="No se pudo descartar la lista temporal densa.";return false;}sparse=false;}
            else if(!records.put(address,bits)){error="No se pudo escribir la lista temporal de candidatos.";return false;}
        }
        collectCandidate(stored.session,address,bits);return true;
    }
    bool finish(std::string&error){
        auto&s=stored.session;s.ready=true;s.streamed=s.candidateCount>ScanMaterializeCandidates;s.baseline=s.streamed;
        if(!s.streamed){records.abort();s.storage=ScanStorage::Memory;s.uniformBits=stored.snapshotCrc=stored.maskCrc=stored.recordsCrc=0;return true;}
        if(uniform){if(!maskOpen||!mask.zeros(s.coveredBytes/width(s.type)-maskAt,[&]{return observe(observerDone,observerTotal,error);})||!mask.finish(stored.maskCrc)){if(error.empty())error="No se pudo cerrar la máscara de candidatos.";return false;}s.storage=ScanStorage::UniformMask;stored.snapshotCrc=stored.recordsCrc=0;}
        else if(sparse){if(!records.finish(stored.recordsCrc,stored.recordsBytes)){error="No se pudo cerrar la lista de candidatos.";return false;}s.storage=ScanStorage::SparseDisk;stored.recordsCodec=RecordCodec::DeltaIndex;s.uniformBits=stored.snapshotCrc=stored.maskCrc=0;}
        else{s.storage=ScanStorage::DenseSnapshot;s.uniformBits=stored.recordsCrc=0;}
        return true;
    }
};
class CandidateInput {
    const Stored &stored;RecordReader records;MaskReader mask;ScopeCursor scope;uint64_t rows=0,position=0;
public:
    explicit CandidateInput(const Stored&s):stored(s),records(s),scope(s.session){}
    bool open(std::string&error){
        const auto &s=stored.session;bool ok=true;
        if(s.storage==ScanStorage::SparseDisk)ok=records.open(file(stored.slot,".records"));
        else if(s.storage!=ScanStorage::Memory)ok=mask.open(file(stored.slot,".mask"));
        if(!ok)error="No se pudieron abrir los candidatos guardados.";
        return ok;
    }
    bool next(ScanCandidate &candidate,bool &found,std::string&error){
        found=false;const auto&s=stored.session;if(rows==s.candidateCount)return true;
        uint64_t index=0;
        if(s.storage==ScanStorage::Memory){candidate=(stored.borrowed?*stored.borrowed:s.candidates)[size_t(rows)];}
        else if(s.storage==ScanStorage::SparseDisk){if(!records.next(candidate,index,error))return false;}
        else{
            uint64_t skipped=0;bool set=false;
            if(!mask.nextSet(s.coveredBytes/width(s.type)-position,skipped,set,rows,s.candidateCount,error)||!set){if(error.empty())error="La máscara de candidatos está incompleta.";return false;}
            position+=skipped;index=position++;
            if(!scope.address(index,candidate.address)){error="Índice de candidato fuera del alcance.";return false;}
            candidate.valueBits=s.uniformBits;
        }
        ++rows;found=true;return true;
    }
    bool finish(std::string&error){
        const auto&s=stored.session;bool ok=rows==s.candidateCount;
        if(s.storage==ScanStorage::SparseDisk)ok=ok&&records.finish(stored.recordsCrc);
        else if(s.storage!=ScanStorage::Memory){uint64_t skipped=0;bool extra=false;ok=ok&&mask.nextSet(s.coveredBytes/width(s.type)-position,skipped,extra,rows,s.candidateCount,error)&&!extra&&mask.finish(stored.maskCrc,maskBytes(s));}
        if(!ok&&error.empty())error="Los candidatos no superan su comprobación CRC/cantidad.";
        return ok;
    }
};
class ReadWindow {
    std::unique_ptr<uint8_t[]> bytes;size_t capacity=0;
public:
    uint64_t address=0;size_t size=0;
    bool open(std::string&error){capacity=ScanReadWindowBytes;bytes.reset(new(std::nothrow)uint8_t[capacity]);if(!bytes){capacity=Chunk;bytes.reset(new(std::nothrow)uint8_t[capacity]);}if(!bytes){error="No hay memoria suficiente para el búfer de lectura.";return false;}return true;}
    bool contains(uint64_t at,size_t length)const{return size&&at>=address&&at-address<size&&length<=size-(at-address);}
    size_t limit()const{return capacity;}
    bool read(const ScanIdentity&id,uint64_t at,uint64_t remaining,const ScanReader&reader,std::string&error){size=0;const auto count=size_t(std::min<uint64_t>(capacity,remaining));if(!count||!reader(id,at,bytes.get(),count,error))return false;address=at;size=count;return true;}
    const uint8_t*data(uint64_t at)const{return bytes.get()+size_t(at-address);}
};
bool filterCandidates(const Stored &previous,Stored &next,ScanCompare compare,uint32_t target,const ScanReader&reader,MatchOutput&output,std::string&error){
    const auto&s=previous.session;CandidateInput input(previous);if(!input.open(error)||!observe(0,s.candidateCount,error))return false;
    const size_t batchLimit=4096;
    std::vector<ScanCandidate> batch;batch.reserve(batchLimit);ReadWindow window;if(!window.open(error))return false;ScopeCursor scope(s);uint64_t done=0;bool ended=false;
    while(!ended){
        batch.clear();{ComparisonTimer timer;while(batch.size()<batchLimit){ScanCandidate c;bool found=false;if(!input.next(c,found,error))return false;if(!found){ended=true;break;}batch.push_back(c);}}
        for(size_t i=0;i<batch.size();){
            const uint64_t address=batch[i].address;
            if(!window.contains(address,width(s.type))){const auto region=std::lower_bound(s.regions.begin(),s.regions.end(),address,[](const auto&r,uint64_t at){return r.address+r.size<=at;});if(region==s.regions.end()||!contained(address,width(s.type),region->address,region->size)){error="Candidato fuera de las regiones guardadas.";return false;}const auto available=address+std::min<uint64_t>(window.limit(),region->address+region->size-address);size_t last=i+1;while(last<batch.size()&&batch[last].address+width(s.type)<=available)++last;const auto span=batch[last-1].address+width(s.type)-address;if(!window.read(s.identity,address,span,reader,error))return false;}
            const uint64_t limit=window.address+window.size;size_t j=i+1;
            while(j<batch.size()&&batch[j].address+width(s.type)<=limit)++j;
            output.progress(done+j-i,s.candidateCount);
            {ComparisonTimer timer;for(size_t k=i;k<j;++k){const auto&c=batch[k];const auto now=bitsAt(window.data(c.address),width(s.type));uint64_t index=0;
                if(!scope.locate(c.address,index)){error="Candidato fuera de alcance.";return false;}
                if(matches(s.type,compare,c.valueBits,now,target)&&!output.add(c.address,now,index,error))return false;
            }}
            done+=j-i;i=j;if(!observe(done,s.candidateCount,error))return false;
        }
    }
    if(!input.finish(error))return false;
    (void)next;return true;
}
bool publishMatches(Stored &stored,std::string&error,uint64_t total){
    const auto &s=stored.session;
    if(!observe(total,total,error))return false;
    const char*suffix=s.storage==ScanStorage::SparseDisk?".records":s.storage==ScanStorage::UniformMask?".mask":nullptr;
    if(suffix){const auto pending=file(stored.slot,(std::string(suffix)+".pending").c_str());if(!removeKnown(file(stored.slot,suffix))||rename(pending.c_str(),file(stored.slot,suffix).c_str())!=0){error="No se pudo confirmar la nueva lista de candidatos.";return false;}}
    if(s.storage==ScanStorage::DenseSnapshot){if(!removeKnown(file(stored.slot,".snapshot"))||rename(file(stored.slot,".snapshot.pending").c_str(),file(stored.slot,".snapshot").c_str())!=0||!removeKnown(file(stored.slot,".mask"))||rename(file(stored.slot,".mask.pending").c_str(),file(stored.slot,".mask").c_str())!=0){error="No se pudo confirmar la comparación de memoria.";return false;}}
    return commit(stored,error,total);
}
bool publishDense(Stored &stored,DenseOutput &output,bool initial,std::string &error){
    auto &s=stored.session;s.streamed=!initial&&s.candidateCount>ScanMaxCandidates;s.baseline=initial||s.streamed;s.ready=true;s.storage=s.baseline?ScanStorage::DenseSnapshot:ScanStorage::Memory;s.uniformBits=stored.recordsCrc=0;
    if(!observe(s.coveredBytes,s.coveredBytes,error))return false;
    if(s.baseline){if(!removeKnown(file(stored.slot,".snapshot"))||rename(output.snapshotPath.c_str(),file(stored.slot,".snapshot").c_str())!=0){error="No se pudo confirmar la referencia de memoria.";return false;}if(s.streamed&&(!removeKnown(file(stored.slot,".mask"))||rename(output.maskPath.c_str(),file(stored.slot,".mask").c_str())!=0)){error="No se pudo confirmar la lista de coincidencias.";return false;}}
    else{stored.snapshotCrc=stored.maskCrc=0;}
    return commit(stored,error,s.coveredBytes);
}
bool filterDense(const Stored&previous,Stored&next,ScanCompare compare,uint32_t target,const ScanReader&reader,MatchOutput&output,DenseOutput*dense,std::string&error){
    const auto&s=previous.session;const bool needOld=s.storage==ScanStorage::DenseSnapshot&&compare!=ScanCompare::Exact;
    ReadWindow current;if(!current.open(error))return false;FILE*snapshot=needOld?fopen(file(previous.slot,".snapshot").c_str(),"rb"):nullptr;
    if(needOld&&!snapshot){error="No se puede abrir la referencia guardada.";return false;}
    MaskReader mask;bool ok=!s.streamed||mask.open(file(previous.slot,".mask"));std::array<uint8_t,Chunk>old{};uint32_t crc=0;uint64_t done=0,index=0,oldCandidates=0;const auto step=width(s.type);
    for(const auto&r:s.regions){if(!ok)break;for(uint64_t offset=0;offset<r.size;){
        if(!current.read(s.identity,r.address+offset,r.size-offset,reader,error)){ok=false;break;}
        for(size_t sub=0;sub<current.size;){const size_t count=std::min(Chunk,current.size-sub);const auto*data=current.data(r.address+offset+sub);
            if(needOld){const auto got=payloadRead(old.data(),count,snapshot);NC_SCAN_IO(snapshotRead,got);if(got!=count){error="La referencia de memoria está incompleta.";ok=false;break;}crc=uint32_t(crc32(crc,old.data(),uInt(count)));}
            if(dense&&!dense->write(data,count)){ok=false;break;}output.progress(done+count,s.coveredBytes);
            {ComparisonTimer timer;for(size_t at=0;at<count;at+=step,++index){bool alive=true;if(s.streamed&&!mask.get(alive)){error="La lista de coincidencias está incompleta.";ok=false;break;}if(alive)++oldCandidates;const auto now=bitsAt(data+at,step),before=needOld?bitsAt(old.data()+at,step):s.uniformBits;const bool match=alive&&matches(s.type,compare,before,now,target);if((dense&&!dense->mask.put(match))||(match&&!output.add(r.address+offset+sub+at,now,index,error))){ok=false;break;}}}
            if(!ok)break;
            sub+=count;done+=count;if(!observe(done,s.coveredBytes,error)){ok=false;break;}
        }
        if(!ok)break;
        offset+=current.size;
    }}
    if(needOld){if(ok&&(fgetc(snapshot)!=EOF||ferror(snapshot)||crc!=previous.snapshotCrc)){error="La referencia de memoria no supera su comprobación CRC.";ok=false;}fclose(snapshot);}
    if(ok&&s.streamed&&(!mask.finish(previous.maskCrc,maskBytes(s))||oldCandidates!=s.candidateCount)){error="La lista de coincidencias no supera su comprobación CRC/cantidad.";ok=false;}
    if(!ok&&error.empty())error="No se pudo completar la comparación; la búsqueda anterior se conserva.";
    (void)next;return ok;
}
bool initialScan(const ScanIdentity&identity,const std::vector<ScanRegion>&regions,ScanValueType type,const std::string&value,bool unknown,const ScanReader&reader,ScanSession&session,std::string&error){
    error.clear();uint32_t target=0;Stored next;if(!validReader(reader,error)||(!unknown&&!parseValue(type,value,target,error))||!prepare(identity,regions,type,next.session,error)||!ensureRoot(error)||!observe(0,next.session.coveredBytes,error))return false;
    next.slot=activeSlot()=='a'?'b':'a';next.session.rounds=1;const bool uniform=!unknown&&type!=ScanValueType::F32;next.session.uniformBits=uniform?target:0;
    DenseOutput dense(next.slot);MatchOutput output(next);ReadWindow window;if(!window.open(error))return false;
    if((!uniform&&!dense.open(!unknown))||(!unknown&&!output.open(uniform,true,error))){if(error.empty())error="No se puede crear la referencia temporal; comprueba la microSD.";return false;}
    const auto step=width(type);uint64_t done=0,index=0;
    for(const auto&r:next.session.regions)for(uint64_t offset=0;offset<r.size;){
        if(!window.read(next.session.identity,r.address+offset,r.size-offset,reader,error))return false;
        for(size_t sub=0;sub<window.size;){const auto count=std::min(Chunk,window.size-sub);const auto*data=window.data(r.address+offset+sub);output.progress(done+count,next.session.coveredBytes);
            if(!uniform&&!dense.write(data,count)){error="No se pudo escribir la referencia; la búsqueda anterior se conserva.";return false;}
            if(!unknown){ComparisonTimer timer;for(size_t at=0;at<count;at+=step,++index){const auto bits=bitsAt(data+at,step);const bool match=matches(type,ScanCompare::Exact,0,bits,target);if((!uniform&&!dense.mask.put(match))||(match&&!output.add(r.address+offset+sub+at,bits,index,error)))return false;}}
            sub+=count;done+=count;if(!observe(done,next.session.coveredBytes,error))return false;
        }offset+=window.size;
    }
    if(!uniform&&!dense.finish(next)){error="No se pudo cerrar la referencia de memoria.";return false;}
    if(unknown){if(!publishDense(next,dense,true,error))return false;}
    else if(!output.finish(error)||!publishMatches(next,error,next.session.coveredBytes))return false;
    session=std::move(next.session);return true;
}
bool sameScope(const ScanSession &a,const ScanSession &b){if(a.type!=b.type||a.coveredBytes!=b.coveredBytes||a.totalBytes!=b.totalBytes||a.partial!=b.partial||a.regions.size()!=b.regions.size())return false;for(size_t i=0;i<a.regions.size();++i)if(a.regions[i].address!=b.regions[i].address||a.regions[i].size!=b.regions[i].size||a.regions[i].writable!=b.regions[i].writable)return false;return true;}
uint64_t storedBytes(const Stored &s){switch(s.session.storage){case ScanStorage::Memory:return 0;case ScanStorage::SparseDisk:return s.recordsBytes;case ScanStorage::UniformMask:return maskBytes(s.session);case ScanStorage::DenseSnapshot:return s.session.coveredBytes+(s.session.streamed?maskBytes(s.session):0);}return 0;}
bool validateStoredData(const Stored &stored,uint64_t &done,uint64_t total,std::string &error){
    if(stored.session.storage==ScanStorage::Memory)return true;
    if(stored.session.storage==ScanStorage::SparseDisk){
        RecordReader input(stored);if(!input.open(file(stored.slot,".records"))){error="No se pudieron abrir los candidatos guardados.";return false;}
        const auto before=done;for(uint64_t i=0;i<stored.session.candidateCount;++i){ScanCandidate value;uint64_t index=0;if(!input.next(value,index,error))return false;done=before+input.consumedBytes();if((i%4096==0)&&!observe(done,total,error))return false;}
        if(!input.finish(stored.recordsCrc)){error="Los candidatos no superan su comprobación CRC/cantidad.";return false;}return observe(done,total,error);
    }
    std::array<uint8_t,Chunk> data{};
    for(bool mask:{false,true}){
        if(!mask&&stored.session.storage==ScanStorage::UniformMask)continue;
        if(mask&&!stored.session.streamed)continue;
        const uint64_t expected=mask?maskBytes(stored.session):stored.session.coveredBytes;
        const auto path=file(stored.slot,mask?".mask":".snapshot");
        if(!regularFile(path,expected)){error="Los datos de una comparación no son un archivo regular completo.";return false;}
        FILE *input=fopen(path.c_str(),"rb");if(!input){error="No se pueden abrir los datos de la comparación.";return false;}
        uint64_t bytes=0,matches=0;uint32_t crc=0;uint8_t last=0;size_t n=0;bool ok=true;
        while((n=payloadRead(data.data(),data.size(),input))){
            if(mask)NC_SCAN_IO(maskRead,n);else NC_SCAN_IO(snapshotRead,n);
            if(n>expected-bytes){error="Los datos de la comparación cambiaron de tamaño.";ok=false;break;}
            bytes+=n;crc=uint32_t(crc32(crc,data.data(),uInt(n)));last=data[n-1];
            if(mask)for(size_t i=0;i<n;++i)matches+=unsigned(__builtin_popcount(unsigned(data[i])));
            done+=n;if(!observe(done,total,error)){ok=false;break;}
        }
        if(ferror(input)&&ok){error="No se pudo leer por completo la comparación.";ok=false;}fclose(input);if(!ok)return false;
        if(bytes!=expected){error="Los datos guardados de la comparación están incompletos.";return false;}
        if(crc!=(mask?stored.maskCrc:stored.snapshotCrc)){error="La comparación no supera su comprobación CRC; no se ha recuperado.";return false;}
        const unsigned used=unsigned((stored.session.coveredBytes/width(stored.session.type))%8);
        if(mask&&(matches!=stored.session.candidateCount||(used&&(last&uint8_t(0xffu<<used))))){error="La lista de coincidencias guardada no es válida.";return false;}
    }
    return true;
}
}

void setScanObserver(std::function<bool(uint64_t,uint64_t)> callback){observer=std::move(callback);}
const ScanCoreStats&scanCoreStats(){return coreStats;}
void resetScanCoreStats(){coreStats={};callbackNs=0;}
bool startExactScan(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,const std::string &value,const ScanReader &reader,ScanSession &session,std::string &error){
    return initialScan(identity,regions,type,value,false,reader,session,error);
}
bool startUnknownScan(const ScanIdentity &identity,const std::vector<ScanRegion> &regions,ScanValueType type,const ScanReader &reader,ScanSession &session,std::string &error){
    return initialScan(identity,regions,type,"",true,reader,session,error);
}
bool refineScan(const ScanIdentity &identity,ScanCompare compare,const std::string &value,const ScanReader &reader,ScanSession &session,std::string &error){
    error.clear();if(unsigned(compare)>unsigned(ScanCompare::Decreased)||!validReader(reader,error)){if(error.empty())error="Comparación de memoria no válida.";return false;}
    Stored previous;if(!loadStored(identity,previous,error,&session))return false;
    if(!(previous.borrowed==&session.candidates?sameSessionState(session,previous.session):sameSession(session,previous.session))){error="La búsqueda guardada cambió. Recárgala antes de filtrar.";return false;}
    if(session.ready&&!session.baseline&&!session.candidateCount){error="No quedan coincidencias. Recupera la comparación anterior o inicia una búsqueda nueva; no se ha guardado otro filtro vacío.";return false;}
    uint32_t target=0;if(compare==ScanCompare::Exact&&!parseValue(session.type,value,target,error))return false;
    if(previous.session.rounds==UINT32_MAX){error="Inicia una búsqueda nueva.";return false;}
    Stored next;next.slot=previous.slot=='a'?'b':'a';next.session=metadataOnly(previous.session);next.session.rounds++;
    const bool uniform=session.type!=ScanValueType::F32&&(compare==ScanCompare::Exact||(session.storage==ScanStorage::UniformMask&&compare==ScanCompare::Unchanged));
    next.session.uniformBits=uniform?(compare==ScanCompare::Exact?target:session.uniformBits):0;
    // Low-density pools use only their ordered survivors. A uniform high-
    // density pool falls back to a dense output for non-uniform comparisons.
    const bool candidates=session.storage==ScanStorage::Memory||session.storage==ScanStorage::SparseDisk||(session.storage==ScanStorage::UniformMask&&(uniform||session.candidateCount<=session.coveredBytes/24))||(session.storage==ScanStorage::DenseSnapshot&&session.streamed&&uniform);
    MatchOutput output(next);const bool compactLegacy=session.storage==ScanStorage::Memory||(session.storage==ScanStorage::SparseDisk&&session.candidateCount<=ScanMaxCandidates);if(!output.open(uniform,true,error,compactLegacy))return false;
    if(candidates){
        if(!filterCandidates(previous,next,compare,target,reader,output,error)||!output.finish(error))return false;
        if(next.session.storage==ScanStorage::DenseSnapshot){error="El conjunto de candidatos no puede ampliarse ni perder valores.";return false;}
        if(!publishMatches(next,error,session.candidateCount))return false;
    }else{
        if(!observe(0,session.coveredBytes,error))return false;
        DenseOutput dense(next.slot);if(!uniform&&!dense.open(true)){error="No se pudo crear la comparación temporal.";return false;}
        if(!filterDense(previous,next,compare,target,reader,output,uniform?nullptr:&dense,error))return false;
        if(!uniform&&!dense.finish(next)){error="No se pudo cerrar la comparación de memoria.";return false;}
        if(!output.finish(error)||!publishMatches(next,error,session.coveredBytes))return false;
    }
    session=std::move(next.session);return true;
}
bool loadScanSession(const ScanIdentity &identity,ScanSession &session,std::string &error){error.clear();Stored stored;if(!loadStored(identity,stored,error))return false;session=std::move(stored.session);return true;}
bool restorePreviousScan(const ScanIdentity &identity,ScanSession &session,std::string &error){
    error.clear();if(!ensureRoot(error))return false;Stored current,previous;if(!loadStored(identity,current,error))return false;if(!sameSession(session,current.session)){error="La búsqueda guardada cambió. Recárgala antes de recuperar el filtro anterior.";return false;}
    if(!loadStoredAt(identity,current.slot=='a'?'b':'a',previous,error)){error="No se puede recuperar la comparación anterior: "+error;return false;}
    if(previous.session.rounds>=current.session.rounds||!sameScope(previous.session,current.session)){error="No hay una comparación anterior de esta misma búsqueda que se pueda recuperar.";return false;}
    if(!previous.session.baseline&&!previous.session.candidateCount){error="El paso anterior también tiene cero coincidencias. Ya no conserva aquellos candidatos; inicia una búsqueda nueva.";return false;}
    uint64_t done=0,total=std::max<uint64_t>(1,storedBytes(current)+storedBytes(previous));if(!observe(0,total,error)||!validateStoredData(current,done,total,error)||!validateStoredData(previous,done,total,error))return false;
    if(!activateSlot(previous.slot,error,total))return false;
    session=std::move(previous.session);return true;
}
bool clearScanSession(std::string &error){error.clear();std::vector<std::string> paths={scanRoot()+"/active.txt",scanRoot()+"/active.previous",scanRoot()+"/active.pending"};for(char slot:{'a','b'})for(const char*suffix:{".dat",".dat.pending",".snapshot",".snapshot.pending",".mask",".mask.pending",".records",".records.pending"})paths.push_back(file(slot,suffix));for(const auto &path:paths){struct stat st{};if(pathStat(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La carpeta del buscador contiene una ruta no admitida; no se ha borrado.";return false;}}for(const auto &path:paths)if(!removeKnown(path)){error="No se pudo borrar por completo la sesión privada del buscador.";return false;}return true;}
bool scanCandidateCheat(const ScanSession &session,size_t index,const std::string &value,const std::string &name,Cheat &cheat,std::string &error){
    error.clear();Stored stored;if(!loadStored(session.identity,stored,error))return false;if(!sameSession(session,stored.session)||session.baseline||!session.ready||index>=session.candidates.size()){error="No hay un candidato válido en esta sesión.";return false;}if(name.empty()||name.size()>63||name.find_first_of("[]{}\r\n")!=std::string::npos||std::any_of(name.begin(),name.end(),[](unsigned char c){return c<32||c==127;})){error="Usa un nombre de 1 a 63 bytes sin corchetes ni saltos de línea.";return false;}uint32_t bits=0;if(!parseValue(session.type,value,bits,error))return false;const auto &candidate=session.candidates[index];
    const bool heap=contained(candidate.address,width(session.type),session.identity.heapBase,session.identity.heapSize);
    const bool alias=contained(candidate.address,width(session.type),session.identity.aliasBase,session.identity.aliasSize);
    const uint32_t memory=heap?1u:alias?2u:0u;
    const uint64_t base=heap?session.identity.heapBase:alias?session.identity.aliasBase:session.identity.mainBase;
    const uint64_t offset=candidate.address-base;
    if(offset>0xffffffffffULL){error="El desplazamiento no cabe en una escritura estática de Atmosphère.";return false;}Cheat next;next.name=name;next.source="NinMagic Scanner · experimental";next.group="NinMagicScan:"+hexId(session.identity.title)+":"+session.identity.fullBuildId+":"+std::to_string(session.identity.pid);next.opcodes={uint32_t(width(session.type)<<24)|(memory<<20)|uint32_t(offset>>32),uint32_t(offset),bits};next.selected=true;cheat=std::move(next);return true;
}
std::string scanValueText(ScanValueType type,uint32_t bits){if(type==ScanValueType::F32){float number;std::memcpy(&number,&bits,4);if(!std::isfinite(number))return "No finito";char text[32];std::snprintf(text,sizeof(text),"%.9g",double(number));return text;}if(type==ScanValueType::U8)bits&=255;if(type==ScanValueType::U16)bits&=65535;return std::to_string(bits);}
}

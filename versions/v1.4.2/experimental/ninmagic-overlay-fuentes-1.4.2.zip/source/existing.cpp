#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "existing.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <limits>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr size_t MaxEntries=50000, MaxPath=768, MaxReceipt=8*1024*1024;
constexpr unsigned MaxDepth=32;
std::string sdRoot() {
#ifdef NC_EXISTING_TEST
    const char *path=std::getenv("NC_EXISTING_ROOT");return path?path:"existing-test";
#else
    return "sdmc:";
#endif
}
bool userGame(const Game &game,std::string &error) {
    if(game.id<0x0100000000010000ULL){error="No se permite cambiar contenido de títulos del sistema.";return false;}
    return true;
}
bool statPath(const std::string &path,struct stat &st,bool &exists,std::string &error) {
    exists=false;
    if(lstat(path.c_str(),&st)!=0){if(errno==ENOENT)return true;error="No se pudo revisar la ruta: "+path;return false;}
    exists=true;
    if(S_ISLNK(st.st_mode)||(!S_ISREG(st.st_mode)&&!S_ISDIR(st.st_mode))){error="La ruta contiene un enlace o un tipo no admitido: "+path;return false;}
    return true;
}
bool directory(const std::string &path,bool create,bool &exists,std::string &error) {
    struct stat st{};
    if(!statPath(path,st,exists,error))return false;
    if(!exists&&create) {
#ifdef _WIN32
        if(mkdir(path.c_str())!=0){error="No se pudo crear la carpeta: "+path;return false;}
#else
        if(mkdir(path.c_str(),0777)!=0){error="No se pudo crear la carpeta: "+path;return false;}
#endif
        if(!statPath(path,st,exists,error)||!exists)return false;
    }
    if(exists&&!S_ISDIR(st.st_mode)){error="Se esperaba una carpeta en: "+path;return false;}
    return true;
}
bool folderChain(const std::string &relative,bool create,bool &exists,std::string &error) {
    std::string current=sdRoot();size_t start=0;exists=true;
    while(start<relative.size()) {
        size_t end=relative.find('/',start);std::string part=relative.substr(start,end==std::string::npos?end:end-start);
        if(part.empty()||part=="."||part==".."||part.find(':')!=std::string::npos){error="Ruta interna inválida.";return false;}
        current+="/"+part;
        if(!directory(current,create,exists,error))return false;
        if(!exists)return true;
        if(end==std::string::npos)break;
        start=end+1;
    }
    return true;
}
bool nameValid(const std::string &name) {
    return !name.empty()&&name!="."&&name!=".."&&std::none_of(name.begin(),name.end(),[](unsigned char c){return c<32||c==127||c=='/'||c=='\\'||c==':';});
}
bool relativeValid(const std::string &path) {
    if(path.size()>MaxPath||path.empty())return path.empty();
    size_t start=0;
    while(start<path.size()) {
        auto end=path.find('/',start);if(!nameValid(path.substr(start,end==std::string::npos?end:end-start)))return false;
        if(end==std::string::npos)return true;
        start=end+1;
    }
    return false;
}
bool walk(const std::string &base,const std::string &relative,ExistingContent &out,std::string &error,unsigned depth=0) {
    if(depth>MaxDepth||relative.size()>MaxPath||out.entries.size()>=MaxEntries){error="El contenido previo supera los límites de revisión (50.000 entradas o 32 niveles).";return false;}
    const std::string path=relative.empty()?base:base+"/"+relative;struct stat st{};bool exists=false;
    if(!statPath(path,st,exists,error)||!exists){if(error.empty())error="El contenido cambió durante la revisión.";return false;}
    ExistingEntry entry;entry.path=relative;entry.directory=S_ISDIR(st.st_mode);entry.modified=int64_t(st.st_mtime);
    if(!entry.directory) {
        if(st.st_size<0||out.bytes>std::numeric_limits<uint64_t>::max()-uint64_t(st.st_size)){error="El tamaño del contenido no es válido.";return false;}
        entry.size=uint64_t(st.st_size);out.bytes+=entry.size;++out.files;out.exists=true;
        if(relative.rfind("cheats/",0)==0)out.cheats=true;else out.mods=true;
    } else if(!relative.empty())++out.directories;
    out.entries.push_back(entry);
    if(entry.directory) {
        DIR *dir=opendir(path.c_str());if(!dir){error="No se pudo abrir la carpeta: "+path;return false;}
        bool ok=true;errno=0;
        while(auto *item=readdir(dir)) {
            std::string name=item->d_name;if(name=="."||name=="..")continue;
            if(!nameValid(name)){error="El contenido previo contiene un nombre no admitido.";ok=false;break;}
            if(!walk(base,relative.empty()?name:relative+"/"+name,out,error,depth+1)){ok=false;break;}
            errno=0;
        }
        int scanError=errno;if(closedir(dir)!=0||scanError) {if(ok)error="No se pudo completar la lectura de la carpeta: "+path;ok=false;}
        if(!ok)return false;
    }
    return true;
}
bool sameEntries(const ExistingContent &a,const ExistingContent &b) {
    if(a.game.id!=b.game.id||a.files!=b.files||a.directories!=b.directories||a.bytes!=b.bytes||a.entries.size()!=b.entries.size())return false;
    for(size_t i=0;i<a.entries.size();++i) {
        const auto &x=a.entries[i],&y=b.entries[i];
        if(x.path!=y.path||x.directory!=y.directory||x.size!=y.size||x.modified!=y.modified)return false;
    }
    return true;
}
std::string sourceRelative(const Game &game){return "atmosphere/contents/"+hexId(game.id);}
std::string backupRelative(const Game &game){return "config/NinMagicCheats/previous-content/"+hexId(game.id);}
std::string serial(unsigned value){char s[9];std::snprintf(s,sizeof(s),"%08u",value);return s;}
bool serialValid(const std::string &value){return value.size()==8&&std::all_of(value.begin(),value.end(),[](unsigned char c){return c>='0'&&c<='9';});}
uint32_t crc(const std::string &data,size_t length) {
    uint32_t value=0xffffffff;
    for(size_t i=0;i<length;++i){value^=static_cast<unsigned char>(data[i]);for(unsigned n=0;n<8;++n)value=(value>>1)^(0xedb88320u&uint32_t(0-int(value&1)));}
    return ~value;
}
void put(std::string &data,uint64_t value,unsigned count){for(unsigned n=0;n<count;++n)data+=char((value>>(8*n))&255);}
std::string receipt(const ExistingContent &content) {
    std::string result("NMEC1\0\0\0",8);put(result,content.game.id,8);put(result,content.entries.size(),4);
    put(result,content.files,4);put(result,content.directories,4);put(result,content.bytes,8);
    for(const auto &entry:content.entries){put(result,entry.path.size(),2);put(result,entry.directory?1:0,1);put(result,entry.size,8);put(result,uint64_t(entry.modified),8);result+=entry.path;}
    put(result,crc(result,result.size()),4);return result;
}
bool take(const std::string &data,size_t &offset,uint64_t &value,unsigned count) {
    if(offset>data.size()||count>data.size()-offset)return false;
    value=0;for(unsigned n=0;n<count;++n)value|=uint64_t(static_cast<unsigned char>(data[offset++]))<<(n*8);return true;
}
bool parseReceipt(const std::string &data,const Game &game,ExistingContent &content) {
    if(data.size()<40||data.size()>MaxReceipt||data.compare(0,8,std::string("NMEC1\0\0\0",8)))return false;
    size_t end=data.size()-4,at=end;uint64_t stored=0;if(!take(data,at,stored,4)||stored!=crc(data,end))return false;
    at=8;uint64_t id=0,count=0,files=0,dirs=0,bytes=0;
    if(!take(data,at,id,8)||!take(data,at,count,4)||!take(data,at,files,4)||!take(data,at,dirs,4)||!take(data,at,bytes,8)||id!=game.id||count==0||count>MaxEntries||files>count||dirs>count)return false;
    content={};content.game=game;
    for(uint64_t n=0;n<count;++n) {
        uint64_t length=0,isdir=0,size=0,modified=0;
        if(!take(data,at,length,2)||!take(data,at,isdir,1)||!take(data,at,size,8)||!take(data,at,modified,8)||length>MaxPath||isdir>1||at>end||length>end-at)return false;
        ExistingEntry entry;entry.path=data.substr(at,size_t(length));at+=size_t(length);entry.size=size;entry.directory=isdir!=0;entry.modified=int64_t(modified);
        if(!relativeValid(entry.path)||(n==0&&(!entry.path.empty()||!entry.directory))||(n>0&&(entry.path.empty()||entry.path<=content.entries.back().path))||(entry.directory&&entry.size))return false;
        if(!entry.directory){++content.files;if(content.bytes>std::numeric_limits<uint64_t>::max()-entry.size)return false;content.bytes+=entry.size;if(entry.path.rfind("cheats/",0)==0)content.cheats=true;else content.mods=true;}
        else if(!entry.path.empty())++content.directories;
        content.entries.push_back(std::move(entry));
    }
    if(at!=end||files!=content.files||dirs!=content.directories||bytes!=content.bytes)return false;
    content.exists=content.files>0;content.valid=true;return true;
}
bool readFile(const std::string &path,std::string &data,std::string &error) {
    struct stat st{};bool exists=false;if(!statPath(path,st,exists,error)||!exists||!S_ISREG(st.st_mode)||st.st_size<0||uint64_t(st.st_size)>MaxReceipt){if(error.empty())error="No existe un registro válido de la copia.";return false;}
    FILE *f=fopen(path.c_str(),"rb");if(!f){error="No se pudo leer el registro de copia.";return false;}
    data.clear();std::array<char,16384> buffer{};size_t n=0;bool ok=true;
    while((n=fread(buffer.data(),1,buffer.size(),f))) {if(data.size()+n>MaxReceipt){ok=false;break;}data.append(buffer.data(),n);}
    if(ferror(f)||data.size()!=uint64_t(st.st_size))ok=false;
    if(fclose(f)!=0)ok=false;
    if(!ok)error="Registro de copia incompleto.";
    return ok;
}
bool writeNew(const std::string &path,const std::string &data,std::string &error) {
    int flags=O_CREAT|O_EXCL|O_WRONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(path.c_str(),flags,0666);if(fd<0){error="No se pudo crear el registro: "+path;return false;}
    size_t written=0;bool ok=true;
    while(written<data.size()){auto n=::write(fd,data.data()+written,data.size()-written);if(n<=0){ok=false;break;}written+=size_t(n);}
    if(ok&&fsync(fd)!=0)ok=false;
    if(close(fd)!=0)ok=false;
    std::string check;if(ok)ok=readFile(path,check,error)&&check==data;
    if(!ok&&error.empty())error="No se pudo confirmar el registro de copia.";
    return ok;
}
bool inspectTree(const Game &game,const std::string &path,ExistingContent &content,std::string &error) {
    content={};content.game=game;struct stat st{};bool exists=false;
    if(!statPath(path,st,exists,error))return false;
    if(!exists){content.valid=true;return true;}
    if(!S_ISDIR(st.st_mode)){error="La carpeta del Title ID fue sustituida por un archivo.";return false;}
    if(!walk(path,"",content,error))return false;
    std::sort(content.entries.begin(),content.entries.end(),[](const ExistingEntry &a,const ExistingEntry &b){return a.path<b.path;});
    content.valid=true;return true;
}
}

bool inspectExisting(const Game &game,ExistingContent &content,std::string &error) {
    error.clear();content={};content.game=game;if(!userGame(game,error))return false;
    bool exists=false;if(!folderChain("atmosphere/contents",false,exists,error))return false;
    if(!exists){content.valid=true;return true;}
    return inspectTree(game,sdRoot()+"/"+sourceRelative(game),content,error);
}
Outcome retireExisting(const ExistingContent &content) {
    Outcome out;std::string error;if(!content.valid||!userGame(content.game,error)){out.message=error.empty()?"Primero revisa el contenido previo del juego.":error;return out;}
    if(content.game.running){out.message="Cierra el juego antes de retirar sus mods y cheats.";return out;}
    ExistingContent now;if(!inspectExisting(content.game,now,error)||!sameEntries(content,now)){out.message=error.empty()?"El contenido previo cambió. Vuelve a revisar antes de continuar.":error;return out;}
    if(!content.exists){out.ok=true;out.message="El juego no tiene archivos previos que retirar.";return out;}
    const auto data=receipt(content);if(data.size()>MaxReceipt){out.message="El registro de los archivos previos supera 8 MiB. No se cambió su contenido.";return out;}
    bool exists=false;if(!folderChain(backupRelative(content.game),true,exists,error)){out.message=error;return out;}
    const std::string base=sdRoot()+"/"+backupRelative(content.game);std::string backup,token;
    for(unsigned n=0;n<100000;++n){std::string candidate=base+"/"+serial(n);struct stat st{};bool found=false;if(!statPath(candidate,st,found,error)){out.message=error;return out;}if(!found){backup=candidate;token=serial(n);break;}}
    if(backup.empty()||!directory(backup,true,exists,error)){out.message=error.empty()?"Hay demasiadas copias anteriores.":error;return out;}
    out.transactionId=token;
    out.backupPath=backup+"/content";
    if(!writeNew(backup+"/receipt.pending",data,error)||std::rename((backup+"/receipt.pending").c_str(),(backup+"/receipt.bin").c_str())!=0||!writeNew(backup+"/ready",std::string("NMEC1\n")+hexId(content.game.id)+"\n",error)) {
        out.message="No se retiró el contenido previo. "+(error.empty()?"No se pudo confirmar el registro de copia.":error);return out;
    }
    // Revalidate after the durable receipt, immediately before the single SD
    // rename. The backup folder is unique and content does not exist in it yet.
    ExistingContent checked;
    if(!inspectExisting(content.game,checked,error)||!sameEntries(content,checked)){out.message=error.empty()?"Los mods o cheats cambiaron durante la preparación. No se retiraron.":error;return out;}
    const std::string source=sdRoot()+"/"+sourceRelative(content.game);struct stat destination{};bool occupied=false;
    if(!statPath(out.backupPath,destination,occupied,error)||occupied){out.message=error.empty()?"El destino de copia ya está ocupado.":error;return out;}
    if(std::rename(source.c_str(),out.backupPath.c_str())!=0){out.message="No se pudo apartar la carpeta anterior; permanece en Atmosphère.";return out;}
    ExistingContent saved;
    bool sourceExists=false;struct stat sourceStat{};
    bool verified=statPath(source,sourceStat,sourceExists,error)&&!sourceExists&&inspectTree(content.game,out.backupPath,saved,error)&&sameEntries(content,saved);
    if(!verified) {
        if(!sourceExists)std::rename(out.backupPath.c_str(),source.c_str());
        out.message="No se pudo confirmar la carpeta apartada. Revisa la copia antes de continuar.";return out;
    }
    if(!writeNew(backup+"/complete","NMEC1\n",error)){out.message="Contenido anterior apartado y conservado, pero no se pudo cerrar el registro. "+error;return out;}
    out.ok=true;out.count=content.files;out.message="Mods y cheats anteriores apartados de Atmosphère. Se conserva la carpeta completa en la copia de seguridad.";return out;
}
static Outcome restoreExistingChoice(const Game &game,const std::string &token) {
    Outcome out;std::string error;if(!userGame(game,error)){out.message=error;return out;}
    if(!token.empty()&&!serialValid(token)){out.message="El identificador de la copia debe contener exactamente ocho dígitos.";return out;}
    if(game.running){out.message="Cierra el juego antes de restaurar sus mods y cheats anteriores.";return out;}
    bool exists=false;if(!folderChain(backupRelative(game),false,exists,error)||!exists){out.message=error.empty()?"No hay una copia completa anterior para este juego.":error;return out;}
    const std::string base=sdRoot()+"/"+backupRelative(game);std::vector<std::string> candidates;
    if(!token.empty())candidates.push_back(token);
    else {
        DIR *dir=opendir(base.c_str());if(!dir){out.message="No se pudo revisar la copia anterior.";return out;}
        errno=0;
        while(auto *item=readdir(dir)){if(serialValid(item->d_name))candidates.emplace_back(item->d_name);errno=0;}
        const int scanError=errno;if(closedir(dir)!=0||scanError){out.message="La lectura de las copias quedó incompleta.";return out;}
        std::sort(candidates.rbegin(),candidates.rend());
    }
    for(const auto &candidate:candidates) {
        out.transactionId=candidate;
        const std::string backup=base+"/"+candidate;bool isdir=false;
        if(!directory(backup,false,isdir,error)||!isdir){out.message=error.empty()?"La carpeta de copia no es válida.":error;return out;}
        struct stat mark{};bool restored=false;
        if(!statPath(backup+"/restored",mark,restored,error)){out.message=error;return out;}
        if(restored&&token.empty())continue;
        bool contentExists=false;if(!statPath(backup+"/content",mark,contentExists,error)){out.message=error;return out;}
        if(!contentExists&&token.empty())continue;
        out.backupPath=backup+"/content";std::string marker,data;ExistingContent expected,saved,current;
        if(!readFile(backup+"/ready",marker,error)||marker!=std::string("NMEC1\n")+hexId(game.id)+"\n"||!readFile(backup+"/receipt.bin",data,error)||!parseReceipt(data,game,expected)) {
            out.message=error.empty()?"La copia anterior cambió o su registro no es válido. Consérvala para revisión manual.":error;return out;
        }
        // An explicitly linked recovery is retryable after a crash or after a
        // different linked recovery failed. It must never advance history.
        // Confirm its receipt, marker and exact destination inventory first.
        if(restored||!contentExists) {
            out.backupPath=backup;
            if(restored&&(!readFile(backup+"/restored",marker,error)||marker!="NMEC1\n"||contentExists)) {
                out.message=error.empty()?"El marcador de esta restauración no es válido.":error;return out;
            }
            if(!inspectExisting(game,current,error)||!sameEntries(expected,current)) {
                out.message=error.empty()?"El contenido restaurado cambió. No se confirmará otra recuperación ni se sobrescribirán sus archivos.":error;return out;
            }
            if(!restored&&!writeNew(backup+"/restored","NMEC1\n",error)){out.message="La carpeta coincide con la copia anterior, pero no se pudo cerrar su registro de recuperación. "+error;return out;}
            out.ok=true;out.message=restored?"Esta copia ya estaba restaurada; se comprobó de nuevo su contenido.":"Se confirmó la restauración interrumpida de esta copia concreta.";return out;
        }
        if(!inspectTree(game,out.backupPath,saved,error)||!sameEntries(expected,saved)) {
            out.message=error.empty()?"La copia anterior cambió o su registro no es válido. Consérvala para revisión manual.":error;return out;
        }
        if(!inspectExisting(game,current,error)){out.message=error;return out;}
        if(current.exists){out.message="Hay contenido nuevo en Atmosphère. La copia anterior se conserva; aparta primero el contenido actual para restaurarla completa.";return out;}
        bool parents=false;if(!folderChain("atmosphere/contents",true,parents,error)){out.message=error;return out;}
        const std::string target=sdRoot()+"/"+sourceRelative(game);
        // restorePack may leave the cheats/ directory after removing its own
        // files. Revalidate the complete empty tree, then remove directories
        // from deepest to shallowest with rmdir only. A newly added file makes
        // rmdir fail and is never deleted or overwritten.
        ExistingContent emptyChecked;
        if(!inspectExisting(game,emptyChecked,error)||!sameEntries(current,emptyChecked)){out.message=error.empty()?"La carpeta vacía cambió antes de restaurar la copia.":error;return out;}
        for(auto entry=current.entries.rbegin();entry!=current.entries.rend();++entry) {
            if(!entry->directory){out.message="Apareció contenido nuevo antes de restaurar la copia.";return out;}
            const std::string emptyPath=entry->path.empty()?target:target+"/"+entry->path;
            bool stillThere=false;
            if(!directory(emptyPath,false,stillThere,error)||!stillThere||rmdir(emptyPath.c_str())!=0){out.message=error.empty()?"La carpeta actual dejó de estar vacía. No se restauró la copia.":error;return out;}
        }
        if(std::rename(out.backupPath.c_str(),target.c_str())!=0){out.message="No se pudo devolver la carpeta anterior a Atmosphère. La copia permanece disponible.";return out;}
        ExistingContent checked;if(!inspectExisting(game,checked,error)||!sameEntries(expected,checked)){out.message="La carpeta volvió a Atmosphère, pero la comprobación necesita revisión.";return out;}
        if(!writeNew(backup+"/restored","NMEC1\n",error)){out.message="Contenido anterior restaurado, pero no se pudo cerrar el registro de restauración.";return out;}
        out.ok=true;out.count=expected.files;out.message="Carpeta anterior de mods y cheats restaurada en Atmosphère.";return out;
    }
    out.message="No hay una copia completa pendiente de restaurar para este juego.";return out;
}
Outcome restoreExisting(const Game &game) {return restoreExistingChoice(game,{});}
Outcome restoreExistingAt(const Game &game,const std::string &transactionId) {
    if(!serialValid(transactionId)){Outcome out;out.message="El identificador de la copia debe contener exactamente ocho dígitos.";return out;}
    return restoreExistingChoice(game,transactionId);
}
}

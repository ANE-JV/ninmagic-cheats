#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "diagnostics.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace nc {
namespace {
constexpr size_t MaxLog=128*1024,MaxRecord=32*1024,MaxCodes=128;
constexpr char Header[]="NINMAGIC-CHEATS-DIAGNOSTIC-V1\nEstados del motor; no se lee memoria del juego ni se confirma su efecto.\n";
std::string root() {
#ifdef NC_DIAGNOSTICS_TEST
    const char *p=std::getenv("NC_DIAGNOSTICS_ROOT");return p?p:"diagnostics-test";
#else
    return "sdmc:";
#endif
}
std::string clean(const std::string &value,size_t maximum) {
    std::string out;out.reserve(std::min(value.size(),maximum));
    for(unsigned char c:value){if(out.size()>=maximum)break;out+=c<32||c==127?' ':char(c);}
    return out;
}
const char *state(CheatState value) {
    switch(value){case CheatState::NotLoaded:return "not-loaded";case CheatState::Disabled:return "disabled";case CheatState::Enabled:return "enabled";default:return "unknown";}
}
uint32_t codeHash(const Cheat &c) {
    uint32_t value=2166136261u;
    for(uint32_t word:c.opcodes)for(unsigned n=0;n<4;++n){value^=uint8_t(word>>(8*n));value*=16777619u;}
    return value;
}
std::string report(const std::string &event,const Pack &pack,const std::string &detail) {
    std::string out="\nBEGIN event="+clean(event,64)+" time="+std::to_string(static_cast<long long>(std::time(nullptr)))+"\n";
    out+="title="+hexId(pack.game.id)+" name="+clean(pack.game.name,256)+" version="+clean(pack.game.version,64)+"\n";
    out+="bid="+clean(pack.game.buildId,64)+" full-bid="+clean(pack.game.fullBuildId,64)+"\n";
    out+="running="+std::to_string(pack.game.running)+" build-verified="+std::to_string(pack.game.buildVerified)+" live-checked="+std::to_string(pack.liveChecked)+" hydrated="+std::to_string(pack.liveHydrated)+" pid="+std::to_string(pack.livePid)+"\n";
    out+="build-detail="+clean(pack.game.detail,2048)+"\npack-detail="+clean(pack.detail,4096)+"\n";
    out+="live-detail="+clean(pack.liveDetail,2048)+"\nextra="+clean(detail,2048)+"\n";
    out+="catalog-codes="+std::to_string(pack.cheats.size())+" selected="+std::to_string(selectedCount(pack))+"\n";
    size_t written=0;
    for(unsigned pass=0;pass<2;++pass)for(const auto &c:pack.cheats) {
        const bool primary=c.selected||c.liveState==CheatState::Enabled||c.liveState==CheatState::Disabled;
        if(primary!=(pass==0))continue;
        if(written>=MaxCodes)continue;
        char hash[9];std::snprintf(hash,sizeof(hash),"%08X",codeHash(c));
        const auto line="code selected="+std::to_string(c.selected)+" master="+std::to_string(c.master)+" state="+state(c.liveState)+" words="+std::to_string(c.opcodes.size())+" hash="+hash+" name="+clean(c.name,128)+" source="+clean(c.source,96)+"\n";
        if(out.size()+line.size()+80>MaxRecord)continue;
        out+=line;++written;
    }
    out+="codes-reported="+std::to_string(written)+" omitted="+std::to_string(pack.cheats.size()-written)+"\nEND\n";return out;
}
bool directory(const std::string &path,bool create) {
    struct stat st{};
    if(lstat(path.c_str(),&st)!=0) {
        if(errno!=ENOENT||!create)return false;
#ifdef _WIN32
        if(mkdir(path.c_str())!=0)return false;
#else
        if(mkdir(path.c_str(),0700)!=0)return false;
#endif
        if(lstat(path.c_str(),&st)!=0)return false;
    }
    return S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);
}
bool writeAll(int fd,const std::string &data) {
    size_t at=0;while(at<data.size()){const auto n=::write(fd,data.data()+at,data.size()-at);if(n<=0)return false;at+=size_t(n);}return true;
}
}
void logCheatDiagnostic(const std::string &event,const Pack &pack,const std::string &detail) noexcept {
    const auto base=root();if(base.empty()||!directory(base+"/",false)||!directory(base+"/config",true)||!directory(base+"/config/NinMagicCheats",true))return;
    const auto path=base+"/config/NinMagicCheats/diagnostico-cheats.txt";
    struct stat before{};bool existed=lstat(path.c_str(),&before)==0;
    if(existed&&(!S_ISREG(before.st_mode)||S_ISLNK(before.st_mode)))return;
    if(!existed&&errno!=ENOENT)return;
    int flags=O_RDWR|O_CREAT;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=open(path.c_str(),flags,0600);if(fd<0)return;
    struct stat now{};
    if(fstat(fd,&now)!=0||!S_ISREG(now.st_mode)||now.st_size<0||(existed&&(now.st_dev!=before.st_dev||now.st_ino!=before.st_ino))){close(fd);return;}
    if(now.st_size) {
        std::array<char,sizeof(Header)-1> prefix{};
        const auto n=::read(fd,prefix.data(),prefix.size());
        if(n!=static_cast<ssize_t>(prefix.size())||std::memcmp(prefix.data(),Header,prefix.size())){close(fd);return;}
    }
    const auto data=report(event,pack,detail);
    const bool reset=!now.st_size||uint64_t(now.st_size)>MaxLog||uint64_t(now.st_size)+data.size()>MaxLog;
    if(reset) {
        if(ftruncate(fd,0)!=0||lseek(fd,0,SEEK_SET)<0||!writeAll(fd,Header)){close(fd);return;}
    }else if(lseek(fd,0,SEEK_END)<0){close(fd);return;}
    if(writeAll(fd,data))fsync(fd);
    close(fd);
}
}

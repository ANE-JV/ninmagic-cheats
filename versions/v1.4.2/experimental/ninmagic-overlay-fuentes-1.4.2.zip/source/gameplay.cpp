#include "gameplay.hpp"
#include <algorithm>
#include <set>
namespace nc {
void gameplayOnly(Pack &pack) {
    std::set<std::string> groups;
    const auto group=[](const Cheat &c){return c.group.empty()?c.source:c.group;};
    for(const auto &c:pack.cheats)if(!c.master&&!(c.categories&(Fps|Resolution|Graphics)))groups.insert(group(c));
    pack.cheats.erase(std::remove_if(pack.cheats.begin(),pack.cheats.end(),[&](const Cheat &c){
        return c.master?!groups.count(group(c)):(c.categories&(Fps|Resolution|Graphics))!=0;
    }),pack.cheats.end());
    const bool hadOptions=pack.compatible;
    pack.compatible=std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const Cheat &c){return !c.master;});
    if(hadOptions&&!pack.compatible)pack.detail="Este Build ID solo tiene ajustes de imagen o rendimiento. No hay cheats de jugabilidad publicados en el catálogo.";
}
}

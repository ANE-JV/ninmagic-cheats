#include "title_metadata.hpp"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cstring>
#include <vector>

namespace nc {
namespace {
// Wire format verified against switchbrew/libnx nx/include/switch/nacp.h:
// https://github.com/switchbrew/libnx/blob/master/nx/include/switch/nacp.h
constexpr size_t NacpSize=0x4000,EntrySize=0x300,NameSize=0x200,AuthorSize=0x100;
constexpr size_t VersionOffset=0x3060,FormatOffset=0x3215,MaxCompressed=0x2FFE;
constexpr size_t MaxExpanded=32*EntrySize;
bool printableUtf8(const uint8_t *text,size_t size) {
    for(size_t i=0;i<size;) {
        const uint8_t first=text[i++];uint32_t code=first;unsigned more=0;uint32_t minimum=0;
        if(first<0x80){}else if(first>=0xC2&&first<=0xDF){code=first&31;more=1;minimum=0x80;}
        else if(first>=0xE0&&first<=0xEF){code=first&15;more=2;minimum=0x800;}
        else if(first>=0xF0&&first<=0xF4){code=first&7;more=3;minimum=0x10000;}
        else return false;
        if(more>size-i)return false;
        for(unsigned n=0;n<more;++n){const uint8_t next=text[i++];if((next&0xC0)!=0x80)return false;code=(code<<6)|(next&63);}
        if((more&&code<minimum)||code>0x10FFFF||(code>=0xD800&&code<=0xDFFF)||code<0x20||(code>=0x7F&&code<=0x9F))return false;
    }
    return true;
}
bool textField(const uint8_t *field,size_t capacity,std::string &out,bool asciiOnly=false) {
    out.clear();const auto *end=static_cast<const uint8_t*>(std::memchr(field,0,capacity));if(!end)return false;
    const size_t size=static_cast<size_t>(end-field);
    if(!size||!printableUtf8(field,size)||(asciiOnly&&std::any_of(field,end,[](uint8_t c){return c>0x7E;})))return false;
    size_t begin=0,length=size;while(begin<length&&field[begin]==' ')++begin;while(length>begin&&field[length-1]==' ')--length;
    if(begin==length)return false;
    out.assign(reinterpret_cast<const char*>(field+begin),length-begin);return true;
}
bool inflateLanguages(const uint8_t *data,std::array<uint8_t,MaxExpanded+1> &expanded,size_t &size,std::string &error) {
    const size_t compressed=size_t(data[0])|(size_t(data[1])<<8);
    if(!compressed||compressed>MaxCompressed){error="El tamaño de los títulos comprimidos del NACP no es válido.";return false;}
    z_stream stream{};stream.next_in=const_cast<Bytef*>(data+2);stream.avail_in=static_cast<uInt>(compressed);
    stream.next_out=expanded.data();stream.avail_out=static_cast<uInt>(expanded.size());
    if(inflateInit2(&stream,-MAX_WBITS)!=Z_OK){error="No se pudo preparar la lectura de los títulos comprimidos.";return false;}
    const int result=inflate(&stream,Z_FINISH);size=static_cast<size_t>(stream.total_out);const bool complete=result==Z_STREAM_END&&stream.avail_in==0;
    inflateEnd(&stream);
    if(!complete||size<16*EntrySize||size>MaxExpanded||size%EntrySize){error="Los títulos comprimidos del NACP están dañados o incompletos.";return false;}
    return true;
}
}
bool parseTitleMetadata(const void *nacp,size_t size,TitleMetadata &out,std::string &error,int preferredLanguage) {
    out={};error.clear();
    if(!nacp||size<NacpSize){error="El NACP no contiene sus 0x4000 bytes completos.";return false;}
    const auto *data=static_cast<const uint8_t*>(nacp);
    out.versionValid=textField(data+VersionOffset,16,out.version,true);
    const unsigned format=data[FormatOffset];
    std::array<uint8_t,MaxExpanded+1> expanded{};const uint8_t *entries=data;size_t entryBytes=16*EntrySize;
    if(format==1){out.compressed=true;if(!inflateLanguages(data,expanded,entryBytes,error))return false;entries=expanded.data();}
    else if(format!=0){error="El formato de los títulos del NACP no está admitido.";return false;}
    out.languageCount=static_cast<unsigned>(entryBytes/EntrySize);
    for(unsigned n=0;n<out.languageCount;++n){auto &language=out.languages[n];const uint8_t *entry=entries+n*EntrySize;language.nameValid=textField(entry,NameSize,language.name);language.authorValid=textField(entry+NameSize,AuthorSize,language.author);}
    std::vector<unsigned> order;
    const auto add=[&](int index){if(index>=0&&static_cast<unsigned>(index)<out.languageCount&&std::find(order.begin(),order.end(),static_cast<unsigned>(index))==order.end())order.push_back(static_cast<unsigned>(index));};
    add(preferredLanguage);for(int n:{0,1,6,5})add(n);for(unsigned n=0;n<out.languageCount;++n)add(static_cast<int>(n));
    for(unsigned n:order)if(out.languages[n].nameValid){out.name=out.languages[n].name;out.selectedLanguage=static_cast<int>(n);out.titleValid=true;break;}
    if(out.selectedLanguage>=0&&out.languages[static_cast<unsigned>(out.selectedLanguage)].authorValid){out.authorLanguage=out.selectedLanguage;out.author=out.languages[static_cast<unsigned>(out.selectedLanguage)].author;out.authorValid=true;}
    else for(unsigned n:order)if(out.languages[n].authorValid){out.authorLanguage=static_cast<int>(n);out.author=out.languages[n].author;out.authorValid=true;break;}
    return true;
}
}

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "archive_merge.hpp"
#include <minizip/zip.h>
#include <minizip/unzip.h>
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
unsigned scenarios=0,checks=0;fs::path sandbox,current;
void check(bool v,const char*s){++checks;if(!v)throw std::runtime_error(s);}
#define CHECK(x) check((x),#x)
struct Item{std::string name,data;unsigned attrs=0100644u<<16;int method=Z_DEFLATED;};
const std::string Tid="01006BB00C6F0000",Bid="909E904AF78AC1B8",OldBid="AE16F71E002AF8CB";
std::string name(const std::string&bid=Bid){return "contents/"+Tid+"/cheats/"+bid+".txt";}
std::string body(const std::string&label="Rupees"){return "["+label+"]\n80000040\n02000000 01CC0760 0000270F\n20000000\n";}
void zip(const fs::path&path,const std::vector<Item>&items){zipFile z=zipOpen64(path.generic_string().c_str(),APPEND_STATUS_CREATE);CHECK(z);for(const auto&i:items){zip_fileinfo meta{};meta.external_fa=i.attrs;CHECK(zipOpenNewFileInZip64(z,i.name.c_str(),&meta,nullptr,0,nullptr,0,nullptr,i.method,i.method==0?0:Z_BEST_SPEED,0)==ZIP_OK);CHECK(zipWriteInFileInZip(z,i.data.data(),unsigned(i.data.size()))==ZIP_OK);CHECK(zipCloseFileInZip(z)==ZIP_OK);}CHECK(zipClose(z,nullptr)==ZIP_OK);}
std::string read(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void put(const fs::path&p,const std::string&s){std::ofstream f(p,std::ios::binary);f.write(s.data(),std::streamsize(s.size()));CHECK(bool(f));}
std::map<std::string,std::string> members(const fs::path&p){unzFile z=unzOpen64(p.generic_string().c_str());CHECK(z);unz_global_info64 g{};CHECK(unzGetGlobalInfo64(z,&g)==UNZ_OK);std::map<std::string,std::string> out;int next=g.number_entry?unzGoToFirstFile(z):UNZ_END_OF_LIST_OF_FILE;for(uint64_t i=0;i<g.number_entry;++i){CHECK(next==UNZ_OK);unz_file_info64 meta{};char n[1025]{};CHECK(unzGetCurrentFileInfo64(z,&meta,n,sizeof(n),nullptr,0,nullptr,0)==UNZ_OK&&meta.size_filename<sizeof(n));CHECK(unzOpenCurrentFile(z)==UNZ_OK);std::string bytes;char b[8192];int count=0;while((count=unzReadCurrentFile(z,b,sizeof(b)))>0)bytes.append(b,size_t(count));CHECK(count==0&&unzCloseCurrentFile(z)==UNZ_OK&&bytes.size()==meta.uncompressed_size);CHECK(out.emplace(n,bytes).second);next=unzGoToNextFile(z);}CHECK(next==UNZ_END_OF_LIST_OF_FILE);CHECK(unzClose(z)==UNZ_OK);return out;}
void next(){current=sandbox/("case-"+std::to_string(++scenarios));fs::create_directory(current);}
bool merge(const std::vector<std::string>&files,const std::string&out="merged.zip"){std::vector<std::string> inputs;for(const auto&n:files)inputs.push_back((current/n).generic_string());std::string error;const bool ok=nc::mergeCheatArchives(inputs,(current/out).generic_string(),error);if(!ok)CHECK(!error.empty());return ok;}
void cleanup(){const auto resolved=fs::weakly_canonical(sandbox),parent=fs::weakly_canonical(fs::temp_directory_path());CHECK(resolved.parent_path()==parent&&resolved.filename().string().find("ninmagic-archive-merge-test-")==0);fs::remove_all(resolved);}
}
int main(int argc,char**argv){sandbox=fs::temp_directory_path()/("ninmagic-archive-merge-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{fs::create_directory(sandbox);
    next();zip(current/"a.zip",{{name(),body()}});const auto original=read(current/"a.zip");CHECK(merge({"a.zip"}));CHECK(members(current/"merged.zip").at(name())==body()&&read(current/"a.zip")==original);
    next();zip(current/"a.zip",{{name(OldBid),body("Old version")},{name(),body("Original")}});zip(current/"b.zip",{{name(),body("New winner")}});CHECK(merge({"a.zip","b.zip"}));auto out=members(current/"merged.zip");CHECK(out.size()==2&&out.at(name())==body("New winner")&&out.at(name(OldBid))==body("Old version"));
    next();zip(current/"a.zip",{{"repo-main/titles/"+Tid+"/cheats/"+Bid+".TXT",body()}});CHECK(merge({"a.zip"})&&members(current/"merged.zip").at(name())==body());
    next();zip(current/"empty.zip",{});zip(current/"a.zip",{{name(),body()}});CHECK(merge({"empty.zip","a.zip","empty.zip"}));
    next();zip(current/"empty.zip",{});CHECK(!merge({"empty.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()}});put(current/"merged.zip","keep existing");CHECK(!merge({"a.zip"})&&read(current/"merged.zip")=="keep existing");CHECK(!merge({"a.zip"},"a.zip")&&members(current/"a.zip").at(name())==body());
    next();zip(current/"a.zip",{{name(),body()},{"titles/"+Tid+"/cheats/"+Bid+".txt",body("Ambiguous")}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"../evil.txt","bad"}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"C:/evil.txt","bad"}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"contents\\evil.txt","bad"}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"readme.txt","link",0120777u<<16}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body(),0100644u<<16,0}});auto damaged=read(current/"a.zip");auto at=damaged.find(body());CHECK(at!=std::string::npos);damaged[at+5]^=1;put(current/"a.zip",damaged);CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"README.md","UNIQUE-CREDIT-BODY",0100644u<<16,0}});damaged=read(current/"a.zip");at=damaged.find("UNIQUE-CREDIT-BODY");CHECK(at!=std::string::npos);damaged[at]^=1;put(current/"a.zip",damaged);CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"contents/"+Tid+"/Atelier Sophie: credits.txt","Author A\nLicence text\n"},{"LICENSE","same licence"}});zip(current/"b.zip",{{name(),body("Latest")},{"COPYING","same licence"}});CHECK(merge({"a.zip","b.zip"}));out=members(current/"merged.zip");CHECK(out.size()==4&&out.at(name())==body("Latest"));unsigned credits=0;for(const auto&entry:out)if(entry.first.rfind("history-credits/",0)==0){++credits;CHECK(entry.second=="Author A\nLicence text\n"||entry.second=="same licence");}CHECK(credits==3);CHECK(merge({"merged.zip","b.zip"},"again.zip"));CHECK(members(current/"again.zip")==out);CHECK(merge({"again.zip","b.zip"},"third.zip")&&members(current/"third.zip")==out);
    next();zip(current/"a.zip",{{name(),body()},{"contents/"+Tid+"/Author A.txt",""},{"contents/"+Tid+"/Author B.txt",""}});zip(current/"b.zip",{{name(),body()},{"contents/"+Tid+"/Author A.txt",""}});CHECK(merge({"a.zip","b.zip"}));out=members(current/"merged.zip");CHECK(out.size()==3);CHECK(merge({"merged.zip","a.zip","b.zip"},"again.zip")&&members(current/"again.zip")==out);
    next();zip(current/"a.zip",{{name(),body()}});fs::create_symlink(current/"a.zip",current/"link.zip");CHECK(fs::is_symlink(current/"link.zip"));CHECK(!merge({"link.zip"})&&!fs::exists(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()}});put(current/"outside","keep");fs::create_symlink(current/"outside",current/"merged.zip");CHECK(!merge({"a.zip"})&&read(current/"outside")=="keep"&&fs::is_symlink(current/"merged.zip"));
    next();zip(current/"a.zip",{{name(),body()},{"too-big.txt",std::string(2*1024*1024+1,'x')}});CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();{std::ofstream huge(current/"a.zip",std::ios::binary);huge.seekp(64ull*1024*1024);huge.put('x');}CHECK(!merge({"a.zip"})&&!fs::exists(current/"merged.zip"));
    next();{std::string error;CHECK(!nc::mergeCheatArchives({},(current/"merged.zip").generic_string(),error)&&!fs::exists(current/"merged.zip"));}
    if(argc>1){next();std::vector<std::string> real;for(int i=1;i<argc;++i)real.push_back(fs::absolute(argv[i]).generic_string());std::string error;CHECK(nc::mergeCheatArchives(real,(current/"merged.zip").generic_string(),error));out=members(current/"merged.zip");CHECK(out.size()>3000&&out.count(name())&&out.count(name(OldBid)));std::cout<<"real merged members: "<<out.size()<<" size="<<fs::file_size(current/"merged.zip")<<'\n';real[0]=(current/"merged.zip").generic_string();CHECK(nc::mergeCheatArchives(real,(current/"again.zip").generic_string(),error));CHECK(members(current/"again.zip")==out);std::cout<<"real repeated merge stable: "<<out.size()<<" members\n";}
    cleanup();std::cout<<"archive merge: "<<scenarios<<" overlay, credit, CRC and path scenarios passed ("<<checks<<" checks)\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<"\nFixtures retained: "<<sandbox<<'\n';return 1;}}

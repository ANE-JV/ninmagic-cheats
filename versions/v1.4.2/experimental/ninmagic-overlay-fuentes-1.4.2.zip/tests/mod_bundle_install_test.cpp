#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "mods.hpp"
#include "mod_install.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <unistd.h>

namespace fs=std::filesystem;
using namespace nc;
namespace {
using Bytes=std::vector<uint8_t>;
fs::path sandbox,current;unsigned scenarios=0,checks=0;
void check(bool v,const char*message){++checks;if(!v)throw std::runtime_error(message);}
#define CHECK(x) check((x),#x)
Game game(){Game g;g.id=0x01007300020FA000ULL;g.buildId="4B159F0F7A360669";g.fullBuildId=g.buildId+std::string(48,'0');g.buildVerified=true;g.name="Production integration fixture";return g;}
void number(Bytes&b,uint32_t value,unsigned n){for(int i=int(n)-1;i>=0;--i)b.push_back(uint8_t(value>>(8*i)));}
Bytes ips(uint32_t address,Bytes values,bool wide=true){Bytes b=wide?Bytes{'I','P','S','3','2'}:Bytes{'P','A','T','C','H'};number(b,address,wide?4:3);number(b,uint32_t(values.size()),2);b.insert(b.end(),values.begin(),values.end());if(wide)b.insert(b.end(),{'E','E','O','F'});else b.insert(b.end(),{'E','O','F'});return b;}
Bytes rle(uint32_t address,uint16_t count,uint8_t value){Bytes b={'P','A','T','C','H'};number(b,address,3);number(b,0,2);number(b,count,2);b.push_back(value);b.insert(b.end(),{'E','O','F'});return b;}
ModPayload prepare(const std::string&name,const Bytes&data){ModEntry e;e.titleId=game().id;e.name=name;e.buildId=game().fullBuildId;e.format=ModFormat::Ips;e.repository="ADEMOLA200/Switch-Emulator-Mod-Database";ModPayload out;std::string error;CHECK(parseModPayload(game(),e,std::string(data.begin(),data.end()),out,error)&&out.compatible);return out;}
ModPayload prepareText(){ModEntry e;e.titleId=game().id;e.name="Sin desenfoque";e.format=ModFormat::Pchtxt;e.repository="ADEMOLA200/Switch-Emulator-Mod-Database";std::string text="@nsobid-"+game().fullBuildId+"\n@flag offset_shift 0x100\n@enabled\n00002F00 11223344\n@stop\n";ModPayload out;std::string error;CHECK(parseModPayload(game(),e,text,out,error));return out;}
void put(const fs::path&p,const Bytes&b){fs::create_directories(p.parent_path());std::ofstream out(p,std::ios::binary);out.write(reinterpret_cast<const char*>(b.data()),std::streamsize(b.size()));CHECK(bool(out));}
Bytes get(const fs::path&p){std::ifstream input(p,std::ios::binary);return {std::istreambuf_iterator<char>(input),{}};}
fs::path own(){return current/"atmosphere/exefs_patches"/("NinMagic-"+hexId(game().id))/(game().fullBuildId+".ips");}
fs::path foreign(){return current/"atmosphere/exefs_patches/OtherMod"/(game().fullBuildId+".ips");}
PatchInventory inspect(){PatchInventory out;std::string error;CHECK(inspectPatches(game(),out,error)&&out.valid);return out;}
std::map<std::string,Bytes> tree(){std::map<std::string,Bytes> out;for(const auto&e:fs::recursive_directory_iterator(current))if(e.is_regular_file())out[e.path().lexically_relative(current).generic_string()]=get(e.path());return out;}
std::map<uint32_t,uint8_t> decode(const Bytes&b){CHECK(b.size()>=9&&std::equal(b.begin(),b.begin()+5,"IPS32"));size_t at=5;std::map<uint32_t,uint8_t> out;while(at+4<=b.size()&&!std::equal(b.begin()+at,b.begin()+at+4,"EEOF")){CHECK(at+6<=b.size());uint32_t address=0;for(unsigned i=0;i<4;++i)address=(address<<8)|b[at++];size_t n=(size_t(b[at])<<8)|b[at+1];at+=2;CHECK(n&&n<=b.size()-at);for(size_t i=0;i<n;++i)out[address+uint32_t(i)]=b[at++];}CHECK(at+4==b.size());return out;}
void next(){current=sandbox/("case-"+std::to_string(++scenarios));fs::create_directory(current);CHECK(setenv("NC_MOD_INSTALL_ROOT",current.generic_string().c_str(),1)==0);}
void cleanup(){const auto base=fs::weakly_canonical(fs::temp_directory_path()),resolved=fs::weakly_canonical(sandbox);CHECK(resolved.parent_path()==base&&resolved.filename().string().find("ninmagic-mod-bundle-install-")==0);fs::remove_all(resolved);}
}
int main(){
    sandbox=fs::temp_directory_path()/("ninmagic-mod-bundle-install-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    try{
        fs::create_directory(sandbox);std::string error;ModPayload combined;
        next();{
            const auto a=prepare("60 FPS",ips(0x1000,{1,2,3,4},false)),b=prepare("Resolución",rle(0x2000,4,9));
            CHECK(combineMods(game(),{a,b},combined,error)&&combined.names.size()==2);const auto installed=installMod(game(),combined,inspect(),false);CHECK(installed.ok&&!installed.transactionId.empty());CHECK(get(own())==combined.ips);auto active=inspect();CHECK(active.entries.size()==1);const auto actual=decode(get(own()));CHECK(actual.size()==8&&actual.at(0x1000)==1&&actual.at(0x1003)==4&&actual.at(0x2000)==9&&actual.at(0x2003)==9);
            const auto removed=removeMods(game());CHECK(removed.ok&&removed.transactionId==installed.transactionId&&!fs::exists(own()));CHECK(ackModRecovery(game(),removed.transactionId).ok);
        }
        next();{
            const auto previous=ips(0x5000,{7,7,7,7});put(own(),previous);CHECK(combineMods(game(),{prepare("60 FPS",ips(0x1000,{1})),prepareText()},combined,error));const auto installed=installMod(game(),combined,inspect(),false,"00000041");CHECK(installed.ok);const auto actual=decode(get(own()));CHECK(actual.at(0x1000)==1&&actual.at(0x3000)==0x11&&actual.at(0x3003)==0x44);const auto removed=removeMods(game());CHECK(removed.ok&&removed.previousContent=="00000041"&&get(own())==previous);const auto pending=removeMods(game());CHECK(pending.ok&&pending.transactionId==removed.transactionId&&pending.previousContent=="00000041"&&pending.count==0&&get(own())==previous);CHECK(ackModRecovery(game(),removed.transactionId).ok);CHECK(!removeMods(game()).ok&&get(own())==previous);
        }
        next();{
            const auto previous=ips(0x1000,{8,8});put(foreign(),previous);CHECK(combineMods(game(),{prepare("60 FPS",ips(0x1000,{1,2})),prepare("Gráficos",ips(0x2000,{3,4}))},combined,error));const auto installed=installMod(game(),combined,inspect(),true);CHECK(installed.ok&&!fs::exists(foreign())&&inspect().entries.size()==1);const auto removed=removeMods(game());CHECK(removed.ok&&get(foreign())==previous&&!fs::exists(own()));CHECK(ackModRecovery(game(),removed.transactionId).ok);
        }
        next();{
            put(foreign(),ips(0x4000,{4,4}));const auto before=tree();const auto a=prepare("30 FPS",ips(0x1000,{1})),b=prepare("60 FPS",rle(0x1000,1,2));CHECK(!combineMods(game(),{a,b},combined,error)&&!combined.compatible&&combined.ips.empty());CHECK(tree()==before&&!fs::exists(current/"config")&&!fs::exists(own()));
        }
        next();{
            put(foreign(),rle(0x1000,4,9));CHECK(combineMods(game(),{prepare("A",ips(0x1000,{9,9,9,9})),prepare("B",rle(0x1002,2,9))},combined,error));CHECK(installMod(game(),combined,inspect(),false).ok&&inspect().entries.size()==2);CHECK(decode(get(own())).size()==4);CHECK(removeMods(game()).ok&&get(foreign())==rle(0x1000,4,9)&&!fs::exists(own()));
        }
        next();{
            put(foreign(),ips(0x4000,{4}));const auto before=tree();auto wrong=prepare("Wrong build",ips(0x1000,{1}));wrong.game.fullBuildId.back()='1';CHECK(!combineMods(game(),{prepare("Correct",ips(0x2000,{2})),wrong},combined,error));CHECK(tree()==before&&!fs::exists(own()));
        }
        next();{
            put(foreign(),ips(0x4000,{4}));CHECK(combineMods(game(),{prepare("A",ips(0x1000,{1})),prepare("B",ips(0x2000,{2}))},combined,error));const auto reviewed=inspect();put(foreign(),ips(0x4000,{5}));const auto before=tree();CHECK(!installMod(game(),combined,reviewed,true).ok);CHECK(tree()==before&&!fs::exists(own()));
        }
        cleanup();std::cout<<"mod bundle install: "<<scenarios<<" production preparation, install and recovery scenarios passed ("<<checks<<" checks)\n";return 0;
    }catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<"\nFixtures retained: "<<sandbox<<'\n';return 1;}
}

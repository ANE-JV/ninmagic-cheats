#include "memory_scan_guard.hpp"
#include <array>
#include <cstdlib>
#include <iostream>

using namespace nc;using namespace nc::native::scan;
namespace {
unsigned scenarios=0,checks=0;
void check(bool value,const char*name){++checks;if(!value){std::cerr<<"FAILED: "<<name<<'\n';std::exit(1);}}
#define CHECK(x) check((x),#x)
ScanIdentity identity(){return {55,0x01006BB00C6F0000ULL,"909E904AF78AC1B8"+std::string(48,'0'),0x10000000,0x40000,0x20000000,0x20000000};}
struct Fake:Access {
    ScanIdentity current=identity();Mapping mapping{0x20000000,0x10000,3};
    unsigned verifies=0,queries=0,reads=0,changeAt=0,changeAliasAt=0;
    bool queryFail=false,readFail=false,unavailable=false;
    bool verify(const ScanIdentity&i,std::string&e)override{++verifies;if(changeAt&&verifies>=changeAt)++current.pid;if(changeAliasAt&&verifies>=changeAliasAt)current.aliasSize+=4096;if(unavailable||!same(i,current)){e="changed session";return false;}return true;}
    bool query(uint64_t,Mapping&m,std::string&e)override{++queries;if(queryFail){e="query failed";return false;}m=mapping;return true;}
    bool read(uint64_t,void*b,size_t size,std::string&e)override{++reads;std::memset(b,0xA5,size);if(readFail){e="read failed";return false;}return true;}
};
bool zero(const std::array<unsigned char,8>&data){return std::all_of(data.begin(),data.end(),[](unsigned char c){return c==0;});}
}
int main(){const auto good=identity();
    CHECK(valid(good)&&same(good,good));++scenarios;
    {auto i=good;i.pid=0;CHECK(!valid(i));++scenarios;}
    {auto i=good;i.title=1;CHECK(!valid(i));++scenarios;}
    {auto i=good;i.fullBuildId.resize(16);CHECK(!valid(i));++scenarios;}
    {auto i=good;i.fullBuildId[63]='G';CHECK(!valid(i));++scenarios;}
    {auto i=good;i.fullBuildId.replace(0,16,"FfFfFfFfFfFfFfFf");CHECK(!valid(i));++scenarios;}
    {auto i=good;i.fullBuildId.replace(0,16,std::string(16,'0'));CHECK(!valid(i));++scenarios;}
    {auto i=good;i.mainBase=UINT64_MAX-10;i.mainSize=20;CHECK(!valid(i));++scenarios;}
    {auto i=good;i.heapSize=MaxExtent+1;CHECK(!valid(i));++scenarios;}
    {auto i=good;i.heapBase=i.mainBase+1;CHECK(!valid(i));++scenarios;}
    for(unsigned field=0;field<7;++field){auto i=good;if(field==0)++i.pid;else if(field==1)++i.title;else if(field==2)i.fullBuildId.back()='1';else if(field==3)++i.mainBase;else if(field==4)++i.mainSize;else if(field==5)++i.heapBase;else ++i.heapSize;CHECK(!same(good,i));++scenarios;}
    CHECK(allowed(good,good.mainBase,good.mainSize)&&allowed(good,good.heapBase+good.heapSize-4,4));CHECK(!allowed(good,good.mainBase-1,4)&&!allowed(good,good.heapBase+good.heapSize-3,4)&&!allowed(good,good.mainBase,0));++scenarios;
    {std::vector<ScanRegion>r;CHECK(append(good,{good.mainBase-0x1000,0x2000,3},r));CHECK(r.size()==1&&r[0].address==good.mainBase&&r[0].size==0x1000&&r[0].writable);++scenarios;}
    {std::vector<ScanRegion>r;CHECK(append(good,{good.heapBase+good.heapSize-0x1000,0x3000,3},r));CHECK(r.size()==1&&r[0].size==0x1000);++scenarios;}
    for(auto permissions:{0u,1u,2u,5u,7u,0x10000003u}){std::vector<ScanRegion>r;CHECK(!append(good,{good.heapBase,0x10000,permissions},r)&&r.empty());++scenarios;}
    {std::vector<ScanRegion>r;CHECK(append(good,{0x50000000,0x10000,3},r)&&r.empty());++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};CHECK(checkedRead(good,good.heapBase,b.data(),b.size(),f,e));CHECK(f.verifies==3&&f.queries==1&&f.reads==1&&b[0]==0xA5);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.current.pid++;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0&&f.queries==0);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.changeAt=2;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0&&f.queries==1);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.changeAt=3;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==1);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.queryFail=true;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.readFail=true;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==1&&f.verifies==3);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.unavailable=true;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);f.mapping.permission=5;CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);CHECK(!checkedRead(good,good.heapBase+f.mapping.size-4,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0);++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);CHECK(!checkedRead(good,good.mainBase-1,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0&&f.verifies==0);++scenarios;}
    {Fake f;std::string e;CHECK(!checkedRead(good,good.heapBase,nullptr,1,f,e)&&f.reads==0&&f.verifies==0);CHECK(!checkedRead(good,good.heapBase,nullptr,0,f,e));++scenarios;}
    {Fake f;std::string e;std::array<unsigned char,8>b{};b.fill(1);CHECK(!checkedRead(good,good.heapBase,b.data(),MaxRead+1,f,e)&&b[0]==1&&f.verifies==0);++scenarios;}
    auto alias=good;alias.aliasBase=0x5000000000ULL;alias.aliasSize=64ULL*1024*1024*1024;
    CHECK(valid(alias)&&same(alias,alias)&&!same(alias,good));++scenarios;
    for(unsigned field=0;field<6;++field){auto i=alias;if(field==0)i.aliasBase=0;else if(field==1)i.aliasSize=0;else if(field==2){i.aliasBase=UINT64_MAX-10;i.aliasSize=20;}else if(field==3)i.aliasSize=MaxAliasExtent+1;else if(field==4){i.aliasBase=i.mainBase;i.aliasSize=4096;}else{i.aliasBase=i.heapBase;i.aliasSize=4096;}CHECK(!valid(i));++scenarios;}
    {auto i=alias;++i.aliasBase;CHECK(!same(alias,i));++i.aliasSize;CHECK(!same(alias,i));++scenarios;}
    CHECK(allowed(alias,alias.aliasBase,4)&&allowed(alias,alias.aliasBase+alias.aliasSize-4,4));CHECK(!allowed(alias,alias.aliasBase+alias.aliasSize-3,4)&&!allowed(alias,alias.aliasBase-1,4));++scenarios;
    {std::vector<ScanRegion>r;CHECK(append(alias,{alias.aliasBase-0x1000,0x3000,3,5},r)&&r.size()==1&&r[0].address==alias.aliasBase&&r[0].size==0x2000);++scenarios;}
    for(unsigned type:{0u,3u,4u,6u,7u,15u,0x10006u}){std::vector<ScanRegion>r;CHECK(append(alias,{alias.aliasBase,0x10000,3,type},r)&&r.empty());++scenarios;}
    {std::vector<ScanRegion>r;CHECK(append(alias,{alias.aliasBase,0x10000,3,0x10005},r)&&r.size()==1);++scenarios;}
    for(unsigned permission:{0u,1u,2u,5u,7u,0x10000003u}){std::vector<ScanRegion>r;CHECK(!append(alias,{alias.aliasBase,0x10000,permission,5},r)&&r.empty());++scenarios;}
    {std::vector<ScanRegion>r;CHECK(!append(alias,{alias.aliasBase,MaxExtent+1,3,5},r)&&r.empty());CHECK(!allowed(alias,0x7000000000ULL,4));++scenarios;}
    {Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,5};std::string e;std::array<unsigned char,8>b{};CHECK(checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&b[0]==0xA5&&f.verifies==3&&f.reads==1);++scenarios;}
    for(unsigned type:{0u,4u,6u}){Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,type};std::string e;std::array<unsigned char,8>b{};b.fill(1);CHECK(!checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==0&&f.queries==1);++scenarios;}
    for(unsigned at:{2u,3u}){Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,5};f.changeAliasAt=at;std::string e;std::array<unsigned char,8>b{};b.fill(1);CHECK(!checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&zero(b)&&f.reads==(at==3?1u:0u));++scenarios;}
    {Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,5};std::string e;CHECK(checkedAliasTarget(alias,alias.aliasBase,4,f,e)&&f.verifies==2&&f.queries==1&&f.reads==0);++scenarios;}
    for(unsigned type:{0u,6u}){Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,type};std::string e;CHECK(!checkedAliasTarget(alias,alias.aliasBase,4,f,e)&&f.reads==0);++scenarios;}
    {Fake f;f.current=alias;f.mapping={alias.aliasBase,0x10000,3,5};f.changeAliasAt=2;std::string e;CHECK(!checkedAliasTarget(alias,alias.aliasBase,4,f,e)&&f.reads==0&&f.verifies==2);++scenarios;}
    {uint32_t codes[]={0x04200000,0x1234,99};uint64_t address=0;size_t size=0;CHECK(aliasStaticAddress(alias,codes,3,address,size)&&address==alias.aliasBase+0x1234&&size==4);codes[0]=0x04200001;CHECK(aliasStaticAddress(alias,codes,3,address,size)&&address==alias.aliasBase+0x100001234ULL);++scenarios;}
    for(unsigned mutation=0;mutation<7;++mutation){uint32_t codes[]={0x04200000,0x1234,99};if(mutation==0)codes[0]=0x04300000;else if(mutation==1)codes[0]=0x04210000;else if(mutation==2)codes[0]=0x08200000;else if(mutation==3)codes[0]=0x44200000;else if(mutation==4){codes[0]=0x01200000;codes[2]=256;}else if(mutation==5){codes[0]=0x04200010;codes[1]=0;}else{codes[0]=0x0420000F;codes[1]=0xffffffff;}uint64_t address=0;size_t size=0;CHECK(!aliasStaticAddress(alias,codes,3,address,size));++scenarios;}
    // Large reads use heap storage. They must still fit one current mapping,
    // preserve all three identity checks and clear the complete output on a
    // failure after copying. No worker/test stack allocation grows with MaxRead.
    {Fake f;f.mapping.size=MaxRead;std::string e;std::vector<uint8_t>b(MaxRead);CHECK(MaxRead==256*1024&&checkedRead(good,good.heapBase,b.data(),b.size(),f,e));CHECK(f.verifies==3&&f.queries==1&&f.reads==1&&b.front()==0xA5&&b.back()==0xA5);++scenarios;}
    {Fake f;f.mapping.size=MaxRead*2;std::string e;std::vector<uint8_t>b(MaxRead);CHECK(checkedRead(good,good.heapBase+MaxRead,b.data(),b.size(),f,e)&&f.reads==1&&b.back()==0xA5);++scenarios;}
    {Fake f;f.mapping.size=MaxRead;std::string e;std::vector<uint8_t>b(MaxRead,1);CHECK(!checkedRead(good,good.heapBase+1,b.data(),b.size(),f,e)&&f.verifies==1&&f.queries==1&&f.reads==0);CHECK(std::all_of(b.begin(),b.end(),[](uint8_t x){return x==0;}));++scenarios;}
    {Fake f;f.mapping={UINT64_MAX-100,MaxRead,3};std::string e;std::vector<uint8_t>b(MaxRead,1);CHECK(!checkedRead(good,good.heapBase,b.data(),b.size(),f,e)&&f.reads==0&&f.queries==1);CHECK(std::all_of(b.begin(),b.end(),[](uint8_t x){return x==0;}));++scenarios;}
    {Fake f;std::string e;std::vector<uint8_t>b(MaxRead,1);CHECK(!checkedRead(good,UINT64_MAX-MaxRead+2,b.data(),b.size(),f,e)&&f.verifies==0&&f.reads==0);CHECK(std::all_of(b.begin(),b.end(),[](uint8_t x){return x==0;}));++scenarios;}
    for(unsigned at:{2u,3u}){Fake f;f.current=alias;f.mapping={alias.aliasBase,MaxRead,3,5};f.changeAliasAt=at;std::string e;std::vector<uint8_t>b(MaxRead,1);CHECK(!checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&f.verifies==at&&f.queries==1&&f.reads==(at==3?1u:0u));CHECK(std::all_of(b.begin(),b.end(),[](uint8_t x){return x==0;}));++scenarios;}
    {Fake f;f.current=alias;f.mapping={alias.aliasBase,MaxRead,3,5};std::string e;std::vector<uint8_t>b(MaxRead);CHECK(checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&f.reads==1&&f.verifies==3);++scenarios;}
    for(unsigned type:{0u,6u}){Fake f;f.current=alias;f.mapping={alias.aliasBase,MaxRead,3,type};std::string e;std::vector<uint8_t>b(MaxRead,1);CHECK(!checkedRead(alias,alias.aliasBase,b.data(),b.size(),f,e)&&f.reads==0&&f.queries==1);CHECK(std::all_of(b.begin(),b.end(),[](uint8_t x){return x==0;}));++scenarios;}
    std::cout<<"memory scan guards: "<<scenarios<<" identity, mapping and stale-read scenarios passed ("<<checks<<" checks)\n";
}

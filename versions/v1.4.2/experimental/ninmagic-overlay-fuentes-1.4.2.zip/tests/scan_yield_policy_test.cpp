#include "scan_yield_policy.hpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool condition){++checks;if(!condition)throw std::runtime_error("scan yield policy check failed");}}
int main(){try{
    nc::ScanYieldPolicy dense;unsigned pauses=0;
    check(!dense.shouldYield(0,100ULL*1024*1024,0));
    for(uint64_t block=1;block<=1600;++block)if(dense.shouldYield(block*65536,100ULL*1024*1024,block*1000))++pauses;
    check(pauses==100); // 100 MiB has 1,600 blocks: no longer 1,600 fixed sleeps.
    nc::ScanYieldPolicy sparse;check(!sparse.shouldYield(0,100,0));
    for(unsigned candidate=1;candidate<16;++candidate)check(!sparse.shouldYield(candidate,100,candidate));
    check(sparse.shouldYield(16,100,16));
    nc::ScanYieldPolicy slow;check(!slow.shouldYield(0,100,0));
    check(slow.shouldYield(1,100,17000000));
    check(!slow.shouldYield(2,100,17000001));
    check(slow.shouldYield(3,100,34000000));
    check(!slow.shouldYield(0,100,34000001)); // A new operation starts fresh.
    check(!slow.shouldYield(1,200,34000002)); // Units/total may change on another phase.
    check(!slow.shouldYield(2,200,1)); // A backward clock cannot underflow elapsed time.
    std::cout<<"scan yield: "<<checks<<" checks PASS; 100MiB uses 100 cooperative pauses instead of 1600\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}

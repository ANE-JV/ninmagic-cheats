# Parser and file installation checks

These checks use the production `cheats.cpp` and `install.cpp` with a host-only
`NC_INSTALL_TEST` path provider. Every file is confined to a newly created,
dedicated `ninmagic-cheats-tests-*` temporary folder. Cleanup verifies its
resolved parent and prefix before removing that exact folder. A failing run
preserves its fixture for inspection. The console and NAND are never accessed.

On Windows with devkitPro's MSYS2 g++:

```powershell
g++ -std=c++17 -O2 -Wall -Wextra -Werror -DNC_INSTALL_TEST -Iinclude tests/cheats_test.cpp source/cheats.cpp source/install.cpp -o "$env:TEMP/ninmagic-cheats-test.exe"
$env:MSYS = 'winsymlinks:sys'
& "$env:TEMP/ninmagic-cheats-test.exe"
```

`winsymlinks:sys` is required for the three symlink cases on this Windows setup.
MSYS's default symlink creation copies files instead; `nativestrict` requires
Windows symlink privileges. The `sys` mode creates emulated links recognized by
the same `lstat` implementation used in the host production code.

Expected result: **38 parser, selection and filesystem scenarios passed
(157 assertions)**.

The suite covers:

- Atmosphère syntax, comments, malformed input, binary/size/word bounds, UTF-8
  name truncation and category recognition.
- Unverified/mismatched identity, system title IDs, zero/invalid Build IDs, empty
  selections, master-code source isolation/conflicts, duplicate names, 127 normal
  cheats plus a master, 64 KiB output limit and conflicting static writes.
- Exact Title ID/Build ID destinations, other games/builds retained, selected
  toggle activation with unrelated states retained, exact backup/restore,
  successive restores and original absence.
- Restoration refused after external edits, running-game file writes refused,
  malformed or oversized toggles, nonregular targets and symlink boundaries.
- Exact related-backup tokens with CRC, cross-title rejection and pending
  recovery acknowledgement: retries keep the same transaction, including an
  outer folder restored before the final acknowledgement.

These are host checks, not confirmation that a third-party cheat works in a game.

#include "cheats.hpp"
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
fs::path sandbox,current;
unsigned scenarios=0,assertions=0;
void require(bool value,const char*description) {
    ++assertions;if(!value)throw std::runtime_error(description);
}
nc::Cheat entry(std::string name="60 FPS",std::string source="A",uint32_t address=0x1000,uint32_t value=1,bool master=false) {
    nc::Cheat c;c.name=std::move(name);c.source=source;c.group=source;c.master=master;c.selected=!master;c.opcodes={0x04000000,address,value};c.categories=nc::classifyCheat(c.name);return c;
}
nc::Pack pack() {
    nc::Pack p;p.compatible=true;p.game.id=0x01007300020FA000ULL;p.game.name="Test Game";p.game.buildId="4B159F0F7A360669";p.game.buildVerified=true;p.game.version="1.0.0";p.cheats.push_back(entry());return p;
}
std::string read(const fs::path&p) {
    std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};
}
void write(const fs::path&p,const std::string&s) {
    fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f.write(s.data(),static_cast<std::streamsize>(s.size()));require(bool(f),"fixture write failed");
}
fs::path cheatsDir(const nc::Game&g) {return current/"atmosphere"/"contents"/nc::hexId(g.id)/"cheats";}
fs::path target(const nc::Game&g) {std::string bid=g.buildId;for(char&c:bid)if(c>='a'&&c<='f')c-=32;return cheatsDir(g)/(bid+".txt");}
void run(const std::string&name,const std::function<void()>&fn) {
    ++scenarios;current=sandbox/("case-"+std::to_string(scenarios));fs::create_directory(current);
    try{fn();}catch(const std::exception&e){throw std::runtime_error(name+": "+e.what());}
}
bool selection(const nc::Pack&p,std::string*errorOut=nullptr) {
    std::vector<nc::Cheat>c;std::string error;bool ok=nc::selectedCheats(p,c,error);if(errorOut)*errorOut=error;return ok;
}
void parserTests() {
    run("valid Atmosphere sections and comments",[]{std::vector<nc::Cheat>c;std::string e;
        require(nc::parseCheats("\xef\xbb\xbf# note\r\n{Master}\r\n04000000 00002000 00000001\r\n[60 FPS]\r\n04000000 00001000 FFFFFFFF // note\n; end\n","test",c,e),"parse failed");
        require(c.size()==2&&c[0].master&&!c[1].master,"section kinds lost");require(c[1].opcodes.back()==0xffffffff,"hex value changed");require(c[1].categories&nc::Fps,"FPS not classified");
    });
    run("malformed opcodes rejected",[]{for(const char*line:{"0400000 00001000 00000001","040000000 00001000 00000001","04000000 00001000 0000000Z","0x400000 00001000 00000001"}){
        std::vector<nc::Cheat>c;std::string e;require(!nc::parseCheats(std::string("[Code]\n")+line,"test",c,e)&&c.empty(),"invalid opcode accepted");}
    });
    run("incomplete and unlabelled data rejected",[]{for(const char*s:{"[Missing\n04000000 00001000 00000001","04000000 00001000 00000001","Text before cheat\n[Code]\n04000000 00001000 00000001","[Empty]\n"}){
        std::vector<nc::Cheat>c;std::string e;require(!nc::parseCheats(s,"test",c,e),"malformed source accepted");}
    });
    run("binary and oversize files rejected",[]{std::vector<nc::Cheat>c;std::string e;std::string s="[Code]\n04000000 00001000 00000001";s.push_back('\0');
        require(!nc::parseCheats(s,"test",c,e),"NUL accepted");require(!nc::parseCheats(std::string(2*1024*1024+1,' '),"test",c,e),"oversize accepted");
    });
    run("per-section opcode bound",[]{std::vector<nc::Cheat>c;std::string e,s="[Code]\n";for(int i=0;i<256;++i)s+="20000000\n";
        require(nc::parseCheats(s,"test",c,e)&&c[0].opcodes.size()==256,"256 words rejected");s+="20000000\n";require(!nc::parseCheats(s,"test",c,e),"257 words accepted");
    });
    run("bounded UTF-8 name and clean serialization",[]{std::vector<nc::Cheat>c;std::string e,s="["+std::string(62,'a')+"ézzz]\n04000000 00001000 00000001\n";
        require(nc::parseCheats(s,"test",c,e)&&c[0].name==std::string(62,'a'),"name split UTF-8");auto p=pack();p.cheats=c;p.cheats[0].selected=true;
        auto text=nc::selectedText(p,e);require(!text.empty()&&nc::parseCheats(text,"roundtrip",c,e),"emitted syntax cannot reparse");
    });
    run("categories and mixed adjustments",[]{require(nc::classifyCheat("Infinite HP")==nc::General,"general category wrong");require(nc::classifyCheat("60 FPS")&nc::Fps,"FPS category wrong");
        require(nc::classifyCheat("1920x1080 Resolution")&nc::Resolution,"resolution category wrong");require(nc::classifyCheat("Improved Shadows and Bloom")&nc::Graphics,"graphics category wrong");
        require((nc::classifyCheat("Dynamic Resolution Target 60 FPS")&(nc::Resolution|nc::Fps))==(nc::Resolution|nc::Fps),"mixed category wrong");
    });
    run("Title ID and Build ID validation",[]{for(auto change:{0,1,2,3,4,5}){auto p=pack();switch(change){case 0:p.compatible=false;break;case 1:p.game.buildVerified=false;break;case 2:p.game.id=0;break;case 3:p.game.id=0x0100000000001000ULL;break;case 4:p.game.buildId="0000000000000000";break;case 5:p.game.buildId="../../../invalid";break;}
        require(!selection(p),"unverified identity accepted");require(!nc::installPack(p).ok,"unverified install accepted");require(!fs::exists(current/"atmosphere"),"invalid identity wrote files");}
        require(nc::validBuild("abcdef1234567890"),"valid lowercase BID rejected");require(!nc::validBuild("1234")&&!nc::validBuild("123456789ABCDEFG"),"invalid BID accepted");
    });
    run("empty selection blocked",[]{auto p=pack();p.cheats[0].selected=false;require(!selection(p)&&!nc::installPack(p).ok,"empty selection accepted");});
    run("master isolation by source",[]{auto p=pack();p.cheats.insert(p.cheats.begin(),entry("Master A","A",0x2000,1,true));p.cheats.push_back(entry("Master B","B",0x3000,2,true));auto b=entry("Graphics B","B",0x4000,3);b.selected=false;p.cheats.push_back(b);
        std::vector<nc::Cheat>c;std::string e;require(nc::selectedCheats(p,c,e)&&c.size()==2&&c[0].name=="Master A","unselected source master leaked");
    });
    run("different masters cannot combine",[]{auto p=pack();p.cheats.insert(p.cheats.begin(),entry("Master A","A",0x2000,1,true));p.cheats.push_back(entry("Master B","B",0x3000,2,true));p.cheats.push_back(entry("Graphics B","B",0x4000,3));require(!selection(p),"conflicting masters accepted");});
    run("equivalent master deduplicated",[]{auto p=pack();p.cheats.insert(p.cheats.begin(),entry("Master A","A",0x2000,1,true));p.cheats.push_back(entry("Master B","B",0x2000,1,true));p.cheats.push_back(entry("Graphics B","B",0x4000,3));
        std::vector<nc::Cheat>c;std::string e;require(nc::selectedCheats(p,c,e)&&c.size()==3,"equivalent master duplicated");
    });
    run("duplicate names guarded",[]{auto p=pack();p.cheats.push_back(p.cheats[0]);std::vector<nc::Cheat>c;std::string e;require(nc::selectedCheats(p,c,e)&&c.size()==1,"identical code duplicated");p.cheats.back().opcodes.back()=2;require(!selection(p),"different same-name code accepted");});
    run("127 normal entries and one master",[]{auto p=pack();p.cheats.clear();for(unsigned i=0;i<127;++i)p.cheats.push_back(entry("Code "+std::to_string(i),"A",0x1000+i*4,1));require(selection(p),"127 cheats rejected");p.cheats.push_back(entry("Master","A",0x8000,1,true));require(selection(p),"127+master rejected");p.cheats.push_back(entry("Code 128","A",0x9000,1));require(!selection(p),"128 normal cheats accepted");});
    run("engine capacity applies even below 64 KiB",[]{auto p=pack();p.cheats.clear();for(unsigned i=0;i<20;++i){auto c=entry("Code "+std::to_string(i));c.opcodes.assign(256,0x20000000);p.cheats.push_back(c);}require(!selection(p),"VM overflow accepted just because text fits in 64 KiB");
        for(unsigned i=20;i<30;++i){auto c=entry("Code "+std::to_string(i));c.opcodes.assign(256,0x20000000);p.cheats.push_back(c);}require(!selection(p),"over 64 KiB accepted");
    });
    run("exact 1024-word VM capacity including master",[]{auto p=pack();p.cheats.clear();for(unsigned i=0;i<3;++i){auto c=entry("Code "+std::to_string(i),"A");c.opcodes.assign(256,0x20000000);p.cheats.push_back(c);}auto m=entry("Master","A",0x2000,1,true);m.opcodes.assign(256,0x20000000);p.cheats.push_back(m);require(selection(p),"1024-word program rejected");auto extra=entry("One more","A");extra.opcodes={0x20000000};p.cheats.push_back(extra);require(!selection(p),"1025-word program accepted");require(!nc::installPack(p).ok&&!fs::exists(current/"atmosphere"),"oversized VM selection wrote files");});
    run("duplicate names and codes count once toward VM",[]{auto p=pack();p.cheats.clear();for(unsigned i=0;i<4;++i){auto c=entry("Code "+std::to_string(i));c.opcodes.assign(256,0x20000000);p.cheats.push_back(c);}p.cheats.push_back(p.cheats[0]);require(selection(p),"identical duplicate counted twice toward VM");p.cheats.back().name="Unique extra";require(!selection(p),"extra enabled definition bypassed VM capacity");});
    run("conflicting straight-line alternatives",[]{auto p=pack();p.cheats.push_back(entry("30 FPS","A",0x1000,2));std::string e;require(!selection(p,&e)&&e.find("Conflicto")!=std::string::npos,"conflicting static writes accepted");p.cheats.back().opcodes.back()=1;require(selection(p),"identical writes rejected");p.cheats.back().opcodes[1]=0x2000;p.cheats.back().opcodes.back()=2;require(selection(p),"different target rejected");});
}
void installTests() {
    run("session scanner experiments cannot be installed for another process",[]{auto p=pack();p.sessionOnly=true;const auto out=nc::installPack(p);require(!out.ok,"session-only experiment exported");require(!fs::exists(current/"atmosphere")&&!fs::exists(current/"config"),"rejected experiment wrote files");});
    run("installed cheat inspection is exact and read-only",[]{auto g=pack().game;bool exists=true;std::string error;require(nc::inspectInstalledCheats(g,exists,error)&&!exists&&error.empty(),"missing target not reported as absent");require(!fs::exists(current/"atmosphere"),"inspection created folders");write(cheatsDir(g)/"AAAAAAAAAAAAAAAA.txt","other build");require(nc::inspectInstalledCheats(g,exists,error)&&!exists,"other Build ID treated as target");auto other=g;other.id+=0x10000;write(target(other),"other game");require(nc::inspectInstalledCheats(g,exists,error)&&!exists,"other title treated as target");write(target(g),"installed bytes");require(nc::inspectInstalledCheats(g,exists,error)&&exists&&read(target(g))=="installed bytes","installed target changed or missed");g.buildId="4b159f0f7a360669";require(nc::inspectInstalledCheats(g,exists,error)&&exists,"lowercase Build ID inspection failed");});
    run("installed inspection rejects unsafe identities",[]{auto g=pack().game;for(unsigned n=0;n<3;++n){auto bad=g;if(n==0)bad.id=0;if(n==1)bad.buildVerified=false;if(n==2)bad.buildId="../outside";bool exists=true;std::string error;require(!nc::inspectInstalledCheats(bad,exists,error)&&!exists&&!error.empty(),"unsafe installed inspection accepted");}require(!fs::exists(current/"atmosphere"),"invalid inspection wrote files");});
    run("installed inspection rejects ordinary parent file",[]{const auto g=pack().game;write(current/"atmosphere","ordinary file");bool exists=false;std::string error;require(!nc::inspectInstalledCheats(g,exists,error)&&!exists&&read(current/"atmosphere")=="ordinary file","non-directory inspection parent accepted or modified");});
    run("installed inspection rejects nonregular target",[]{const auto g=pack().game;fs::create_directories(target(g));bool exists=false;std::string error;require(!nc::inspectInstalledCheats(g,exists,error)&&fs::is_directory(target(g)),"directory inspected as cheat file");});
    run("installed inspection rejects target link",[]{const auto g=pack().game;const auto external=current/"external.txt";write(external,"external bytes");fs::create_directories(cheatsDir(g));fs::create_symlink(external,target(g));require(fs::is_symlink(target(g)),"fixture target symlink missing");bool exists=false;std::string error;require(!nc::inspectInstalledCheats(g,exists,error)&&read(external)=="external bytes"&&fs::is_symlink(target(g)),"target symlink followed or modified");});
    run("installed inspection rejects linked parent",[]{const auto g=pack().game;const auto external=current/"external";fs::create_directory(external);write(external/"sentinel","keep");fs::create_directory_symlink(external,current/"atmosphere");require(fs::is_symlink(current/"atmosphere"),"fixture parent symlink missing");bool exists=false;std::string error;require(!nc::inspectInstalledCheats(g,exists,error)&&read(external/"sentinel")=="keep"&&!fs::exists(external/"contents"),"inspection traversed or changed parent link");});
    run("first install confined to exact title and build",[]{auto p=pack();const auto unrelated=current/"atmosphere/contents/0100123456789000/cheats/AAAAAAAAAAAAAAAA.txt";write(unrelated,"unrelated game");auto otherBid=cheatsDir(p.game)/"BBBBBBBBBBBBBBBB.txt";write(otherBid,"other build");
        auto o=nc::installPack(p);std::string e;require(o.ok&&o.count==1,"first install failed");require(read(target(p.game))==nc::selectedText(p,e),"wrong target payload");require(read(cheatsDir(p.game)/"toggles.txt")=="[60 FPS]\ntrue\n","selection not enabled");
        require(read(unrelated)=="unrelated game"&&read(otherBid)=="other build","unrelated cheats changed");require(read(fs::path(o.backupPath)/"ready")=="NMC100\n","absence manifest wrong");
    });
    run("selected toggle true and other states preserved",[]{auto p=pack();write(cheatsDir(p.game)/"toggles.txt","[Other Build Cheat]\nfalse\n[60 FPS]\nfalse\n[Existing On]\non\n");require(nc::installPack(p).ok,"toggle merge install failed");auto text=read(cheatsDir(p.game)/"toggles.txt");require(text.find("[60 FPS]\ntrue\n")!=std::string::npos,"selected false retained");require(text.find("[Other Build Cheat]\nfalse\n")!=std::string::npos&&text.find("[Existing On]\ntrue\n")!=std::string::npos,"unrelated state changed");});
    run("backup and restore byte exact",[]{auto p=pack();const std::string old="[Old Cheat]\r\n04000000 00001000 00000002\r\n",toggles="[Old Cheat]\r\noff\r\n";write(target(p.game),old);write(cheatsDir(p.game)/"toggles.txt",toggles);auto o=nc::installPack(p);require(o.ok,"overwrite install failed");
        require(read(fs::path(o.backupPath)/"previous-cheats.txt")==old&&read(fs::path(o.backupPath)/"previous-toggles.txt")==toggles,"backup bytes changed");require(nc::restorePack(p.game).ok,"restore failed");require(read(target(p.game))==old&&read(cheatsDir(p.game)/"toggles.txt")==toggles,"restored bytes differ");require(fs::exists(fs::path(o.backupPath)/"previous-cheats.txt"),"backup deleted");require(!nc::restorePack(p.game).ok,"same backup restored twice");
    });
    run("restore original absence",[]{auto p=pack();require(nc::installPack(p).ok,"first install failed");require(nc::restorePack(p.game).ok,"absence restore failed");require(!fs::exists(target(p.game))&&!fs::exists(cheatsDir(p.game)/"toggles.txt"),"new files retained");});
    run("restore latest then previous installation",[]{auto p=pack();write(target(p.game),"original");auto a=nc::installPack(p);require(a.ok,"first install failed");const auto first=read(target(p.game));p.cheats[0].opcodes.back()=3;require(nc::installPack(p).ok,"second install failed");require(nc::restorePack(p.game).ok&&read(target(p.game))==first,"latest restore wrong");require(nc::restorePack(p.game).ok&&read(target(p.game))=="original","earlier restore wrong");});
    run("external cheat edits block restore",[]{auto p=pack();require(nc::installPack(p).ok,"install failed");write(target(p.game),"external edit");require(!nc::restorePack(p.game).ok&&read(target(p.game))=="external edit","external edit overwritten");});
    run("external toggle edits block restore",[]{auto p=pack();require(nc::installPack(p).ok,"install failed");write(cheatsDir(p.game)/"toggles.txt","[External]\ntrue\n");require(!nc::restorePack(p.game).ok&&read(cheatsDir(p.game)/"toggles.txt")=="[External]\ntrue\n","external toggles overwritten");});
    run("running game blocks file install and restore",[]{auto p=pack();write(target(p.game),"before");p.game.running=true;require(!nc::installPack(p).ok&&!nc::restorePack(p.game).ok,"running game files changed");require(read(target(p.game))=="before","running target modified");});
    run("restore bound to verified game and Build ID",[]{auto p=pack();auto o=nc::installPack(p);require(o.ok,"install failed");const auto before=read(target(p.game));auto wrong=p.game;wrong.buildId="AAAAAAAAAAAAAAAA";require(!nc::restorePack(wrong).ok,"different BID restore accepted");wrong=p.game;wrong.id+=0x10000;require(!nc::restorePack(wrong).ok,"different title restore accepted");wrong=p.game;wrong.buildVerified=false;require(!nc::restorePack(wrong).ok,"unverified restore accepted");require(read(target(p.game))==before,"original target changed");});
    run("invalid existing toggle grammar blocks write",[]{for(const char*s:{"[Old]\nmaybe\n","[Missing]\n","bad data","[Name\ntrue\n"}){auto p=pack();write(target(p.game),"old");write(cheatsDir(p.game)/"toggles.txt",s);require(!nc::installPack(p).ok,"invalid toggles accepted");require(read(target(p.game))=="old"&&read(cheatsDir(p.game)/"toggles.txt")==s,"invalid toggle install changed files");}});
    run("large toggle result blocked",[]{auto p=pack();std::string s;for(int i=0;i<2000;++i)s+="[Unrelated previous cheat "+std::to_string(i)+"]\nfalse\n";write(cheatsDir(p.game)/"toggles.txt",s);require(!nc::installPack(p).ok&&!fs::exists(target(p.game)),"over 64 KiB toggles installed");});
    run("case normalized BID file",[]{auto p=pack();p.game.buildId="4b159f0f7a360669";require(nc::installPack(p).ok&&fs::exists(target(p.game)),"lowercase BID install failed");bool uppercase=false;for(const auto&e:fs::directory_iterator(cheatsDir(p.game)))if(e.path().filename().string()=="4B159F0F7A360669.txt")uppercase=true;require(uppercase,"BID filename not uppercase");});
    run("nonregular target rejected",[]{auto p=pack();fs::create_directories(target(p.game));require(!nc::installPack(p).ok&&fs::is_directory(target(p.game)),"directory target replaced");});
    run("non-directory parent rejected",[]{auto p=pack();write(current/"atmosphere","ordinary file");require(!nc::installPack(p).ok&&read(current/"atmosphere")=="ordinary file","ordinary parent changed");});
    run("symlink target rejected",[]{auto p=pack();const auto external=current/"external.txt";write(external,"external bytes");fs::create_directories(cheatsDir(p.game));fs::create_symlink(external,target(p.game));require(fs::is_symlink(target(p.game)),"fixture did not create a symlink");const auto o=nc::installPack(p);require(!o.ok,"symlink install allowed");require(read(external)=="external bytes","symlink target contents changed");require(fs::is_symlink(target(p.game)),"symlink target replaced");});
    run("symlink atmosphere parent rejected",[]{auto p=pack();const auto external=current/"external";fs::create_directory(external);write(external/"sentinel","external bytes");fs::create_directory_symlink(external,current/"atmosphere");require(!nc::installPack(p).ok&&read(external/"sentinel")=="external bytes"&&!fs::exists(external/"contents"),"symlink parent followed");});
    run("symlink backup parent rejected",[]{auto p=pack();const auto external=current/"external";fs::create_directory(external);fs::create_directory(current/"config");fs::create_directory_symlink(external,current/"config/NinMagicCheats");require(!nc::installPack(p).ok&&!fs::exists(target(p.game))&&!fs::exists(external/"backups"),"symlink backup parent followed");});
    run("related backup tokens bound to one installation",[]{auto p=pack();auto installed=nc::installPack(p,"00000011","00000022");require(installed.ok&&!installed.transactionId.empty(),"related install failed");auto undone=nc::restorePack(p.game);require(undone.ok&&undone.transactionId==installed.transactionId&&undone.previousContent=="00000011"&&undone.previousPatches=="00000022","related tokens lost");std::string error;require(nc::finishPackRecovery(p.game,undone.transactionId,error),"related recovery acknowledgement failed");require(!nc::restorePack(p.game).ok,"acknowledged transaction repeated");});
    run("pending linked recovery never advances undo history",[]{auto p=pack();auto first=nc::installPack(p);require(first.ok,"first install failed");const auto firstBytes=read(target(p.game));p.cheats[0].opcodes.back()^=1;auto second=nc::installPack(p,"00000042","00000024");require(second.ok,"second install failed");auto undone=nc::restorePack(p.game);require(undone.ok&&undone.transactionId==second.transactionId&&read(target(p.game))==firstBytes,"second undo failed");auto retry=nc::restorePack(p.game);require(retry.ok&&retry.transactionId==second.transactionId&&retry.previousContent=="00000042"&&read(target(p.game))==firstBytes,"pending recovery advanced to older install");std::string error;require(!nc::finishPackRecovery(p.game,"../bad",error),"invalid acknowledgement token accepted");write(fs::path(second.backupPath)/"associations-complete","broken");require(!nc::restorePack(p.game).ok&&read(target(p.game))==firstBytes,"corrupt acknowledgement advanced history");fs::remove(fs::path(second.backupPath)/"associations-complete");require(nc::finishPackRecovery(p.game,second.transactionId,error),"pending acknowledgement failed");auto older=nc::restorePack(p.game);require(older.ok&&older.transactionId==first.transactionId&&!fs::exists(target(p.game)),"older install did not become available after acknowledgement");});
    run("invalid and corrupted related references blocked",[]{auto p=pack();require(!nc::installPack(p,"../bad","").ok&&!fs::exists(target(p.game)),"invalid related reference changed files");auto installed=nc::installPack(p,"00000011","");require(installed.ok,"linked install failed");const auto before=read(target(p.game));auto data=read(fs::path(installed.backupPath)/"related.bin");const auto at=data.find("00000011");require(at!=std::string::npos,"fixture reference missing");data[at+7]='2';write(fs::path(installed.backupPath)/"related.bin",data);require(!nc::restorePack(p.game).ok&&read(target(p.game))==before,"corrupted related reference was used");});
    run("related references cannot cross title identities",[]{auto p=pack();auto a=nc::installPack(p,"00000011","");auto other=p;other.game.id+=0x10000;auto b=nc::installPack(other);require(a.ok&&b.ok,"identity fixtures failed");write(fs::path(b.backupPath)/"related.bin",read(fs::path(a.backupPath)/"related.bin"));const auto before=read(target(other.game));require(!nc::restorePack(other.game).ok&&read(target(other.game))==before,"other title references accepted");});
    run("pending retry accepts files restored by its linked outer folder",[]{auto p=pack();auto installed=nc::installPack(p,"00000042","");require(installed.ok,"linked install failed");auto undone=nc::restorePack(p.game);require(undone.ok&&!fs::exists(target(p.game)),"inner undo failed");write(target(p.game),"Original cheats restored by the associated outer folder");write(cheatsDir(p.game)/"toggles.txt","[Original]\nfalse\n");const auto before=read(target(p.game));auto retry=nc::restorePack(p.game);require(retry.ok&&retry.transactionId==installed.transactionId&&retry.previousContent=="00000042"&&read(target(p.game))==before,"pending retry rejected or overwrote outer restored files");std::string error;require(nc::finishPackRecovery(p.game,retry.transactionId,error),"outer recovery acknowledgement failed");});
}
void cleanup() {
    const auto expected=fs::weakly_canonical(fs::temp_directory_path());const auto resolved=fs::weakly_canonical(sandbox);
    if(resolved.parent_path()!=expected||resolved.filename().string().find("ninmagic-cheats-tests-")!=0)throw std::runtime_error("test cleanup path validation failed");
    fs::remove_all(resolved);
}
}
namespace nc {std::string installTestRoot(){return current.string();}}
int main() {
    const auto token=std::to_string(static_cast<unsigned long long>(std::chrono::steady_clock::now().time_since_epoch().count()));
    sandbox=fs::temp_directory_path()/("ninmagic-cheats-tests-"+std::to_string(getpid())+"-"+token);
    try {require(fs::create_directory(sandbox),"could not create dedicated test directory");parserTests();installTests();cleanup();std::cout<<"cheats: "<<scenarios<<" parser, selection and filesystem scenarios passed ("<<assertions<<" assertions)\n";return 0;}
    catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<"\nFixtures preserved at "<<sandbox<<'\n';return 1;}
}

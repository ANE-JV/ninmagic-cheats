#pragma once
// Host-only thread/service primitives for the production overlay controller.
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <thread>
using Result=int;
constexpr bool R_SUCCEEDED(Result value){return value==0;}
constexpr bool R_FAILED(Result value){return value!=0;}
struct Mutex{std::mutex value;};
inline void mutexInit(Mutex*){}
inline void mutexLock(Mutex*m){m->value.lock();}
inline void mutexUnlock(Mutex*m){m->value.unlock();}
struct UEvent{std::mutex lock;std::condition_variable ready;bool signalled=false,automatic=true;};
inline void ueventCreate(UEvent*event,bool automatic){event->signalled=false;event->automatic=automatic;}
inline void ueventSignal(UEvent*event){{std::lock_guard<std::mutex>guard(event->lock);event->signalled=true;}event->ready.notify_one();}
inline UEvent*waiterForUEvent(UEvent*event){return event;}
inline Result waitSingle(UEvent*event,uint64_t){std::unique_lock<std::mutex>guard(event->lock);event->ready.wait(guard,[&]{return event->signalled;});if(event->automatic)event->signalled=false;return 0;}
struct Thread{std::thread*thread=nullptr;void(*entry)(void*)=nullptr;void*argument=nullptr;};
inline Result threadCreate(Thread*thread,void(*entry)(void*),void*arg,void*,size_t,int,int){thread->entry=entry;thread->argument=arg;return 0;}
inline Result threadStart(Thread*thread){thread->thread=new std::thread(thread->entry,thread->argument);return 0;}
inline Result threadWaitForExit(Thread*thread){if(thread->thread&&thread->thread->joinable())thread->thread->join();return 0;}
inline Result threadClose(Thread*thread){delete thread->thread;thread->thread=nullptr;return 0;}
inline void svcSleepThread(int64_t nanos){std::this_thread::sleep_for(std::chrono::nanoseconds(nanos));}
inline std::atomic<unsigned> mockSmOpen{0},mockSmClose{0},mockSdOpen{0},mockSdClose{0};
inline Result smInitialize(){++mockSmOpen;return 0;}
inline void smExit(){++mockSmClose;}
inline Result fsdevMountSdmc(){++mockSdOpen;return 0;}
inline void fsdevUnmountDevice(const char*){++mockSdClose;}

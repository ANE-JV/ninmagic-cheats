# Verified host checks

Final Windows checks use MSYS2 g++ with `-std=c++17 -O2 -Wall -Wextra -Werror`.
No tests connect to the console or execute cheats against a real game.

| Suite | Result |
| --- | --- |
| Cheats parser, selection, files and linked recovery | 38 scenarios, 157 assertions |
| Native cheat engine simulation and live withdrawal | 43 scenarios |
| Durable live receipt, crash recovery and NRO reopen | 29 scenarios, including two symlink cases |
| Existing Title ID folder inspection and exact recovery | 136 checks, including real install/undo integration |
| ZIP catalogs, cache and exact cheat IDs | 34 checks |
| Two mod indexes, Git blob validation and full-BID patch conversion | 50 checks, including both real downloaded indexes |
| IPS installation, conflicts, backups and pending acknowledgement | 47 scenarios, 440 checks |
| Spanish option names and real available-effect summaries | 49 checks |
| Mod selection, identity, memory bounds and catalog refresh | 51 checks |
| Multiple-mod IPS/IPS32/RLE merge and conflicts | 36 scenarios, 197 checks |
| Production preparation, combined installation and recovery | 7 scenarios, 82 checks |

Version 1.1.0 adds the last four suites. The production integration links the
actual patch parser, bundle builder and installer with no network or validator
stub, and verifies that several selected mods create one reversible IPS file.

All destructive filesystem fixtures are confined to fresh dedicated temporary
folders. Their test cleanup checks the resolved parent and expected prefix.
MSYS symlink fixtures require `$env:MSYS='winsymlinks:sys'`. Pass fixture folder
arguments to MSYS executables as `/c/Users/...` paths rather than backslash paths.

See [cheats.md](cheats.md), [native-platform.md](../docs/native-platform.md),
[mod-installation.md](../docs/mod-installation.md) and individual test headers
for compilation commands and test definitions. Existing/catalog/mod tests create
their explicit fixture roots before use. `catalog_test.cpp` and `mods_test.cpp`
include their production translation unit directly and should not link it twice.

The independent source data audit found malformed or oversized cheat files;
those files are refused by the production parser. Recognizing a valid file or
matching its Build ID does not prove its instructions work correctly in a game.

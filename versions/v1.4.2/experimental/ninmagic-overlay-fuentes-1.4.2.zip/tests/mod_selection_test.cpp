#include "mod_selection.hpp"
#include <cstdlib>
#include <iostream>

using namespace nc;
namespace {
unsigned checks=0;
void check(bool value,const char *message){++checks;if(!value){std::cerr<<"FAILED: "<<message<<'\n';std::exit(1);}}
Game game(){Game g;g.id=0x01007300020FA000ULL;g.buildId="0123456789ABCDEF";g.fullBuildId=g.buildId+std::string(48,'0');g.buildVerified=true;return g;}
ModPayload payload(unsigned n=0){ModPayload p;p.game=game();p.entry.titleId=p.game.id;p.entry.repository="source";p.entry.path=std::to_string(n)+".pchtxt";p.entry.blobSha=std::to_string(n);p.entry.name="Mod "+std::to_string(n);p.compatible=true;p.buildId=p.game.fullBuildId;p.ips={'I','P','S','3','2',0,0,1,0,0,1,1,'E','E','O','F'};return p;}
}
int main(){
    const auto g=game();std::string error;auto a=payload(),b=payload(1);
    std::vector<ModEntry> rows{a.entry,b.entry};std::vector<ModPayload> selected;
    check(selectPreparedMod(rows,selected,g,a,error)&&rows[0].selected&&!rows[1].selected&&selected.size()==1,"only checked row marked");
    check(selectPreparedMod(rows,selected,g,a,error)&&selected.size()==1,"repeated completion duplicates selection");
    check(selectPreparedMod(rows,selected,g,b,error)&&rows[1].selected&&selected.size()==2,"multiple mods not selected");
    unselectMod(rows,selected,a.entry);check(!rows[0].selected&&rows[1].selected&&selected.size()==1&&sameModEntry(selected[0].entry,b.entry),"unmark changed another selection");
    a.compatible=false;check(!selectPreparedMod(rows,selected,g,a,error)&&!rows[0].selected&&selected.size()==1,"failed preparation was marked");a=payload();
    auto wrong=a;++wrong.game.id;check(!selectPreparedMod(rows,selected,g,wrong,error)&&selected.size()==1,"other title selected");
    wrong=a;wrong.game.fullBuildId.back()='1';check(!selectPreparedMod(rows,selected,g,wrong,error),"other full BID selected");
    wrong=a;wrong.buildId.back()='1';check(!selectPreparedMod(rows,selected,g,wrong,error),"unmatched payload BID selected");
    wrong=a;++wrong.entry.titleId;check(!selectPreparedMod(rows,selected,g,wrong,error),"other entry title selected");
    wrong=a;wrong.entry.blobSha="changed";check(!selectPreparedMod(rows,selected,g,wrong,error),"unlisted blob selected");
    wrong=a;wrong.ips.clear();check(!selectPreparedMod(rows,selected,g,wrong,error),"empty patch selected");
    std::vector<ModEntry> refreshed{b.entry,a.entry};check(refreshModSelection(refreshed,selected,g)==0&&refreshed[0].selected&&!refreshed[1].selected,"unchanged source blob lost after sorting refresh");
    refreshed[0].revision="new-tree";check(refreshModSelection(refreshed,selected,g)==0&&selected.size()==1,"same source bytes lost after index revision change");
    refreshed[0].blobSha="different";check(refreshModSelection(refreshed,selected,g)==1&&selected.empty()&&!refreshed[0].selected,"changed blob remained marked");
    rows={a.entry};check(selectPreparedMod(rows,selected,g,a,error),"valid fixture selection failed");
    auto changedGame=g;changedGame.fullBuildId.back()='2';check(refreshModSelection(rows,selected,changedGame)==1&&selected.empty()&&!rows[0].selected,"old build selection survived new game build");
    rows.clear();selected.clear();for(unsigned n=0;n<33;++n)rows.push_back(payload(n).entry);
    for(unsigned n=0;n<32;++n)check(selectPreparedMod(rows,selected,g,payload(n),error),"valid selection below 32 failed");
    check(!selectPreparedMod(rows,selected,g,payload(32),error)&&selected.size()==32&&!rows[32].selected,"32-mod boundary exceeded");
    rows={a.entry,b.entry};selected.clear();a.ips.resize(2*1024*1024);
    check(selectPreparedMod(rows,selected,g,a,error),"exact 2 MiB boundary rejected");
    check(!selectPreparedMod(rows,selected,g,b,error)&&selected.size()==1&&!rows[1].selected,"combined 2 MiB bound exceeded");
    std::cout<<"mod selection: "<<checks<<" marking, refresh and identity checks passed\n";
}

#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>

namespace nc {std::string testDownloadUrl;bool catalogDownloadHttps(const std::string &url,const std::string &,std::string &error){testDownloadUrl=url;error="Synthetic test: network disabled";return false;}}
namespace {
unsigned checks=0;
void require(bool ok,const char *message){++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
nc::Game game(){nc::Game g;g.id=0x01007300020FA000ULL;g.name="ASTRAL CHAIN";g.buildVerified=true;g.buildId="4B159F0F7A360669";g.fullBuildId="4B159F0F7A360669738390EE8657B4F0"+std::string(32,'0');return g;}
nc::ModEntry entry(){nc::ModEntry e;e.titleId=game().id;e.path="Astral Chain/01007300020FA000/Disable Bloom/exefs/1.0.1.pchtxt";e.repository="ADEMOLA200/Switch-Emulator-Mod-Database";e.format=nc::ModFormat::Pchtxt;e.revision=std::string(40,'1');return e;}
std::string patch(){return "@nsobid-4B159F0F7A360669738390EE8657B4F0\n@flag print_values\n@flag offset_shift 0x100\n@enabled\n00414188 E4031F2A // static ARM64 bytes\n@stop\n@author\nhttps://author.example\n";}
std::string item(const std::string &path){return "{\"path\":\""+path+"\",\"type\":\"blob\",\"sha\":\""+std::string(40,'2')+"\",\"size\":200}";}
std::string tree(const std::string &items){return "{\"sha\":\""+std::string(40,'1')+"\",\"tree\":["+items+"],\"truncated\":false}";}
}
int main(int argc,char **argv) {
    require(argc>=2,"dedicated fixture root argument");std::filesystem::path base=std::filesystem::absolute(argv[1]);require(std::filesystem::is_directory(base),"fixture directory exists");setenv("NC_MODS_ROOT",base.generic_string().c_str(),1);
    std::string error;nc::ModPayload payload;auto e=entry();
    require(nc::parseModPayload(game(),e,patch(),payload,error)&&payload.compatible&&payload.buildId==game().fullBuildId,"exact full BID static patch converts");
    require(payload.ips.size()==19&&payload.ips[5]==0&&payload.ips[6]==0x41&&payload.ips[7]==0x42&&payload.ips[8]==0x88&&payload.ips[11]==0xe4,"IPS32 output adds declared 0x100 shift without changing byte order");
    require(nc::validateModIps(payload.ips,error),"converted IPS32 validates");
    auto g=game();g.buildId="4B159F0F7A360660";require(!nc::parseModPayload(g,e,patch(),payload,error)&&!payload.compatible,"wrong installed BID blocked");
    g=game();g.fullBuildId[31]='1';require(!nc::parseModPayload(g,e,patch(),payload,error),"matching short BID cannot bypass differing full NSO module ID");
    g=game();g.fullBuildId.clear();require(!nc::parseModPayload(g,e,patch(),payload,error),"missing full NSO module ID blocked");
    g=game();++g.id;require(!nc::parseModPayload(g,e,patch(),payload,error),"wrong Title ID blocked");
    g=game();g.buildVerified=false;require(!nc::parseModPayload(g,e,patch(),payload,error),"unverified game blocked");
    for(const std::string suffix:{"\n@flag unknown 5\n","\n@dynamicfps\n","\n00414188 1122334Z\n","\n00414188 11223344 extra\n","\n00414188 11223344\n00414188 44332211\n"}) {
        auto text=patch();text.erase(text.find("@stop"));text+=suffix;
        require(!nc::parseModPayload(game(),e,text,payload,error),"unsupported syntax or overlapping conflict blocked");
    }
    require(!nc::parseModPayload(game(),e,"# Emulator only\n"+patch(),payload,error),"explicit emulator-only mod blocked");
    auto noBid=patch();noBid.erase(0,noBid.find('\n')+1);require(!nc::parseModPayload(game(),e,noBid,payload,error),"missing source BID blocked");
    auto multiple=patch();multiple.insert(0,"@nsobid-4B159F0F7A360669738390EE8657B4F0\n");require(!nc::parseModPayload(game(),e,multiple,payload,error),"multiple source BIDs blocked");
    auto protectedHeader=std::string("@nsobid-4B159F0F7A360669\n@enabled\n00000000 11223344\n@stop\n");require(!nc::parseModPayload(game(),e,protectedHeader,payload,error),"NSO header writes blocked");
    auto disabled=patch();disabled.insert(disabled.find("@stop"),"@disabled\n00414188 44332211\n");require(nc::parseModPayload(game(),e,disabled,payload,error)&&payload.ips[11]==0xe4,"disabled alternatives remain disabled");
    e.format=nc::ModFormat::Ips;e.buildId=game().fullBuildId;std::string legacy="PATCH";legacy.append("\x00\x10\x00\x00\x04\x11\x22\x33\x44",9);legacy+="EOF";
    require(nc::parseModPayload(game(),e,legacy,payload,error),"exact BID legacy IPS validates");
    auto overlap=legacy;overlap.resize(overlap.size()-3);overlap.append("\x00\x10\x00\x00\x01\xff",6);overlap+="EOF";require(!nc::parseModPayload(game(),e,overlap,payload,error),"raw IPS conflicting self-overlap blocked");
    e.buildId=game().buildId;require(!nc::parseModPayload(game(),e,legacy,payload,error),"short IPS filename implies zero tail and cannot match a nonzero full module ID");e.buildId=game().fullBuildId;
    require(nc::parseModPayload(game(),e,legacy,payload,error),"valid IPS payload can be prepared after rejected candidates");
    auto cut=payload.ips;cut.pop_back();require(!nc::validateModIps(cut,error),"truncated IPS blocked");
    auto trailer=payload.ips;trailer.push_back(0);require(!nc::validateModIps(trailer,error),"IPS truncation trailer blocked");
    auto header=payload.ips;header[5]=header[6]=header[7]=0;require(!nc::validateModIps(header,error),"raw IPS NSO header write blocked");
    e.buildId="4B159F0F7A360660";require(!nc::parseModPayload(game(),e,legacy,payload,error),"raw IPS wrong BID blocked");
    e=entry();e.repository="medinacristofer034-art/SwitchOptimizerMods";require(!nc::parseModPayload(game(),e,patch(),payload,error),"PC emulator source is browse-only");
    e=entry();e.format=nc::ModFormat::Romfs;require(!nc::parseModPayload(game(),e,"romfs bytes",payload,error),"unbound RomFS content cannot install");

    nc::ModsCatalog catalog;std::string known="Game/[01007300020FA000]/60fps/1.0.pchtxt";
    require(nc::parseModsTree(tree(item(known)),catalog,error)&&catalog.entries.size()==1&&catalog.entries[0].titleId==game().id,"path exact Title ID indexed");
    require(catalog.entries[0].name=="60fps / 1.0","readable mod label");
    auto ambiguous=tree(item("Game/01007300020FA000/a.pchtxt")+","+item("Game/01007300020FA001/b.pchtxt")+","+item("Game/exefs/unknown.pchtxt"));
    require(nc::parseModsTree(ambiguous,catalog,error)&&catalog.entries.back().titleId==0,"ambiguous game folder never supplies guessed Title ID");
    require(nc::parseModsTree(tree(item("Game/01007300020FA000/a.pchtxt")+","+item("Game/exefs/unknown.pchtxt")),catalog,error)&&catalog.entries.back().titleId==game().id,"unique folder Title ID association");
    require(nc::parseModsTree(tree(item("Game/01007300020FA000/a.pchtxt")+","+item("Game/01007300020FA000/01007300020FA001/ambiguous.pchtxt")),catalog,error)&&catalog.entries.back().titleId==0,"explicit ambiguous path never receives folder inference");
    for(const std::string &invalid:{tree(item("../evil.pchtxt")),tree(item("Game//evil.pchtxt")),tree(item("Game/./evil.pchtxt")),tree(item("Game/evil.pchtxt")+","+item("Game/evil.pchtxt")),std::string("{\"sha\":\"bad\",\"tree\":[],\"truncated\":false}")})require(!nc::parseModsTree(invalid,catalog,error),"invalid index rejected");
    auto truncated=tree(item(known));truncated.replace(truncated.find("false"),5,"true");require(!nc::parseModsTree(truncated,catalog,error),"GitHub truncated response rejected");
    require(!nc::parseModsTree(tree(item(known)),catalog,error,"unapproved/repository"),"unapproved source rejected");
    require(nc::parseModsTree(tree(item("Astral_Chain/mod.zip")),catalog,error,"medinacristofer034-art/SwitchOptimizerMods")&&nc::findMods(game(),catalog).size()==1&&catalog.entries[0].titleId==0,"source without IDs visible by exact normalized name only");
    require(nc::gitBlobSha("")=="e69de29bb2d1d6434b8b29ae775ad8c2e48c5391","Git blob SHA-1 empty known vector");
    require(nc::gitBlobSha("test\n")=="9daeafb9864cf43055ae93beb0afd6c7d144bfa4","Git blob SHA-1 text known vector");
    // A valid offline payload must match its indexed Git object before parsing.
    e=entry();auto text=patch();e.size=text.size();e.blobSha=nc::gitBlobSha(text);std::filesystem::create_directory(base/"mod-files");std::ofstream(base/"mod-files"/(e.blobSha+".bin"),std::ios::binary)<<text;
    require(nc::prepareMod(game(),e,payload,error),"verified pinned offline payload prepares without network");
    {std::ofstream out(base/"mod-files"/(e.blobSha+".bin"),std::ios::binary);auto altered=text;altered[altered.find("E4031F2A")]='F';out<<altered;}
    require(!nc::prepareMod(game(),e,payload,error)&&!payload.compatible,"same-size corrupted cache cannot bypass Git hash check");
    require(nc::testDownloadUrl.find("/develop/")!=std::string::npos,"raw payload uses branch ref, indexed blob hash binds its revision");
    if(argc>=3) {
        std::filesystem::path seed=argv[2];setenv("NC_MODS_ROOT",seed.generic_string().c_str(),1);require(nc::loadModsCatalog(catalog,error)&&catalog.ready,"both real public tree indexes load offline");
        require(catalog.entries.size()>1000,"real catalog contains mods from both sources");
        std::cout<<"Real mod index: "<<catalog.entries.size()<<" files, Astral Chain "<<nc::findMods(game(),catalog).size()<<" candidates\n";
    }
    std::cout<<"mods: "<<checks<<" index, conversion and compatibility checks passed\n";
}

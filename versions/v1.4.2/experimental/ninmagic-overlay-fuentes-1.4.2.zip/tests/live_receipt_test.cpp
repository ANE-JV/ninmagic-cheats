#include "live_receipt.hpp"
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <unistd.h>

namespace fs=std::filesystem;
using namespace nc;using namespace nc::native;
namespace {
fs::path sandbox;unsigned scenarios=0;
const std::string relative="config/NinMagicCheats/live.bin";
void require(bool ok,const char*s){if(!ok){std::cerr<<"FAILED after scenario "<<scenarios<<": "<<s<<'\n';std::exit(1);}}
#define CHECK(x) require((x),#x)
void reset(){const auto absolute=fs::absolute(sandbox).lexically_normal();CHECK(absolute.parent_path()==fs::absolute(fs::temp_directory_path()).lexically_normal());CHECK(absolute.filename().string().find("ninmagic-live-receipt-test-")==0);fs::remove_all(absolute);fs::create_directories(absolute);}
void put(const std::string&p,const std::string&data){auto file=sandbox/p;fs::create_directories(file.parent_path());std::ofstream out(file,std::ios::binary);out.write(data.data(),data.size());}
std::string bytes(const std::string&p){std::ifstream in(sandbox/p,std::ios::binary);return {std::istreambuf_iterator<char>(in),std::istreambuf_iterator<char>()};}
Definition definition(const char*name,uint32_t address=0x1000){Definition d{};std::memcpy(d.name,name,std::min(strlen(name),size_t(63)));d.count=3;d.codes[0]=0x04000000;d.codes[1]=address;d.codes[2]=0x60000000;return d;}
LiveReceipt receipt(){LiveReceipt r;r.valid=true;r.pid=55;r.title=0x0100000000010000ULL;r.buildId="0123456789ABCDEF";LiveChange c;c.id=1;c.added=true;c.definition=definition("60 FPS");r.changes={c};Entry e;e.id=1;e.enabled=1;e.definition=c.definition;r.observed={e};return r;}
void revise(LiveReceipt&r){r.changes[0].definition.codes[2]^=1;r.observed[0].definition=r.changes[0].definition;}
void word(std::string&data,size_t at,uint32_t v){for(unsigned i=0;i<4;++i)data[at+i]=char(uint8_t(v>>(8*i)));}
void checksum(std::string&b){uint32_t c=0xffffffff;for(size_t i=0;i<b.size();++i)if(i<24||i>=28){c^=uint8_t(b[i]);for(unsigned n=0;n<8;++n)c=(c>>1)^(0xedb88320u&uint32_t(-int32_t(c&1)));}word(b,24,c^0xffffffff);}
struct Fake:Runtime {
    Metadata meta{};std::vector<Entry> state;int removals=0,failRemove=0;
    explicit Fake(const LiveReceipt&r){meta.pid=r.pid;meta.title=r.title;uint8_t b[]={1,0x23,0x45,0x67,0x89,0xab,0xcd,0xef};std::memcpy(meta.build,b,8);state=r.observed;}
    bool metadata(Metadata&m)override{m=meta;return true;}
    bool entries(std::vector<Entry>&e)override{e=state;return true;}
    bool add(const Definition&,uint32_t&)override{return false;}
    bool remove(uint32_t id)override{++removals;if(failRemove==removals)return false;auto p=std::find_if(state.begin(),state.end(),[&](const Entry&e){return e.id==id;});if(p==state.end())return false;state.erase(p);return true;}
    bool toggle(uint32_t id)override{for(auto&e:state)if(e.id==id){e.enabled=!e.enabled;return true;}return false;}
    bool master(const Definition&)override{return false;}
};
Game game(const LiveReceipt&r){Game g;g.id=r.title;g.buildId=r.buildId;g.buildVerified=true;return g;}
LiveReceipt maximumReceipt(){auto r=receipt();r.changes.clear();r.observed.clear();r.masterAdded=true;r.master=definition("Master");r.master.count=256;for(unsigned n=0;n<256;++n)r.master.codes[n]=n;Entry m;m.id=0;m.enabled=1;m.definition=r.master;r.observed.push_back(m);for(unsigned id=1;id<128;++id){LiveChange c;c.id=id;c.added=true;c.definition=definition(("Published "+std::to_string(id)).c_str());c.definition.count=256;for(unsigned n=0;n<256;++n)c.definition.codes[n]=id*256+n;r.changes.push_back(c);Entry e;e.id=id;e.enabled=id%2;e.definition=c.definition;r.observed.push_back(e);}return r;}
}
int main(){
    sandbox=fs::temp_directory_path()/("ninmagic-live-receipt-test-"+std::to_string(getpid()));setLiveReceiptTestRoot(sandbox.generic_string());reset();
    std::string error;LiveReceipt out;auto r=receipt();
    CHECK(loadLiveReceipt(out,error)&&!out.valid&&!fs::exists(sandbox/"config"));++scenarios;
    CHECK(saveLiveReceipt(r,error));const auto first=bytes(relative);CHECK(loadLiveReceipt(out,error)&&out.valid&&out.pid==55&&out.changes.size()==1&&out.changes[0].definition.codes[2]==0x60000000);++scenarios;
    revise(r);CHECK(saveLiveReceipt(r,error));const auto second=bytes(relative);CHECK(first!=second&&bytes(relative+".backup")==first);CHECK(loadLiveReceipt(out,error)&&out.changes[0].definition.codes[2]==r.changes[0].definition.codes[2]);++scenarios;
    // Simulate closing and reopening the NRO while the same game process lives.
    out={};CHECK(loadLiveReceipt(out,error));Fake running(out);CHECK(undoChecked(game(out),running,out).ok&&running.state.empty()&&!out.valid);++scenarios;
    reset();put(relative,first);put(relative+".pending",second);CHECK(loadLiveReceipt(out,error)&&out.changes[0].definition.codes[2]==r.changes[0].definition.codes[2]);CHECK(saveLiveReceipt(out,error)&&loadLiveReceipt(out,error));CHECK(!fs::exists(sandbox/(relative+".pending")));++scenarios;
    reset();put(relative,"broken");put(relative+".pending","incomplete");put(relative+".backup",second);CHECK(loadLiveReceipt(out,error)&&out.valid);CHECK(saveLiveReceipt(out,error)&&loadLiveReceipt(out,error));++scenarios;
    reset();put(relative,"broken");put(relative+".backup",first);CHECK(loadLiveReceipt(out,error)&&out.changes[0].definition.codes[2]==0x60000000);++scenarios;
    reset();put(relative,"broken");CHECK(!loadLiveReceipt(out,error)&&!out.valid);CHECK(!saveLiveReceipt(r,error)&&bytes(relative)=="broken");++scenarios;
    reset();put(relative,first);put(relative+".pending","interrupted write");CHECK(loadLiveReceipt(out,error)&&out.valid);CHECK(saveLiveReceipt(out,error));++scenarios;
    reset();auto bad=first;bad.back()^=1;put(relative,bad);CHECK(!loadLiveReceipt(out,error)&&!out.valid);CHECK(!saveLiveReceipt(r,error)&&bytes(relative)==bad);++scenarios;
    reset();bad=first;bad[12]^=1;put(relative,bad);CHECK(!loadLiveReceipt(out,error));++scenarios;
    reset();for(size_t n=0;n<first.size();++n){put(relative,first.substr(0,n));CHECK(!loadLiveReceipt(out,error)&&!out.valid);}++scenarios;
    reset();put(relative,std::string(512*1024+1,'x'));CHECK(!loadLiveReceipt(out,error)&&!saveLiveReceipt(r,error)&&!clearLiveReceipt(error));++scenarios;
    reset();bad=first;word(bad,28,4);checksum(bad);put(relative,bad);CHECK(!loadLiveReceipt(out,error));++scenarios;
    reset();bad=first;word(bad,64,128);checksum(bad);put(relative,bad);CHECK(!loadLiveReceipt(out,error));++scenarios;
    reset();bad=first;word(bad,144,257);checksum(bad);put(relative,bad);CHECK(!loadLiveReceipt(out,error));++scenarios;
    reset();bad=first;std::fill(bad.begin()+80,bad.begin()+144,'A');checksum(bad);put(relative,bad);CHECK(!loadLiveReceipt(out,error));++scenarios;
    reset();auto invalid=r;invalid.changes.push_back(invalid.changes[0]);CHECK(!saveLiveReceipt(invalid,error)&&!fs::exists(sandbox/relative));++scenarios;
    invalid=r;invalid.observed.clear();CHECK(!saveLiveReceipt(invalid,error));++scenarios;
    invalid=r;invalid.changes[0].id=0;CHECK(!saveLiveReceipt(invalid,error));++scenarios;
    invalid=r;invalid.buildId="0000000000000000";CHECK(!saveLiveReceipt(invalid,error));++scenarios;
    invalid=r;invalid.observed[0].enabled=2;CHECK(!saveLiveReceipt(invalid,error));++scenarios;
    reset();auto master=r;master.masterAdded=true;master.master=definition("Master");Entry m;m.id=0;m.enabled=1;m.definition=master.master;master.observed.push_back(m);CHECK(saveLiveReceipt(master,error)&&loadLiveReceipt(out,error)&&out.masterAdded&&out.observed.size()==2);++scenarios;
    reset();put("config","not a folder");CHECK(!loadLiveReceipt(out,error)&&!saveLiveReceipt(r,error)&&!clearLiveReceipt(error));++scenarios;
    reset();fs::create_directories(sandbox/(relative+".pending"));CHECK(!loadLiveReceipt(out,error)&&!saveLiveReceipt(r,error)&&!clearLiveReceipt(error));++scenarios;
    reset();CHECK(saveLiveReceipt(r,error)&&saveLiveReceipt(r,error));CHECK(clearLiveReceipt(error)&&!fs::exists(sandbox/relative)&&!fs::exists(sandbox/(relative+".backup")));CHECK(loadLiveReceipt(out,error)&&!out.valid);++scenarios;
    reset();auto partial=receipt();LiveChange secondChange=partial.changes[0];secondChange.id=2;secondChange.definition=definition("Resolution",0x2000);partial.changes.push_back(secondChange);Entry secondEntry;secondEntry.id=2;secondEntry.enabled=1;secondEntry.definition=secondChange.definition;partial.observed.push_back(secondEntry);Fake partialRunning(partial);partialRunning.failRemove=2;CHECK(!undoChecked(game(partial),partialRunning,partial).ok&&partial.changes.size()==1);CHECK(saveLiveReceipt(partial,error));auto remainingState=partialRunning.state;out={};CHECK(loadLiveReceipt(out,error)&&out.changes.size()==1);Fake reopened(out);reopened.state=remainingState;CHECK(undoChecked(game(out),reopened,out).ok&&reopened.state.empty());CHECK(clearLiveReceipt(error));++scenarios;
    reset();put("external/marker","keep");std::error_code ec;fs::create_directory_symlink(sandbox/"external",sandbox/"config",ec);if(!ec&&fs::is_symlink(sandbox/"config")){CHECK(!loadLiveReceipt(out,error)&&!saveLiveReceipt(r,error)&&!clearLiveReceipt(error));CHECK(bytes("external/marker")=="keep");++scenarios;}
    reset();put("external/marker","keep");fs::create_directories((sandbox/relative).parent_path());ec.clear();fs::create_symlink(sandbox/"external/marker",sandbox/relative,ec);if(!ec&&fs::is_symlink(sandbox/relative)){CHECK(!loadLiveReceipt(out,error)&&!saveLiveReceipt(r,error)&&!clearLiveReceipt(error));CHECK(bytes("external/marker")=="keep");++scenarios;}
    // Equal generations keep the original file priority: main, pending,
    // backup. Different bytes at that generation are not a new rejection.
    reset();auto tied=first;word(tied,152,7);word(tied,240,7);checksum(tied);put(relative,first);put(relative+".pending",tied);put(relative+".backup",tied);CHECK(loadLiveReceipt(out,error)&&out.changes[0].definition.codes[1]==0x1000);++scenarios;
    reset();put(relative,"broken");put(relative+".pending",first);put(relative+".backup",tied);CHECK(loadLiveReceipt(out,error)&&out.changes[0].definition.codes[1]==0x1000);++scenarios;
    // Failure after a valid first candidate may not return that partial
    // result to the caller when another recovery path is not admissible.
    reset();put(relative,first);fs::create_directory(sandbox/(relative+".pending"));out=receipt();CHECK(!loadLiveReceipt(out,error)&&!out.valid);CHECK(!saveLiveReceipt(r,error)&&bytes(relative)==first);++scenarios;
    reset();put(relative+".backup",first);CHECK(loadLiveReceipt(out,error)&&out.valid);CHECK(saveLiveReceipt(out,error)&&loadLiveReceipt(out,error)&&!fs::exists(sandbox/(relative+".pending")));++scenarios;
    reset();auto exhausted=first;word(exhausted,12,UINT32_MAX);word(exhausted,16,UINT32_MAX);checksum(exhausted);put(relative,exhausted);CHECK(loadLiveReceipt(out,error)&&out.valid);CHECK(!saveLiveReceipt(out,error)&&bytes(relative)==exhausted);++scenarios;
    reset();auto large=maximumReceipt();CHECK(saveLiveReceipt(large,error));const auto bigFirst=bytes(relative);CHECK(bigFirst.size()==281664);large.changes[0].definition.codes[255]^=1;large.observed[1].definition=large.changes[0].definition;CHECK(saveLiveReceipt(large,error));const auto bigSecond=bytes(relative);reset();put(relative,bigFirst);put(relative+".pending",bigSecond);put(relative+".backup",bigFirst);CHECK(loadLiveReceipt(out,error)&&out.changes.size()==127&&out.observed.size()==128&&out.masterAdded&&out.changes[0].definition.codes[255]==large.changes[0].definition.codes[255]);CHECK(saveLiveReceipt(out,error)&&loadLiveReceipt(out,error)&&out.changes.size()==127);++scenarios;
    reset();fs::remove(sandbox);std::cout<<"live receipt: "<<scenarios<<" persistence, recovery and reopen scenarios passed\n";
}

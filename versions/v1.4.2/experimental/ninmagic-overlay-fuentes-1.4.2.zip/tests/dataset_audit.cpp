// Read-only audit driver for the production parser against downloaded source ZIPs.
#include "cheats.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
int main() {
    std::string path;
    while(std::getline(std::cin,path)) {
        std::ifstream f(path,std::ios::binary);
        const std::string data{std::istreambuf_iterator<char>(f),{}};
        std::vector<nc::Cheat>cheats;std::string error;bool ok=nc::parseCheats(data,"dataset-audit",cheats,error);
        std::cout<<path<<'\t'<<(ok?"OK":"FAIL")<<'\t'<<cheats.size()<<'\t'<<error<<'\n';
    }
}

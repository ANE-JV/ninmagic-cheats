// Host simulation of native service failures/FD ownership. Real certificates
// are still verified by Horizon SSL, which requires a separate console probe.
#define __SWITCH__
#include "../source/https_lite.cpp"
#include <iostream>
#include <vector>
namespace {
unsigned checks=0,scenarios=0;std::vector<std::string> events;std::string request,wire;
uint64_t ticks=0;size_t at=0;bool oldFirmware=false,denyCert=false,denyFlags=false,denyTimeout=false;
u32 tlsMask=0,verifyMask=0,ioTimeout=0;SocketInitConfig config{};unsigned sockets=0,contexts=0,connections=0,reads=0,writes=0;
void require(bool ok,const char*label){++checks;if(!ok){std::cerr<<"FAIL "<<label<<"\n";std::exit(1);}}
void reset(){nc::https_lite::shutdown();events.clear();request.clear();wire="HTTP/1.1 200 OK\r\nContent-Length: 1234\r\nETag: verified\r\n\r\n";at=0;ticks=0;oldFirmware=denyCert=denyFlags=denyTimeout=false;tlsMask=verifyMask=ioTimeout=0;sockets=contexts=connections=reads=writes=0;}
bool ordered(const char*a,const char*b){auto x=std::find(events.begin(),events.end(),a),y=std::find(events.begin(),events.end(),b);return x!=events.end()&&y!=events.end()&&x<y;}
}
bool hosversionBefore(int,int,int){return oldFirmware;}u64 armTicksToNs(u64 t){return t;}u64 armGetSystemTick(){return ticks+=1000;}
Result socketInitialize(const SocketInitConfig*c){config=*c;events.push_back("socketInit");return 0;}void socketExit(){events.push_back("socketExit");}Result socketGetLastResult(){return 0x1234;}
Result nifmInitialize(NifmServiceType){events.push_back("nifmInit");return 0;}void nifmExit(){events.push_back("nifmExit");}Result nifmGetInternetConnectionStatus(NifmInternetConnectionType*,u32*,NifmInternetConnectionStatus*s){*s=NifmInternetConnectionStatus_Connected;return 0;}
Result sslInitialize(u32 count){require(count==1,"single SSL session budget");events.push_back("sslInit");return 0;}void sslExit(){events.push_back("sslExit");}
Result sslCreateContext(SslContext*,u32 mask){tlsMask=mask;++contexts;events.push_back("contextCreate");return 0;}void sslContextClose(SslContext*){require(contexts>0,"context closes only once");--contexts;events.push_back("contextClose");}
Result sslContextCreateConnection(SslContext*,SslConnection*){++connections;events.push_back("connectionCreate");return 0;}void sslConnectionClose(SslConnection*){require(connections>0,"connection closes only once");--connections;events.push_back("connectionClose");}
Result sslConnectionSetOption(SslConnection*,SslOptionType type,bool value){require(type==SslOptionType_DoNotCloseSocket&&value,"never enable skip verification; original FD remains owned");events.push_back("dontClose");return 0;}
Result sslConnectionSetHostName(SslConnection*,const char*host,u32 size){require(std::string(host)=="example.com"&&size==12,"SNI and host verification exact DNS including terminator");events.push_back("host");return 0;}
Result sslConnectionSetVerifyOption(SslConnection*,u32 mask){verifyMask=mask;events.push_back("verify");return denyFlags?0x4444:0;}
int socketSslConnectionSetSocketDescriptor(SslConnection*,int fd){require(fd==1000,"socket passed through libnx descriptor wrapper");events.push_back("descriptor");errno=ENOENT;return -1;}
Result sslConnectionSetIoMode(SslConnection*,SslIoMode mode){require(mode==SslIoMode_Blocking,"blocking mode uses explicit timeout");return 0;}
Result sslConnectionSetIoTimeout(SslConnection*,u32 timeout){ioTimeout=timeout;return denyTimeout?0x5555:0;}
Result sslConnectionDoHandshake(SslConnection*,u32*,u32*,void*,u32){events.push_back("handshake");require(verifyMask==7,"CA, host and date required before handshake");return denyCert?0x6666:0;}
Result sslConnectionWrite(SslConnection*,const void*p,u32 size,u32*done){++writes;*done=std::min<u32>(size,7);request.append(static_cast<const char*>(p),*done);return 0;}
Result sslConnectionRead(SslConnection*,void*p,u32 size,u32*done){++reads;*done=u32(std::min<size_t>({size,wire.size()-at,9}));std::memcpy(p,wire.data()+at,*done);at+=*done;return 0;}
extern "C" {
int __wrap_socket(int,int,int){require(sockets==0,"one socket per sequential request");++sockets;events.push_back("fdCreate");return 1000;}
int __wrap_fcntl(int fd,int,...){require(fd==1000,"fcntl only network FD");return 0;}
int __wrap_connect(int fd,const sockaddr*,socklen_t){require(fd==1000,"connect exact FD");events.push_back("connect");return 0;}
int __real_close(int);
int __wrap_close(int fd){if(fd!=1000)return __real_close(fd);require(sockets==1,"original FD closed exactly once");--sockets;events.push_back("fdClose");return 0;}
int __wrap_getaddrinfo(const char*host,const char*service,const addrinfo*hints,addrinfo**out){require(std::string(host)=="example.com"&&std::string(service)=="443"&&hints->ai_family==AF_INET,"DNS exact peer and TLS port");static sockaddr address{};static addrinfo entry{};entry.ai_family=AF_INET;entry.ai_socktype=SOCK_STREAM;entry.ai_addr=&address;entry.ai_addrlen=sizeof(address);*out=&entry;return 0;}
void __wrap_freeaddrinfo(addrinfo*){}
}
int main(){
    using namespace nc::https_lite;Response response;std::string error;
    ++scenarios;reset();require(download("https://example.com/a","",response,error,true,1),"native HEAD simulated success");require(response.status==200&&response.length=="1234"&&response.bytes==0,"HEAD captures validators without body");
    require(tlsMask==((1<<5)|(1<<6))&&verifyMask==7,"TLS1.2/1.3 only and full verification flags");
    const u32 total=config.tcp_tx_buf_size+config.tcp_rx_buf_size+config.udp_tx_buf_size+config.udp_rx_buf_size;require(total==128*1024&&!config.tcp_rx_buf_max_size&&!config.tcp_tx_buf_max_size&&config.sb_efficiency==1&&config.num_bsd_sessions==1,"BSD transfer memory exactly128KiB via libnx formula");
    require(ioTimeout==10000&&writes>1&&reads>1&&request.rfind("HEAD /a HTTP/1.1\r\n",0)==0,"bounded I/O and partial-write retry");
    require(!sockets&&!connections&&!contexts&&ordered("dontClose","descriptor")&&ordered("verify","handshake")&&ordered("connectionClose","fdClose")&&ordered("fdClose","contextClose"),"TLS duplicate and input FD correct cleanup order");
    shutdown();require(ordered("sslExit","nifmExit")&&ordered("nifmExit","socketExit"),"service shutdown reverse order");
    ++scenarios;reset();denyCert=true;require(!download("https://example.com/a","",response,error,true)&&writes==0&&reads==0&&!sockets&&!connections&&!contexts,"certificate failure never sends HTTP and cleans handles");
    ++scenarios;reset();denyFlags=true;require(!download("https://example.com/a","",response,error,true)&&std::find(events.begin(),events.end(),"handshake")==events.end()&&!sockets&&!connections&&!contexts,"verify-policy failure fails closed");
    ++scenarios;reset();denyTimeout=true;require(!download("https://example.com/a","",response,error,true)&&std::find(events.begin(),events.end(),"handshake")==events.end()&&!sockets&&!connections&&!contexts,"unsupported timeout never falls back to unbounded blocking");
    ++scenarios;reset();oldFirmware=true;require(!download("https://example.com/a","",response,error,true)&&events.empty(),"old firmware rejects before service allocation");
    ++scenarios;reset();require(!download("https://example.com/a","",response,error,true,1,[](){return true;})&&events.empty(),"cancel before native initialization");
    shutdown();std::cout<<"https_lite_native: "<<scenarios<<" scenarios, "<<checks<<" checks PASS\n";
}

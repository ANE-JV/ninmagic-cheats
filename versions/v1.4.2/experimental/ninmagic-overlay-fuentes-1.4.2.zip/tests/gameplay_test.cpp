#include "gameplay.hpp"
#include <cstdlib>
#include <iostream>
namespace {
unsigned checks=0;
void require(bool v,const char*m){++checks;if(!v){std::cerr<<m<<'\n';std::exit(1);}}
nc::Cheat c(const char*name,unsigned kind,const char*group,bool master=false){nc::Cheat x;x.name=name;x.categories=kind;x.source=group;x.group=group;x.master=master;x.opcodes={0x04000000,0x10,1};return x;}
}
int main(){
    nc::Pack p;p.compatible=true;p.cheats={c("Master A",nc::Graphics,"A",true),c("Infinite HP",nc::General,"A"),c("60 FPS",nc::Fps,"A"),c("720p",nc::Resolution,"A"),c("Master B",nc::General,"B",true),c("Shadows",nc::Graphics,"B"),c("Infinite Ammo",nc::General,"C")};
    const auto codes=p.cheats[1].opcodes;nc::gameplayOnly(p);
    require(p.compatible&&p.cheats.size()==3,"gameplay/master filtering");require(p.cheats[0].master&&p.cheats[0].group=="A","needed master retained even with visual name");require(p.cheats[1].name=="Infinite HP"&&p.cheats[1].opcodes==codes,"gameplay bytes unchanged");require(p.cheats[2].name=="Infinite Ammo","second source preserved");
    nc::Pack q;q.compatible=true;q.cheats={c("Master",nc::General,"A",true),c("Mixed graphics",nc::General|nc::Graphics,"A")};nc::gameplayOnly(q);require(!q.compatible&&q.cheats.empty(),"mixed visual option and orphan master removed");require(q.detail.find("jugabilidad")!=std::string::npos,"empty result explained");
    nc::Pack empty;empty.detail="Exact BID unavailable";nc::gameplayOnly(empty);require(empty.detail=="Exact BID unavailable","original missing-version reason preserved");
    std::cout<<checks<<" gameplay checks passed\n";
}

#include "platform_internal.hpp"
#include "cheats.hpp"
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>

using namespace nc;
using namespace nc::native;
namespace {
int scenarios=0;
void require(bool ok,const char*line){if(!ok){std::cerr<<"FAILED: "<<line<<'\n';std::exit(1);}}
#define CHECK(x) require((x),#x)
Cheat code(std::string name,uint32_t word=0x04000000,bool selected=true,std::string group="a") {
    Cheat c;c.name=name;c.opcodes={word,0x1000,0x60000000};c.source="test";c.group=group;c.selected=selected;return c;
}
Pack pack(){Pack p;p.game.id=0x0100000000010000ULL;p.game.buildId="0123456789ABCDEF";p.game.buildVerified=true;p.compatible=true;p.cheats={code("60 FPS")};return p;}
Cheat counted(std::string name,unsigned words,uint32_t seed){auto c=code(name);c.opcodes.assign(words,0x20000000);if(words)c.opcodes[0]=seed;return c;}
Definition def(const Cheat&c){Definition d{};std::memcpy(d.name,c.name.data(),std::min(c.name.size(),size_t(63)));d.count=static_cast<uint32_t>(c.opcodes.size());std::copy(c.opcodes.begin(),c.opcodes.end(),d.codes);return d;}
struct Fake:Runtime {
    Metadata meta{};std::vector<Entry> state;
    int mutations=0,adds=0,toggles=0,masters=0,removes=0,metaCalls=0,entryCalls=0;
    int failAdd=0,failToggle=0,failRemove=0,changeAt=0;bool failMaster=false,failVerify=false,noopRemove=false,noopToggle=false,unavailable=false;
    int sessionChangeAt=0,sessionChangeField=0,injectAt=0;
    Fake(){meta.pid=8;meta.title=0x0100000000010000ULL;uint8_t bytes[]={0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef};std::memcpy(meta.build,bytes,8);}
    bool metadata(Metadata&m)override{++metaCalls;if(unavailable)return false;m=meta;if(changeAt&&metaCalls>=changeAt)m.pid=9;if(sessionChangeAt&&metaCalls>=sessionChangeAt){if(sessionChangeField==0)m.build[31]^=1;else if(sessionChangeField==1)m.mainBase+=0x1000;else if(sessionChangeField==2)m.mainSize+=0x1000;else if(sessionChangeField==3)m.heapBase+=0x1000;else if(sessionChangeField==4)m.heapSize+=0x1000;else if(sessionChangeField==5)m.aliasBase+=0x1000;else m.aliasSize+=0x1000;}return true;}
    bool entries(std::vector<Entry>&e)override{++entryCalls;if(failVerify&&entryCalls>=2)return false;if(injectAt==entryCalls){auto foreign=code("Foreign pointer",0x58000000);existing(foreign,true,100);}e=state;return true;}
    bool add(const Definition&d,uint32_t&id)override{
        ++adds;if(failAdd==adds)return false;
        for(id=1;id<128;++id)if(std::none_of(state.begin(),state.end(),[&](const Entry&e){return e.id==id;}))break;
        if(id==128)return false;
        Entry e;e.id=id;e.definition=d;state.push_back(e);++mutations;return true;
    }
    bool remove(uint32_t id)override{++removes;if(failRemove==removes)return false;auto it=std::find_if(state.begin(),state.end(),[&](const Entry&e){return e.id==id;});if(it==state.end())return false;if(noopRemove)return true;state.erase(it);++mutations;return true;}
    bool toggle(uint32_t id)override{++toggles;if(failToggle==toggles)return false;for(auto&e:state)if(e.id==id){if(noopToggle)return true;e.enabled=!e.enabled;++mutations;return true;}return false;}
    bool master(const Definition&d)override{++masters;if(failMaster)return false;Entry e;e.id=0;e.enabled=1;e.definition=d;state.push_back(e);++mutations;return true;}
    void existing(const Cheat&c,bool enabled,uint32_t id){Entry e;e.id=id;e.enabled=enabled;e.definition=def(c);state.push_back(e);}
};
Pack sessionPack(Fake&f){auto p=pack();f.meta.mainBase=0x10000000;f.meta.mainSize=0x10000;f.meta.heapBase=0x20000000;f.meta.heapSize=0x20000000;p.game.running=true;p.game.fullBuildId=p.game.buildId+std::string(48,'0');p.sessionOnly=true;p.sessionBinding={f.meta.pid,f.meta.title,p.game.fullBuildId,f.meta.mainBase,f.meta.mainSize,f.meta.heapBase,f.meta.heapSize};p.cheats[0].name="Experimental";p.cheats[0].opcodes={0x04000000,0x1000,0x20};return p;}
Pack aliasSessionPack(Fake&f){auto p=sessionPack(f);f.meta.aliasBase=0x300000000ULL;f.meta.aliasSize=0x1000000000ULL;p.sessionBinding.aliasBase=f.meta.aliasBase;p.sessionBinding.aliasSize=f.meta.aliasSize;p.cheats[0].opcodes={0x01200000,0x80,9};return p;}
}
int main(){
    {auto p=pack();Fake f;p.compatible=false;CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;++f.meta.title;CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;f.meta.build[0]=0x10;CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;f.meta.pid=0;CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;auto o=applyChecked(p,f);CHECK(o.ok&&o.live&&o.count==1);CHECK(f.state.size()==1&&f.state[0].enabled);++scenarios;}
    {auto p=pack();Fake f;f.existing(p.cheats[0],true,3);auto o=applyChecked(p,f);CHECK(o.ok&&f.mutations==0&&f.state.size()==1);++scenarios;}
    {auto p=pack();Fake f;f.existing(p.cheats[0],false,3);CHECK(applyChecked(p,f).ok);CHECK(f.state[0].enabled&&f.adds==0&&f.toggles==1);++scenarios;}
    {auto p=pack();Fake f;f.existing(code("other",0x08000000),true,5);f.existing(code("disabled",0x02000000),false,6);CHECK(applyChecked(p,f).ok);CHECK(f.state[0].enabled&&!f.state[1].enabled&&f.state.size()==3);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);CHECK(applyChecked(p,f).ok);CHECK(f.masters==1&&f.state.size()==2);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Other source master",0x08000000,false,"b");m.master=true;p.cheats.push_back(m);CHECK(applyChecked(p,f).ok);CHECK(f.masters==0&&f.state.size()==1);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(code("Old master",0x02000000),true,0);CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(m,true,0);CHECK(applyChecked(p,f).ok);CHECK(f.masters==0&&f.state.size()==2);++scenarios;}
    {auto p=pack();p.cheats.push_back(code("Infinite",0x02000000));Fake f;f.failAdd=2;CHECK(!applyChecked(p,f).ok);CHECK(f.state.empty());++scenarios;}
    {auto p=pack();p.cheats.push_back(code("Infinite",0x02000000));Fake f;f.existing(p.cheats[0],false,4);f.failToggle=2;CHECK(!applyChecked(p,f).ok);CHECK(f.state.size()==1&&!f.state[0].enabled&&f.state[0].id==4);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.failMaster=true;CHECK(!applyChecked(p,f).ok);CHECK(f.state.empty());++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.failToggle=1;CHECK(!applyChecked(p,f).ok);CHECK(f.state.empty());++scenarios;}
    {auto p=pack();Fake f;f.failVerify=true;CHECK(!applyChecked(p,f).ok);CHECK(f.state.empty());++scenarios;}
    {auto p=pack();Fake f;f.changeAt=3;auto o=applyChecked(p,f);CHECK(!o.ok&&o.message.find("reinicia")!=std::string::npos);CHECK(f.state.size()==1&&!f.state[0].enabled);++scenarios;}
    {auto p=pack();Fake f;for(unsigned i=1;i<128;++i)f.existing(code("other",0x02000000+i),false,i);CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;f.existing(code("bad"),false,129);CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;f.existing(code("bad"),false,1);f.state[0].definition.count=257;CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;p.cheats.push_back(code("Duplicate codes"));auto o=applyChecked(p,f);CHECK(o.ok&&o.count==1&&f.state.size()==1);++scenarios;}
    {auto p=pack();Fake f;p.cheats[0].opcodes.resize(257);CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master A",0x08000000,false,"a");m.master=true;p.cheats.push_back(m);m.name="Master B";m.group="b";m.opcodes[0]=0x02000000;p.cheats.push_back(m);p.cheats.push_back(code("Other",0x01000000,true,"b"));CHECK(!applyChecked(p,f).ok);CHECK(f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;auto m=code("Master A",0x08000000,false,"a");m.master=true;p.cheats.push_back(m);m.name="Master B";m.group="b";p.cheats.push_back(m);p.cheats.push_back(code("Other",0x01000000,true,"b"));CHECK(applyChecked(p,f).ok);CHECK(f.masters==1&&f.state.size()==3);++scenarios;}
    {auto p=pack();Fake f;auto other=p.cheats[0];other.name="30 FPS";other.opcodes[2]=0x52800020;f.existing(other,true,5);auto o=applyChecked(p,f);CHECK(!o.ok&&o.message.find("conflicto")!=std::string::npos);CHECK(f.mutations==0&&f.state.size()==1);++scenarios;}
    {auto p=pack();Fake f;auto other=p.cheats[0];other.name="30 FPS";other.opcodes[2]=0x52800020;f.existing(other,false,5);CHECK(applyChecked(p,f).ok);CHECK(f.state.size()==2&&!f.state[0].enabled&&f.state[1].enabled);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto unrelated=code("Other");unrelated.opcodes[1]=0x2000;f.existing(unrelated,true,5);CHECK(applyChecked(p,f,&r).ok);CHECK(r.changes.size()==1&&r.changes[0].added);auto o=undoChecked(p.game,f,r);CHECK(o.ok&&f.state.size()==1&&f.state[0].id==5&&f.state[0].enabled&&!r.valid);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;f.existing(p.cheats[0],false,3);CHECK(applyChecked(p,f,&r).ok);CHECK(r.changes.size()==1&&!r.changes[0].added);CHECK(undoChecked(p.game,f,r).ok);CHECK(f.state.size()==1&&f.state[0].id==3&&!f.state[0].enabled);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;f.existing(p.cheats[0],true,3);CHECK(applyChecked(p,f,&r).ok);CHECK(r.changes.empty());auto out=undoChecked(p.game,f,r);CHECK(out.ok&&out.liveEffect==LiveEffect::NoOwned);CHECK(f.state.size()==1&&f.state[0].enabled&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);CHECK(applyChecked(p,f,&r).ok);CHECK(r.changes.size()==1);CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);auto other=code("Other");other.opcodes[1]=0x2000;p.cheats.push_back(other);CHECK(applyChecked(p,f,&r).ok);CHECK(r.changes.size()==2);CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);CHECK(applyChecked(p,f,&r).ok);CHECK(r.masterAdded);CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(m,true,0);CHECK(applyChecked(p,f,&r).ok);CHECK(!r.masterAdded);CHECK(undoChecked(p.game,f,r).ok);CHECK(f.state.size()==1&&f.state[0].id==0);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);CHECK(applyChecked(p,f,&r).ok);auto other=code("Other");other.opcodes[1]=0x2000;f.existing(other,false,4);int mutations=f.mutations;CHECK(!undoChecked(p.game,f,r).ok&&f.mutations==mutations&&r.valid);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);CHECK(applyChecked(p,f,&r).ok);auto other=code("Other");other.opcodes[1]=0x2000;f.existing(other,false,4);CHECK(applyChecked(p,f,&r).ok);int mutations=f.mutations;CHECK(!undoChecked(p.game,f,r).ok&&f.mutations==mutations&&r.valid);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);f.state[0].definition.codes[2]^=1;int mutations=f.mutations;CHECK(!undoChecked(p.game,f,r).ok&&f.mutations==mutations);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);++f.meta.pid;int mutations=f.mutations;CHECK(!undoChecked(p.game,f,r).ok&&f.mutations==mutations&&!r.valid);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);f.state.clear();CHECK(undoChecked(p.game,f,r).ok&&!r.valid&&f.state.empty());++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;auto other=code("Other");other.opcodes[1]=0x2000;p.cheats.push_back(other);CHECK(applyChecked(p,f,&r).ok);f.failRemove=2;CHECK(!undoChecked(p.game,f,r).ok);CHECK(r.valid&&r.changes.size()==1&&f.state.size()==1);f.failRemove=0;CHECK(undoChecked(p.game,f,r).ok&&f.state.empty()&&!r.valid);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);f.noopRemove=true;CHECK(!undoChecked(p.game,f,r).ok&&r.valid&&r.changes.size()==1&&f.state.size()==1);f.noopRemove=false;CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;f.existing(p.cheats[0],false,3);CHECK(applyChecked(p,f,&r).ok);f.noopToggle=true;CHECK(!undoChecked(p.game,f,r).ok&&r.valid&&r.changes.size()==1&&f.state[0].enabled);f.noopToggle=false;CHECK(undoChecked(p.game,f,r).ok&&!f.state[0].enabled);++scenarios;}
    {auto p=pack();Fake f;LiveReceipt r;CHECK(applyChecked(p,f,&r).ok);f.unavailable=true;const auto mutations=f.mutations;CHECK(!undoChecked(p.game,f,r).ok&&r.valid&&r.changes.size()==1&&f.mutations==mutations);f.unavailable=false;CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    // All enabled entries share Atmosphere's single 1024-word VM program.
    {auto p=pack();Fake f;for(unsigned i=0;i<4;++i)f.existing(counted("Existing",256,0x40000000+i),true,i+1);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;p.cheats={counted("Existing",256,0x40000000)};for(unsigned i=0;i<4;++i)f.existing(counted("Existing",256,0x40000000+i),true,i+1);CHECK(applyChecked(p,f).ok&&f.mutations==0&&f.state.size()==4);++scenarios;}
    {auto p=pack();Fake f;p.cheats.clear();for(unsigned i=0;i<4;++i)p.cheats.push_back(counted("Selected "+std::to_string(i),256,0x40000000+i));f.existing(counted("Disabled",256,0x50000000),false,8);CHECK(applyChecked(p,f).ok&&f.state.size()==5&&!f.state[0].enabled);++scenarios;}
    {auto p=pack();Fake f;p.cheats={counted("Selected",255,0x50000000)};auto m=counted("Master",1,0x20000000);m.master=true;p.cheats.push_back(m);for(unsigned i=0;i<3;++i)f.existing(counted("Existing",256,0x40000000+i),true,i+1);CHECK(applyChecked(p,f).ok&&f.masters==1);++scenarios;}
    {auto p=pack();Fake f;p.cheats={counted("Selected",255,0x50000000)};auto m=counted("Master",2,0x20000000);m.master=true;p.cheats.push_back(m);for(unsigned i=0;i<3;++i)f.existing(counted("Existing",256,0x40000000+i),true,i+1);CHECK(!applyChecked(p,f).ok&&f.mutations==0&&f.masters==0);++scenarios;}
    // A reopened app seeds selection from the actual engine, without mutation.
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);p.cheats[0].selected=false;CHECK(readCheckedState(p,f,error)&&p.liveChecked&&p.liveHydrated&&p.livePid==8);CHECK(p.cheats[0].liveState==CheatState::Enabled&&p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],false,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Disabled&&!p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::NotLoaded&&!p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);CHECK(readCheckedState(p,f,error));p.cheats[0].selected=false;CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled&&!p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.unavailable=true;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&!p.liveHydrated&&p.livePid==0&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;++f.meta.title;CHECK(!readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.meta.build[0]^=1;CHECK(!readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;p.game.fullBuildId=p.game.buildId+std::string(48,'0');f.existing(p.cheats[0],true,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled);p.game.fullBuildId.back()='1';CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);f.changeAt=2;CHECK(!readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&!p.liveHydrated&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.meta.pid=0;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);f.existing(p.cheats[0],false,5);CHECK(!readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,128);CHECK(!readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);f.state[0].definition.count=257;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);f.state[0].enabled=2;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);std::fill(std::begin(f.state[0].definition.name),std::end(f.state[0].definition.name),'x');CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto different=p.cheats[0];different.opcodes[2]^=1;f.existing(different,true,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::NotLoaded&&!p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto alias=p.cheats[0];alias.name="Another label";f.existing(alias,true,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled&&p.cheats[0].selected&&p.liveDetail.find("otro nombre")!=std::string::npos&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],false,5);f.existing(p.cheats[0],true,6);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled&&p.cheats[0].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(p.cheats[0],true,5);f.existing(m,true,0);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled&&p.cheats[1].liveState==CheatState::Enabled&&!p.cheats[1].selected&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(p.cheats[0],true,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&p.cheats[0].selected&&p.cheats[1].liveState==CheatState::NotLoaded&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto m=code("Other group master",0x08000000,false,"other");m.master=true;p.cheats.push_back(m);f.existing(p.cheats[0],true,5);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Enabled&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;auto m=code("Master",0x08000000,false);m.master=true;p.cheats.push_back(m);f.existing(p.cheats[0],true,5);auto wrong=m;wrong.opcodes[0]^=1;f.existing(wrong,true,0);CHECK(readCheckedState(p,f,error)&&p.cheats[0].liveState==CheatState::Unknown&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);for(unsigned i=0;i<4;++i)f.existing(counted("Other",256,0x40000000+i),true,i+10);CHECK(readCheckedState(p,f,error)&&p.liveChecked&&p.cheats[0].liveState==CheatState::Unknown&&p.cheats[0].selected&&p.liveDetail.find("1024")!=std::string::npos&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;f.existing(p.cheats[0],true,5);CHECK(readCheckedState(p,f,error));p.cheats[0].selected=false;f.unavailable=true;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&p.livePid==0&&p.cheats[0].liveState==CheatState::Unknown&&!p.cheats[0].selected&&p.liveHydrated&&f.mutations==0);++scenarios;}
    {auto p=pack();Fake f;std::string error;const std::string text="[Infinite / Max Hearts Press ZR]\n80000200\n01000000 01CC0764 00000050\n20000000\n\n[9999 Rupees Press L]\n80000040\n02000000 01CC0760 0000270F\n20000000\n";CHECK(parseCheats(text,"general",p.cheats,error));for(auto&c:p.cheats)c.selected=true;const auto hearts=p.cheats[0].opcodes,rupees=p.cheats[1].opcodes;CHECK(applyChecked(p,f).ok);const auto mutations=f.mutations;Pack reopened=pack();CHECK(parseCheats(text,"general",reopened.cheats,error)&&!reopened.cheats[0].selected&&!reopened.cheats[1].selected);CHECK(readCheckedState(reopened,f,error)&&reopened.cheats[0].selected&&reopened.cheats[1].selected&&reopened.cheats[0].liveState==CheatState::Enabled&&reopened.cheats[1].liveState==CheatState::Enabled);CHECK(reopened.cheats[0].opcodes==hearts&&reopened.cheats[1].opcodes==rupees&&hearts[0]==0x80000200&&rupees[0]==0x80000040&&f.mutations==mutations);++scenarios;}
    // Experimental writes are restricted to one exact process and memory layout.
    {Fake f;auto p=sessionPack(f);LiveReceipt r;CHECK(applyChecked(p,f,&r).ok&&f.state.size()==1&&f.state[0].enabled);CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    {Fake f;auto p=sessionPack(f);CHECK(applyChecked(p,f).ok);const auto old=f.mutations;CHECK(applyChecked(p,f).ok&&f.mutations==old);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.existing(p.cheats[0],true,5);CHECK(applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.existing(code("Disabled pointer",0x58000000),false,5);CHECK(applyChecked(p,f).ok&&!f.state[0].enabled&&f.state.size()==2);++scenarios;}
    {Fake f;auto p=sessionPack(f);auto other=p.cheats[0];other.opcodes[1]=0x2000;f.existing(other,true,5);CHECK(!applyChecked(p,f).ok&&f.mutations==0&&f.state[0].enabled);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.existing(code("Active pointer",0x58000000),true,5);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.existing(code("Master"),true,0);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.existing(code("Master"),false,0);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);++p.sessionBinding.pid;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);p.sessionBinding.fullBuildId.back()='1';CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    for(unsigned field=0;field<4;++field){Fake f;auto p=sessionPack(f);if(field==0)++p.sessionBinding.mainBase;else if(field==1)++p.sessionBinding.mainSize;else if(field==2)++p.sessionBinding.heapBase;else ++p.sessionBinding.heapSize;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    for(unsigned field=0;field<5;++field){Fake f;auto p=sessionPack(f);f.sessionChangeAt=2;f.sessionChangeField=int(field);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.sessionChangeAt=4;f.sessionChangeField=1;CHECK(!applyChecked(p,f).ok&&f.adds==1&&f.toggles==0&&f.state.size()==1&&!f.state[0].enabled);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.injectAt=2;CHECK(!applyChecked(p,f).ok&&f.mutations==0&&f.state.size()==1&&f.state[0].id==100&&f.state[0].enabled);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.injectAt=3;CHECK(!applyChecked(p,f).ok&&f.adds==1&&f.removes==1&&f.toggles==0&&f.state.size()==1&&f.state[0].id==100&&f.state[0].enabled);++scenarios;}
    {Fake f;auto p=sessionPack(f);f.injectAt=4;CHECK(!applyChecked(p,f).ok&&f.adds==1&&f.removes==1&&f.toggles==1&&f.state.size()==1&&f.state[0].id==100&&f.state[0].enabled);++scenarios;}
    {Fake f;auto p=sessionPack(f);auto m=code("Master");m.master=true;p.cheats.push_back(m);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);auto second=p.cheats[0];second.opcodes[1]=0x2000;p.cheats.push_back(second);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    for(auto word:{0x04010000u,0x44000000u,0x04200000u,0x04000100u}){Fake f;auto p=sessionPack(f);p.cheats[0].opcodes[0]=word;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);p.cheats[0].opcodes[1]=0xFFFF;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);p.cheats[0].opcodes[0]=0x01000000;p.cheats[0].opcodes[2]=0x100;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=sessionPack(f);p.cheats[0].opcodes[0]=0x04100000;CHECK(applyChecked(p,f).ok);++scenarios;}
    {Fake f;auto p=sessionPack(f);std::string error;f.existing(p.cheats[0],true,5);++p.sessionBinding.pid;CHECK(!readCheckedState(p,f,error)&&!p.liveChecked&&f.mutations==0);++scenarios;}
    {Fake f;auto p=pack();LiveReceipt r;auto out=undoChecked(p.game,f,r);CHECK(out.ok&&out.liveEffect==LiveEffect::NoOwned&&f.mutations==0&&f.metaCalls==0);++scenarios;}
    {Fake f;auto p=pack();LiveReceipt r;r.pid=99;auto out=undoChecked(p.game,f,r);CHECK(!out.ok&&out.liveEffect==LiveEffect::Uncertain&&r.pid==99&&f.mutations==0);++scenarios;}
    {Fake f;auto p=pack();LiveReceipt r;r.valid=true;r.pid=8;r.title=p.game.id+1;r.buildId=p.game.buildId;auto out=undoChecked(p.game,f,r);CHECK(!out.ok&&out.liveEffect==LiveEffect::Unchanged&&r.valid&&f.mutations==0);++scenarios;}
    {Fake f;auto p=pack();p.compatible=false;auto out=applyChecked(p,f);CHECK(!out.ok&&out.liveEffect==LiveEffect::Unchanged&&f.mutations==0);++scenarios;}
    {Fake f;auto p=pack();f.failAdd=1;auto out=applyChecked(p,f);CHECK(!out.ok&&out.liveEffect==LiveEffect::Uncertain&&f.adds==1);++scenarios;}
    {Fake f;auto p=pack();LiveReceipt r;auto out=applyChecked(p,f,&r);CHECK(out.ok&&out.liveEffect==LiveEffect::Enabled);f.unavailable=true;out=undoChecked(p.game,f,r);CHECK(!out.ok&&out.liveEffect==LiveEffect::Uncertain&&r.valid&&!r.changes.empty());f.unavailable=false;out=undoChecked(p.game,f,r);CHECK(out.ok&&out.liveEffect==LiveEffect::Removed&&!r.valid);++scenarios;}
    // Alias-backed experiments retain the same strict single-value/session
    // restrictions. Native platform preflight separately verifies Heap+RW.
    {Fake f;auto p=aliasSessionPack(f);LiveReceipt r;CHECK(applyChecked(p,f,&r).ok&&f.state.size()==1&&f.state.front().enabled);CHECK(f.state.front().definition.codes[0]==0x01200000);std::string error;CHECK(readCheckedState(p,f,error)&&p.cheats.front().liveState==CheatState::Enabled);CHECK(undoChecked(p.game,f,r).ok&&f.state.empty());++scenarios;}
    for(auto word:{0x02200000u,0x04200000u}){Fake f;auto p=aliasSessionPack(f);p.cheats.front().opcodes[0]=word;CHECK(applyChecked(p,f).ok);++scenarios;}
    {Fake f;auto p=aliasSessionPack(f);p.cheats.front().opcodes[0]=0x01200001;CHECK(applyChecked(p,f).ok);++scenarios;}
    for(auto word:{0x01300000u,0x01210000u}){Fake f;auto p=aliasSessionPack(f);p.cheats.front().opcodes[0]=word;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=aliasSessionPack(f);p.cheats.front().opcodes={0x01200010,0,9};CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=aliasSessionPack(f);p.cheats.front().opcodes={0x0420000F,0xFFFFFFFE,9};CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    {Fake f;auto p=aliasSessionPack(f);p.sessionBinding.aliasBase=p.sessionBinding.aliasSize=0;f.meta.aliasBase=f.meta.aliasSize=0;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    for(unsigned field=0;field<2;++field){Fake f;auto p=aliasSessionPack(f);if(field==0)++p.sessionBinding.aliasBase;else ++p.sessionBinding.aliasSize;CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    for(unsigned field=5;field<7;++field){Fake f;auto p=aliasSessionPack(f);f.sessionChangeAt=2;f.sessionChangeField=int(field);CHECK(!applyChecked(p,f).ok&&f.mutations==0);++scenarios;}
    std::cout<<"runtime: "<<scenarios<<" identity, dependency and rollback scenarios passed\n";
}

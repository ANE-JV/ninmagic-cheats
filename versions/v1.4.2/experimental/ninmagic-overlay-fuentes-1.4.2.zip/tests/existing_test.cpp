// All rename/write targets are newly created synthetic folders below argv[1].
#define NC_EXISTING_TEST
#include "../source/existing.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <utime.h>
#ifdef NC_EXISTING_INSTALL_INTEGRATION
#include "cheats.hpp"
namespace nc {std::string installTestRoot(){const char *p=std::getenv("NC_EXISTING_ROOT");return p?p:"existing-test";}}
#endif

namespace fs=std::filesystem;
namespace {
unsigned checks=0,scenario=0;fs::path base,active;
void require(bool ok,const char *message){++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
nc::Game game(){nc::Game g;g.id=0x01007300020FA000ULL;g.name="Test Game";return g;}
std::string title(){return "atmosphere/contents/"+nc::hexId(game().id);}
void fresh(){active=base/("case-"+std::to_string(++scenario));require(fs::create_directory(active),"create fresh fixture folder");setenv("NC_EXISTING_ROOT",active.generic_string().c_str(),1);}
void file(const std::string &path,const std::string &text="test"){fs::create_directories((active/path).parent_path());std::ofstream out(active/path,std::ios::binary);out<<text;require(bool(out),"write synthetic fixture");}
std::string read(const fs::path &path){std::ifstream in(path,std::ios::binary);return std::string(std::istreambuf_iterator<char>(in),{});}
nc::ExistingContent inspect(const nc::Game &g=game()){nc::ExistingContent content;std::string error;bool ok=nc::inspectExisting(g,content,error);if(!ok)std::cerr<<error<<"\n";require(ok,"inspect fixture");return content;}
}
int main(int argc,char **argv) {
    require(argc==2,"test base directory argument");base=fs::absolute(argv[1]);require(fs::is_directory(base),"explicit test base exists");
    fresh();auto empty=inspect();require(empty.valid&&!empty.exists&&!empty.cheats&&!empty.mods&&empty.entries.empty(),"missing Atmosphere is empty");
    require(nc::retireExisting(empty).ok,"no-op empty snapshot");
    fs::create_directories(active/title()/"romfs"/"empty");empty=inspect();require(!empty.exists&&empty.files==0&&empty.directories==2,"empty directories do not trigger prompt");

    fresh();file(title()+"/cheats/0123456789ABCDEF.txt","[test]\n04000000 00000000 00000001\n");
    auto onlyCheats=inspect();require(onlyCheats.exists&&onlyCheats.cheats&&!onlyCheats.mods&&onlyCheats.files==1,"detect cheats-only tree");
    file(title()+"/romfs/mod/data.bin","MODDATA");file(title()+"/exefs/main.npdm","EXEFS");file(title()+"/config.ini","config");file(title()+"/.hidden","hidden");file("atmosphere/contents/01007300020FA001/romfs/other.bin","OTHER");
    auto mixed=inspect();require(mixed.cheats&&mixed.mods&&mixed.files==5&&mixed.directories==4,"detect all mods and cheats including hidden files");
    auto retired=nc::retireExisting(mixed);if(!retired.ok)std::cerr<<retired.message<<"\n";
    require(retired.ok&&retired.count==5&&!retired.backupPath.empty(),"retire complete exact title folder");
    require(!fs::exists(active/title())&&read(fs::path(retired.backupPath)/"romfs/mod/data.bin")=="MODDATA","content moved intact outside Atmosphere");
    require(read(active/"atmosphere/contents/01007300020FA001/romfs/other.bin")=="OTHER","other game untouched");
    require(fs::is_regular_file(fs::path(retired.backupPath).parent_path()/"receipt.bin")&&fs::is_regular_file(fs::path(retired.backupPath).parent_path()/"ready")&&fs::is_regular_file(fs::path(retired.backupPath).parent_path()/"complete"),"receipt exists before complete backup");
    auto restored=nc::restoreExisting(game());require(restored.ok&&read(active/title()/"romfs/mod/data.bin")=="MODDATA","restore previous full content");
    require(!nc::restoreExisting(game()).ok,"same backup not restored twice");

    fresh();file(title()+"/romfs/mod.bin");auto running=game();running.running=true;auto held=inspect(running);
    require(!nc::retireExisting(held).ok&&fs::exists(active/title()/"romfs/mod.bin"),"running game cannot retire mods");
    require(!nc::restoreExisting(running).ok,"running game cannot restore mods");
    nc::Game system;system.id=0x0100000000000001ULL;nc::ExistingContent protectedContent;std::string error;
    require(!nc::inspectExisting(system,protectedContent,error)&&!protectedContent.valid,"system title refused");

    fresh();file(title()+"/romfs/mod.bin","old");auto stale=inspect();file(title()+"/romfs/new.bin","new");
    require(!nc::retireExisting(stale).ok&&read(active/title()/"romfs/mod.bin")=="old","added file invalidates consent snapshot");
    stale=inspect();file(title()+"/romfs/mod.bin","longer changed content");
    require(!nc::retireExisting(stale).ok&&fs::exists(active/title()),"changed file size invalidates snapshot");
    stale=inspect();fs::remove(active/title()/"romfs/new.bin");require(!nc::retireExisting(stale).ok,"removed file invalidates snapshot");
    stale=inspect();struct utimbuf times{};times.actime=100;times.modtime=100;require(utime((active/title()/"romfs/mod.bin").generic_string().c_str(),&times)==0,"set fixture mtime");
    require(!nc::retireExisting(stale).ok,"changed mtime invalidates snapshot");

    fresh();file(title()+"/romfs/mod.bin","ORIGINAL");retired=nc::retireExisting(inspect());require(retired.ok,"backup original for collision case");
    file(title()+"/cheats/new.txt","NEW");restored=nc::restoreExisting(game());
    require(!restored.ok&&read(active/title()/"cheats/new.txt")=="NEW"&&read(fs::path(retired.backupPath)/"romfs/mod.bin")=="ORIGINAL","restore never merges over new content");
    fs::remove(active/title()/"cheats/new.txt");fs::create_directories(active/title()/"romfs"/"empty"/"nested");
    restored=nc::restoreExisting(game());require(restored.ok&&read(active/title()/"romfs/mod.bin")=="ORIGINAL","restore through an empty cheats directory and other empty nested directories");

    fresh();file(title()+"/romfs/mod.bin","POWER-LOSS-RECOVERY");retired=nc::retireExisting(inspect());require(retired.ok,"backup for interruption recovery case");
    fs::remove(fs::path(retired.backupPath).parent_path()/"complete");
    require(nc::restoreExisting(game()).ok&&read(active/title()/"romfs/mod.bin")=="POWER-LOSS-RECOVERY","durable ready receipt can recover an interrupted final marker");

    fresh();file(title()+"/romfs/mod.bin","RECEIPT");auto receiptFixture=inspect();nc::ExistingContent parsed;
    require(nc::parseReceipt(nc::receipt(receiptFixture),game(),parsed)&&nc::sameEntries(receiptFixture,parsed),"receipt round-trip preserves full metadata");
    auto wrongGame=game();++wrongGame.id;require(!nc::parseReceipt(nc::receipt(receiptFixture),wrongGame,parsed),"receipt cannot restore another Title ID");
    auto invalid=receiptFixture;invalid.entries.back().path="../other-game/file.bin";
    require(!nc::parseReceipt(nc::receipt(invalid),game(),parsed),"receipt traversal path rejected even with valid CRC");
    invalid=receiptFixture;invalid.entries[0].directory=false;require(!nc::parseReceipt(nc::receipt(invalid),game(),parsed),"receipt root must be a directory");
    invalid=receiptFixture;invalid.entries.push_back(invalid.entries.back());require(!nc::parseReceipt(nc::receipt(invalid),game(),parsed),"receipt duplicate path rejected");

    fresh();file(title()+"/romfs/mod.bin","UNCHANGED");retired=nc::retireExisting(inspect());require(retired.ok,"backup for corrupt receipt case");
    {std::ofstream out(fs::path(retired.backupPath).parent_path()/"receipt.bin",std::ios::binary);out<<"corrupt";}
    require(!nc::restoreExisting(game()).ok&&fs::exists(fs::path(retired.backupPath)/"romfs/mod.bin"),"corrupt receipt blocks restoration and preserves backup");

    fresh();file(title()+"/romfs/mod.bin","BEFORE");retired=nc::retireExisting(inspect());require(retired.ok,"backup for changed backup case");
    {std::ofstream out(fs::path(retired.backupPath)/"romfs/mod.bin",std::ios::binary);out<<"CHANGED-BACKUP";}
    require(!nc::restoreExisting(game()).ok&&!fs::exists(active/title()),"changed backup blocks restoration");

    fresh();file(title()+"/romfs/mod.bin");std::string veryDeep=title();for(unsigned n=0;n<34;++n)veryDeep+="/d";fs::create_directories(active/veryDeep);
    nc::ExistingContent bounded;error.clear();require(!nc::inspectExisting(game(),bounded,error)&&!bounded.valid,"excess depth rejected");

    fresh();file(title()+"/romfs/mod.bin");file("external/secret.bin","OTHER");
    require(symlink((active/"external/secret.bin").generic_string().c_str(),(active/title()/"romfs/link.bin").generic_string().c_str())==0,"create symlink fixture");
    error.clear();require(!nc::inspectExisting(game(),bounded,error)&&read(active/"external/secret.bin")=="OTHER","symlink refused and unrelated target preserved");

    fresh();fs::create_directories(active/"atmosphere");fs::create_directories(active/"external");
    require(symlink((active/"external").generic_string().c_str(),(active/"atmosphere/contents").generic_string().c_str())==0,"create parent symlink fixture");
    error.clear();require(!nc::inspectExisting(game(),bounded,error),"symlink parent refused");

    fresh();file("atmosphere/contents","not a directory");error.clear();require(!nc::inspectExisting(game(),bounded,error),"non-directory contents parent refused");
    fresh();file(title(),"not a directory");error.clear();require(!nc::inspectExisting(game(),bounded,error),"non-directory exact title path refused");

    // A later installation must not accidentally consume an earlier operation's
    // full-title backup. Explicit restoration tokens never fall back to latest.
    fresh();file(title()+"/romfs/mod.bin","OLDER-OPERATION");
    auto older=nc::retireExisting(inspect());require(older.ok&&older.transactionId=="00000000","retirement returns exact first transaction token");
    file(title()+"/romfs/mod.bin","NEWER-OPERATION");
    auto newer=nc::retireExisting(inspect());require(newer.ok&&newer.transactionId=="00000001","new retirement gets independent transaction token");
    require(!nc::restoreExistingAt(game(),"00000002").ok&&!fs::exists(active/title())&&read(fs::path(newer.backupPath)/"romfs/mod.bin")=="NEWER-OPERATION","missing exact token never restores newest backup");
    for(const std::string token:{"","0000000","000000000","abcdefgh","../00000000","00000000/content","0000000/"})require(!nc::restoreExistingAt(game(),token).ok&&!fs::exists(active/title()),"invalid token never searches or restores another backup");
    auto explicitOlder=nc::restoreExistingAt(game(),older.transactionId);
    require(explicitOlder.ok&&explicitOlder.transactionId==older.transactionId&&read(active/title()/"romfs/mod.bin")=="OLDER-OPERATION","explicit old token restores only its associated content");
    require(read(fs::path(newer.backupPath)/"romfs/mod.bin")=="NEWER-OPERATION"&&!fs::exists(fs::path(newer.backupPath).parent_path()/"restored"),"restoring older operation does not consume newer backup");
    auto idempotent=nc::restoreExistingAt(game(),older.transactionId);
    require(idempotent.ok&&idempotent.count==0&&idempotent.transactionId==older.transactionId&&read(active/title()/"romfs/mod.bin")=="OLDER-OPERATION","exact already-restored token is idempotent after full destination check");
    require(read(fs::path(newer.backupPath)/"romfs/mod.bin")=="NEWER-OPERATION"&&!fs::exists(fs::path(newer.backupPath).parent_path()/"restored"),"idempotent old restoration never consumes newer pending backup");
    {std::ofstream out(fs::path(older.backupPath).parent_path()/"restored",std::ios::binary);out<<"invalid marker";}
    require(!nc::restoreExistingAt(game(),older.transactionId).ok&&read(active/title()/"romfs/mod.bin")=="OLDER-OPERATION","already-restored exact token requires a valid completion marker");
    {std::ofstream out(fs::path(older.backupPath).parent_path()/"restored",std::ios::binary);out<<"NMEC1\n";}
    require(!nc::restoreExistingAt(game(),newer.transactionId).ok&&read(active/title()/"romfs/mod.bin")=="OLDER-OPERATION","exact token cannot overwrite content restored by another operation");
    fs::remove(active/title()/"romfs/mod.bin");
    require(!nc::restoreExistingAt(game(),older.transactionId).ok&&!fs::exists(active/title()/"romfs/mod.bin"),"already consumed exact token never falls back to another pending token");
    auto explicitNewer=nc::restoreExistingAt(game(),newer.transactionId);
    require(explicitNewer.ok&&read(active/title()/"romfs/mod.bin")=="NEWER-OPERATION","pending newer token remains restorable explicitly");
    auto another=game();++another.id;
    require(!nc::restoreExistingAt(another,newer.transactionId).ok&&!fs::exists(active/"atmosphere/contents/01007300020FA001"),"transaction token cannot escape selected Title ID prefix");

    fresh();file(title()+"/romfs/mod.bin","EXACT-TARGET");
    retired=nc::retireExisting(inspect());require(retired.ok&&nc::restoreExistingAt(game(),retired.transactionId).ok,"restore fixture for interrupted acknowledgement");
    fs::remove(fs::path(retired.backupPath).parent_path()/"restored");
    auto interrupted=nc::restoreExistingAt(game(),retired.transactionId);
    require(interrupted.ok&&interrupted.count==0&&read(active/title()/"romfs/mod.bin")=="EXACT-TARGET"&&read(fs::path(retired.backupPath).parent_path()/"restored")=="NMEC1\n","crash after folder rename before completion marker is recoverable by the exact token");
    file(title()+"/romfs/mod.bin","EXTERNALLY-CHANGED-TARGET");
    require(!nc::restoreExistingAt(game(),retired.transactionId).ok&&read(active/title()/"romfs/mod.bin")=="EXTERNALLY-CHANGED-TARGET","idempotent restoration refuses externally edited destination and preserves it");

    fresh();file(title()+"/romfs/mod.bin","VALIDATED-RECEIPT");
    retired=nc::retireExisting(inspect());require(retired.ok&&nc::restoreExistingAt(game(),retired.transactionId).ok,"restore fixture for acknowledgement receipt validation");
    {std::ofstream out(fs::path(retired.backupPath).parent_path()/"receipt.bin",std::ios::binary);out<<"corrupt";}
    require(!nc::restoreExistingAt(game(),retired.transactionId).ok&&read(active/title()/"romfs/mod.bin")=="VALIDATED-RECEIPT","idempotent completed token still validates its exact receipt and CRC");
#ifdef NC_EXISTING_INSTALL_INTEGRATION
    fresh();file(title()+"/romfs/original.bin","ORIGINAL-MOD");file(title()+"/cheats/old-build.txt","ORIGINAL-CHEATS");
    retired=nc::retireExisting(inspect());require(retired.ok,"integration: old mods and cheats retired");
    nc::Pack pack;pack.compatible=true;pack.game=game();pack.game.buildVerified=true;pack.game.buildId="0123456789ABCDEF";
    nc::Cheat cheat;cheat.name="Test FPS";cheat.source="Test";cheat.group="Test";cheat.selected=true;cheat.opcodes={0x04000000,0x100,0xD503201F};pack.cheats.push_back(cheat);
    auto installed=nc::installPack(pack);if(!installed.ok)std::cerr<<installed.message<<"\n";
    require(installed.ok&&fs::exists(active/title()/"cheats/0123456789ABCDEF.txt"),"integration: new cheats installed");
    auto undone=nc::restorePack(pack.game);if(!undone.ok)std::cerr<<undone.message<<"\n";
    require(undone.ok&&!inspect().exists&&fs::is_directory(active/title()/"cheats"),"integration: own cheats undone, empty cheats directory remains");
    auto original=nc::restoreExisting(pack.game);if(!original.ok)std::cerr<<original.message<<"\n";
    require(original.ok&&read(active/title()/"romfs/original.bin")=="ORIGINAL-MOD"&&read(active/title()/"cheats/old-build.txt")=="ORIGINAL-CHEATS","integration: complete original mods and cheats restored");
#endif
    std::cout<<"existing: "<<checks<<" inspection, backup and restoration checks passed\n";
}

#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "diagnostics.hpp"
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
fs::path base,current;unsigned scenarios=0,checks=0;
void check(bool v,const char*s){++checks;if(!v)throw std::runtime_error(s);}
#define CHECK(x) check((x),#x)
void next(){current=base/("case-"+std::to_string(++scenarios));fs::create_directory(current);CHECK(setenv("NC_DIAGNOSTICS_ROOT",current.generic_string().c_str(),1)==0);}
fs::path file(){return current/"config/NinMagicCheats/diagnostico-cheats.txt";}
std::string read(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
nc::Pack pack(){nc::Pack p;p.game.id=0x01006BB00C6F0000ULL;p.game.name="Zelda";p.game.version="1.0.0";p.game.buildVerified=p.game.running=true;p.game.buildId="909E904AF78AC1B8";p.game.fullBuildId=p.game.buildId+std::string(48,'0');p.liveChecked=p.liveHydrated=true;p.livePid=123;p.liveDetail="Motor: 1 entrada, 1 habilitada";nc::Cheat c;c.name="Hearts Press ZR";c.source="General";c.selected=true;c.liveState=nc::CheatState::Enabled;c.opcodes={0x80000200,0x01000000,0x01cc0764,0x50,0x20000000};p.cheats.push_back(c);return p;}
}
int main(){base=fs::temp_directory_path()/("ninmagic-diagnostics-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{
    fs::create_directory(base);auto p=pack();p.game.detail="CodeFS/main-open rc=0x00000202";p.detail="Fuente sin comprobar";
    next();nc::logCheatDiagnostic("search",p,"detail");auto first=read(file());CHECK(first.find("NINMAGIC-CHEATS-DIAGNOSTIC-V1")==0&&first.find("event=search")!=std::string::npos&&first.find("pid=123")!=std::string::npos&&first.find("909E904AF78AC1B8")!=std::string::npos&&first.find("state=enabled words=5 hash=")!=std::string::npos&&first.find("Hearts Press ZR")!=std::string::npos);CHECK(!fs::exists(current/"atmosphere"));nc::logCheatDiagnostic("exit",p);CHECK(read(file()).size()>first.size()&&read(file()).find("event=exit")!=std::string::npos);
    CHECK(first.find("build-detail=CodeFS/main-open rc=0x00000202")!=std::string::npos&&first.find("pack-detail=Fuente sin comprobar")!=std::string::npos);
    next();auto longPack=p;longPack.game.name="Injected\nBEGIN event=fake";longPack.game.detail="stage\nBEGIN event=forged";longPack.detail=std::string(100000,'p');longPack.liveDetail=std::string(100000,'d');for(unsigned i=0;i<500;++i){auto c=p.cheats[0];c.name=std::string(10000,'n');longPack.cheats.push_back(c);}nc::logCheatDiagnostic("apply\nforged",longPack,std::string(100000,'x'));auto text=read(file());CHECK(text.size()<=128*1024&&text.find("name=Injected BEGIN event=fake")!=std::string::npos&&text.find("event=apply forged")!=std::string::npos&&text.find("\nBEGIN event=fake")==std::string::npos);const auto countAt=text.find("codes-reported=");CHECK(countAt!=std::string::npos);const auto count=std::stoul(text.substr(countAt+15));CHECK(count>0&&count<=128&&text.find("omitted="+std::to_string(longPack.cheats.size()-count))!=std::string::npos);CHECK(text.find("\nBEGIN event=forged")==std::string::npos&&text.find(std::string(4097,'p'))==std::string::npos);
    next();nc::logCheatDiagnostic("first",p);first=read(file());for(unsigned i=0;i<200;++i)nc::logCheatDiagnostic("many",p,std::string(4096,'x'));text=read(file());CHECK(text.size()<=128*1024&&text.find("NINMAGIC-CHEATS-DIAGNOSTIC-V1")==0&&text.find("event=many")!=std::string::npos&&text.find("event=first")==std::string::npos);
    next();put(file(),"user notes");nc::logCheatDiagnostic("ignored",p);CHECK(read(file())=="user notes");
    next();put(current/"config","ordinary file");nc::logCheatDiagnostic("ignored",p);CHECK(read(current/"config")=="ordinary file"&&!fs::exists(file()));
    next();fs::create_directories(file());nc::logCheatDiagnostic("ignored",p);CHECK(fs::is_directory(file()));
    next();const auto outside=current/"outside.txt";put(outside,"keep");fs::create_directories(file().parent_path());fs::create_symlink(outside,file());CHECK(fs::is_symlink(file()));nc::logCheatDiagnostic("ignored",p);CHECK(read(outside)=="keep"&&fs::is_symlink(file()));
    next();const auto outsideDir=current/"outside";fs::create_directory(outsideDir);fs::create_directory(current/"config");fs::create_directory_symlink(outsideDir,current/"config/NinMagicCheats");CHECK(fs::is_symlink(current/"config/NinMagicCheats"));nc::logCheatDiagnostic("ignored",p);CHECK(fs::is_empty(outsideDir));
    const auto resolved=fs::weakly_canonical(base),parent=fs::weakly_canonical(fs::temp_directory_path());CHECK(resolved.parent_path()==parent&&resolved.filename().string().find("ninmagic-diagnostics-test-")==0);fs::remove_all(resolved);std::cout<<"diagnostics: "<<scenarios<<" bounded logging and filesystem scenarios passed ("<<checks<<" checks)\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<"\nFixtures retained: "<<base<<'\n';return 1;}}

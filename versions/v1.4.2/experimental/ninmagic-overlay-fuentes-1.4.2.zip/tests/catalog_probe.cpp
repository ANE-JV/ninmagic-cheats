// Host integration check against the downloaded original public ZIP archives.
#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <iostream>

int main(int argc,char **argv) {
    if(argc!=2)return 2;
    setenv("NC_CATALOG_ROOT",argv[1],1);
    nc::Catalog catalog;std::string error;
    if(!nc::loadSlot('a',catalog,error,true)){std::cerr<<error<<"\n";return 1;}
    unsigned good=0,bad=0,cheatCount=0;
    for(const auto &entry:catalog.entries) {
        unzFile zip=unzOpen64(entry.archive.c_str());std::string text;
        bool ok=zip&&unzLocateFile(zip,entry.path.c_str(),1)==UNZ_OK&&nc::currentFile(zip,text,error);
        if(zip)unzClose(zip);
        std::vector<nc::Cheat> cheats;if(ok)ok=nc::parseCheats(text,entry.source,cheats,error);
        if(ok){++good;cheatCount+=unsigned(cheats.size());}
        else {if(bad<12)std::cerr<<entry.source<<" "<<nc::hexId(entry.titleId)<<"/"<<entry.buildId<<": "<<error<<"\n";++bad;}
    }
    std::cout<<"Real catalog: "<<catalog.entries.size()<<" exact identity files; "<<good<<" parsed; "<<bad<<" rejected; "<<cheatCount<<" cheats\n";
    return 0;
}

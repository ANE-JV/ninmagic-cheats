"""Create only synthetic cheat ZIPs in the explicitly supplied test directory."""
from pathlib import Path
import sys
import zipfile

base = Path(sys.argv[1])
base.mkdir(parents=True, exist_ok=True)
member = "contents/01007300020FA000/cheats/4B159F0F7A360669.txt"
text = b"[Good]\n04000000 00000000 D503201F\n"


def archive(path, members):
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_STORED) as output:
        for name in members:
            output.writestr(name, text)


slot = base / "cache" / "catalog-a"
archive(slot / "general.zip", [member])
archive(slot / "graphics.zip", ["repo-main/" + member.replace("contents/", "titles/")])
(slot / "complete.txt").write_text("NINMAGIC-CATALOG-1\n2026-10-26 00:00 UTC\n", encoding="ascii")
(base / "cache" / "active.txt").write_text("a\n", encoding="ascii")
archive(base / "duplicate.zip", [member, "repo/" + member])
archive(base / "crc.zip", [member])
bad = (base / "crc.zip").read_bytes().replace(b"D503201F", b"D503201E", 1)
(base / "crc.zip").write_bytes(bad)
archive(base / "empty.zip", [])
archive(base / "traversal.zip", ["../" + member])
archive(base / "new.zip", [member.replace("4B159F0F7A360669", "4B159F0F7A360670")])

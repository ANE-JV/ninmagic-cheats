// Compile this translation unit alone: including the production source gives
// direct coverage of its private ZIP/path validation without test hooks in NRO.
#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <minizip/zip.h>
namespace {
unsigned checks=0;
void require(bool ok,const char *message) {++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
void manualZip(const std::string &path,const std::vector<std::pair<std::string,std::string>> &files){zipFile z=zipOpen64(path.c_str(),APPEND_STATUS_CREATE);require(z,"create synthetic manual archive");for(const auto &item:files){zip_fileinfo meta{};meta.external_fa=0100644u<<16;require(zipOpenNewFileInZip64(z,item.first.c_str(),&meta,nullptr,0,nullptr,0,nullptr,0,0,0)==ZIP_OK,"open synthetic manual member");require(zipWriteInFileInZip(z,item.second.data(),unsigned(item.second.size()))==ZIP_OK&&zipCloseFileInZip(z)==ZIP_OK,"write synthetic manual member");}require(zipClose(z,nullptr)==ZIP_OK,"close synthetic manual archive");}
}
int main(int argc,char **argv) {
    require(argc==2||argc==3,"fixture directory and optional private import argument");
    std::filesystem::path base=std::filesystem::absolute(argv[1]);
    std::string dir=(base/"cache").generic_string();setenv("NC_CATALOG_ROOT",dir.c_str(),1);
    uint64_t title=0;std::string build;
    require(nc::memberIdentity("contents/01007300020FA000/cheats/4B159F0F7A360669.txt",title,build)&&title==0x01007300020FA000ULL,"release ZIP path");
    require(nc::memberIdentity("repo-main/titles/01007300020fa000/cheats/4b159f0f7a360669.TXT",title,build)&&build=="4B159F0F7A360669","source ZIP case canonicalization");
    for(const std::string path:{"/contents/01007300020FA000/cheats/4B159F0F7A360669.txt","../titles/01007300020FA000/cheats/4B159F0F7A360669.txt","contents/01007300020FA000/../4B159F0F7A360669.txt","C:/contents/01007300020FA000/cheats/4B159F0F7A360669.txt","titles\\01007300020FA000\\cheats\\4B159F0F7A360669.txt","titles/0100000000000001/cheats/4B159F0F7A360669.txt","titles/01007300020FA000/cheats/0000000000000000.txt","titles/01007300020FA000/cheats/4B159F0F7A36066Z.txt","titles/01007300020FA000/cheats/4B159F0F7A360669.bin","titles/01007300020FA000/cheats/4B159F0F7A360669.txt/evil"})require(!nc::memberIdentity(path,title,build),"reject unsafe or unrelated ZIP member");
    require(nc::safeUrl("https://example.com/cheats.zip?key=value"),"valid HTTPS mirror");
    for(const std::string url:{"http://example.com/a.zip","file:///tmp/a.zip","https://u:p@example.com/a.zip","https://example.com/a.zip\n","https://example.com\\a.zip","https:///a.zip"})require(!nc::safeUrl(url),"reject invalid URL");
    nc::Catalog catalog;std::string error;
    if(!nc::loadSlot('a',catalog,error))std::cerr<<"Slot error: "<<error<<"\n";
    bool loaded=nc::loadCatalog(catalog,error);
    if(!loaded)std::cerr<<"Cache error: "<<error<<" Root: "<<dir<<"\n";
    require(loaded&&catalog.entries.size()==1,"load general cheats offline and ignore legacy graphics archive");
    require(catalog.generalReady&&!catalog.graphicsReady&&catalog.stamp=="2026-10-26 00:00 UTC","general source and timestamp without graphics provider");
    nc::Game game;game.id=0x01007300020FA000ULL;game.buildId="4B159F0F7A360669";game.buildVerified=true;
    auto pack=nc::findCheats(game,catalog);
    require(pack.compatible&&pack.cheats.size()==1,"exact BID from general source");
    std::filesystem::remove(base/"cache"/"catalog-a"/"graphics.zip");
    require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==1,"graphics archive is not required at all");
    game.buildVerified=false;pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.cheats.empty()&&pack.availableBuilds.size()==1,"unverified BID cannot apply");
    game.buildVerified=true;game.buildId="4B159F0F7A360660";pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.cheats.empty()&&pack.availableBuilds.size()==1,"other game version not substituted");
    game.id=0x01007300020FA001ULL;pack=nc::findCheats(game,catalog);
    require(!pack.compatible&&pack.availableBuilds.empty(),"other Title ID not substituted");
    std::vector<nc::CatalogEntry> entries;
    require(!nc::indexArchive((base/"duplicate.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"duplicate identity rejected");
    error.clear();require(!nc::indexArchive((base/"crc.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"CRC error rejected before cache commit");
    error.clear();require(!nc::indexArchive((base/"empty.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"empty catalog rejected");
    error.clear();require(!nc::indexArchive((base/"traversal.zip").generic_string(),"test",entries,error,true)&&entries.empty(),"traversal-only ZIP rejected");
    // Invalid active slot must fall back to the untouched complete slot.
    std::filesystem::create_directories(base/"cache"/"catalog-b");
    std::filesystem::copy_file(base/"cache"/"catalog-a"/"complete.txt",base/"cache"/"catalog-b"/"complete.txt",std::filesystem::copy_options::overwrite_existing);
    std::ofstream(base/"cache"/"active.txt")<<"b\n";
    error.clear();require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==1&&error.empty(),"half-downloaded update never replaces previous general cache");
    std::ofstream(base/"cache"/"sources.ini")<<"general_url=http://bad.example/x.zip\n";
    std::string general,graphics;
    require(!nc::sourceUrls(general,graphics,error),"HTTP config rejected");
    std::ofstream(base/"cache"/"sources.ini")<<"general_url=https://mirror.example/general.zip\ngraphics_url=https://mirror.example/graphics.zip\n";
    error.clear();require(nc::sourceUrls(general,graphics,error)&&general=="https://mirror.example/general.zip"&&graphics.empty(),"general HTTPS mirror works and obsolete graphics setting is ignored");
    // Simulate HTTPS without a network, exercising the real merge and cache
    // commit code. A failed second source must not acknowledge new releases.
    std::filesystem::remove(base/"cache"/"sources.ini");
    std::ofstream(base/"cache"/"active.txt")<<"a\n";
    const std::string localPath=dir+"/manual-cheats.zip",localMember="contents/01007300020FA002/cheats/4B159F0F7A360671.txt",localText="[Synthetic local option]\n04000000 00000000 D503201F\n",credit="Unique synthetic attribution body\n";
    manualZip(localPath,{{localMember,localText},{"FUENTE.txt",credit}});
    error.clear();require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==2&&error.empty(),"valid local import augments official cache");
    nc::Game localGame;localGame.id=0x01007300020FA002ULL;localGame.buildId="4B159F0F7A360671";localGame.buildVerified=true;
    auto localPack=nc::findCheats(localGame,catalog);
    require(localPack.compatible&&localPack.cheats.size()==1&&localPack.cheats[0].source=="Importacion local"&&localPack.cheats[0].opcodes==std::vector<uint32_t>({0x04000000,0,0xD503201F}),"production parser preserves exact local opcode words");
    localGame.buildId="4B159F0F7A360672";require(!nc::findCheats(localGame,catalog).compatible,"local import refuses a different Build ID");
    manualZip(localPath,{{localMember,localText},{"contents/01007300020FA002/cheats/4B159F0F7A360672.txt","[Invalid]\nNOT AN OPCODE\n"}});
    error.clear();require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==1&&error.empty()&&catalog.detail.find("omitida")!=std::string::npos,"malformed manual cheat omits the whole import without invalidating official cache");
    manualZip(localPath,{{localMember,localText},{"FUENTE.txt",credit}});
    std::string bytes;require(nc::readSmall(localPath,bytes,size_t(nc::MaxArchive)),"read synthetic import for CRC fault injection");auto at=bytes.find(credit);require(at!=std::string::npos,"find synthetic credit payload");bytes[at]^=1;require(nc::writeSmall(localPath,bytes),"damage only synthetic attribution CRC");
    error.clear();require(nc::loadCatalog(catalog,error)&&catalog.entries.size()==1&&catalog.detail.find("omitida")!=std::string::npos,"credit member CRC also gates whole import");
    manualZip(localPath,{{localMember,localText},{"FUENTE.txt",credit}});std::string unchangedImport;require(nc::readSmall(localPath,unchangedImport,size_t(nc::MaxArchive)),"record imported archive before sync");
    nc::CheatRelease oldRelease;oldRelease.id=1;oldRelease.tag="old";oldRelease.published="2026-01-01T00:00:00Z";
    nc::ReleaseAsset asset;asset.id=10;asset.size=std::filesystem::file_size(base/"new.zip");asset.name="contents_complete.zip";asset.updated="2026-10-26T00:00:00Z";asset.url="https://github.com/HamletDuFromage/switch-cheats-db/releases/download/new/contents_complete.zip";
    nc::CheatRelease newRelease;newRelease.id=2;newRelease.tag="new";newRelease.published="2026-10-26T00:00:00Z";newRelease.assets={asset};
    const auto jsonRelease=[](const nc::CheatRelease &r){std::string s="{\"id\":"+std::to_string(r.id)+",\"tag_name\":\""+r.tag+"\",\"published_at\":\""+r.published+"\",\"draft\":false,\"assets\":[";for(size_t i=0;i<r.assets.size();++i){if(i)s+=",";const auto &a=r.assets[i];s+="{\"id\":"+std::to_string(a.id)+",\"size\":"+std::to_string(a.size)+",\"name\":\""+a.name+"\",\"browser_download_url\":\""+a.url+"\",\"updated_at\":\""+a.updated+"\",\"digest\":null}";}return s+"]}";};
    nc::SeenMap manifest;manifest[oldRelease.id]={oldRelease.published,nc::cheatReleaseSignature(oldRelease)};
    require(nc::writeSmall(dir+"/catalog-a/releases-seen.txt",nc::seenText(manifest)),"write historical baseline fixture");
    nc::RemoteStamp remote{"\"unchanged\"","Mon, 26 Oct 2026 00:00:00 GMT","123"};
    std::string published="["+jsonRelease(oldRelease)+"]";unsigned zipGets=0;bool failGeneral=false;
    nc::testNetworkReady=true;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &failure,nc::RemoteStamp *stamp,bool head){
        if(stamp)*stamp=remote;
        if(head)return true;
        if(url.rfind("https://api.github.com/",0)==0)return nc::writeSmall(path,published);
        ++zipGets;
        require(url.find("codeload")==std::string::npos&&url.find("graphics")==std::string::npos,"no retired graphics network request");
        if(failGeneral){failure="synthetic interrupted HTTPS";return false;}
        const auto input=base/"new.zip";
        std::filesystem::copy_file(input,path,std::filesystem::copy_options::overwrite_existing);return true;
    };
    error.clear();require(nc::refreshCatalog(catalog,false,error)&&zipGets==0&&nc::activeSlot()=='a',"unchanged release signatures and HEAD skip ZIP downloads");
    published="["+jsonRelease(oldRelease)+","+jsonRelease(newRelease)+"]";
    failGeneral=true;error.clear();require(!nc::refreshCatalog(catalog,true,error)&&nc::activeSlot()=='a',"interrupted source preserves active cache");
    nc::SeenMap afterFailure;require(nc::readSeen(dir+"/catalog-a/releases-seen.txt",afterFailure)&&afterFailure.size()==1,"failed commit does not acknowledge new publication");
    failGeneral=false;error.clear();require(nc::refreshCatalog(catalog,false,error)&&nc::activeSlot()=='b',"new release commits atomically after successful validated merge");
    require(catalog.entries.size()==3,"new merge retains older BID and local import");
    require(nc::readSmall(localPath,bytes,size_t(nc::MaxArchive))&&bytes==unchangedImport,"synchronization preserves local archive byte for byte");
    nc::SeenMap afterSuccess;require(nc::readSeen(dir+"/catalog-b/releases-seen.txt",afterSuccess)&&afterSuccess.size()==2,"seen release advances only inside committed slot");
    unsigned previousGets=zipGets;error.clear();require(nc::refreshCatalog(catalog,false,error)&&zipGets==previousGets,"second launch rechecks metadata without fetching unchanged ZIPs");
    std::string pendingJson="["+jsonRelease(oldRelease)+","+jsonRelease(newRelease);
    for(unsigned i=3;i<=12;++i){auto nextRelease=newRelease;nextRelease.id=i;nextRelease.published="2026-10-27T00:00:00Z";pendingJson+=","+jsonRelease(nextRelease);}published=pendingJson+"]";
    error.clear();require(!nc::refreshCatalog(catalog,false,error)&&error.find("pendientes")!=std::string::npos,"bounded batch reports unfinished release history honestly");
    nc::SeenMap partial;require(nc::readSeen(dir+"/catalog-a/releases-seen.txt",partial)&&partial.size()==10,"bounded commit acknowledges downloaded releases only");
    nc::testTransfer={};nc::testNetworkReady=false;
    if(argc==3){std::filesystem::copy_file(argv[2],localPath,std::filesystem::copy_options::overwrite_existing);error.clear();require(nc::loadCatalog(catalog,error),"load optional private archive with production parser");unsigned imports=0;for(const auto &entry:catalog.entries)if(entry.archive==localPath){++imports;nc::Game exact;exact.id=entry.titleId;exact.buildId=entry.buildId;exact.buildVerified=true;const auto found=nc::findCheats(exact,catalog);require(found.compatible&&!found.cheats.empty(),"optional private archive has parseable exact-BID definitions");exact.buildId.back()=exact.buildId.back()=='0'?'1':'0';require(!nc::findCheats(exact,catalog).compatible,"optional private archive cannot substitute another BID");}require(imports==1,"optional private archive contains one exact identity");}
    std::cout<<"catalog: "<<checks<<" ZIP, cache and compatibility checks passed\n";
}

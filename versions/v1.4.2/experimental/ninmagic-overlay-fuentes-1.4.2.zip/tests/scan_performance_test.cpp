#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#define NC_SCAN_PERFORMANCE_TEST
#include "scan_performance.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <unistd.h>

namespace fs=std::filesystem;
namespace {
unsigned scenarios=0,checks=0,statsReads=0;
nc::ScanReadStats nativeStats;
nc::ScanCoreStats coreStats;
fs::path sandbox,current,privateRoot;
void require(bool value,const char*text){++checks;if(!value)throw std::runtime_error(text);}
#define CHECK(x) require((x),#x)
struct Json {
    enum Kind {Object,String,Number,Boolean} kind=Object;
    std::string scalar;std::map<std::string,Json> fields;
    const Json&at(const std::string&key)const{return fields.at(key);}
};
// Independent parser for the object/scalar subset used by this report. It
// rejects duplicate keys, trailing data and malformed JSON numbers/strings.
class Parser {
    const std::string &text;size_t at=0;
    void ws(){while(at<text.size()&&(text[at]==' '||text[at]=='\r'||text[at]=='\n'||text[at]=='\t'))++at;}
    bool take(char c){ws();if(at<text.size()&&text[at]==c){++at;return true;}return false;}
    std::string string(){if(!take('"'))throw std::runtime_error("JSON string expected");std::string out;while(at<text.size()){const unsigned char c=text[at++];if(c=='"')return out;if(c<32||c=='\\')throw std::runtime_error("invalid report string");out+=char(c);}throw std::runtime_error("unterminated JSON string");}
    Json value(){ws();if(at==text.size())throw std::runtime_error("missing JSON value");Json out;
        if(take('{')){out.kind=Json::Object;if(take('}'))return out;for(;;){const auto key=string();if(!take(':'))throw std::runtime_error("missing JSON colon");if(!out.fields.emplace(key,value()).second)throw std::runtime_error("duplicate JSON key");if(take('}'))return out;if(!take(','))throw std::runtime_error("missing JSON comma");}}
        if(text[at]=='"'){out.kind=Json::String;out.scalar=string();return out;}
        for(const char*word:{"true","false"}){const std::string token=word;if(text.compare(at,token.size(),token)==0){at+=token.size();out.kind=Json::Boolean;out.scalar=token;return out;}}
        const auto start=at;while(at<text.size()&&text[at]>='0'&&text[at]<='9')++at;if(start==at||(at-start>1&&text[start]=='0'))throw std::runtime_error("invalid report number");out.kind=Json::Number;out.scalar=text.substr(start,at-start);return out;
    }
public:explicit Parser(const std::string&s):text(s){}Json parse(){auto result=value();ws();if(at!=text.size())throw std::runtime_error("trailing JSON data");return result;}
};
void next(bool directory=true){current=sandbox/("case-"+std::to_string(++scenarios));fs::create_directory(current);privateRoot=current/"private";if(directory)fs::create_directory(privateRoot);CHECK(setenv("NC_SCAN_PERFORMANCE_ROOT",privateRoot.generic_string().c_str(),1)==0);nativeStats={};coreStats={};statsReads=0;}
fs::path report(bool overlay=true){return privateRoot/(overlay?"scan-performance-overlay.json":"scan-performance-nro.json");}
std::string read(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void write(const fs::path&p,const std::string&text){std::ofstream f(p,std::ios::binary);f<<text;CHECK(bool(f));}
void shape(const std::string&text){CHECK(!text.empty()&&text.size()<3072);const auto json=Parser(text).parse();CHECK(json.kind==Json::Object&&json.fields.size()==7);CHECK(json.at("schema").scalar=="1"&&json.at("version").kind==Json::String);CHECK(json.at("elapsed_ms").kind==Json::Number&&json.at("ok").kind==Json::Boolean);CHECK(json.at("native").fields.size()==18&&json.at("core").fields.size()==10);
    const std::set<std::string> nativeKeys={"completed_reads","completed_bytes","metadata_calls","metadata_failures","metadata_ns","full_proof_calls","full_proof_failures","full_proof_ns","query_calls","query_failures","query_ns","read_calls","read_failures","attempted_read_bytes","read_ns","checked_calls","checked_failures","checked_ns"};
    const std::set<std::string> coreKeys={"snapshot_read_bytes","snapshot_write_bytes","mask_read_bytes","mask_write_bytes","records_read_bytes","records_write_bytes","read_calls","write_calls","io_ns","comparison_ns"};
    for(const auto&entry:json.at("native").fields)CHECK(nativeKeys.count(entry.first)&&entry.second.kind==Json::Number);
    for(const auto&entry:json.at("core").fields)CHECK(coreKeys.count(entry.first)&&entry.second.kind==Json::Number);
    for(const char*privateField:{"pid","title","build","address","value","name","error","detail"})CHECK(text.find(std::string("\"")+privateField+"\"")==std::string::npos);
}
}
namespace nc {
ScanReadStats scanReadStats(){++statsReads;return nativeStats;}
const ScanCoreStats&scanCoreStats(){return coreStats;}
}
int main(){sandbox=fs::temp_directory_path()/("ninmagic-scan-performance-"+std::to_string(getpid())+"-"+std::to_string(nc::scanClockNs()));try{
    fs::create_directory(sandbox);
    next();{const auto text=nc::scanPerformanceJson(true,true,12,{},{});shape(text);const auto json=Parser(text).parse();CHECK(json.at("operation").scalar=="initial"&&json.at("ok").scalar=="true"&&json.at("elapsed_ms").scalar=="12");}
    next();{nc::ScanReadStats r;nc::ScanCoreStats c;r.completedReads=r.completedBytes=r.metadataCalls=r.metadataFailures=r.metadataNs=r.fullProofCalls=r.fullProofFailures=r.fullProofNs=r.queryCalls=r.queryFailures=r.queryNs=r.readCalls=r.readFailures=r.attemptedReadBytes=r.readNs=r.checkedCalls=r.checkedFailures=r.checkedNs=UINT64_MAX;c.snapshotReadBytes=c.snapshotWriteBytes=c.maskReadBytes=c.maskWriteBytes=c.recordsReadBytes=c.recordsWriteBytes=c.readCalls=c.writeCalls=c.ioNs=c.comparisonNs=UINT64_MAX;const auto text=nc::scanPerformanceJson(false,false,UINT64_MAX,r,c);shape(text);const auto json=Parser(text).parse();CHECK(json.at("operation").scalar=="comparison"&&json.at("ok").scalar=="false"&&json.at("elapsed_ms").scalar=="18446744073709551615");for(const auto&v:json.at("native").fields)CHECK(v.second.scalar=="18446744073709551615");for(const auto&v:json.at("core").fields)CHECK(v.second.scalar=="18446744073709551615");}
    next();{nativeStats.metadataNs=9;nativeStats.fullProofNs=8;nativeStats.queryNs=7;nativeStats.readNs=6;nativeStats.checkedNs=2;const auto text=nc::scanPerformanceJson(false,true,1,nativeStats,{});const auto json=Parser(text).parse();CHECK(json.at("native").at("checked_ns").scalar=="2"&&json.at("native").at("metadata_ns").scalar=="9");}
    next();{nativeStats.completedBytes=262144;coreStats.recordsReadBytes=123;CHECK(nc::saveScanPerformance(nc::ScanReportClient::Overlay,false,true,45));const auto text=read(report());shape(text);const auto json=Parser(text).parse();CHECK(json.at("native").at("completed_bytes").scalar=="262144"&&json.at("core").at("records_read_bytes").scalar=="123"&&statsReads==1);CHECK(!fs::exists(report().string()+".pending")&&!fs::exists(report(false)));CHECK(nc::saveScanPerformance(nc::ScanReportClient::Nro,true,false,67));CHECK(Parser(read(report(false))).parse().at("operation").scalar=="initial"&&read(report())==text&&statsReads==2);write(report(),std::string(10000,'x'));CHECK(nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,89)&&read(report()).size()<3072&&statsReads==3);}
    next(false);CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&!fs::exists(privateRoot)&&statsReads==0);
    next(false);write(privateRoot,"keep");CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&read(privateRoot)=="keep"&&statsReads==0);
    next();CHECK(!nc::saveScanPerformance(static_cast<nc::ScanReportClient>(55),true,true,0)&&fs::is_empty(privateRoot)&&statsReads==0);
    next();CHECK(setenv("NC_SCAN_PERFORMANCE_ROOT","",1)==0);CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&fs::is_empty(privateRoot)&&statsReads==0);
    next(false);{const auto outside=current/"outside";fs::create_directory(outside);fs::create_directory_symlink(outside,privateRoot);CHECK(fs::is_symlink(privateRoot));CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&fs::is_empty(outside)&&statsReads==0);}
    for(bool pending:{false,true}){next();const auto outside=current/"outside.txt";write(outside,"keep");const auto target=fs::path(report().string()+(pending?".pending":""));fs::create_symlink(outside,target);CHECK(fs::is_symlink(target));CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&read(outside)=="keep"&&fs::is_symlink(target)&&statsReads==0);}
    for(bool pending:{false,true}){next();const auto target=fs::path(report().string()+(pending?".pending":""));fs::create_directory(target);if(pending)write(report(),"previous");CHECK(!nc::saveScanPerformance(nc::ScanReportClient::Overlay,true,true,0)&&fs::is_directory(target)&&statsReads==0);if(pending)CHECK(read(report())=="previous");}
    next();{const auto start=nc::scanClockNs();CHECK(nc::scanElapsedMs(start)<1000&&nc::scanElapsedMs(UINT64_MAX)==0);}
    const auto resolved=fs::weakly_canonical(sandbox);CHECK(resolved.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&resolved.filename().string().find("ninmagic-scan-performance-")==0);fs::remove_all(resolved);std::cout<<"scan performance: "<<scenarios<<" sanitized JSON and fixed-path scenarios PASS ("<<checks<<" checks)\n";return 0;
}catch(const std::exception&error){std::cerr<<"FAIL: "<<error.what()<<"\nFixtures retained: "<<sandbox<<'\n';return 1;}}

#include "controller.hpp"
#include "platform.hpp"
#include "published_cache.hpp"
#include "live_receipt.hpp"
#include "cheats.hpp"
#include "catalog.hpp"
#include "https_lite.hpp"
#include "switch.h"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <iostream>
#include <stdexcept>
namespace {
std::atomic<unsigned> checks{0};
void require(bool b,const char*s){++checks;if(!b)throw std::runtime_error(s);}
#define CHECK(x) require((x),#x)
std::atomic<unsigned> starts{0},stops{0},generation{0},applies{0},removes{0},engineReads{0},applyGeneration{0},removeGeneration{0},receiptDiskReads{0};
std::atomic<unsigned> queries{0},saves{0};
std::atomic<bool> nativeOpen{false},platformContext{false},catalogOpen{false},tlsOpen{false};
bool missing=false,empty=false,preflightReject=false,failApply=false,failRemove=false,unsaved=false,own=false,running=true;
bool unverified=false,saveFails=false,failInitOnce=false;unsigned gameVariant=0;
enum class QueryMode {Success,Empty,Partial,Fail,WaitCancel,ChangeGame,WrongIdentity};
QueryMode queryMode=QueryMode::Success;
uint64_t cacheVersion=1;
nc::Game game(){nc::Game g;g.id=0x01006BB00C6F0000ULL;g.name="Published host fixture";g.buildId="909E904AF78AC1B8";g.fullBuildId=g.buildId+std::string(48,'0');if(gameVariant)g.fullBuildId.back()='1';g.running=running;g.buildVerified=!unverified;if(unverified){g.buildId.clear();g.fullBuildId.clear();}return g;}
nc::Pack cached,captured;std::vector<std::string> enabled;
nc::Pack fixture(size_t regular=2){nc::Pack p;p.game=game();p.compatible=true;nc::Cheat master;master.name="Master";master.master=true;master.source="General";master.group="g";master.opcodes={0x40000000,0,0};p.cheats.push_back(master);for(size_t i=0;i<regular;++i){nc::Cheat c;c.name="Infinite option "+std::to_string(i);c.source="General";c.group="g";c.opcodes={0x01000000,uint32_t(0x100+i),9};p.cheats.push_back(c);}return p;}
void idle(){const auto limit=std::chrono::steady_clock::now()+std::chrono::seconds(5);while(nc::overlay::snapshot().busy){if(std::chrono::steady_clock::now()>limit)throw std::runtime_error("worker timeout");std::this_thread::sleep_for(std::chrono::milliseconds(1));}}
}
namespace nc {
bool platformInit(Environment&,std::string&e){CHECK(!catalogOpen&&!tlsOpen);e.clear();++starts;++generation;platformContext=true;if(failInitOnce){failInitOnce=false;nativeOpen=false;e="native reopen failed";return false;}nativeOpen=true;return true;}
void platformExit(){if(platformContext.exchange(false))++stops;nativeOpen=false;if(unsaved)own=false;}
bool hasLiveOwnership(const Game&g){return own&&g.id==0x01006BB00C6F0000ULL&&g.buildId=="909E904AF78AC1B8";}
bool detectRunningGame(Game&out,Environment&,std::string&e){e.clear();out=game();if(!out.running){e="No game running";return false;}return true;}
bool loadPublishedCache(const Game&g,Pack&out,std::string&e,uint64_t*stamp){e.clear();if(missing||g.id!=cached.game.id||g.fullBuildId!=cached.game.fullBuildId){e="No exact prepared cache";return false;}out=cached;out.game=g;if(empty){out.compatible=false;out.cheats.clear();}for(auto&c:out.cheats){c.selected=false;c.liveState=CheatState::Unknown;}if(stamp)*stamp=cacheVersion;return true;}
bool savePublishedCache(const Pack&p,std::string&e){++saves;CHECK(nativeOpen&&!catalogOpen&&!tlsOpen);e.clear();if(saveFails){e="cache save blocked";return false;}cached=p;missing=false;empty=!p.compatible;++cacheVersion;return true;}
bool findPublishedGameDirect(const Game&g,bool force,Pack&out,std::vector<CheatSourceReport>&reports,std::string&e,const std::function<bool()>&cancelled){CHECK(force&&!nativeOpen);const auto view=overlay::snapshot();CHECK(view.searching&&view.busy&&!view.ready&&view.items.empty());catalogOpen=tlsOpen=true;++queries;out=fixture();out.game=g;for(auto&c:out.cheats)if(!c.master)c.name="Online "+c.name;CheatSourceReport report;report.source="Online fixture";report.checked=true;report.found=true;report.httpStatus=200;reports={report};e.clear();if(queryMode==QueryMode::WaitCancel){const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(4);while(!cancelled()){if(std::chrono::steady_clock::now()>deadline)throw std::runtime_error("cancel timeout");std::this_thread::sleep_for(std::chrono::milliseconds(1));}e="query cancelled";return false;}if(queryMode==QueryMode::Fail){out.cheats.clear();out.compatible=false;e="network unavailable";return false;}if(queryMode==QueryMode::Empty){out.cheats.clear();out.compatible=false;reports.front().found=false;reports.front().httpStatus=404;}if(queryMode==QueryMode::Partial){reports.front().checked=false;e="one source unavailable";return false;}if(queryMode==QueryMode::ChangeGame)gameVariant=1;if(queryMode==QueryMode::WrongIdentity)out.game.fullBuildId.back()='1';return true;}
void logSourceReports(const Game&,const std::vector<CheatSourceReport>&,const std::string&){}
void catalogExit(){catalogOpen=false;}
namespace https_lite {void shutdown(){tlsOpen=false;}}
bool checkPublishedCache(const Game&,uint64_t stamp,std::string&e){e.clear();if(stamp!=cacheVersion||missing){e="cache changed";return false;}return true;}
bool readLiveState(Pack&p,std::string&e){++engineReads;e.clear();p.liveChecked=true;for(auto&c:p.cheats){const bool on=std::find(enabled.begin(),enabled.end(),c.name)!=enabled.end();c.liveState=on?CheatState::Enabled:CheatState::NotLoaded;if(!p.liveHydrated)c.selected=on;}p.liveHydrated=true;return true;}
Outcome applyLive(const Pack&p){++applies;Outcome o;if(preflightReject){o.message="preflight rejected";return o;}captured=p;applyGeneration=generation.load();own=true;unsaved=failApply;o.ok=!failApply;o.liveEffect=LiveEffect::Enabled;o.message=failApply?"ENOSPC after activation":"published enabled";std::vector<Cheat>selected;std::string error;if(!selectedCheats(p,selected,error))throw std::runtime_error(error);for(auto&c:selected)if(std::find(enabled.begin(),enabled.end(),c.name)==enabled.end())enabled.push_back(c.name);return o;}
Outcome removeLive(const Game&){++removes;removeGeneration=generation.load();Outcome o;if(!own){o.ok=true;o.liveEffect=LiveEffect::NoOwned;o.message="no own codes";return o;}o.ok=!failRemove;o.liveEffect=failRemove?LiveEffect::Uncertain:LiveEffect::Removed;o.message=failRemove?"undo uncertain":"own codes removed";if(o.ok){own=false;unsaved=false;enabled.clear();}return o;}
namespace native {bool loadLiveReceipt(LiveReceipt&r,std::string&e){++receiptDiskReads;e.clear();r={};if(unsaved){e="partial receipt";return false;}if(own){r.valid=true;r.title=game().id;r.buildId=game().buildId;r.changes.resize(1);}return true;}}
}
int main(){try{cached=fixture();std::string error;
    CHECK(nc::overlay::init(error));idle();auto s=nc::overlay::snapshot();CHECK(s.ready&&s.cacheAvailable&&s.totalItems==2&&s.items.size()==2&&s.selectedCount==0&&!s.canApply&&applies==0&&removes==0);CHECK(s.items[0].name=="Infinite option 0"&&!s.items[0].selected);
    const auto reads=engineReads.load();CHECK(nc::overlay::toggle(0));idle();s=nc::overlay::snapshot();CHECK(s.selectedCount==1&&s.canApply&&engineReads==reads&&applies==0&&s.selectedNames.size()==1);CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().selectedCount==0&&applies==0);
    // Neutral undo never creates dirty ownership or a false historical error.
    CHECK(nc::overlay::remove());idle();s=nc::overlay::snapshot();CHECK(!s.lastActionKnown&&!s.ownActive&&s.error.empty());
    CHECK(nc::overlay::toggle(0));idle();++cacheVersion;const auto beforeStale=applies.load();CHECK(nc::overlay::apply());idle();CHECK(applies==beforeStale&&!nc::overlay::snapshot().lastActionOk);const auto staleMessage=nc::overlay::snapshot().lastAction;CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().lastAction==staleMessage);
    CHECK(nc::overlay::toggle(0));idle();CHECK(nc::overlay::toggle(1));idle();CHECK(nc::overlay::apply());idle();s=nc::overlay::snapshot();CHECK(s.lastActionOk&&s.ownActive&&s.liveChecked&&applies==1&&!captured.sessionOnly&&captured.sessionBinding.pid==0);std::vector<nc::Cheat>chosen;CHECK(nc::selectedCheats(captured,chosen,error)&&chosen.size()==3&&chosen[0].master);const auto action=s.lastAction;
    CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().lastAction==action&&nc::overlay::snapshot().selectedCount==2&&applies==1);
    // Clearing a draft checkbox is not permission to disable a live code.
    CHECK(nc::overlay::toggle(0));idle();CHECK(nc::overlay::apply());idle();CHECK(enabled.size()==3&&nc::overlay::snapshot().selectedCount==1);
    CHECK(nc::overlay::remove());idle();s=nc::overlay::snapshot();CHECK(s.lastActionOk&&s.lastActionRemove&&!s.ownActive&&enabled.empty());const auto removedMessage=s.lastAction;CHECK(nc::overlay::remove());idle();CHECK(nc::overlay::snapshot().lastAction==removedMessage&&nc::overlay::snapshot().error.empty());
    CHECK(nc::overlay::toggle(0));idle();preflightReject=true;const auto removeBefore=removes.load();CHECK(nc::overlay::apply());idle();CHECK(removes==removeBefore&&!nc::overlay::snapshot().ownActive);preflightReject=false;
    // A failed SD receipt after activation must undo in the same native
    // generation. If undo is ambiguous, no refresh/apply may discard RAM.
    failApply=failRemove=true;CHECK(nc::overlay::apply());idle();s=nc::overlay::snapshot();CHECK(s.ownActive&&!s.canApply&&applyGeneration==removeGeneration);const auto dirtyGeneration=generation.load(),dirtyApplies=applies.load();const auto dirtyQueries=queries.load();CHECK(nc::overlay::search());idle();CHECK(queries==dirtyQueries&&generation==dirtyGeneration&&nc::overlay::snapshot().ownActive);CHECK(nc::overlay::refresh());idle();CHECK(generation==dirtyGeneration&&nc::overlay::snapshot().ownActive);CHECK(nc::overlay::apply());idle();CHECK(applies==dirtyApplies&&generation==dirtyGeneration);failRemove=false;CHECK(nc::overlay::remove());idle();CHECK(!nc::overlay::snapshot().ownActive&&removeGeneration==dirtyGeneration);failApply=false;
    // Empty cache is a valid last NRO query; missing cache asks for NRO and
    // cannot be presented as proof that no published codes exist.
    empty=true;CHECK(nc::overlay::refresh());idle();s=nc::overlay::snapshot();CHECK(s.cacheAvailable&&!s.ready&&!s.totalItems&&!s.canApply&&s.error.empty());empty=false;missing=true;CHECK(nc::overlay::refresh());idle();s=nc::overlay::snapshot();CHECK(!s.cacheAvailable&&!s.ready&&!s.error.empty()&&s.error.find("X busca")!=std::string::npos);missing=false;
    running=false;CHECK(nc::overlay::refresh());idle();s=nc::overlay::snapshot();CHECK(!s.game.running&&!s.cacheAvailable&&!s.canApply&&!s.error.empty());running=true;
    cached=fixture(14);CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().items.size()==8&&nc::overlay::snapshot().totalItems==14);CHECK(nc::overlay::move(9));idle();s=nc::overlay::snapshot();CHECK(s.highlighted==9&&s.firstItem==8&&s.items.size()==6&&s.items[0].index==8);CHECK(nc::overlay::toggle(1000));idle();CHECK(!nc::overlay::snapshot().error.empty()&&applies==dirtyApplies);
    // X is the only online operation. The worker drops the old Pack and native
    // services before transport, closes transport before reconnecting, and
    // never invokes apply/remove as part of a query.
    const auto onlineApplies=applies.load(),onlineRemoves=removes.load(),initialQueries=queries.load();const auto historicalAction=nc::overlay::snapshot().lastAction;
    missing=true;queryMode=QueryMode::Success;CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(queries==initialQueries+1&&s.ready&&s.cacheAvailable&&!s.searching&&s.totalItems==2&&s.selectedCount==0&&s.items[0].name.find("Online")==0&&s.error.empty());CHECK(!catalogOpen&&!tlsOpen&&nativeOpen&&s.lastAction==historicalAction&&applies==onlineApplies&&removes==onlineRemoves);
    const auto firstOnlineVersion=cacheVersion;const auto firstOnlineSaves=saves.load();queryMode=QueryMode::Fail;CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(s.ready&&s.cacheAvailable&&!s.error.empty()&&cacheVersion==firstOnlineVersion&&saves==firstOnlineSaves&&s.items[0].name.find("Online")==0);
    queryMode=QueryMode::WaitCancel;const auto beforeCancelQueries=queries.load();CHECK(nc::overlay::search());const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(3);while(queries==beforeCancelQueries){if(std::chrono::steady_clock::now()>deadline)throw std::runtime_error("query did not start");std::this_thread::sleep_for(std::chrono::milliseconds(1));}CHECK(nc::overlay::snapshot().searching&&nc::overlay::snapshot().busy);nc::overlay::cancel();idle();s=nc::overlay::snapshot();CHECK(s.ready&&s.cacheAvailable&&!s.searching&&s.error.find("cancelada")!=std::string::npos&&cacheVersion==firstOnlineVersion&&saves==firstOnlineSaves&&!catalogOpen&&!tlsOpen);
    queryMode=QueryMode::Partial;CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(s.ready&&!s.error.empty()&&cacheVersion==firstOnlineVersion+1&&saves==firstOnlineSaves+1);
    const auto beforeWrongVersion=cacheVersion;const auto beforeWrongSaves=saves.load();queryMode=QueryMode::WrongIdentity;CHECK(nc::overlay::search());idle();CHECK(nc::overlay::snapshot().ready&&!nc::overlay::snapshot().error.empty()&&cacheVersion==beforeWrongVersion&&saves==beforeWrongSaves);
    queryMode=QueryMode::ChangeGame;CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(!s.ready&&!s.cacheAvailable&&s.game.fullBuildId.back()=='1'&&s.error.find("cambió")!=std::string::npos&&cacheVersion==beforeWrongVersion&&saves==beforeWrongSaves);gameVariant=0;CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().ready);
    unverified=true;const auto beforeUnverified=queries.load();CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(!s.game.buildVerified&&!s.ready&&!s.error.empty()&&queries==beforeUnverified&&saves==beforeWrongSaves);unverified=false;CHECK(nc::overlay::refresh());idle();
    queryMode=QueryMode::Success;saveFails=true;CHECK(nc::overlay::search());idle();CHECK(nc::overlay::snapshot().ready&&nc::overlay::snapshot().error.find("save blocked")!=std::string::npos&&cacheVersion==beforeWrongVersion);saveFails=false;
    queryMode=QueryMode::Empty;CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(s.cacheAvailable&&!s.ready&&!s.totalItems&&s.error.empty()&&!s.searching&&empty);
    missing=true;queryMode=QueryMode::Fail;const auto beforeMissingSaves=saves.load();CHECK(nc::overlay::search());idle();s=nc::overlay::snapshot();CHECK(!s.cacheAvailable&&!s.ready&&!s.error.empty()&&saves==beforeMissingSaves);
    missing=false;empty=false;cached=fixture();queryMode=QueryMode::Success;failInitOnce=true;const auto beforeReopenVersion=cacheVersion;CHECK(nc::overlay::search());idle();CHECK(!nc::overlay::snapshot().initialized&&!nc::overlay::snapshot().ready&&cacheVersion==beforeReopenVersion&&!catalogOpen&&!tlsOpen);CHECK(nc::overlay::search());idle();CHECK(nc::overlay::snapshot().initialized&&nc::overlay::snapshot().ready&&cacheVersion==beforeReopenVersion+1);
    CHECK(applies==onlineApplies&&removes==onlineRemoves&&nc::overlay::snapshot().lastAction==historicalAction);
    cached=fixture(14);CHECK(nc::overlay::refresh());idle();
    CHECK(nc::overlay::toggle(9));idle();failApply=failRemove=true;CHECK(nc::overlay::apply());idle();CHECK(nc::overlay::snapshot().ownActive);const auto beforeShutdown=removes.load(),beforeShutdownGeneration=generation.load();nc::overlay::shutdown();CHECK(removes==beforeShutdown+1&&removeGeneration==beforeShutdownGeneration);CHECK(mockSmOpen==mockSmClose&&mockSdOpen==mockSdClose&&starts==stops);
    // Unloading during transport synchronously cancels and joins; it must not
    // reconnect, publish a new cache, or run an activation after the join.
    failApply=failRemove=unsaved=own=false;cached=fixture();queryMode=QueryMode::WaitCancel;CHECK(nc::overlay::init(error));idle();const auto shutdownQueries=queries.load(),shutdownSaves=saves.load(),shutdownApplies=applies.load();CHECK(nc::overlay::search());const auto shutdownDeadline=std::chrono::steady_clock::now()+std::chrono::seconds(3);while(queries==shutdownQueries){if(std::chrono::steady_clock::now()>shutdownDeadline)throw std::runtime_error("shutdown query did not start");std::this_thread::sleep_for(std::chrono::milliseconds(1));}nc::overlay::shutdown();CHECK(saves==shutdownSaves&&applies==shutdownApplies&&!catalogOpen&&!tlsOpen&&!nativeOpen&&!nc::overlay::snapshot().initialized);CHECK(mockSmOpen==mockSmClose&&mockSdOpen==mockSdClose&&starts==stops);
    CHECK(receiptDiskReads==0);std::cout<<"published overlay controller: "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception&e){nc::overlay::shutdown();std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}

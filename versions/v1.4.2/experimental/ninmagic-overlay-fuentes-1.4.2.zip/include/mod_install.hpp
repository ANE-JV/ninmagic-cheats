#pragma once
#include "model.hpp"
namespace nc {
struct PatchEntry {
    // Canonical path relative to sdmc:, always under atmosphere/exefs_patches.
    std::string path;
    uint64_t size=0;
    int64_t modified=0;
    uint32_t crc=0;
    std::vector<uint8_t> data;
};
struct PatchInventory { Game game;std::vector<PatchEntry> entries;bool valid=false; };
bool inspectPatches(const Game &game,PatchInventory &inventory,std::string &error);
bool samePatchInventory(const PatchInventory &a,const PatchInventory &b);
Outcome installMod(const Game &game,const ModPayload &payload,const PatchInventory &previous,bool retirePrevious,const std::string &previousContent={});
Outcome removeMods(const Game &game);
// Complete only after the exact associated title-content recovery has succeeded.
Outcome ackModRecovery(const Game &game,const std::string &transactionId);
// Independent transaction type for the Cheats flow; never uninstalls a newer mod.
Outcome retirePatches(const PatchInventory &previous);
Outcome restoreRetiredPatches(const Game &game);
// Restores only the exact retirement associated with the action being undone.
Outcome restoreRetiredPatchesAt(const Game &game,const std::string &transactionId);
}

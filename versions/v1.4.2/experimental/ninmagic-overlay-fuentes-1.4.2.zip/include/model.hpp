#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "scanner.hpp"
#include "app_update.hpp"

namespace nc {
constexpr unsigned General=1, Fps=2, Resolution=4, Graphics=8;
enum class CheatState { Unknown, NotLoaded, Disabled, Enabled };
struct Game {
    uint64_t id=0;
    std::string name, author, version, buildId, fullBuildId, detail;
    uint32_t contentVersion=0;
    bool versionKnown=false, buildVerified=false, running=false, sd=false, nand=false, card=false;
};
struct Cheat {
    std::string name, source, group;
    std::vector<uint32_t> opcodes;
    unsigned categories=General;
    bool master=false, selected=false;
    CheatState liveState=CheatState::Unknown;
};
struct CatalogEntry {
    uint64_t titleId=0;
    std::string buildId, source, path, archive;
};
struct Catalog {
    std::vector<CatalogEntry> entries;
    std::string stamp, detail;
    bool generalReady=false, graphicsReady=false;
};
struct Pack {
    Game game;
    std::vector<Cheat> cheats;
    std::vector<std::string> availableBuilds;
    std::string detail;
    bool compatible=false;
    bool liveChecked=false, liveHydrated=false;
    uint64_t livePid=0;
    std::string liveDetail;
    // Scanner experiments are valid only for this exact process and layout.
    bool sessionOnly=false;
    ScanIdentity sessionBinding;
};
struct Environment {
    std::string firmware, atmosphere, detail;
    bool applet=false, dmnt=false, network=false;
    uint64_t runningTitle=0;
    std::string runningBuild;
};
// Explicit engine/ownership result; UI text is never used to decide whether
// an in-memory activation receipt must be retained.
enum class LiveEffect { Unchanged, NoOwned, Enabled, Removed, Uncertain };
struct Outcome {
    bool ok=false, live=false;
    LiveEffect liveEffect=LiveEffect::Unchanged;
    std::string message, backupPath;
    // Private eight-digit receipt IDs. They bind recovery to the exact action
    // being undone rather than whichever backup happens to be newest.
    std::string transactionId, previousContent, previousPatches;
    unsigned count=0;
};
struct ExistingEntry {
    std::string path;
    uint64_t size=0;
    int64_t modified=0;
    bool directory=false;
};
struct ExistingContent {
    Game game;
    bool valid=false, exists=false, cheats=false, mods=false;
    unsigned files=0, directories=0, activeCheats=0, externalPatches=0;
    uint64_t bytes=0;
    std::vector<ExistingEntry> entries;
};
enum class ModFormat { Pchtxt, Ips, Romfs, Archive, Unsupported };
struct ModEntry {
    uint64_t titleId=0, size=0;
    std::string name, path, blobSha, revision, buildId, detail, repository, source;
    ModFormat format=ModFormat::Unsupported;
    bool selected=false;
};
struct ModsCatalog {
    std::vector<ModEntry> entries;
    std::string revision, stamp, detail;
    bool ready=false;
};
struct ModPayload {
    Game game;
    ModEntry entry;
    std::string buildId, detail;
    std::vector<uint8_t> ips;
    std::vector<std::string> names;
    bool compatible=false;
};
enum class Screen { Loading, Library, GameOptions, Cheats, Mods, ModConfirm, Confirm, Existing, Busy, Result, Help, ScanSetup, ScanResults, ScanConfirm, AppUpdate };
struct View {
    Screen screen=Screen::Loading;
    Environment env;
    Catalog catalog;
    std::vector<Game> games;
    Pack pack;
    Outcome outcome;
    ExistingContent existing;
    ModsCatalog modsCatalog;
    std::vector<ModEntry> mods;
    ModPayload modPayload;
    std::vector<ModPayload> modPayloads;
    int selected=0, cheatSelected=0, filter=0, returnScreen=0;
    int existingChoice=0;
    int modSelected=0, modReviewOffset=0;
    bool restore=false, liveRequested=false, removeMod=false, modRequested=false;
    uint64_t frame=0;
    std::string status="Detectando juegos instalados...";
    ScanSession scan;
    std::string scanValue="100",scanDetail;
    ScanCompare scanCompare=ScanCompare::Changed;
    int scanSelected=0,scanPurpose=0;
    bool scanUnknown=true,scanConfirmStart=true;
    AppUpdateInfo appUpdate;
    std::string appUpdateDetail;
};
inline std::string hexId(uint64_t id) {
    char s[17]; const char *h="0123456789ABCDEF";
    for(int i=15;i>=0;--i) {s[i]=h[id&15];id>>=4;} s[16]=0;return s;
}
inline unsigned selectedCount(const Pack &p) {
    unsigned n=0;for(const auto &c:p.cheats)if(c.selected&&!c.master)++n;return n;
}
}

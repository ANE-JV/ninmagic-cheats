#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>

namespace nc {
struct TitleLanguage {
    std::string name,author;
    bool nameValid=false,authorValid=false;
};
struct TitleMetadata {
    std::array<TitleLanguage,32> languages;
    unsigned languageCount=0;
    int selectedLanguage=-1,authorLanguage=-1;
    std::string name,author,version;
    bool compressed=false,titleValid=false,authorValid=false,versionValid=false;
};
// Parses the first 0x4000 bytes of control.nacp without depending on the SDK's
// NacpStruct layout. Format 1 (FW21+) contains raw DEFLATE language entries.
// preferredLanguage is the NACP index (Spanish=6, Latin American Spanish=5),
// not the SetLanguage enum. Invalid/empty entries fall back to valid entries.
// false indicates malformed/unsupported structural metadata. A separately
// validated display version remains available even if language decoding fails.
// true may have titleValid=false; the caller should then display the Title ID.
bool parseTitleMetadata(const void *nacp,size_t size,TitleMetadata &out,std::string &error,int preferredLanguage=-1);
}

#pragma once
#include "model.hpp"
namespace nc {
// Inspects only atmosphere/contents/<the exact selected user Title ID>.
// exists means that the tree contains at least one regular file.
bool inspectExisting(const Game &game,ExistingContent &content,std::string &error);
// Caller must refresh game.running before invoking. The full snapshot is checked
// again before the exact Title ID folder is renamed into a durable backup.
Outcome retireExisting(const ExistingContent &content);
// Restores the newest un-restored whole-folder backup only when the destination
// is absent or contains only empty directories. Never merges over new files.
Outcome restoreExisting(const Game &game);
// Restore only the explicitly linked 8-digit transaction under this game's own
// backup folder. No search for a different or newer transaction is permitted.
// Retrying an already restored token succeeds only after its receipt, completion
// marker and current destination metadata inventory have been verified again.
Outcome restoreExistingAt(const Game &game,const std::string &transactionId);
}

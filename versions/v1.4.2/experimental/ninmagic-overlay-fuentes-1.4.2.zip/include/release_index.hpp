#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace nc {
struct ReleaseAsset {uint64_t id=0,size=0;std::string name,url,updated,digest;};
struct CheatRelease {uint64_t id=0;std::string tag,published;std::vector<ReleaseAsset> assets;};
bool parseCheatReleases(const std::string &json,std::vector<CheatRelease> &releases,std::string &error);
std::string cheatReleaseSignature(const CheatRelease &release);
}

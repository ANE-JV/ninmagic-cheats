#pragma once
#include <cstdint>
#include <functional>
#include <string>
namespace nc::https_lite {
struct Response {long status=0;std::string etag,modified,length,finalUrl;uint64_t bytes=0;};
// Worker only. HTTPS only, verified CA/host/date, at most five redirects.
// GET streams to a regular temporary file; the caller promotes verified data.
// Status is retained on HTTP failures (including 404). No game memory access.
// Firmware >=16: Horizon SSL, TLS 1.2/1.3, 10-second I/O timeout.
// Cancellation is checked between IPC calls; in-flight DNS cannot be cancelled.
// The output must be caller-owned scratch inside the app's private SD cache.
// Each response has <=32 KiB headers, <=64 MiB decoded body, and five redirects.
bool download(const std::string&url,const std::string&path,Response&,std::string&error,bool head=false,uint64_t maxBytes=64ULL*1024*1024,const std::function<bool()>&cancelled={});
void shutdown();
}

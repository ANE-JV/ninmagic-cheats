#pragma once
#include "model.hpp"
#include <algorithm>

namespace nc {
inline bool sameModEntry(const ModEntry &a,const ModEntry &b) {
    return a.titleId==b.titleId&&a.repository==b.repository&&a.path==b.path&&a.blobSha==b.blobSha;
}
inline bool modBelongsToGame(const ModPayload &p,const Game &game) {
    return p.compatible&&game.buildVerified&&game.fullBuildId.size()==64&&p.game.id==game.id&&p.entry.titleId==game.id&&p.game.buildId==game.buildId&&p.game.fullBuildId==game.fullBuildId&&p.buildId==game.fullBuildId;
}
inline bool selectPreparedMod(std::vector<ModEntry> &entries,std::vector<ModPayload> &selection,const Game &game,const ModPayload &payload,std::string &error) {
    error.clear();
    if(!modBelongsToGame(payload,game)){error="El mod preparado no coincide con el juego y Build ID actuales.";return false;}
    auto entry=std::find_if(entries.begin(),entries.end(),[&](const ModEntry &e){return sameModEntry(e,payload.entry);});
    if(entry==entries.end()){error="El mod ya no aparece con ese archivo en el catálogo. Vuelve a comprobarlo.";return false;}
    auto existing=std::find_if(selection.begin(),selection.end(),[&](const ModPayload &p){return sameModEntry(p.entry,payload.entry);});
    if(existing==selection.end()) {
        if(selection.size()>=32){error="Puedes seleccionar hasta 32 mods en una instalación.";return false;}
        size_t bytes=payload.ips.size();
        for(const auto &p:selection)bytes+=p.ips.size();
        if(payload.ips.empty()||bytes>2*1024*1024){error="La selección de parches supera el límite de 2 MiB. Desmarca algún mod antes de añadir otro.";return false;}
        selection.push_back(payload);
    }
    entry->selected=true;return true;
}
inline void unselectMod(std::vector<ModEntry> &entries,std::vector<ModPayload> &selection,const ModEntry &target) {
    for(auto &e:entries)if(sameModEntry(e,target))e.selected=false;
    selection.erase(std::remove_if(selection.begin(),selection.end(),[&](const ModPayload &p){return sameModEntry(p.entry,target);}),selection.end());
}
// A refreshed index keeps only the exact verified source blobs for this game.
inline unsigned refreshModSelection(std::vector<ModEntry> &entries,std::vector<ModPayload> &selection,const Game &game) {
    const auto before=selection.size();for(auto &e:entries)e.selected=false;
    selection.erase(std::remove_if(selection.begin(),selection.end(),[&](const ModPayload &p){
        return !modBelongsToGame(p,game)||std::none_of(entries.begin(),entries.end(),[&](const ModEntry &e){return sameModEntry(e,p.entry);});
    }),selection.end());
    for(auto &e:entries)e.selected=std::any_of(selection.begin(),selection.end(),[&](const ModPayload &p){return sameModEntry(e,p.entry);});
    return static_cast<unsigned>(before-selection.size());
}
}

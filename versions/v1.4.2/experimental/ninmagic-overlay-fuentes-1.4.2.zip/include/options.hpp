#pragma once
#include "model.hpp"
namespace nc {
// Display helpers only: never change original names, selection or cheat code.
std::string cheatLabel(const Cheat &cheat);
std::string explainCheat(const Cheat &cheat);
// Effects explicitly named by this pack's actual cheat options. Mod filenames
// never establish an effect or version match; they add only "Mods publicados".
std::vector<std::string> optionEffects(const Pack &pack,const std::vector<ModEntry> &mods);
}

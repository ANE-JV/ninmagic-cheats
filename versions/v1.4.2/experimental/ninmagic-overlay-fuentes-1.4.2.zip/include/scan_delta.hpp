#pragma once
#include <cstddef>
#include <cstdint>
namespace nc::scan_delta {
inline size_t encode(uint32_t value,uint8_t out[5]){size_t n=0;do{const auto byte=uint8_t(value&127u);value>>=7;out[n++]=uint8_t(byte|(value?128u:0u));}while(value);return n;}
// Canonical unsigned LEB128, at most five bytes. No wrapped index is accepted.
struct Decoder {
    uint32_t value=0;unsigned bytes=0;bool done=false;
    bool put(uint8_t byte){if(done||bytes>=5||(bytes==4&&(byte&240u)))return false;value|=uint32_t(byte&127u)<<(7*bytes);++bytes;if(!(byte&128u)){if(bytes>1&&!(byte&127u))return false;done=true;}return true;}
};
inline bool advance(uint32_t previous,uint32_t delta,bool first,uint32_t &next){if(!first&&!delta)return false;if(first){next=delta;return true;}if(delta>UINT32_MAX-previous)return false;next=previous+delta;return true;}
}

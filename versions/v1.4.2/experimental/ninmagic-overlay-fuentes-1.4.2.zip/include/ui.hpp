#pragma once
#include "model.hpp"
namespace nc {
bool uiInit(const std::string &assetRoot);
void uiDraw(uint32_t *pixels,int stride,const View &view);
void uiExit();
}

#pragma once
#include "model.hpp"
namespace nc {
bool parseCheats(const std::string &text,const std::string &source,std::vector<Cheat> &cheats,std::string &error);
unsigned classifyCheat(const std::string &name);
bool validBuild(const std::string &build);
bool selectedCheats(const Pack &pack,std::vector<Cheat> &selected,std::string &error);
bool validateWriteConflicts(const std::vector<Cheat> &cheats,std::string &error);
std::string selectedText(const Pack &pack,std::string &error);
// Read-only exact Title ID / Build ID check; a missing component is normal.
bool inspectInstalledCheats(const Game &game,bool &exists,std::string &error);
Outcome installPack(const Pack &pack,const std::string &previousContent={},const std::string &previousPatches={});
Outcome restorePack(const Game &game);
bool finishPackRecovery(const Game &game,const std::string &transactionId,std::string &error);
}

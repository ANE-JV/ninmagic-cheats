#pragma once
#include <cstdint>

namespace nc {
// Progress can count bytes or candidates. Bound cooperative pauses by callback
// count and elapsed time instead of assuming that every callback is 64 KiB.
class ScanYieldPolicy {
    bool started=false;
    uint64_t lastDone=0,lastTotal=0,lastYieldNs=0;
    unsigned callbacks=0;
public:
    bool shouldYield(uint64_t done,uint64_t total,uint64_t nowNs){
        if(!started||!done||done<lastDone||total!=lastTotal||nowNs<lastYieldNs){
            started=true;lastDone=done;lastTotal=total;lastYieldNs=nowNs;callbacks=0;return false;
        }
        lastDone=done;
        if(++callbacks<16&&nowNs-lastYieldNs<16000000ULL)return false;
        callbacks=0;lastYieldNs=nowNs;return true;
    }
};
}

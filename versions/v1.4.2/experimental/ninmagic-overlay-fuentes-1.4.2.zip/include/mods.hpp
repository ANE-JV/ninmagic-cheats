#pragma once
#include "model.hpp"
namespace nc {
bool loadModsCatalog(ModsCatalog &catalog,std::string &error);
bool syncModsCatalog(ModsCatalog &catalog,std::string &error);
std::vector<ModEntry> findMods(const Game &game,const ModsCatalog &catalog);
bool prepareMod(const Game &game,const ModEntry &entry,ModPayload &payload,std::string &error);
// Portable parser and validation used by preparation and host tests.
bool parseModsTree(const std::string &json,ModsCatalog &catalog,std::string &error,const std::string &repository="ADEMOLA200/Switch-Emulator-Mod-Database");
bool parseModPayload(const Game &game,const ModEntry &entry,const std::string &bytes,ModPayload &payload,std::string &error);
bool validateModIps(const std::vector<uint8_t> &ips,std::string &error);
// Pure, portable merge of already verified static patches. No SD or network IO.
bool combineMods(const Game &game,const std::vector<ModPayload> &payloads,ModPayload &combined,std::string &error);
}

#pragma once
#include <string>
#include <vector>
namespace nc {
// Creates a new canonical ZIP. Later inputs replace the same exact TID/BID key.
// Existing output files and every input are left untouched on rejection.
bool mergeCheatArchives(const std::vector<std::string> &oldestToNewestPaths,const std::string &output,std::string &error);
}

#pragma once
#include "platform_internal.hpp"
namespace nc::native {
bool loadLiveReceipt(LiveReceipt &receipt,std::string &error);
bool saveLiveReceipt(const LiveReceipt &receipt,std::string &error);
bool clearLiveReceipt(std::string &error);
#ifdef NC_LIVE_RECEIPT_TEST
void setLiveReceiptTestRoot(const std::string &root);
#endif
}

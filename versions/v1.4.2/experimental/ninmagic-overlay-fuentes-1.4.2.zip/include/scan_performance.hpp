#pragma once
#include "platform.hpp"
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <sys/stat.h>

namespace nc {
inline uint64_t scanClockNs(){return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());}
inline uint64_t scanElapsedMs(uint64_t start){const auto now=scanClockNs();return now>=start?(now-start)/1000000:0;}
// Local performance data only: no PID, title, addresses, values, or user text.
// checkedNs includes the native subphases; these numbers must not be added.
inline std::string scanPerformanceJson(bool initial,bool ok,uint64_t elapsedMs,const ScanReadStats&r,const ScanCoreStats&c){
    char output[3072]{};
    const auto n=std::snprintf(output,sizeof(output),
        "{\n\"schema\":1,\"version\":\"1.3.9\",\"operation\":\"%s\",\"ok\":%s,\"elapsed_ms\":%llu,\n"
        "\"native\":{\"completed_reads\":%llu,\"completed_bytes\":%llu,\"metadata_calls\":%llu,\"metadata_failures\":%llu,\"metadata_ns\":%llu,\"full_proof_calls\":%llu,\"full_proof_failures\":%llu,\"full_proof_ns\":%llu,\"query_calls\":%llu,\"query_failures\":%llu,\"query_ns\":%llu,\"read_calls\":%llu,\"read_failures\":%llu,\"attempted_read_bytes\":%llu,\"read_ns\":%llu,\"checked_calls\":%llu,\"checked_failures\":%llu,\"checked_ns\":%llu},\n"
        "\"core\":{\"snapshot_read_bytes\":%llu,\"snapshot_write_bytes\":%llu,\"mask_read_bytes\":%llu,\"mask_write_bytes\":%llu,\"records_read_bytes\":%llu,\"records_write_bytes\":%llu,\"read_calls\":%llu,\"write_calls\":%llu,\"io_ns\":%llu,\"comparison_ns\":%llu}\n}\n",
        initial?"initial":"comparison",ok?"true":"false",static_cast<unsigned long long>(elapsedMs),
        static_cast<unsigned long long>(r.completedReads),static_cast<unsigned long long>(r.completedBytes),
        static_cast<unsigned long long>(r.metadataCalls),static_cast<unsigned long long>(r.metadataFailures),static_cast<unsigned long long>(r.metadataNs),
        static_cast<unsigned long long>(r.fullProofCalls),static_cast<unsigned long long>(r.fullProofFailures),static_cast<unsigned long long>(r.fullProofNs),
        static_cast<unsigned long long>(r.queryCalls),static_cast<unsigned long long>(r.queryFailures),static_cast<unsigned long long>(r.queryNs),
        static_cast<unsigned long long>(r.readCalls),static_cast<unsigned long long>(r.readFailures),static_cast<unsigned long long>(r.attemptedReadBytes),static_cast<unsigned long long>(r.readNs),
        static_cast<unsigned long long>(r.checkedCalls),static_cast<unsigned long long>(r.checkedFailures),static_cast<unsigned long long>(r.checkedNs),
        static_cast<unsigned long long>(c.snapshotReadBytes),static_cast<unsigned long long>(c.snapshotWriteBytes),static_cast<unsigned long long>(c.maskReadBytes),static_cast<unsigned long long>(c.maskWriteBytes),
        static_cast<unsigned long long>(c.recordsReadBytes),static_cast<unsigned long long>(c.recordsWriteBytes),static_cast<unsigned long long>(c.readCalls),static_cast<unsigned long long>(c.writeCalls),
        static_cast<unsigned long long>(c.ioNs),static_cast<unsigned long long>(c.comparisonNs));
    return n>0&&size_t(n)<sizeof(output)?std::string(output,size_t(n)):std::string{};
}
inline bool scanReportTarget(const std::string&path){struct stat st{};return lstat(path.c_str(),&st)!=0?errno==ENOENT:S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode);}
enum class ScanReportClient { Overlay, Nro };
inline std::string scanPerformanceRoot(){
#ifdef NC_SCAN_PERFORMANCE_TEST
    const char*root=std::getenv("NC_SCAN_PERFORMANCE_ROOT");return root?root:"";
#else
    return "sdmc:/config/NinMagicCheats";
#endif
}
inline bool scanReportDirectory(const std::string&path){struct stat st{};return lstat(path.c_str(),&st)==0&&S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);}
inline bool saveScanPerformance(ScanReportClient client,bool initial,bool ok,uint64_t elapsedMs){
    if(client!=ScanReportClient::Overlay&&client!=ScanReportClient::Nro)return false;
    const std::string root=scanPerformanceRoot();
    if(root.empty()||!scanReportDirectory(root))return false;
#ifndef NC_SCAN_PERFORMANCE_TEST
    if(!scanReportDirectory("sdmc:/config"))return false;
#endif
    const std::string target=root+(client==ScanReportClient::Overlay?"/scan-performance-overlay.json":"/scan-performance-nro.json"),pending=target+".pending";
    if(!scanReportTarget(target)||!scanReportTarget(pending))return false;
    const auto json=scanPerformanceJson(initial,ok,elapsedMs,scanReadStats(),scanCoreStats());if(json.empty())return false;
    FILE*f=std::fopen(pending.c_str(),"wb");if(!f)return false;
    bool written=std::fwrite(json.data(),1,json.size(),f)==json.size();if(std::fflush(f)!=0)written=false;if(std::fclose(f)!=0)written=false;
    if(!written){std::remove(pending.c_str());return false;}return std::rename(pending.c_str(),target.c_str())==0;
}
}

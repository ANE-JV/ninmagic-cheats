#pragma once
#include "model.hpp"
namespace nc {
// Best effort, bounded private text report. Never reads game memory or changes cheats.
void logCheatDiagnostic(const std::string &event,const Pack &pack,const std::string &detail={}) noexcept;
}

#pragma once
#include "model.hpp"
#include <array>

namespace nc::native {
// Wire layouts of Atmosphere's documented dmnt:cht service.
struct Definition { char name[0x40]{}; uint32_t count=0; uint32_t codes[0x100]{}; };
struct Entry { uint8_t enabled=0; uint8_t padding[3]{}; uint32_t id=0; Definition definition; };
struct Metadata {
    uint64_t pid=0, title=0;
    uint64_t mainBase=0,mainSize=0,heapBase=0,heapSize=0,aliasBase=0,aliasSize=0,aslrBase=0,aslrSize=0;
    uint8_t build[0x20]{};
};
static_assert(sizeof(Definition)==0x444,"dmnt cheat definition wire size");
static_assert(sizeof(Entry)==0x44C,"dmnt cheat entry wire size");
static_assert(sizeof(Metadata)==0x70,"dmnt metadata wire size");
struct Runtime {
    virtual ~Runtime()=default;
    virtual bool metadata(Metadata &value)=0;
    virtual bool entries(std::vector<Entry> &value)=0;
    virtual bool add(const Definition &value,uint32_t &id)=0;
    virtual bool remove(uint32_t id)=0;
    virtual bool toggle(uint32_t id)=0;
    virtual bool master(const Definition &value)=0;
};
struct LiveChange { uint32_t id=0; bool added=false; Definition definition; };
struct LiveReceipt {
    bool valid=false,masterAdded=false;
    uint64_t pid=0,title=0;
    std::string buildId;
    Definition master;
    std::vector<LiveChange> changes;
    std::vector<Entry> observed;
};
std::string buildString(const uint8_t *bytes);
bool readCheckedState(Pack &pack,Runtime &runtime,std::string &error);
Outcome applyChecked(const Pack &pack,Runtime &runtime,LiveReceipt *receipt=nullptr);
Outcome undoChecked(const Game &game,Runtime &runtime,LiveReceipt &receipt);
}

#pragma once
#include "scanner.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <limits>

namespace nc::native::scan {
// This is a client safety limit, not an Atmosphere IPC limit. Keep every read
// inside one freshly queried mapping; larger buffers belong on bounded heap.
constexpr size_t MaxRead=256*1024;
constexpr uint64_t MaxExtent=8ULL*1024*1024*1024;
constexpr uint64_t MaxAliasExtent=512ULL*1024*1024*1024;
struct Mapping {uint64_t address=0,size=0;uint32_t permission=0,type=0;};
inline bool span(uint64_t base,uint64_t size){return base&&size&&size<=MaxExtent&&size<=std::numeric_limits<uint64_t>::max()-base;}
inline bool aliasSpan(uint64_t base,uint64_t size){return base&&size&&size<=MaxAliasExtent&&size<=std::numeric_limits<uint64_t>::max()-base;}
inline bool contains(uint64_t base,uint64_t size,uint64_t address,uint64_t length){return span(base,size)&&length&&address>=base&&address-base<size&&length<=size-(address-base);}
inline bool containsAlias(const ScanIdentity&i,uint64_t address,uint64_t length){return aliasSpan(i.aliasBase,i.aliasSize)&&length&&address>=i.aliasBase&&address-i.aliasBase<i.aliasSize&&length<=i.aliasSize-(address-i.aliasBase);}
inline bool fullBuild(const std::string&s){return s.size()==64&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;})&&!std::all_of(s.begin(),s.begin()+16,[](char c){return c=='0';})&&!std::all_of(s.begin(),s.begin()+16,[](char c){return c=='F'||c=='f';});}
inline bool valid(const ScanIdentity&i){const bool alias=(!i.aliasBase&&!i.aliasSize)||(aliasSpan(i.aliasBase,i.aliasSize)&&(i.aliasBase+i.aliasSize<=i.mainBase||i.mainBase+i.mainSize<=i.aliasBase)&&(i.aliasBase+i.aliasSize<=i.heapBase||i.heapBase+i.heapSize<=i.aliasBase));return i.pid&&i.title>=0x0100000000010000ULL&&fullBuild(i.fullBuildId)&&span(i.mainBase,i.mainSize)&&span(i.heapBase,i.heapSize)&&(i.mainBase+i.mainSize<=i.heapBase||i.heapBase+i.heapSize<=i.mainBase)&&alias;}
inline bool same(const ScanIdentity&a,const ScanIdentity&b){return valid(a)&&valid(b)&&a.pid==b.pid&&a.title==b.title&&a.fullBuildId==b.fullBuildId&&a.mainBase==b.mainBase&&a.mainSize==b.mainSize&&a.heapBase==b.heapBase&&a.heapSize==b.heapSize&&a.aliasBase==b.aliasBase&&a.aliasSize==b.aliasSize;}
inline bool allowed(const ScanIdentity&i,uint64_t address,uint64_t length){return valid(i)&&(contains(i.mainBase,i.mainSize,address,length)||contains(i.heapBase,i.heapSize,address,length)||containsAlias(i,address,length));}
inline bool writable(const Mapping&m){return span(m.address,m.size)&&(m.permission&3u)==3u&&(m.permission&~3u)==0;}
inline bool aliasHeap(const Mapping&m){return writable(m)&&(m.type&0xffu)==5;}
inline bool readable(const ScanIdentity&i,const Mapping&m,uint64_t address,uint64_t length){return length<=MaxRead&&allowed(i,address,length)&&writable(m)&&contains(m.address,m.size,address,length)&&(!containsAlias(i,address,length)||aliasHeap(m));}
inline bool append(const ScanIdentity&i,const Mapping&m,std::vector<ScanRegion>&regions){
    if(!valid(i)||!writable(m))return false;
    const auto clip=[&](uint64_t base,uint64_t size){const auto begin=std::max(base,m.address),end=std::min(base+size,m.address+m.size);if(begin<end)regions.push_back({begin,end-begin,true});};
    clip(i.mainBase,i.mainSize);clip(i.heapBase,i.heapSize);if(aliasHeap(m)&&aliasSpan(i.aliasBase,i.aliasSize))clip(i.aliasBase,i.aliasSize);return true;
}
struct Access {
    virtual ~Access()=default;
    virtual bool verify(const ScanIdentity&,std::string&)=0;
    virtual bool query(uint64_t,Mapping&,std::string&)=0;
    virtual bool read(uint64_t,void*,size_t,std::string&)=0;
};
inline bool aliasStaticAddress(const ScanIdentity&identity,const uint32_t*codes,size_t count,uint64_t&address,size_t&size){
    address=0;size=0;if(!codes||count!=3||!valid(identity)||!aliasSpan(identity.aliasBase,identity.aliasSize))return false;
    const uint32_t first=codes[0],width=(first>>24)&15;
    if((first>>28)!=0||((first>>20)&15)!=2||(first&0x000FFF00u)||(width!=1&&width!=2&&width!=4)||(width<4&&codes[2]>=(uint32_t(1)<<(width*8))))return false;
    const uint64_t offset=(uint64_t(first&255)<<32)|codes[1];
    if(offset>=identity.aliasSize||width>identity.aliasSize-offset)return false;
    address=identity.aliasBase+offset;size=width;return true;
}
// Preflight for an explicitly requested experiment. This only checks metadata
// and mapping permissions/type: it neither reads values nor writes memory.
inline bool checkedAliasTarget(const ScanIdentity&identity,uint64_t address,size_t size,Access&access,std::string&error){
    error.clear();if(!valid(identity)||!containsAlias(identity,address,size)||(size!=1&&size!=2&&size!=4)){error="La prueba Alias no tiene un destino estático válido.";return false;}
    if(!access.verify(identity,error))return false;
    Mapping mapping;if(!access.query(address,mapping,error))return false;
    if(!readable(identity,mapping,address,size)||!aliasHeap(mapping)){error="La página Alias no es de tipo Heap con permiso exacto de lectura y escritura.";return false;}
    return access.verify(identity,error);
}
inline bool checkedRead(const ScanIdentity&identity,uint64_t address,void*buffer,size_t size,Access&access,std::string&error){
    error.clear();
    if(!buffer||!size||size>MaxRead){error="La lectura debe tener entre 1 byte y 256 KiB.";return false;}
    std::memset(buffer,0,size);
    if(!allowed(identity,address,size)){error="La lectura sale de las regiones MAIN/HEAP verificadas.";return false;}
    if(!access.verify(identity,error))return false;
    Mapping mapping;if(!access.query(address,mapping,error))return false;
    if(!readable(identity,mapping,address,size)){error="La página ya no es un bloque de datos MAIN/HEAP con lectura y escritura.";return false;}
    if(!access.verify(identity,error))return false;
    const bool read=access.read(address,buffer,size,error);
    // A successful identity check may clear its error argument. Keep a failed
    // read's diagnostic unless the final identity check itself fails.
    std::string verificationError;
    const bool same=access.verify(identity,verificationError);
    if(!same)error=verificationError;
    if(!read||!same){std::memset(buffer,0,size);return false;}
    return true;
}
}

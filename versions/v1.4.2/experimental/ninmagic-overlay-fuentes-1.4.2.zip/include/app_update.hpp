#pragma once
#include <cstdint>
#include <string>
namespace nc {
struct AppUpdateInfo {
    bool configured=false,available=false,prepared=false,installed=false;
    std::string version,url,sha256,detail;
    uint64_t size=0;
};
// Missing update-url.txt is an intentionally unconfigured state, not an error.
bool checkAppUpdate(AppUpdateInfo&,std::string &error);
// target must be exactly sdmc:/switch/ninmagic-cheats/ninmagic-cheats.nro.
bool prepareAppUpdate(AppUpdateInfo&,const std::string &target,std::string &error);
// Main must obtain explicit confirmation and call romfsExit before replacing
// its NRO. Success requires closing/reopening; no automatic relaunch occurs.
bool installPreparedAppUpdate(AppUpdateInfo&,const std::string &target,std::string &error);
// Call on startup before a new update. Retains immutable numbered backups.
bool recoverAppUpdate(const std::string &target,std::string &error);
}

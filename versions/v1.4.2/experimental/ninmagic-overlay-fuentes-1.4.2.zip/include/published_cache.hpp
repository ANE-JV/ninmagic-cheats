#pragma once
#include "model.hpp"
#include <cstddef>
namespace nc {
constexpr size_t PublishedCacheMaxBytes=256*1024,PublishedCacheMaxEntries=256,PublishedCacheMaxWords=16384;
bool savePublishedCache(const Pack&,std::string&error);
bool loadPublishedCache(const Game&,Pack&,std::string&error,uint64_t*stamp=nullptr);
bool checkPublishedCache(const Game&,uint64_t stamp,std::string&error);
}

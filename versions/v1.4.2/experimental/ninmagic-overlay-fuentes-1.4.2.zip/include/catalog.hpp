#pragma once
#include "model.hpp"
#include <functional>
namespace nc {
bool loadCatalog(Catalog &catalog,std::string &error);
bool syncCatalog(Catalog &catalog,std::string &error);
// Call from a worker: checks published releases and remote validators without
// downloading unchanged archives. force also refreshes the latest snapshot.
bool refreshCatalog(Catalog &catalog,bool force,std::string &error);
struct CheatSourceReport {
    std::string source,url,detail;
    bool checked=false,cached=false,found=false;
    long httpStatus=0;
};
// Worker-only, selected game only. Uses a six-hour per-source cache unless
// force is set; a network failure never removes previously verified codes.
// findCheats reads these caches offline. checked=false means not verified online.
bool refreshGameSources(const Game &game,bool force,std::vector<CheatSourceReport> &reports,std::string &error);
// Direct overlay query: never loads the global index. On false, an exact cached
// Pack may still be returned. Do not replace a prepared cache with an empty Pack
// after an incomplete/cancelled query. No cheats are installed or activated.
bool findPublishedGameDirect(const Game&,bool force,Pack&,std::vector<CheatSourceReport>&,std::string&,
                             const std::function<bool()> &cancelled={});
void logSourceReports(const Game&,const std::vector<CheatSourceReport>&,const std::string &error);
// Verified HTTPS transport shared by catalog and the executable updater.
bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error);
Pack findCheats(const Game &game,const Catalog &catalog);
void catalogExit();
}

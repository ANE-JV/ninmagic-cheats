#pragma once
#include "model.hpp"
namespace nc {
// Keep gameplay options and only the masters needed by their source groups.
void gameplayOnly(Pack &pack);
}

#include "ui.hpp"
#include "options.hpp"
#include "cheat_review.hpp"
#include "app_update_ui.hpp"
#include "ui_text.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>

namespace nc {
namespace {
constexpr int W=1280, H=720;
using Color=uint32_t;
constexpr Color rgb(unsigned r,unsigned g,unsigned b) { return r|(g<<8)|(b<<16)|0xff000000u; }
constexpr Color ink=rgb(227,239,254), muted=rgb(143,164,192), dim=rgb(85,113,146);
constexpr Color cyan=rgb(65,237,255), violet=rgb(179,132,255), pink=rgb(255,89,203), green=rgb(177,255,87), orange=rgb(255,174,72), blue=rgb(77,151,255);
constexpr Color panel=rgb(13,22,40), raised=rgb(20,34,56), border=rgb(36,53,79);
struct Glyph {int w=0,h=0,advance=0;std::vector<uint8_t> alpha;};
struct Font {std::array<Glyph,224> glyphs;};
std::map<int,Font> fonts;
std::vector<uint8_t> rawFont, logo;
std::array<uint8_t,224> advances{};
std::vector<Color> background;
Color *fb=nullptr;
int pitch=W;

void pixel(int x,int y,Color c) {if(x>=0&&x<W&&y>=0&&y<H) fb[y*pitch+x]=c;}
void rect(int x,int y,int w,int h,Color c) {
    int x0=std::max(0,x),x1=std::min(W,x+w),y0=std::max(0,y),y1=std::min(H,y+h);
    if(x1<=x0||y1<=y0) return;
    for(int yy=y0;yy<y1;++yy) std::fill(fb+yy*pitch+x0,fb+yy*pitch+x1,c);
}
Color blend(Color dst,Color src,unsigned a) {
    unsigned r=(((dst&255)*(255-a)+(src&255)*a)+127)/255;
    unsigned g=((((dst>>8)&255)*(255-a)+((src>>8)&255)*a)+127)/255;
    unsigned b=((((dst>>16)&255)*(255-a)+((src>>16)&255)*a)+127)/255;
    return rgb(r,g,b);
}
void alphaPixel(int x,int y,Color c,unsigned a) {
    if(x>=0&&x<W&&y>=0&&y<H&&a) {
        Color &p=fb[y*pitch+x];p=a==255?c:blend(p,c,a);
    }
}
void line(int x0,int y0,int x1,int y1,Color c) {
    int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;
    for(;;){pixel(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
}
void box(int x,int y,int w,int h,Color fill=panel,Color edge=border) {
    rect(x,y,w,h,fill);rect(x,y,w,1,edge);rect(x,y+h-1,w,1,edge);
    rect(x,y,1,h,edge);rect(x+w-1,y,1,h,edge);
    // Cut corners and short highlights give the panels their circuit-board shape.
    line(x,y+7,x+7,y,edge);line(x+w-8,y+h-1,x+w-1,y+h-8,edge);
    rect(x+1,y+1,6,2,fill);rect(x+1,y+3,4,2,fill);rect(x+1,y+5,2,2,fill);
}
std::vector<uint32_t> decode(const std::string&s) {
    return ui_text::displayCodepoints(s);
}
std::string encode(const std::vector<uint32_t>&v) {
    std::string s;for(auto cp:v) {if(cp<128)s+=static_cast<char>(cp);else{s+=static_cast<char>(0xc0|(cp>>6));s+=static_cast<char>(0x80|(cp&63));}}return s;
}
Font& font(int size) {
    auto it=fonts.find(size);if(it!=fonts.end())return it->second;
    Font scaled;
    for(unsigned i=0;i<224;++i) {
        auto &g=scaled.glyphs[i];g.w=size;g.h=(34*size+12)/24;g.advance=(advances[i]*size+12)/24;
        g.alpha.resize(g.w*g.h);
        for(int y=0;y<g.h;++y)for(int x=0;x<g.w;++x)
            g.alpha[y*g.w+x]=rawFont.empty()?0:rawFont[i*24*34+(y*34/g.h)*24+x*24/g.w];
    }
    return fonts.emplace(size,std::move(scaled)).first->second;
}
int width(const std::string&s,int size) {
    auto &f=font(size);int w=0;for(auto cp:decode(s))w+=f.glyphs[cp-32].advance;return w;
}
void text(const std::string&s,int x,int y,int size=18,Color c=ink) {
    auto &f=font(size);int offset=(5*size+12)/24;
    for(auto cp:decode(s)) {
        const auto &g=f.glyphs[cp-32];
        for(int yy=0;yy<g.h;++yy) {
            int py=y+yy-offset;if(py<0||py>=H)continue;
            for(int xx=0;xx<g.w;++xx)if(g.alpha[yy*g.w+xx])alphaPixel(x+xx,py,c,g.alpha[yy*g.w+xx]);
        }
        x+=g.advance;
    }
}
std::string fit(const std::string&s,int maxw,int size) {
    if(width(s,size)<=maxw)return s;
    auto chars=decode(s);while(!chars.empty()&&width(encode(chars)+"...",size)>maxw)chars.pop_back();
    return encode(chars)+"...";
}
void fitted(const std::string&s,int x,int y,int maxw,int size=18,Color c=ink) {text(fit(s,maxw,size),x,y,size,c);}
void wrapped(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=ink) {
    std::istringstream words(s);std::string word,current;int n=0;
    while(words>>word) {
        std::string trial=current.empty()?word:current+" "+word;
        if(width(trial,size)>maxw&&!current.empty()) {
            fitted(current,x,y+n*(size+9),maxw,size,c);if(++n>=maxlines)return;current=word;
        } else current=trial;
        if(n==maxlines-1) {
            std::string rest;std::getline(words,rest);fitted(current+rest,x,y+n*(size+9),maxw,size,c);return;
        }
    }
    if(!current.empty())fitted(current,x,y+n*(size+9),maxw,size,c);
}
// File paths must remain exact: wrap at character boundaries, never abbreviate.
std::vector<std::string> pathLines(const std::string&s,int maxw,int size) {
    std::vector<std::string> lines;std::vector<uint32_t> current;
    for(auto cp:decode(s)) {
        auto trial=current;trial.push_back(cp);
        if(!current.empty()&&width(encode(trial),size)>maxw){lines.push_back(encode(current));current.clear();}
        current.push_back(cp);
    }
    if(!current.empty())lines.push_back(encode(current));
    return lines;
}
void exactPath(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=muted) {
    const auto lines=pathLines(s,maxw,size);
    for(int i=0;i<std::min(maxlines,static_cast<int>(lines.size()));++i)text(lines[i],x,y+i*(size+7),size,c);
    if(static_cast<int>(lines.size())>maxlines)text("Ruta abreviada en esta vista.",x,y+maxlines*(size+7),12,dim);
}
void logoAt(int x,int y,int size) {
    if(logo.size()!=256*256*4){box(x,y,size,size,raised,cyan);text("NM",x+size/8,y+size/4,size/3,cyan);return;}
    for(int yy=0;yy<size;++yy)for(int xx=0;xx<size;++xx) {
        size_t p=((yy*256/size)*256+xx*256/size)*4;
        alphaPixel(x+xx,y+yy,rgb(logo[p],logo[p+1],logo[p+2]),logo[p+3]);
    }
}
void key(const std::string&k,const std::string&label,int x,int y,Color c=muted) {
    int kw=std::max(23,width(k,13)+14);box(x,y,kw,25,rgb(19,34,55),rgb(46,71,100));text(k,x+(kw-width(k,13))/2,y+5,13,ink);text(label,x+kw+9,y+5,14,c);
}
void badge(const std::string&s,int x,int y,Color c=cyan,int maxw=300) {
    int w=std::min(maxw,width(s,12)+22);box(x,y,w,26,rgb(20,37,55),rgb(43,76,91));fitted(s,x+11,y+6,w-22,12,c);
}
void neonLine(int x,int y,int w) {
    const Color colors[]={cyan,blue,violet,pink,orange,green};int at=x;
    for(int i=0;i<6;++i){int n=i==5?x+w-at:w/6;rect(at,y,n,2,colors[i]);at+=n;}
}
void footer(const std::vector<std::pair<std::string,std::string>>&items) {
    rect(32,666,1216,1,border);int x=32;
    for(const auto&p:items){key(p.first,p.second,x,683);x+=std::max(23,width(p.first,13)+14)+width(p.second,14)+27;}
    text("NINMAGIC / 1.4.6",1100,689,11,violet);
}
void smallLabel(const std::string&s,int x,int y,Color c=dim){text(s,x,y,11,c);}
void title(const std::string&s,const std::string&sub="") {fitted(s,32,151,1216,29);if(!sub.empty())fitted(sub,34,193,1212,15,muted);}
std::string version(const Game&g){return g.version.empty()?"Versión no declarada":"v"+g.version;}
std::string location(const Game&g){return g.sd&&g.nand?"SD + INTERNA":g.sd?"microSD":g.nand?"INTERNA":g.card?"CARTUCHO":"INSTALADO";}
void header(const View&v) {
    logoAt(32,14,65);text("NINMAGIC",111,17,28,ink);text("CHEATS DE JUEGOS",113,53,12,cyan);
    rect(350,23,1,41,border);text("ELIGE TUS TRUCOS",373,28,17,muted);badge("JUGABILIDAD",1108,28,pink,140);neonLine(32,90,1216);
    smallLabel("FW",32,110);fitted(v.env.firmware.empty()?"--":v.env.firmware,61,108,160,13,muted);
    smallLabel("ATMOSPHÈRE",245,110);fitted(v.env.atmosphere.empty()?"--":v.env.atmosphere,337,108,199,13,muted);
    rect(550,107,1,19,border);text(v.env.dmnt?"MOTOR DISPONIBLE":"MOTOR SIN CONEXIÓN",571,109,12,v.env.dmnt?green:violet);
    std::string state=v.catalog.entries.empty()?"CATÁLOGO SIN DESCARGAR":"BASE DE CHEATS EN CACHÉ";text(state,1248-width(state,12),109,12,v.catalog.entries.empty()?orange:blue);
}
void identityStrip(const Game&g) {
    smallLabel("TITLE ID",32,173);text(hexId(g.id),94,171,13,muted);smallLabel("BUILD ID",323,173);text(g.buildVerified?g.buildId:"SIN VERIFICAR",392,171,13,g.buildVerified?cyan:orange);
    fitted(version(g),694,171,259,13,muted);badge(!g.buildVerified?"SIN COMPROBAR":g.running?"JUEGO ABIERTO":"JUEGO CERRADO",1100,160,g.buildVerified&&g.running?green:violet,148);
}
void library(const View&v) {
    text("Biblioteca",32,154,29);text(std::to_string(v.games.size())+(v.games.size()==1?" juego":" juegos"),203,167,13,blue);smallLabel("ELIGE UN JUEGO",32,195,cyan);
    box(32,224,405,399,panel,border);const int count=static_cast<int>(v.games.size()),sel=count?std::clamp(v.selected,0,count-1):0;
    int first=std::max(0,sel-3);if(first+7>count)first=std::max(0,count-7);
    for(int i=first;i<std::min(first+7,count);++i){const auto&g=v.games[i];int y=233+(i-first)*54;bool active=i==sel;
        if(active){rect(41,y,387,51,rgb(19,45,65));rect(41,y,3,51,cyan);rect(44,y,383,1,blue);}
        char n[12];std::snprintf(n,sizeof(n),"%02d",i+1);text(n,55,y+9,11,active?pink:dim);fitted(g.name.empty()?hexId(g.id):g.name,83,y+6,330,17,active?ink:muted);
        fitted(version(g)+" · "+location(g),84,y+31,299,11,active?cyan:dim);if(g.running)rect(407,y+34,5,5,green);
    }
    if(count>7){int h=std::max(24,373*7/count);rect(431,236,2,373,border);rect(431,236+first*(373-h)/std::max(1,count-7),2,h,pink);}
    if(!count){wrapped("No se han detectado juegos instalados.",57,254,355,21,3);wrapped("Pulsa X para volver a leer la biblioteca.",57,362,355,16,2,muted);}
    box(461,150,787,473,panel,border);neonLine(461,150,787);
    if(count){const auto&g=v.games[sel];smallLabel("JUEGO SELECCIONADO",486,173,cyan);wrapped(g.name.empty()?"Título sin nombre":g.name,486,206,732,28,2);
        fitted(g.author.empty()?"Editor no disponible":g.author,487,290,489,14,muted);fitted(version(g),1007,289,216,16,cyan);rect(486,325,737,1,border);
        smallLabel("TITLE ID",486,345,blue);text(hexId(g.id),486,367,18,muted);smallLabel("BUILD ID",858,345,violet);text(g.buildVerified?g.buildId:"Se comprueba al elegir",858,367,17,g.buildVerified?cyan:muted);
        badge(g.running?"JUEGO ABIERTO":"JUEGO CERRADO",486,412,g.running?green:violet,737);
        wrapped(g.running?"Los cheats se podrán aplicar a la sesión del juego que sigue abierta.":"Los cheats se podrán guardar para que se carguen al iniciar el juego.",486,461,737,17,2,muted);
        box(486,537,737,55,rgb(15,44,57),rgb(35,122,136));key("A","VER CHEATS PUBLICADOS",506,552,cyan);
        fitted("Se comprobará el Build ID del juego antes de mostrar sus cheats.",487,602,735,12,muted);
    }else{wrapped("Tus juegos, tus trucos.",486,204,647,29,2);wrapped("Actualiza el catálogo y elige un juego para consultar sus cheats de jugabilidad.",486,291,647,20,3,muted);logoAt(1060,435,132);}
    const std::string status=v.appUpdate.available?"Nueva versión de NinMagic: "+v.appUpdate.version+" · L abre la actualización de la aplicación.":v.status;
    fitted(status,34,640,1214,13,v.appUpdate.available?green:muted);footer({{"ARRIBA / ABAJO","Mover"},{"A","Cheats"},{"Y","Catálogo"},{"L","Actualizar app"},{"X","Juegos"},{"-","Ayuda"},{"+","Salir"}});
}
CheatState checkedState(const Pack&p,const Cheat&c){return p.liveChecked&&p.game.running?c.liveState:CheatState::Unknown;}
std::string stateLabel(CheatState s){switch(s){case CheatState::Enabled:return "ACTIVO EN EL MOTOR";case CheatState::Disabled:return "CARGADO · APAGADO";case CheatState::NotLoaded:return "SIN CARGAR";case CheatState::Unknown:return "SIN COMPROBAR";}return "SIN COMPROBAR";}
Color stateColor(CheatState s){return s==CheatState::Enabled?green:s==CheatState::Disabled?orange:s==CheatState::NotLoaded?blue:violet;}
unsigned activeCount(const Pack&p){return static_cast<unsigned>(std::count_if(p.cheats.begin(),p.cheats.end(),[&](const Cheat&c){return !c.master&&checkedState(p,c)==CheatState::Enabled;}));}
bool unknownStates(const Pack&p){return std::any_of(p.cheats.begin(),p.cheats.end(),[&](const Cheat&c){return !c.master&&checkedState(p,c)==CheatState::Unknown;});}
std::string blockedSelection(const Pack&p){for(const auto&c:p.cheats)if(c.selected&&!c.master){auto reason=blockedCheatReason(p.game,c);if(!reason.empty())return reason;}return {};}
std::vector<std::string> otherBuilds(const Pack&p){std::vector<std::string>out;for(auto build:p.availableBuilds){if(build.size()!=16)continue;for(auto&c:build)if(c>='a'&&c<='f')c=char(c-'a'+'A');if(build==p.game.buildId||build.find_first_not_of("0123456789ABCDEF")!=std::string::npos||std::find(out.begin(),out.end(),build)!=out.end())continue;out.push_back(std::move(build));if(out.size()==4)break;}return out;}
void cheats(const View&v) {
    const auto&p=v.pack;fitted(p.game.name.empty()?"Cheats del juego":p.game.name,32,142,1192,24);identityStrip(p.game);
    box(32,211,1216,31,rgb(16,29,47),border);text("CASILLAS: PRÓXIMA SELECCIÓN",48,221,11,cyan);text("ESTADO: MOTOR DEL JUEGO",979,221,11,green);
    std::vector<const Cheat*>rows;for(const auto&c:p.cheats)if(!c.master)rows.push_back(&c);
    const int count=static_cast<int>(rows.size()),sel=count?std::clamp(v.cheatSelected,0,count-1):0;box(32,259,813,362,panel,border);smallLabel("CHEATS DE JUGABILIDAD",54,279,pink);text(std::to_string(count)+(count==1?" opción":" opciones"),735,279,11,dim);
    int first=std::max(0,sel-2);if(first+6>count)first=std::max(0,count-6);
    for(int i=first;i<std::min(first+6,count);++i){const auto&c=*rows[i];int y=301+(i-first)*51;bool current=i==sel;const auto state=checkedState(p,c);const bool blocked=!blockedCheatReason(p.game,c).empty();const auto label=stateLabel(state);int sw=width(label,10)+18;
        if(current){rect(41,y,795,47,rgb(22,41,65));rect(41,y,3,47,cyan);}
        box(56,y+12,22,22,raised,c.selected?cyan:blocked?orange:border);if(c.selected){line(61,y+23,66,y+28,cyan);line(66,y+28,74,y+17,cyan);}
        box(818-sw,y+3,sw,21,rgb(18,31,47),state==CheatState::Enabled?rgb(69,102,47):border);text(label,827-sw,y+9,10,stateColor(state));
        fitted(cheatLabel(c),93,y+5,711-sw,17,blocked?orange:current?ink:muted);fitted(blocked?"EN REVISIÓN · "+c.name:c.name,94,y+30,540,10,blocked?orange:dim);fitted(c.source,651,y+30,165,10,dim);
    }
    if(count>6){int h=std::max(20,303*6/count);rect(838,306,2,303,border);rect(838,306+first*(303-h)/std::max(1,count-6),2,h,pink);}
    if(!count){
        if(!p.game.buildVerified){
            wrapped("Falta comprobar la versión del juego",58,328,757,24,2,orange);
            wrapped("Inicia este juego y abre NinMagic desde Álbum sin cerrarlo, o consulta desde el overlay.",58,387,757,18,2,muted);
            if(!p.detail.empty()){smallLabel("DETALLE DE LA COMPROBACIÓN",58,459,pink);wrapped(p.detail,58,481,757,15,3,muted);}
            badge("BUILD ID · SIN COMPROBAR",58,580,violet,757);
        }else if(p.lookupState!=LookupState::Complete){
            wrapped(p.lookupState==LookupState::Incomplete?"No se pudo completar la consulta de cheats":"La consulta de cheats no está comprobada",58,328,757,24,2,orange);
            wrapped("No se ha confirmado si hay cheats para este Build ID. Vuelve a la biblioteca con B y pulsa Y para reintentar.",58,387,757,18,2,muted);
            if(!p.detail.empty()){smallLabel("DETALLE DE LA CONSULTA",58,459,pink);wrapped(p.detail,58,481,757,15,3,muted);}
            badge("BUILD ID · "+p.game.buildId,58,580,violet,757);
        }else{
            const auto other=otherBuilds(p);wrapped("No compatible con esta versión",58,332,757,24,2,orange);
            wrapped(other.empty()?p.detail.empty()?"No se encontraron cheats publicados para este Build ID en las fuentes consultadas. B vuelve a la biblioteca y Y actualiza el catálogo.":p.detail:"Los cheats publicados para otros Build ID no se pueden asignar a la versión instalada.",58,391,757,17,other.empty()?4:2,muted);
            if(!other.empty()){smallLabel("OTROS BUILD ID PUBLICADOS · MISMO JUEGO",58,453,blue);for(size_t i=0;i<other.size();++i)text(other[i],58+int(i%2)*365,480+int(i/2)*28,17,cyan);}
            badge("BUILD ID · "+p.game.buildId,58,549,violet,757);
        }
    }
    box(869,259,379,362,panel,border);rect(869,259,100,2,pink);smallLabel("PRÓXIMA SELECCIÓN",893,279,cyan);const auto n=std::to_string(selectedCount(p));text(n,891,306,41);text(selectedCount(p)==1?"preparado":"preparados",911+width(n,41),331,15,muted);
    const auto active=activeCount(p);const bool unknown=unknownStates(p);smallLabel("ESTAS OPCIONES EN EL MOTOR",893,366,blue);fitted(!p.game.buildVerified?"SIN COMPROBAR":!p.game.running?"JUEGO CERRADO":!p.liveChecked||(!active&&unknown)?"SIN COMPROBAR":std::to_string(active)+(active==1?" activa":" activas")+(unknown?" · ESTADO PARCIAL":""),893,388,331,15,p.game.buildVerified&&p.game.running&&p.liveChecked&&!unknown?green:violet);
    if(count){const auto&c=*rows[sel];const auto blocked=blockedCheatReason(p.game,c);badge(stateLabel(checkedState(p,c)),893,416,stateColor(checkedState(p,c)),331);smallLabel("NOMBRE ORIGINAL / BOTONES",893,453,pink);wrapped(c.name,893,476,331,15,blocked.empty()?3:2);
        const auto detail=!blocked.empty()?blocked:!p.liveChecked&&!p.liveDetail.empty()?p.liveDetail:p.lookupState==LookupState::Incomplete?p.detail:explainCheat(c);wrapped(detail,893,blocked.empty()?553:535,331,12,blocked.empty()?3:4,blocked.empty()?muted:orange);
    }else wrapped(!p.game.buildVerified?"Primero se comprueba el Build ID. Sin él no se puede determinar qué cheats son compatibles.":p.lookupState!=LookupState::Complete?p.cachedLookup?"La copia guardada no confirma que falten cheats. Reintenta la consulta cuando haya conexión.":"Las fuentes todavía no se han comprobado por completo. Una lista vacía no confirma que falten cheats.":"La disponibilidad depende de los cheats publicados para el Build ID instalado. La biblioteca permite actualizar el catálogo.",893,451,331,17,5,muted);
    const auto selectionBlock=blockedSelection(p);fitted(count?!selectionBlock.empty()?"La selección contiene un código en revisión. Desmárcalo con A. L permite retirar los códigos propios.":p.lookupState==LookupState::Incomplete?p.cachedLookup?"Consulta incompleta: se muestra la copia guardada disponible. Reintenta desde la biblioteca.":"Consulta incompleta: se muestran las opciones disponibles. Reintenta desde la biblioteca.":"Marcar no activa códigos. Y revisa; A en la confirmación aplica. X comprueba el estado real del motor.":!p.game.buildVerified?"B vuelve a la biblioteca. Selecciona el juego para reintentar, o consulta desde el overlay.":p.lookupState==LookupState::Complete?"No compatible con esta versión. No se puede aplicar una lista de otro Build ID.":"B vuelve a la biblioteca. Allí puedes actualizar el catálogo con Y.",34,638,1214,13,selectionBlock.empty()?muted:orange);
    if(count)footer({{"ARRIBA / ABAJO","Mover"},{"A",rows[sel]->selected?"Desmarcar":"Marcar"},{"Y","Revisar"},{"X","Estado"},{"L","Quitar"},{"B","Volver"},{"+","Salir"}});
    else footer({{"B","Biblioteca"},{"L","Quitar mis cheats"},{"+","Salir"}});
}
void targetCard(const Game&g) {
    box(32,229,400,397,panel,border);rect(32,229,100,2,pink);smallLabel("JUEGO DE DESTINO",56,249,pink);wrapped(g.name.empty()?"Juego seleccionado":g.name,56,279,352,24,2);fitted(version(g),56,362,352,17,cyan);
    smallLabel("TITLE ID",56,407,blue);text(hexId(g.id),56,429,17,muted);smallLabel("BUILD ID COMPROBADO",56,471,violet);text(g.buildVerified?g.buildId:"SIN VERIFICAR",56,493,17,g.buildVerified?cyan:orange);
    badge(g.running?"JUEGO ABIERTO":"JUEGO CERRADO",56,565,g.running?green:violet,352);
}
void confirmation(const View&v) {
    const auto&p=v.pack;const bool live=p.game.running;const auto blocked=v.restore?std::string{}:blockedSelection(p);title(v.restore?"Quitar mis cheats":!blocked.empty()?"Selección en revisión":"Confirma tus cheats",v.restore?"Se deshacen los cambios registrados por NinMagic para este juego.":!blocked.empty()?"No se aplicarán los códigos de esta selección.":"Una confirmación: la aplicación elige cómo aplicarlos según el estado del juego.");targetCard(p.game);
    box(456,229,792,397,panel,border);rect(456,229,110,2,live?green:blue);
    if(!blocked.empty()){smallLabel("CÓDIGO BLOQUEADO · COMPATIBILIDAD EN REVISIÓN",482,249,orange);wrapped(blocked,483,300,734,23,5);wrapped("Vuelve con B y desmarca los códigos en revisión. Si ya estaban activos, utiliza L para retirar los códigos de NinMagic y reinicia el juego.",483,468,734,18,4,muted);footer({{"B","Volver a la selección"}});return;}
    std::string action;
    if(v.restore){smallLabel("RECUPERAR EL ESTADO REGISTRADO",482,249,pink);wrapped(live?"Se retirarán las entradas añadidas por NinMagic a esta sesión y se recuperarán los estados anteriores registrados.":"Se recuperará el archivo de cheats anterior a la última instalación de NinMagic. Si antes no existía, se retirará el que creó la aplicación.",483,289,734,21,4,muted);
        rect(482,420,740,1,border);wrapped(live?"Reinicia el juego si sus valores ya cambiaron. Retirar el código no restaura automáticamente la memoria del juego.":"Los archivos anteriores se conservan en su copia. La aplicación comprueba que no hayan cambiado después de instalarlos.",483,451,734,17,3,muted);action=live?"QUITAR AHORA":"DESHACER EL ARCHIVO";
    }else{smallLabel("SELECCIÓN · "+std::to_string(selectedCount(p))+(selectedCount(p)==1?" CHEAT":" CHEATS"),482,249,cyan);unsigned shown=0;for(const auto&c:p.cheats)if(c.selected&&!c.master&&shown<4){fitted(cheatLabel(c),483,280+static_cast<int>(shown)*28,734,17);++shown;}
        if(selectedCount(p)>shown)text("+ "+std::to_string(selectedCount(p)-shown)+" más en la selección",483,395,13,violet);
        badge(live?"APLICAR AL JUEGO ABIERTO":"GUARDAR PARA EL PRÓXIMO INICIO",483,422,live?green:blue,734);
        std::string prior=live?v.existing.activeCheats?"Hay "+std::to_string(v.existing.activeCheats)+" cheats cargados. Los demás conservan su estado; se revisan los conflictos.":"Se comprobará el proceso y se habilitarán los cheats preparados en esta sesión.":v.existing.cheats?"Ya existe un archivo para este Build ID. Se sustituirá con la selección y se guardará una copia para deshacerlo.":"Se guardará esta selección para que Atmosphère la cargue al iniciar el juego.";
        wrapped(prior,483,466,734,17,3,((live&&v.existing.activeCheats)||(!live&&v.existing.cheats))?orange:muted);action=live?"APLICAR AHORA":"GUARDAR PARA INICIAR";
    }
    box(483,553,739,57,rgb(15,43,55),live?green:blue);key("A",action,503,569,live?green:cyan);
    fitted(v.restore?"Algunos parches requieren cerrar y reabrir el juego. Las partidas guardadas no se revierten.":"Un código habilitado puede requerir pulsar botones dentro del juego. Revisa sus condiciones originales.",34,641,1214,13,orange);
    footer({{"A","Confirmar"},{"B","Volver"}});
}
std::string memorySize(uint64_t bytes) {
    char s[48];std::snprintf(s,sizeof(s),"%.1f MiB",static_cast<double>(bytes)/(1024.0*1024.0));return s;
}
void loading(const View&v,bool busy) {
    box(172,207,936,388,panel,border);neonLine(172,207,936);logoAt(209,247,132);text(busy?"Operación en curso":"Leyendo tus juegos",374,260,29);
    wrapped(v.status,375,318,686,19,3,muted);rect(210,472,859,4,border);int pos=static_cast<int>((v.frame*6)%685);rect(210+pos,472,174,4,busy?pink:cyan);
    text(busy?"OPERACIÓN EN CURSO":"CONSULTA EN CURSO",210,501,12,busy?pink:cyan);fitted("Espera a que termine la operación antes de salir.",210,541,859,15,muted);footer({});
}
void appUpdate(const View&v) {
    const auto&u=v.appUpdate;const auto&r=v.completedUpdate;const auto action=appUpdateAction(u,r,v.appUpdateDetail);const bool canInstall=action==AppUpdateAction::Install;
    const bool canReview=action==AppUpdateAction::ReviewCompletedRecord,blocked=r.state==CompletedUpdateState::Blocked,sdDiff=differentAppOnSd(u),onSd=publishedAppOnSd(u);
    const bool unconfirmed=!v.appUpdateDetail.empty()&&!u.installed;
    const std::string detail=v.appUpdateDetail.empty()?u.detail:v.appUpdateDetail;
    title("Actualizar NinMagic","Distingue el programa abierto del NRO que hay en la microSD.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(139,251,154);
    smallLabel("PROGRAMA EN EJECUCIÓN",56,430,blue);fitted(u.runningVersion.empty()?"1.4.6":u.runningVersion,56,451,319,31);
    smallLabel("ARCHIVO NRO EN LA SD",56,501,pink);fitted(u.sdVerified?u.sdVersion:"SIN COMPROBAR",56,523,319,24,u.sdVerified?cyan:violet);
    badge(canReview?"REGISTRO ANTIGUO TERMINADO":u.installed||sdDiff?"CIERRA Y VUELVE A ABRIR":blocked||unconfirmed?"REQUIERE REVISIÓN":u.available?"HAY UNA NUEVA VERSIÓN":"NINMAGIC CHEATS",56,580,canReview||u.installed||sdDiff||blocked||unconfirmed?orange:u.available?green:cyan,319);
    box(423,229,825,397,panel,border);rect(423,229,110,2,u.configured&&!unconfirmed?cyan:orange);
    if(canReview){smallLabel("REGISTRO ANTIGUO TERMINADO",449,249,orange);text("Revisa el registro antes de archivarlo",449,286,27);
        wrapped(r.detail.empty()?"Se encontró un registro terminado que puede archivarse tras revisar el archivo actual y las copias conservadas.":r.detail,449,343,770,19,4,muted);
        smallLabel("REVISIÓN PREVIA A CUALQUIER CAMBIO",449,470,blue);wrapped("A muestra las versiones y la huella del NRO. Después podrás confirmar el archivado del registro. Se conservan el ejecutable y las copias anteriores.",449,493,770,15,3,muted);
        box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","REVISAR REGISTRO TERMINADO",469,569,cyan);
    }else if(blocked){smallLabel("REGISTRO NO ARCHIVABLE",449,249,orange);text("No se puede archivar este registro",449,286,27);
        wrapped(r.detail.empty()?detail:r.detail,449,343,770,19,6,muted);wrapped(sdDiff?"El archivo de la SD difiere del programa abierto. Cierra NinMagic y vuelve a abrirlo desde hbmenu.":"Se conserva el registro para revisar su estado; no se preparará otra instalación desde esta pantalla.",449,514,770,16,3,orange);badge("REVISA EL INFORME",449,580,orange,770);
    }else if(sdDiff||u.installed||onSd){smallLabel(onSd?"PUBLICACIÓN YA PRESENTE EN LA SD":"ARCHIVO DE LA SD DISTINTO AL PROGRAMA ABIERTO",449,249,orange);text(sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo":"El archivo publicado ya está en la SD",449,286,27);
        wrapped(sdDiff?"La versión del NRO de la SD y la que sigue ejecutándose son distintas. Sal completamente y abre NinMagic desde hbmenu para cargar el archivo de la SD.":u.installed?"La instalación terminó. Esta sesión sigue usando el programa anterior hasta que cierres NinMagic y lo abras de nuevo.":"El tamaño, la huella SHA-256 y la versión del NRO de la SD coinciden con la publicación consultada. No hace falta descargarlo otra vez.",449,343,770,19,4,muted);
        smallLabel(onSd?"SHA-256 COINCIDENTE CON LA PUBLICACIÓN":"SHA-256 DEL ARCHIVO DE LA SD",449,460,blue);exactPath(u.sdVerified?u.sdSha256:"Sin comprobar",449,483,770,12,1,muted);
        if(!v.appUpdateDetail.empty())wrapped(v.appUpdateDetail,449,521,770,14,2,orange);
        badge(sdDiff||u.installed?"ABRE EL ARCHIVO DE LA SD DESDE HBMENU":"SIN DESCARGA PENDIENTE",449,580,orange,770);
    }else if(unconfirmed){smallLabel("ACTUALIZACIÓN SIN COMPROBAR",449,249,orange);text("No se pudo comprobar la versión",449,286,27);
        wrapped(detail,449,343,770,19,5,muted);
        wrapped("El informe de error no permite saber si hay una versión más reciente. Revisa la conexión o el canal configurado y vuelve a comprobar.",449,502,770,16,3,muted);
        badge("CONSULTA PENDIENTE",449,580,orange,770);
    }else if(!u.configured){smallLabel("CANAL DE VERSIONES SIN CONFIGURAR",449,249,orange);text("Falta vincular el servidor",449,286,27);
        wrapped("Todavía no hay un canal de actualizaciones vinculado a esta copia de NinMagic. La dirección del manifiesto HTTPS público se configura en:",449,343,770,19,3,muted);
        exactPath("sdmc:/config/NinMagicCheats/update-url.txt",449,449,770,16,2,cyan);
        wrapped(detail.empty()?"Cuando se configure, esta pantalla mostrará la nueva versión, su archivo y el tamaño antes de descargarla.":detail,449,508,770,15,3,muted);
        badge("INSTALACIÓN NO DISPONIBLE",449,580,orange,770);
    }else{smallLabel(u.installed?"ARCHIVO INSTALADO Y COMPROBADO":u.prepared?"DESCARGA VERIFICADA":u.available?"NUEVA VERSIÓN PUBLICADA":"SIN ACTUALIZACIÓN PENDIENTE",449,249,u.installed||u.available?green:blue);
        fitted(u.version.empty()?"Versión no indicada":u.version,449,280,500,31);fitted(u.size?memorySize(u.size):"Tamaño no indicado",982,295,239,17,muted);
        smallLabel("ARCHIVO NRO · HTTPS",449,334,blue);exactPath(u.url.empty()?"Dirección no disponible":u.url,449,357,770,13,2,muted);
        smallLabel(u.prepared||u.installed?"SHA-256 COMPROBADO":"SHA-256 PUBLICADO",449,415,violet);exactPath(u.sha256.empty()?"Sin huella disponible":u.sha256,449,437,770,12,1,muted);
        wrapped(detail.empty()?(u.available?"A confirma la descarga e instalación. Se comprobarán el archivo NRO y su huella antes de sustituir la aplicación.":"No hay una versión más reciente disponible en el canal configurado."):detail,449,474,770,16,2,u.installed?green:muted);
        if(canInstall){box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A",u.prepared?"INSTALAR DESCARGA VERIFICADA":"DESCARGAR E INSTALAR",469,569,cyan);}
        else badge(u.installed?"CIERRA NINMAGIC Y ÁBRELO DE NUEVO":"SIN DESCARGAS PENDIENTES",449,576,u.installed?orange:blue,770);
    }
    fitted(canReview?"A abre una revisión de sólo lectura; archivar requiere una segunda confirmación.":sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo desde hbmenu. No se preparará otra descarga en esta sesión.":blocked?"El registro y el archivo actual se conservan. X vuelve a comprobar su estado.":unconfirmed?"X vuelve a comprobar la actualización. El estado actual de la publicación sigue sin verificar.":!u.configured?"Configura el canal de versiones para habilitar las descargas desde la aplicación.":!u.available?"X vuelve a consultar el canal de versiones configurado.":"La consulta comprueba versiones. La instalación comienza únicamente al confirmarla con A.",34,641,1214,13,canReview||sdDiff||u.installed||blocked||unconfirmed?orange:muted);
    if(canReview)footer({{"A","Revisar registro"},{"X","Comprobar"},{"B","Volver"},{"+","Cerrar"}});
    else if(u.installed||sdDiff)footer({{"+","Cerrar NinMagic"},{"B","Volver"}});
    else if(canInstall)footer({{"A","Descargar e instalar"},{"X","Volver a comprobar"},{"B","Volver"}});
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void appUpdateRecord(const View&v){
    const auto&r=v.completedUpdate;const bool ready=completedReviewReady(r);title("Revisa el registro terminado","Comprueba estos datos antes de confirmar el archivado del registro.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);smallLabel("NRO ACTUAL EN LA SD",56,249,cyan);fitted(r.currentVersion.empty()?"SIN COMPROBAR":r.currentVersion,56,282,319,31);fitted(r.currentSize?memorySize(r.currentSize):"Tamaño sin comprobar",56,330,319,17,muted);
    smallLabel("SHA-256 LEÍDO DEL ARCHIVO",56,383,blue);exactPath(r.currentSha256.empty()?"Sin comprobar":r.currentSha256,56,410,319,12,3,muted);smallLabel("RUTA DEL EJECUTABLE",56,512,pink);exactPath("sdmc:/switch/ninmagic-cheats/ninmagic-cheats.nro",56,540,319,13,3,muted);
    box(423,229,825,397,panel,border);rect(423,229,110,2,ready?cyan:orange);smallLabel(ready?"REGISTRO ANTIGUO TERMINADO":r.state==CompletedUpdateState::Blocked?"REGISTRO NO ARCHIVABLE":"NO HAY UN REGISTRO PARA ARCHIVAR",449,249,ready?cyan:orange);
    smallLabel("VERSIÓN ANTERIOR REGISTRADA",449,294,blue);fitted(r.oldVersion.empty()?"Sin datos":r.oldVersion,449,320,350,24);smallLabel("VERSIÓN OBJETIVO REGISTRADA",836,294,violet);fitted(r.newVersion.empty()?"Sin datos":r.newVersion,836,320,380,24);
    fitted("Registro "+(r.token.empty()?std::string("sin identificar"):r.token)+" · "+(r.journalState=="committed"?"instalación terminada":r.journalState=="restored"?"recuperación terminada":"estado sin confirmar"),449,373,770,15,orange);
    wrapped(r.detail.empty()?v.appUpdateDetail:r.detail,449,413,770,17,ready?3:6,muted);
    if(ready){wrapped("Se archivará únicamente el registro terminado. El NRO de la SD y sus copias anteriores se conservan.",449,508,770,15,2,muted);box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","CONFIRMAR ARCHIVADO DEL REGISTRO",469,569,cyan);footer({{"A","Archivar registro"},{"B","Cancelar"}});}
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void result(const View&v) {
    if(v.returnScreen==4&&v.appUpdateArchiveResult){
        title(v.outcome.ok?"Registro antiguo archivado":"No se pudo archivar el registro",v.outcome.ok?"Revisa el estado del programa abierto y del archivo de la SD.":"Se conserva la revisión necesaria para comprobar qué cambió.");box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(127,258,177);fitted(v.outcome.ok?"REGISTRO ARCHIVADO":"REQUIERE ATENCIÓN",55,476,321,22,v.outcome.ok?green:orange);badge("INFORME DEL REGISTRO",56,581,v.outcome.ok?cyan:orange,319);box(423,229,825,397,panel,border);smallLabel("INFORME",449,249,pink);wrapped(v.outcome.message.empty()?"No hay un informe disponible.":v.outcome.message,449,286,770,20,8,muted);footer({{"A","Volver"},{"B","Volver"},{"+","Salir"}});return;
    }
    const bool ok=v.outcome.ok,updating=v.returnScreen==4,installed=ok&&updating&&v.appUpdate.installed,catalog=ok&&!updating&&!v.restore&&!v.outcome.live&&v.outcome.count==0;
    const std::string heading=!ok?"Resultado de la operación":updating?installed?"NinMagic actualizado":"Actualización de NinMagic":v.restore?v.outcome.live?"Cheats retirados del motor":"Archivo de cheats restaurado":catalog?"Catálogo actualizado":v.outcome.live?"Cheats aplicados al motor":"Cheats guardados";
    title(heading,ok?updating?installed?"Cierra NinMagic y vuelve a abrirlo para utilizar la nueva versión.":"Revisa el informe de la actualización antes de continuar.":v.restore?"Revisa el informe y reinicia el juego si procede.":catalog?"El catálogo está preparado para consultar los cheats de tus juegos.":v.outcome.live?"El motor confirmó la selección; conserva sus botones y condiciones de activación.":"La selección está preparada para el próximo inicio del juego.":"Revisa el detalle antes de continuar.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(127,258,177);fitted(ok?"COMPLETADO":"REQUIERE ATENCIÓN",55,476,321,22,ok?green:orange);
    fitted(!ok?"Consulta el informe":updating?v.appUpdate.version:catalog?"Base de cheats":v.restore&&!v.outcome.live?"Copia anterior":std::to_string(v.outcome.count)+(v.outcome.count==1?" cheat":" cheats"),56,522,319,28);
    badge(!ok?"OPERACIÓN SIN COMPLETAR":updating?installed?"CIERRA Y VUELVE A ABRIR":"INFORME DE ACTUALIZACIÓN":catalog?"CATÁLOGO EN CACHÉ":v.restore?"CAMBIOS RETIRADOS":v.outcome.live?"ESTADO DEL MOTOR":"ARCHIVO EN microSD",56,581,ok?cyan:orange,319);
    box(423,229,825,397,panel,border);smallLabel("INFORME",449,249,pink);wrapped(v.outcome.message.empty()?"No hay un informe disponible.":v.outcome.message,449,286,770,20,6,muted);
    if(!v.outcome.backupPath.empty()){rect(449,494,772,1,border);smallLabel("COPIA DE SEGURIDAD",449,514,blue);exactPath(v.outcome.backupPath,449,541,770,14,3,muted);}
    footer({{"A","Volver"},{"B","Volver"},{"+","Salir"}});
}
void help(const View&) {
    title("Elige, aplica y juega","Cheats publicados para la versión instalada de tus juegos.");box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(112,250,207);text("NINMAGIC",92,478,33);text("CHEATS DE JUEGOS",107,530,16,cyan);text("1.4.6",179,580,16,pink);box(423,229,825,397,panel,border);
    struct Tip{const char*label;const char*body;Color color;};const Tip tips[]={
        {"01  BIBLIOTECA Y ACTUALIZACIONES","A: cheats · Y: catálogo · X: juegos · L: actualizar NinMagic, si hay un canal de versiones configurado.",cyan},
        {"02  MARCA LO QUE QUIERAS","A prepara cada cheat. Conserva los botones y condiciones del autor; algunos exigen mantenerlos dentro del juego.",pink},
        {"03  Y APLICAR · A CONFIRMAR","Juego abierto: aplicar al motor. Juego cerrado: guardar para el próximo inicio. Se informa si existe un archivo anterior.",blue},
        {"04  X LEE EL ESTADO REAL","Las casillas son la próxima selección. ACTIVO EN EL MOTOR indica código habilitado; no demuestra su efecto.",green},
        {"05  CHEATS MANUALES","Copia config/NinMagicCheats/manual-cheats.zip en la microSD. Se importa al abrir o actualizar el catálogo.",violet},
        {"06  L QUITA MIS CHEATS","Recupera el estado registrado. Reinicia el juego si hace falta; los cambios guardados en la partida no se revierten.",orange}
    };
    for(int i=0;i<6;++i){int y=244+i*63;text(tips[i].label,449,y,12,tips[i].color);wrapped(tips[i].body,449,y+23,772,13,2,muted);if(i<5)rect(449,y+57,772,1,border);}
    footer({{"A","Volver"},{"B","Volver"},{"-","Cerrar ayuda"}});
}
uint32_t le32(const uint8_t*p){return p[0]|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
std::vector<uint8_t> readFile(const std::string&path){std::ifstream in(path,std::ios::binary);if(!in)return{};in.seekg(0,std::ios::end);auto n=in.tellg();if(n<0||n>4000000)return{};in.seekg(0);std::vector<uint8_t>b(static_cast<size_t>(n));in.read(reinterpret_cast<char*>(b.data()),n);return in?b:std::vector<uint8_t>{};}
} // namespace
bool uiInit(const std::string&assetRoot) {
    uiExit();auto data=readFile(assetRoot+"/font.bin");logo=readFile(assetRoot+"/logo.rgba");
    if(data.size()!=32+224+224*24*34||le32(data.data())!=0x54464D4E||le32(data.data()+4)!=32||le32(data.data()+8)!=224||le32(data.data()+12)!=24||le32(data.data()+16)!=34)return false;
    std::copy(data.begin()+32,data.begin()+256,advances.begin());rawFont.assign(data.begin()+256,data.end());for(int size:{10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,27,28,29,33,41})font(size);
    background.resize(W*H);Color*old=fb;int oldPitch=pitch;fb=background.data();pitch=W;
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){int a=std::max(0,310-(std::abs(x-1035)+std::abs(y-120))/2),b=std::max(0,230-(std::abs(x-120)+std::abs(y-620))/2);pixel(x,y,rgb(6+a/55+b/30,10+a/31+b/72,22+a/18+b/28));}
    const Color traces[]={rgb(20,48,63),rgb(27,39,70),rgb(48,28,65),rgb(58,35,43),rgb(30,49,39)};
    for(int i=0;i<5;++i){int x=735+i*113;auto c=traces[i];line(x,0,x,34+i*10,c);line(x,34+i*10,x+23,57+i*10,c);line(x+23,57+i*10,1279,57+i*10,c);rect(x-2,32+i*10,5,5,blend(rgb(5,10,22),i%2?pink:cyan,85));}
    for(int i=0;i<4;++i){int x=747+i*130;line(x,719,x,650-i*9,traces[i]);line(x,650-i*9,x+22,628-i*9,traces[i]);line(x+22,628-i*9,1279,628-i*9,traces[i]);}
    fb=old;pitch=oldPitch;return logo.size()==256*256*4;
}
void uiDraw(uint32_t*pixels,int stride,const View&view) {
    if(!pixels||stride<W)return;
    fb=pixels;pitch=stride;
    if(background.size()==W*H)for(int y=0;y<H;++y)std::memcpy(fb+y*pitch,background.data()+y*W,W*sizeof(Color));else rect(0,0,W,H,rgb(6,10,22));header(view);
    switch(view.screen){case Screen::Loading:loading(view,false);break;case Screen::Library:library(view);break;case Screen::Cheats:cheats(view);break;case Screen::Confirm:confirmation(view);break;case Screen::AppUpdate:appUpdate(view);break;case Screen::AppUpdateRecord:appUpdateRecord(view);break;case Screen::Busy:loading(view,true);break;case Screen::Result:result(view);break;case Screen::Help:help(view);break;default:help(view);break;}
}
void uiExit(){fonts.clear();rawFont.clear();logo.clear();background.clear();fb=nullptr;pitch=W;}
} // namespace nc

#include "app_update_ui.hpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool b){++checks;if(!b)throw std::runtime_error("update UI action guard");}}
int main(){try{
    nc::AppUpdateInfo u;nc::CompletedUpdateInfo r;
    check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.configured=u.available=true;u.runningVersion="1.4.5";u.version="1.4.7";u.sha256=std::string(64,'a');u.size=2500000;
    check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::Install);
    u.sdVerified=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size;
    check(nc::publishedAppOnSd(u)&&nc::differentAppOnSd(u));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.sdSha256=std::string(64,'b');check(!nc::publishedAppOnSd(u));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.sdVersion="1.4.4";check(nc::differentAppOnSd(u));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.sdVersion="1.4.6";check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.sdVersion=u.runningVersion;check(!nc::differentAppOnSd(u));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::Install);
    check(nc::appUpdateAction(u,r,"manifest failed")==nc::AppUpdateAction::None);
    r.state=nc::CompletedUpdateState::CanArchive;check(nc::appUpdateAction(u,r,"legacy record retained")==nc::AppUpdateAction::ReviewCompletedRecord);check(!nc::completedReviewReady(r));
    r.token="00000001";r.reviewSha256=std::string(64,'c');check(nc::completedReviewReady(r));
    u.sdVersion=u.version;u.sdSha256=u.sha256;check(nc::publishedAppOnSd(u));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::ReviewCompletedRecord);
    r.state=nc::CompletedUpdateState::Blocked;check(!nc::completedReviewReady(r));check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    r={};u.sdVersion=u.runningVersion;u.installed=true;check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.installed=false;u.available=false;check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.available=true;u.configured=false;check(nc::appUpdateAction(u,r,{})==nc::AppUpdateAction::None);
    u.configured=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size+1;check(!nc::publishedAppOnSd(u));
    u.sdSize=u.size;u.sdVerified=false;check(!nc::publishedAppOnSd(u)&&!nc::differentAppOnSd(u));
    std::cout<<"app update UI: "<<checks<<" action guards PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}

#pragma once
#include "model.hpp"
#include "scanner.hpp"
namespace nc {
bool platformInit(Environment &env,std::string &error);
void platformExit();
bool scanGames(std::vector<Game> &games,Environment &env,std::string &error);
bool resolveBuild(Game &game,Environment &env,std::string &error);
// Read only: counts loaded dmnt entries (including disabled entries and master)
// for this exact running game without attaching the cheat engine.
bool inspectActive(const Game &game,unsigned &count,std::string &error);
// Queries only an already attached engine. Does not attach, enable or disable.
bool readLiveState(Pack &pack,std::string &error);
Outcome applyLive(const Pack &pack);
Outcome removeLive(const Game &game);
// Read-only session lookup; does not attach dmnt or change cheat states.
bool peekScanProcess(const Game &game,ScanIdentity &identity,std::string &error);
// Only call after explicit scan-start confirmation. An initial dmnt attachment
// can load and enable the game's pre-existing SD cheat file.
bool getScanProcess(const Game &game,ScanIdentity &identity,std::string &error);
bool enumerateScanRegions(const ScanIdentity &identity,std::vector<ScanRegion> &regions,std::string &error);
// Read only, at most 256 KiB per call within one current mapping: exact-RW
// MAIN/HEAP pages, or Heap-type
// pages inside the verified Alias interval. No mapping permission is cached.
bool readScanMemory(const ScanIdentity &identity,uint64_t address,void *buffer,size_t size,std::string &error);
// Worker-thread counters for the current read operation. Contains no process
// identity, addresses or memory values. Read before resetScanReadSession().
struct ScanReadStats {
    uint64_t completedReads=0,completedBytes=0;
    // Fresh fast-path metadata calls only. Full-proof IPC/time is accounted
    // separately, so these fields do not count its internal metadata calls.
    uint64_t metadataCalls=0,metadataFailures=0,metadataNs=0;
    uint64_t fullProofCalls=0,fullProofFailures=0,fullProofNs=0;
    uint64_t queryCalls=0,queryFailures=0,queryNs=0;
    uint64_t readCalls=0,readFailures=0,attemptedReadBytes=0,readNs=0;
    // Total checked-call time includes the preceding phase timings.
    uint64_t checkedCalls=0,checkedFailures=0,checkedNs=0;
};
ScanReadStats scanReadStats();
// Worker-thread only: delimit a scan/read operation and discard its loader
// proof cache on completion, cancellation or error. Never changes engine state.
void resetScanReadSession();
}

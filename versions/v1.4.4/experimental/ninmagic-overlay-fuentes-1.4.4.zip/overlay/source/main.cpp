#define TESLA_INIT_IMPL
#include <tesla.hpp>
#include "controller.hpp"
#include "ui_text.hpp"
#include <algorithm>
#include <array>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

namespace {
using Renderer=tsl::gfx::Renderer;
using Color=tsl::Color;
constexpr Color ink{14,15,15,15},muted{9,11,13,15},dim{5,7,9,15};
constexpr Color cyan{3,14,15,15},pink{15,5,12,15},lime{11,15,5,15},orange{15,10,4,15},violet{11,8,15,15},blue{4,9,15,15};
constexpr Color navy{0,1,2,14},panel{1,2,3,15},edge{2,4,5,15};
enum class Page { List, ConfirmApply, ConfirmRemove, Details, Result, Help };
Page page=Page::List;
bool rightSide=false,awaitingResult=false,awaitingSearch=false,pendingRemove=false;
bool resultKnown=false,resultOk=false,resultRemove=false;
std::string message,resultMessage;
nc::Game resultGame;
std::array<uint8_t,64*64*4> logo{};
bool hasLogo=false;
nc::overlay::Snapshot state;
u32 measure(Renderer*r,const std::string&s,int size){return r->drawString(s.c_str(),false,0,0,float(size),Color{0,0,0,0}).first;}
std::string fitLabel(Renderer*r,const std::string&s,int size,int maxWidth){
    if(maxWidth<=0)return {};
    if(!nc::ui_text::validUtf8(s))return "Texto no válido";
    if(measure(r,s,size)<=unsigned(maxWidth))return s;
    const std::string suffix="...";if(measure(r,suffix,size)>unsigned(maxWidth))return {};
    std::vector<size_t>ends;for(size_t at=0;at<s.size();){uint32_t cp=0;nc::ui_text::nextUtf8(s,at,cp);ends.push_back(at);}
    size_t lo=0,hi=ends.size();while(lo<hi){const size_t mid=(lo+hi+1)/2;const auto test=s.substr(0,ends[mid-1])+suffix;if(measure(r,test,size)<=unsigned(maxWidth))lo=mid;else hi=mid-1;}
    return (lo?s.substr(0,ends[lo-1]):std::string{})+suffix;
}
void label(Renderer*r,const std::string&s,int x,int y,int size=18,Color c=ink,int maxWidth=402){const auto t=fitLabel(r,s,size,maxWidth);r->drawString(t.c_str(),false,x,y,float(size),c);}
int exactSize(Renderer*r,const std::string&s,int size,int maxWidth){while(size>11&&measure(r,s,size)>unsigned(maxWidth))--size;return size;}
void exactValue(Renderer*r,const std::string&s,int x,int y,int size=18,Color c=ink,int maxWidth=402){r->drawString(s.c_str(),false,x,y,float(exactSize(r,s,size,maxWidth)),c);}
void wrap(Renderer*r,const std::string&s,int x,int y,int width,int size,int maxLines,Color c=muted){
    std::string line,word;int n=0;size_t at=0;
    while(at<s.size()&&n<maxLines){while(at<s.size()&&s[at]==' ')++at;const auto end=s.find(' ',at);word=s.substr(at,end==std::string::npos?end:end-at);at=end==std::string::npos?s.size():end+1;
        if(word.empty())continue;
        const auto trial=line.empty()?word:line+" "+word;
        if(!line.empty()&&r->drawString(trial.c_str(),false,0,0,float(size),Color{0,0,0,0}).first>static_cast<u32>(width)){
            label(r,line,x,y+n*(size+9),size,c,width);++n;line=word;
        }else line=trial;
        if(n==maxLines-1&&at<s.size()){line+=" "+s.substr(at);at=s.size();}
    }
    if(!line.empty()&&n<maxLines)label(r,line,x,y+n*(size+9),size,c,width);
}
void box(Renderer*r,int x,int y,int w,int h,Color fill=panel,Color border=edge){r->drawRect(x,y,w,h,fill);r->drawRect(x,y,w,1,border);r->drawRect(x,y+h-1,w,1,border);r->drawRect(x,y,1,h,border);r->drawRect(x+w-1,y,1,h,border);}
void stripe(Renderer*r,int y,int x=18,int width=412){const Color colors[]={cyan,blue,violet,pink,orange,lime};for(int i=0;i<6;++i)r->drawRect(x+i*width/6,y,(i==5?width-i*width/6:width/6),2,colors[i]);}
void loadLogo(){
#ifdef __SWITCH__
    // RomFS locates this OVL through its SD path. Copy the small logo before
    // starting the worker, then release both mounts so the worker owns its SD.
    hasLogo=false;
    if(R_FAILED(fsdevMountSdmc()))return;
    struct SdGuard {~SdGuard(){fsdevUnmountDevice("sdmc");}} sd;
    if(R_FAILED(romfsInit()))return;
    struct RomGuard {~RomGuard(){romfsExit();}} rom;
    FILE*f=std::fopen("romfs:/logo.rgba","rb");if(!f)return;std::array<uint8_t,256*4>rowBytes{};bool ok=true;
    for(unsigned y=0;y<64&&ok;++y){if(std::fseek(f,long(y*4*256*4),SEEK_SET)||std::fread(rowBytes.data(),1,rowBytes.size(),f)!=rowBytes.size()){ok=false;break;}for(unsigned x=0;x<64;++x)for(unsigned c=0;c<4;++c)logo[(y*64+x)*4+c]=rowBytes[x*16+c];}
    if(std::fclose(f)!=0)ok=false;
    hasLogo=ok;
#endif
}
void footer(Renderer*r,const std::string&first,const std::string&second="B  Volver",Color c=muted){r->drawRect(18,655,412,1,edge);label(r,first,22,683,14,c,404);label(r,second,22,707,12,muted,404);}
void place(){Renderer::setLayerPos(rightSide?tsl::cfg::ScreenWidth-tsl::cfg::LayerWidth:0,0);}
void refreshState(){state=nc::overlay::snapshot();}
void finishSearch(){if(awaitingSearch&&!state.busy){awaitingSearch=false;message.clear();}}
void consumeResult(){if(!awaitingResult||state.busy)return;resultKnown=true;resultOk=state.error.empty();resultRemove=pendingRemove;resultMessage=resultOk?state.status:state.error;resultGame=state.game;awaitingResult=false;page=Page::Result;}
const nc::overlay::PublishedItem*currentItem(){const auto it=std::find_if(state.items.begin(),state.items.end(),[](const auto&i){return i.index==state.highlighted;});return it==state.items.end()?nullptr:&*it;}
nc::CheatState checkedState(const nc::overlay::PublishedItem&i){return state.liveChecked&&state.game.running?i.liveState:nc::CheatState::Unknown;}
std::string stateLabel(nc::CheatState s){switch(s){case nc::CheatState::Enabled:return "ON";case nc::CheatState::Disabled:return "OFF";case nc::CheatState::NotLoaded:return "SIN CARGAR";case nc::CheatState::Unknown:return "SIN COMPROBAR";}return "SIN COMPROBAR";}
Color stateColor(nc::CheatState s){return s==nc::CheatState::Enabled?lime:s==nc::CheatState::Disabled?orange:s==nc::CheatState::NotLoaded?blue:violet;}
void header(Renderer*r){
    r->fillScreen(navy);r->drawRect(447,0,1,720,edge);
    if(hasLogo)r->drawBitmap(20,17,64,64,logo.data());else label(r,"NM",26,58,31,cyan,65);
    label(r,"NINMAGIC",98,45,25);label(r,"CHEATS PUBLICADOS",100,68,12,cyan);stripe(r,96);
    const auto&game=page==Page::Result&&resultKnown?resultGame:state.game;
    wrap(r,game.name.empty()?"Sin juego abierto":game.name,21,122,406,18,2,ink);
    label(r,game.version.empty()?"Versión no declarada":"v"+game.version,22,171,12,cyan,250);
    label(r,!game.buildVerified?"SIN COMPROBAR":game.running?"JUEGO ABIERTO":"JUEGO CERRADO",281,171,10,game.buildVerified&&game.running?lime:violet,147);
    label(r,game.id?nc::hexId(game.id):"TITLE ID SIN COMPROBAR",22,195,11,muted,220);
    label(r,game.buildVerified?game.buildId:"BID SIN COMPROBAR",256,195,11,game.buildVerified?cyan:orange,174);
}
void note(Renderer*r,const std::string&fallback=""){
    const auto&detail=!message.empty()?message:!state.error.empty()?state.error:!fallback.empty()?fallback:state.status;
    if(!detail.empty())wrap(r,detail,28,592,392,12,2,!message.empty()||!state.error.empty()?orange:muted);
}
void drawEmpty(Renderer*r){
    box(r,18,216,412,425);stripe(r,216);
    const bool unresolved=state.game.id&&!state.game.buildVerified;
    const bool incomplete=state.lookupState==nc::LookupState::Incomplete,complete=state.lookupState==nc::LookupState::Complete;
    label(r,state.searching?"BUSCANDO CHEATS ONLINE":state.busy?"COMPROBANDO LISTA GUARDADA":unresolved?"BUILD ID SIN COMPROBAR":!state.game.running?"ABRE UN JUEGO REAL":incomplete?"CONSULTA INCOMPLETA":!state.cacheAvailable?"BUSCA LOS CHEATS DE ESTE JUEGO":!complete?"LISTA GUARDADA SIN COMPROBAR":"SIN CHEATS COMPATIBLES",30,244,12,state.busy?pink:orange,388);
    wrap(r,state.searching?"Comprobando el juego y consultando fuentes de cheats.":state.busy?"Comprobando el juego y su lista guardada...":unresolved?"Falta comprobar la versión de este juego.":!state.game.running?"Abre el juego y vuelve a este overlay.":incomplete?"No se pudo completar la consulta de cheats.":!state.cacheAvailable?"Pulsa X para buscar cheats online.":!complete?"La lista guardada no confirma la consulta online actual.":"No compatible con esta versión.",30,287,388,23,4,ink);
    wrap(r,state.searching?"Puedes seguir jugando con B. La consulta no activa ningún cheat. X cancela la búsqueda.":state.busy?"Esta comprobación usa la lista guardada. X busca o actualiza online cuando termine.":unresolved?"X vuelve a comprobar el juego. No se puede decidir la compatibilidad sin verificar su Build ID.":!state.game.running?"Mantén el juego real abierto. X buscará sus cheats publicados para el Build ID comprobado.":incomplete?"No se ha confirmado si hay cheats para este Build ID. X vuelve a intentarlo.":!complete?"X consulta las fuentes online. Una copia local vacía no confirma que falten cheats.":"No se encontraron cheats publicados para este Build ID en las fuentes consultadas. X vuelve a buscar online.",30,425,388,17,5,muted);
    note(r,incomplete?state.lookupDetail:std::string{});
    footer(r,state.searching?"X  Cancelar consulta · B  Seguir jugando":state.busy?"Operación en curso · B  Seguir jugando":"X  Buscar/actualizar cheats",state.busy?"Espera a que termine para salir":"L  Quitar · B  Jugar · +  Menú de overlays");
}
void drawList(Renderer*r){
    if(!state.ready||!state.totalItems||state.items.empty()){drawEmpty(r);return;}
    const bool incomplete=state.lookupState==nc::LookupState::Incomplete;
    box(r,18,216,412,51);label(r,"A MARCA · MARCAR NO ACTIVA",29,237,10,cyan,280);
    label(r,std::to_string(state.selectedCount)+(state.selectedCount==1?" marcado":" marcados"),323,237,10,cyan,95);
    label(r,state.searching?"BUSCANDO CHEATS ONLINE":state.busy?"OPERACIÓN EN CURSO":incomplete?"CONSULTA INCOMPLETA · LISTA GUARDADA":state.liveChecked?"ESTADO: LECTURA DEL MOTOR":"ESTADO: SIN COMPROBAR",29,257,10,state.busy?pink:incomplete?orange:state.liveChecked?lime:violet,388);
    size_t row=0;for(const auto&i:state.items){if(row==8)break;const int y=279+int(row++)*34;const bool selected=i.index==state.highlighted;
        if(selected){box(r,18,y-1,412,34,Color{1,3,4,15},cyan);r->drawRect(18,y-1,3,34,cyan);}
        const bool blocked=!i.blockedReason.empty();box(r,29,y+5,19,19,panel,i.selected?cyan:blocked?orange:edge);if(i.selected){r->drawRect(33,y+9,11,11,cyan);}
        const auto actual=checkedState(i);label(r,i.label.empty()?i.name:i.label,60,y+15,16,blocked?orange:selected?ink:muted,246);
        label(r,stateLabel(actual),322,y+14,11,stateColor(actual),102);
        label(r,blocked?"EN REVISIÓN · "+i.name:i.label==i.name?i.source:i.name,61,y+29,10,blocked?orange:dim,355);
    }
    if(state.totalItems>8){const int height=std::max(18,int(265*8/state.totalItems));r->drawRect(433,280,2,265,edge);r->drawRect(433,280+int(state.firstItem*(265-height)/std::max(size_t(1),state.totalItems-8)),2,height,pink);}
    box(r,18,565,412,77);const auto*item=currentItem();
    const bool blocked=item&&!item->blockedReason.empty();label(r,state.searching?"CONSULTANDO FUENTES ONLINE":blocked?"COMPATIBILIDAD EN REVISIÓN":incomplete?"AVISO DE CONSULTA · DATOS GUARDADOS":!message.empty()||!state.error.empty()?"REQUIERE ATENCIÓN":"ORIGINAL / BOTONES DEL AUTOR",29,582,10,blocked||incomplete||!message.empty()||!state.error.empty()?orange:pink,390);
    if(state.searching||incomplete||!message.empty()||!state.error.empty())note(r,!state.searching&&incomplete?state.lookupDetail:std::string{});else if(item)wrap(r,blocked?item->blockedReason:item->name,29,603,389,12,2,blocked?orange:muted);
    footer(r,state.searching?"X  Cancelar consulta · B  Seguir jugando":state.busy?"Operación en curso · B  Seguir jugando":"A  Marcar · Y  Revisar · X  Buscar/actualizar",state.busy?"Espera a que termine para salir":"L  Quitar · R  Detalle · B  Jugar · +  Salir");
}
void drawConfirmApply(Renderer*r){
    if(!state.blockedSelectionReason.empty()){label(r,"SELECCIÓN BLOQUEADA · EN REVISIÓN",22,235,12,orange);wrap(r,state.blockedSelectionReason,24,291,400,22,6,ink);wrap(r,"Vuelve y desmarca los códigos en revisión. L permite retirar los códigos de NinMagic que ya estaban activos.",24,500,400,17,5,muted);footer(r,"B  Volver a la lista","");return;}
    label(r,"CONFIRMA LOS CHEATS MARCADOS",22,235,12,cyan);
    exactValue(r,std::to_string(state.selectedCount)+(state.selectedCount==1?" seleccionado":" seleccionados"),23,283,27,ink);
    size_t row=0;for(const auto&name:state.selectedNames){if(row==4)break;label(r,name,25,326+int(row++)*36,17,muted,398);}
    if(state.selectedCount>row)label(r,"+ "+std::to_string(state.selectedCount-row)+" más en la selección",25,479,14,violet);
    wrap(r,"Se habilitarán los marcados para este juego y Build ID. Los demás conservan su estado. L retira los códigos de NinMagic.",24,526,400,16,3,muted);
    label(r,"Conserva los botones y condiciones del autor.",24,635,12,orange);
    footer(r,"A  Confirmar aplicación","B  Volver a la lista",cyan);
}
void drawConfirmRemove(Renderer*r){
    label(r,"QUITAR LOS CHEATS DE NINMAGIC",22,235,12,orange);
    wrap(r,"Se retirarán las entradas añadidas por NinMagic a esta sesión y se recuperarán los estados anteriores registrados.",24,291,400,23,5,ink);
    wrap(r,"Retirar códigos no restaura necesariamente los valores ya cambiados ni una partida guardada. Reinicia el juego si hace falta.",24,477,400,18,5,muted);
    footer(r,"A  Confirmar retirada","B  Cancelar",orange);
}
void drawDetails(Renderer*r){
    const auto*item=currentItem();label(r,"CONDICIONES DEL CHEAT",22,235,12,pink);
    if(!item){wrap(r,"Vuelve a la lista y elige un cheat.",24,291,400,22,3);footer(r,"B  Volver","");return;}
    wrap(r,item->label.empty()?item->name:item->label,24,278,400,21,3,ink);
    label(r,"NOMBRE ORIGINAL",24,385,11,pink);wrap(r,item->name,24,418,400,16,4,muted);
    label(r,stateLabel(checkedState(*item))+" · "+item->source,24,540,13,stateColor(checkedState(*item)),400);
    wrap(r,item->blockedReason.empty()?item->detail:item->blockedReason,24,578,400,13,3,item->blockedReason.empty()?muted:orange);footer(r,"B  Volver a la lista","");
}
void drawResult(Renderer*r){
    const bool known=resultKnown||state.lastActionKnown,ok=resultKnown?resultOk:state.lastActionOk,removed=resultKnown?resultRemove:state.lastActionRemove;
    label(r,!known?"INFORME":!ok?"NO SE COMPLETÓ":removed?"INFORME DE RETIRADA":"CHEATS HABILITADOS",22,235,12,!known||!ok?orange:removed?cyan:lime);
    wrap(r,resultKnown?resultMessage:state.lastActionKnown?state.lastAction:!state.error.empty()?state.error:state.status,24,290,400,21,9,ink);
    label(r,"Puedes volver a la lista o continuar en el juego.",24,636,12,muted);footer(r,"B  Volver a la lista","+  Salir al menú de overlays");
}
void drawHelp(Renderer*r){
    label(r,"ELIGE, APLICA Y JUEGA",22,235,12,pink);
    const char*steps[]={"1  Abre el juego y este overlay. X busca o actualiza sus cheats online por Build ID.","2  A marca opciones. ON/OFF muestra el estado leído del motor, separado de las casillas.","3  Y revisa la selección. A en la confirmación aplica al juego abierto.","4  R enseña el nombre original y las condiciones. L pide confirmar la retirada.","5  B vuelve al juego desde la lista. ZL cambia el lado. + sale al menú de overlays."};
    for(int i=0;i<5;++i)wrap(r,steps[i],24,282+i*68,400,16,3,i==2?cyan:muted);
    footer(r,"B  Volver a la lista","La aplicación es opcional para importar o ver listas grandes");
}
class Canvas final:public tsl::elm::Element {
public:explicit Canvas(std::function<void(Renderer*)>draw):render(std::move(draw)){}void draw(Renderer*r)override{render(r);}void layout(u16 x,u16 y,u16 w,u16 h)override{setBoundaries(x,y,w,h);}private:std::function<void(Renderer*)>render;
};
class NinMagicGui final:public tsl::Gui {
public:
    tsl::elm::Element*createUI()override{return new Canvas([this](Renderer*r){draw(r);});}
    void update()override{refreshState();finishSearch();consumeResult();}
    bool handleInput(u64,u64,const HidTouchState&,HidAnalogStickState,HidAnalogStickState)override;
private:void draw(Renderer*r){header(r);switch(page){case Page::List:drawList(r);break;case Page::ConfirmApply:drawConfirmApply(r);break;case Page::ConfirmRemove:drawConfirmRemove(r);break;case Page::Details:drawDetails(r);break;case Page::Result:drawResult(r);break;case Page::Help:drawHelp(r);break;}}
};
void hideForGame(){tsl::Overlay::get()->hide();}
void refused(){refreshState();message=state.error.empty()?"No se pudo iniciar la operación. Revisa el juego y espera a que termine la consulta.":state.error;}
bool NinMagicGui::handleInput(u64 keys,u64 held,const HidTouchState&,HidAnalogStickState,HidAnalogStickState){
    (void)held;
    if(keys&HidNpadButton_Plus){if(!state.busy)tsl::Overlay::get()->close();else message="Espera a que termine la operación antes de salir.";return true;}
    if(keys&HidNpadButton_B){if(page==Page::List)hideForGame();else{page=Page::List;message.clear();}return true;}
    if(keys&HidNpadButton_ZL){rightSide=!rightSide;place();return true;}
    if(keys&HidNpadButton_Minus){page=Page::Help;return true;}
    if(state.busy){if(state.searching&&(keys&HidNpadButton_X)){nc::overlay::cancel();message="Cancelando la consulta online...";}return true;}
    if(page==Page::ConfirmApply){if(keys&HidNpadButton_A){if(!state.blockedSelectionReason.empty()){page=Page::List;message=state.blockedSelectionReason;}else if(state.canApply&&state.selectedCount&&nc::overlay::apply()){awaitingResult=true;pendingRemove=false;resultKnown=false;page=Page::List;message.clear();refreshState();}else{page=Page::List;refused();}}return true;}
    if(page==Page::ConfirmRemove){if(keys&HidNpadButton_A){if(nc::overlay::remove()){awaitingResult=true;pendingRemove=true;resultKnown=false;page=Page::List;message.clear();refreshState();}else{page=Page::List;refused();}}return true;}
    if(page!=Page::List)return true;
    if(keys&HidNpadButton_X){message.clear();if(!nc::overlay::search())refused();else{awaitingSearch=true;refreshState();}return true;}
    if(keys&HidNpadButton_L){if(state.game.running&&state.game.buildVerified)page=Page::ConfirmRemove;else message="Abre el juego real para retirar sus cheats de esta sesión.";return true;}
    if(keys&HidNpadButton_Y){const auto*item=currentItem();if(!state.blockedSelectionReason.empty())message=state.blockedSelectionReason;else if(state.ready&&state.canApply&&state.selectedCount)page=Page::ConfirmApply;else if(!state.selectedCount&&item&&!item->blockedReason.empty())message=item->blockedReason;else message=state.selectedCount?"Busca o actualiza con X antes de aplicar.":"Marca los cheats que quieras usar con A.";return true;}
    if(keys&HidNpadButton_R){if(currentItem())page=Page::Details;return true;}
    if(state.ready&&state.totalItems){
        if(keys&(HidNpadButton_Up|HidNpadButton_Down)){message.clear();if(!nc::overlay::move(keys&HidNpadButton_Up?-1:1))refused();else refreshState();return true;}
        if(keys&HidNpadButton_A){const auto*item=currentItem();if(item){if(!item->selected&&!item->blockedReason.empty()){message=item->blockedReason;return true;}const auto index=item->index;message.clear();if(!nc::overlay::toggle(index))refused();else refreshState();}return true;}
    }
    return true;
}
class NinMagicOverlay final:public tsl::Overlay {
public:
    void initServices()override{loadLogo();std::string error;if(!nc::overlay::init(error))message=error;else nc::overlay::refresh();}
    void exitServices()override{nc::overlay::shutdown();}
    void onShow()override{place();refreshState();if(awaitingResult){consumeResult();return;}if(awaitingSearch){finishSearch();page=Page::List;return;}if(page!=Page::Result)page=Page::List;if(!state.busy)nc::overlay::refresh();}
    std::unique_ptr<tsl::Gui>loadInitialGui()override{return initially<NinMagicGui>();}
};
}
int main(int argc,char**argv){return tsl::loop<NinMagicOverlay>(argc,argv);}

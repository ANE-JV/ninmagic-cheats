#define NC_CATALOG_TEST
#include "../source/catalog.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <minizip/zip.h>
namespace fs=std::filesystem;
namespace {
unsigned checks=0;
void require(bool ok,const char *message){++checks;if(!ok){std::cerr<<"FAILED: "<<message<<"\n";std::exit(1);}}
void makeZip(const std::string &path,const std::vector<std::pair<std::string,std::string>> &files){zipFile z=zipOpen64(path.c_str(),APPEND_STATUS_CREATE);require(z,"open synthetic archive");for(const auto &f:files){zip_fileinfo m{};m.external_fa=0100644u<<16;require(zipOpenNewFileInZip64(z,f.first.c_str(),&m,nullptr,0,nullptr,0,nullptr,0,0,0)==ZIP_OK,"open member");require(zipWriteInFileInZip(z,f.second.data(),unsigned(f.second.size()))==ZIP_OK&&zipCloseFileInZip(z)==ZIP_OK,"write member");}require(zipClose(z,nullptr)==ZIP_OK,"close ZIP");}
}
int main(int argc,char **argv){
    require(argc>=2&&argc<=6,"explicit fresh fixture directory and optional real source files");const auto base=fs::absolute(argv[1]);fs::create_directories(base);const auto dir=(base/"cache").generic_string();setenv("NC_CATALOG_ROOT",dir.c_str(),1);
    nc::Game game;game.id=0x01007300020FA000ULL;game.buildId="4B159F0F7A360669";game.fullBuildId=game.buildId+std::string(48,'0');game.buildVerified=game.running=true;
    const auto tid=nc::hexId(game.id),member="contents/"+tid+"/cheats/"+game.buildId+".txt";
    const std::string a="[Synthetic health]\n04000000 00000100 00000009\n",b="[Synthetic money]\n04000000 00000200 00000032\n",c="[Synthetic ammunition]\n04000000 00000300 00000064\n";
    const auto general=(base/"general.zip").generic_string(),nx=(base/"nx.zip").generic_string(),raw=(base/"raw.zip").generic_string(),sthetix=(base/"sthetix.zip").generic_string();
    const std::string irrelevant="UNRELATED CRC BODY MUST NOT BE INFLATED";
    makeZip(general,{{member,a},{"contents/01007300020FA001/cheats/4B159F0F7A360670.txt",irrelevant}});makeZip(nx,{{member,b}});makeZip(raw,{});
    makeZip(sthetix,{{member,"[Synthetic extra source]\n04000000 00000400 00000001\n"}});
    std::string bytes;require(nc::readSmall(general,bytes,size_t(nc::MaxArchive)),"read synthetic ZIP");const auto damaged=bytes.find(irrelevant);require(damaged!=std::string::npos,"find unrelated stored body");bytes[damaged]^=1;require(nc::writeSmall(general,bytes),"damage only unrelated CRC");
    unsigned gets=0,heads=0;bool offline=false,missing=false,invalidPlain=false,cancelNow=false,stopOnGet=false,oldLowerOnly=false;
    nc::testNetworkReady=true;
    nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &error,nc::RemoteStamp *stamp,bool head){
        if(stamp)*stamp={"\"stable\"","Tue, 27 Oct 2026 00:00:00 GMT","123",200};
        if(offline){error="Synthetic offline";return false;}if(head){++heads;return true;}++gets;
        if(stopOnGet){cancelNow=true;error="Synthetic cancellation";return false;}
        if(url==nc::GeneralUrl||url==nc::RawUrl||url==nc::NxCodeUrl||url==nc::SthetixUrl){const auto input=url==nc::GeneralUrl?general:url==nc::RawUrl?raw:url==nc::NxCodeUrl?nx:sthetix;fs::copy_file(input,path,fs::copy_options::overwrite_existing);return true;}
        if(oldLowerOnly&&url.find("OldManKain")!=std::string::npos&&url.find(game.buildId)!=std::string::npos){if(stamp)stamp->status=404;error="Synthetic uppercase-only missing";return false;}
        if(missing||(url.find(game.buildId)==std::string::npos&&url.find("4b159f0f7a360669")==std::string::npos)){if(stamp)stamp->status=404;error="Synthetic404";return false;}
        return nc::writeSmall(path,invalidPlain?"<html>not code</html>":c);
    };
    nc::Pack pack;std::vector<nc::CheatSourceReport> reports;std::string error;
    auto invalid=game;invalid.fullBuildId.clear();require(!nc::findPublishedGameDirect(invalid,false,pack,reports,error)&&gets==0&&reports.empty()&&pack.detail.find("No se pudo")!=std::string::npos,"missing full BID is an unperformed query, not no-cheats claim");
    nc::testInflatedBytes=0;
    require(nc::findPublishedGameDirect(game,false,pack,reports,error)&&pack.compatible&&pack.cheats.size()==4&&reports.size()==6,"direct query combines all six exact sources without a global catalog");
    require(std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const nc::Cheat &v){return v.source=="sthetix/nx-cheats-db";}),"new source is actually included, not only reported");
    require(!fs::exists(base/"cache"/"catalog-a")&&!fs::exists(base/"cache"/"catalog-b"),"no global slot/index loaded or manufactured");
    require(nc::testInflatedBytes<4096,"only requested ZIP members are inflated; unrelated CRC damage ignored");
    require(std::any_of(pack.cheats.begin(),pack.cheats.end(),[](const nc::Cheat &v){return v.source.find("MyNXCheats")!=std::string::npos&&v.source.find("ibnux")!=std::string::npos;}),"equivalent source options deduplicate and retain both origins");
    require(gets==6,"three complete snapshots and three exact text requests; no raw when primary complete matches");
    for(const auto &r:reports)require(r.checked&&r.cached&&r.found&&r.httpStatus==200,"per-source online status is explicit");
    const auto priorGets=gets,priorHeads=heads;const auto p=nc::gameProviders(game)[0];const auto marker=nc::providerPath(game,p)+".checked";std::string timeBefore;require(nc::readSmall(marker,timeBefore,4096),"read checked timestamp");
    require(nc::findPublishedGameDirect(game,false,pack,reports,error)&&gets==priorGets&&heads==priorHeads,"six-hour reuse performs no network");
    std::string timeAfter;require(nc::readSmall(marker,timeAfter,4096)&&timeBefore==timeAfter,"local reuse does not postpone real freshness checks");
    for(const auto &r:reports)require(!r.checked&&r.cached,"cache reuse never claims online check");
    offline=true;require(!nc::findPublishedGameDirect(game,true,pack,reports,error)&&pack.compatible&&pack.cheats.size()==4&&!error.empty(),"offline query yields verified exact cached options with incomplete status");offline=false;
    invalidPlain=true;require(!nc::findPublishedGameDirect(game,true,pack,reports,error)&&pack.cheats.size()==4,"malformed upstream text retains previous exact options");invalidPlain=false;
    missing=true;require(nc::findPublishedGameDirect(game,true,pack,reports,error)&&pack.cheats.size()==4,"404 preserves matching previously published text");missing=false;
    oldLowerOnly=true;require(nc::findPublishedGameDirect(game,true,pack,reports,error)&&reports.back().source=="OldManKain/Switch-Cheats-Mods-Saves"&&reports.back().httpStatus==200&&reports.back().url.find("4b159f0f7a360669.txt")!=std::string::npos,"one historical provider tries only the same exact BID in lowercase after uppercase404");oldLowerOnly=false;
    auto other=game;other.buildId="4B159F0F7A360671";other.fullBuildId=other.buildId+std::string(48,'0');
    require(nc::findPublishedGameDirect(other,false,pack,reports,error)&&!pack.compatible&&pack.cheats.empty(),"complete negative query never substitutes another BID");
    const auto cached=nc::providerPath(game,p);std::string old;require(nc::readSmall(cached,old,nc::DirectText+4096),"record verified source cache");
    cancelNow=true;require(!nc::findPublishedGameDirect(game,true,pack,reports,error,[&]{return cancelNow;})&&error.find("cancelada")!=std::string::npos,"cancel before query is explicit");cancelNow=false;
    stopOnGet=true;require(!nc::findPublishedGameDirect(game,true,pack,reports,error,[&]{return cancelNow;}),"cancel during download is incomplete");stopOnGet=cancelNow=false;
    std::string still;require(nc::readSmall(cached,still,nc::DirectText+4096)&&still==old,"cancellation preserves confirmed per-game codes byte for byte");
    std::vector<nc::Cheat> parsed,generalParsed;
    const std::string master="{Synthetic master}\n04000000 00000000 00000001\n";
    require(nc::parseDirect("\xef\xbb\xbf"+master+a,"A",parsed,error)&&nc::parseCheats("\xef\xbb\xbf"+master+a,"A",generalParsed,error)&&parsed.size()==generalParsed.size()&&parsed[0].opcodes==generalParsed[0].opcodes&&parsed[1].name==generalParsed[1].name,"bounded parser preserves the general parser's author semantics");
    std::string many;for(unsigned n=0;n<129;++n)many+="[Option"+std::to_string(n)+"]\n04000000 00000000 00000001\n";
    require(!nc::parseDirect(many,"too many",parsed,error)&&parsed.empty(),"oversized option source rejected wholly, never truncated");
    makeZip(general,{{member,a},{"titles/"+tid+"/cheats/"+game.buildId+".txt",b}});bool found=false;std::string text;
    require(!nc::zipExact(general,game,text,found,error)&&!found&&text.empty(),"duplicate exact identity rejected without choosing an arbitrary source member");
    makeZip(general,{{member,"[Invalid author file]\nNOT OPCODES\n"}});
    const auto savedZip=nc::providerRoot()+"/hamlet-latest.zip";std::string priorZip,afterZip;
    require(nc::readSmall(savedZip,priorZip,size_t(nc::MaxArchive)),"record previously verified direct ZIP");
    require(nc::removeOutput(savedZip+".remote",error),"force validation of newly published ZIP");
    require(!nc::findPublishedGameDirect(game,true,pack,reports,error)&&pack.compatible,"invalid target syntax is an incomplete query with cached options");
    require(nc::readSmall(savedZip,afterZip,size_t(nc::MaxArchive))&&priorZip==afterZip,"CRC-valid but invalid author target never replaces old usable ZIP");
    fs::copy_file(savedZip,savedZip+".previous",fs::copy_options::overwrite_existing);require(nc::writeSmall(savedZip,"corrupt current ZIP"),"damage current while retaining valid previous ZIP");
    makeZip(general,{{member,a}});const auto getsBeforeRecovery=gets,headsBeforeRecovery=heads;nc::CheatSourceReport recovered;recovered.source="Hamlet";found=false;text.clear();error.clear();
    require(nc::refreshDirectZip(game,"hamlet-latest",nc::GeneralUrl,false,text,found,recovered,error)&&found&&recovered.checked,"previous-only recovery forces a fresh verified download");
    require(gets==getsBeforeRecovery+1&&heads==headsBeforeRecovery,"previous archive never reuses another file's recent TTL or unchanged ETag");
    std::string diagnostic;require(nc::readSmall(nc::providerRoot()+"/last-query.txt",diagnostic,32*1024)&&diagnostic.find("NINMAGIC-SOURCES-1")==0,"source diagnostics persist separately from game memory");
    if(argc>=3){
        nc::Game actual;actual.id=0x01006BB00C6F0000ULL;actual.buildId="909E904AF78AC1B8";actual.fullBuildId=actual.buildId+std::string(48,'0');actual.buildVerified=true;
        for(int file=2;file<argc&&file<4;++file){
            const auto before=nc::testInflatedBytes;found=false;text.clear();error.clear();
            require(nc::zipExact(argv[file],actual,text,found,error)&&found,"real archive targeted lookup succeeds without global index");
            require(nc::testInflatedBytes-before==text.size(),"real archive inflates only requested member bytes");
            require(nc::parseDirect(text,"Actual source audit",parsed,error)&&!parsed.empty(),"real requested member passes bounded parser");
            std::cout<<"real archive "<<file<<": target bytes="<<text.size()<<" definitions="<<parsed.size()<<"\n";
        }
    }
    if(argc>=5){require(nc::readDirectFile(argv[4],text)&&nc::parseDirect(text,"Actual author payload",parsed,error),"real canonical text source passes bounded parser");std::cout<<"real text: bytes="<<text.size()<<" definitions="<<parsed.size()<<"\n";}
    if(argc==6){
        const auto wonderRoot=(base/"wonder-exact").generic_string();setenv("NC_CATALOG_ROOT",wonderRoot.c_str(),1);
        nc::Game wonder;wonder.id=0x010015100B514000ULL;wonder.buildId="FF773E90972D544E";wonder.fullBuildId="FF773E90972D544EB79406EAA65396D53C43EFB9000000000000000000000000";wonder.buildVerified=wonder.running=true;
        const auto oldTransfer=nc::testTransfer;
        nc::testTransfer=[&](const std::string &url,const std::string &path,std::string &why,nc::RemoteStamp *stamp,bool head){if(url==nc::SthetixUrl){if(stamp)*stamp={"\"actual\"","Fri, 26 Sep 2026 00:00:00 GMT","8550804",200};if(!head)fs::copy_file(argv[5],path,fs::copy_options::overwrite_existing);return true;}return oldTransfer(url,path,why,stamp,head);};
        const auto before=nc::testInflatedBytes;error.clear();
        require(nc::findPublishedGameDirect(wonder,true,pack,reports,error)&&pack.compatible&&pack.cheats.size()==11,"real new provider resolves exact Wonder FF77 without other-version substitution");
        size_t words=0;for(const auto &v:pack.cheats){words+=v.opcodes.size();require(v.source=="sthetix/nx-cheats-db"&&!v.master,"real new options retain author source and no invented masters");}
        require(words==281&&nc::testInflatedBytes-before==2763,"real Wonder lookup reads only the 2763-byte requested member and preserves all 281 words");
        std::cout<<"real Sthetix: bytes=2763 definitions="<<pack.cheats.size()<<" words="<<words<<"\n";
        auto mismatched=wonder;mismatched.buildId.back()='0';mismatched.fullBuildId.replace(0,16,mismatched.buildId);
        require(nc::findPublishedGameDirect(mismatched,false,pack,reports,error)&&!pack.compatible&&pack.cheats.empty(),"real new provider refuses a different Build ID");
        nc::testTransfer=oldTransfer;
    }
    for(const bool previousOnly:{false,true}){
        const auto diagnosticRoot=(base/(previousOnly?"tcp-previous":"head-current")).generic_string();fs::create_directories(fs::path(diagnosticRoot)/"published-sources");setenv("NC_CATALOG_ROOT",diagnosticRoot.c_str(),1);
        const auto archive=diagnosticRoot+"/published-sources/nx-direct.zip"+(previousOnly?".previous":"");fs::copy_file(nx,archive);
        std::string beforeArchive,afterArchive;require(nc::readSmall(archive,beforeArchive,size_t(nc::MaxArchive)),"record cached exact archive before failed connection");
        const auto savedTransfer=nc::testTransfer;nc::testTransfer=[](const std::string&,const std::string&,std::string &why,nc::RemoteStamp *stamp,bool head){if(stamp)*stamp={};why=head?"Exact original HEAD/TCP failure":"Exact original GET/TCP failure";return false;};
        require(!nc::findPublishedGameDirect(game,true,pack,reports,error)&&pack.compatible&&pack.cheats.size()==1,"failed global connection preserves exact archive options but remains incomplete");
        const auto expected=previousOnly?"Exact original GET/TCP failure":"Exact original HEAD/TCP failure";
        require(reports[1].detail.find(expected)!=std::string::npos&&error.find(expected)!=std::string::npos,"source report and aggregate retain original network failure after cached parsing");
        require(!reports[1].checked&&reports[1].httpStatus==0&&reports[1].cached&&reports[1].found,"failed source is cached rather than freshly checked or absent");
        require(nc::readSmall(archive,afterArchive,size_t(nc::MaxArchive))&&beforeArchive==afterArchive,"network diagnostic fix never changes cached archive bytes");
        nc::testTransfer=savedTransfer;
    }
    nc::testTransfer={};nc::testNetworkReady=false;
    std::cout<<"direct: "<<checks<<" identity, target-only ZIP, budget, cache and cancellation checks passed\n";
}

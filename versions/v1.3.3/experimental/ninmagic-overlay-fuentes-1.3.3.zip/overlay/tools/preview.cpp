#include "controller.hpp"
#define main ninmagic_overlay_entry
#include "../source/main.cpp"
#undef main

namespace {unsigned beginCalls=0,testCalls=0,filterCalls=0,removeCalls=0,undoCalls=0;std::string testedValue;}
namespace nc::overlay {
bool init(std::string&){return true;}void shutdown(){}Snapshot snapshot(){return state;}bool refresh(){return true;}
bool begin(ScanValueType,bool,const std::string&,int){++beginCalls;return true;}bool filter(ScanCompare,const std::string&){++filterCalls;return true;}bool test(const std::string&v,int){++testCalls;testedValue=v;return true;}bool remove(){++removeCalls;return true;}void cancel(){}
bool undo(){++undoCalls;return true;}
}
int main(int argc,char**argv){
    if(argc!=3)return 1;
    auto&r=Renderer::get();if(!r.loadFont(std::string(argv[1])+"/font.bin"))return 2;
    FILE*f=std::fopen((std::string(argv[1])+"/logo.rgba").c_str(),"rb");if(f){std::array<uint8_t,1024>b{};hasLogo=true;for(unsigned y=0;y<64;++y){if(std::fseek(f,long(y*4096),SEEK_SET)||std::fread(b.data(),1,b.size(),f)!=b.size()){hasLogo=false;break;}for(unsigned x=0;x<64;++x)for(unsigned c=0;c<4;++c)logo[(y*64+x)*4+c]=b[x*16+c];}std::fclose(f);}
    state.initialized=state.ready=state.game.running=state.game.buildVerified=true;state.game.id=0x010015100B514000ULL;state.game.name="Super Mario Bros. Wonder";state.game.buildId="A1B2C3D4E5F6789";state.candidateCount=146238;state.streamed=state.baseline=true;state.coveredBytes=512ULL*1024*1024;state.totalBytes=900ULL*1024*1024;state.partial=true;state.rounds=2;state.status="La comparación se ha guardado. Sigue jugando y compara otro cambio.";
    const auto save=[&](const char*name){return r.save(std::string(argv[2])+"/"+name+".ppm");};
    header(&r);drawHome(&r);if(!save("01-home"))return 3;
    state.busy=true;state.operationTotal=512ULL*1024*1024;state.processedBytes=176ULL*1024*1024;drawPassive(&r);if(!save("02-passive-hud"))return 3;
    state.busy=false;header(&r);drawSetup(&r);if(!save("03-setup"))return 3;
    header(&r);drawConfirmStart(&r);if(!save("04-confirm-reading"))return 3;
    selected=4;header(&r);drawCompare(&r);if(!save("05-comparisons"))return 3;
    state.streamed=state.baseline=false;state.candidateCount=1;state.canTest=true;state.candidateAddress=0x1800450060ULL;state.candidateValue="8";value="8";header(&r);drawReview(&r,true);if(!save("06-confirm-experiment"))return 3;
    state.candidateCount=0;state.canTest=false;state.rounds=5;state.status="El filtro dejó cero coincidencias. La búsqueda anterior puede recuperarse explícitamente.";header(&r);drawHome(&r);if(!save("07-zero-undo"))return 3;
    NinMagicOverlay overlay;tsl::Overlay::active=&overlay;NinMagicGui gui;unsigned checks=0;
    const auto check=[&](bool ok){++checks;if(!ok){std::fprintf(stderr,"Overlay UI guard failed: %u\n",checks);std::exit(4);}};
    const auto press=[&](u64 keys){gui.handleInput(keys,0,{},{},{});};
    page=Page::Home;selected=2;passive=true;press(HidNpadButton_A|HidNpadButton_B|HidNpadButton_Down|HidNpadButton_Minus|HidNpadButton_Y);check(passive&&page==Page::Home&&testCalls==0&&beginCalls==0&&removeCalls==0&&undoCalls==0);
    passive=false;state.canTest=false;press(HidNpadButton_A);check(page==Page::Home&&testCalls==0);
    state.canTest=true;press(HidNpadButton_A);check(page==Page::Review&&testCalls==0);
    press(HidNpadButton_X);check(page==Page::Edit);press(HidNpadButton_Up);press(HidNpadButton_A);check(page==Page::Review&&value=="9"&&testCalls==0);
    press(HidNpadButton_A);check(page==Page::ConfirmTest&&testCalls==0);press(HidNpadButton_B);check(page==Page::Home&&testCalls==0);
    selected=2;press(HidNpadButton_A);press(HidNpadButton_A);check(page==Page::ConfirmTest&&testCalls==0);press(HidNpadButton_A);check(testCalls==1&&testedValue=="8");
    selected=2;press(HidNpadButton_A);press(HidNpadButton_X);press(HidNpadButton_Up);press(HidNpadButton_A);check(page==Page::Review&&value=="9");press(HidNpadButton_A);check(page==Page::ConfirmTest&&testCalls==1);press(HidNpadButton_A);check(testCalls==2&&testedValue=="9");
    selected=0;press(HidNpadButton_A);check(page==Page::Setup&&beginCalls==0);selected=4;press(HidNpadButton_A);check(page==Page::ConfirmStart&&beginCalls==0);press(HidNpadButton_B);check(beginCalls==0);
    page=Page::ConfirmStart;press(HidNpadButton_A);check(beginCalls==1&&page==Page::Home);
    selected=3;press(HidNpadButton_A);check(page==Page::ConfirmRemove&&removeCalls==0);press(HidNpadButton_A);check(removeCalls==1);
    page=Page::Compare;selected=int(nc::ScanCompare::Changed);press(HidNpadButton_A);check(filterCalls==1&&testCalls==2);
    page=Page::Home;state.busy=true;state.ready=true;state.rounds=5;press(HidNpadButton_Y);check(undoCalls==0);
    state.busy=false;state.ready=false;press(HidNpadButton_Y);check(undoCalls==0);
    state.ready=true;state.rounds=1;press(HidNpadButton_Y);check(undoCalls==0);
    state.rounds=5;press(HidNpadButton_Y);check(undoCalls==1&&testCalls==2&&beginCalls==1&&removeCalls==1);
    page=Page::Compare;press(HidNpadButton_Y);check(undoCalls==1);
    page=Page::Edit;editText="8";editCursor=0;press(HidNpadButton_Y);check(undoCalls==1&&editText=="0");
    std::printf("PASS overlay UI: %u input guards; 7 mock previews generated\n",checks);
    return 0;
}

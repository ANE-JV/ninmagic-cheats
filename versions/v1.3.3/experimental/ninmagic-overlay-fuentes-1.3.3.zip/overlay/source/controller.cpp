#include "controller.hpp"
#include "platform.hpp"
#include "live_receipt.hpp"
#include "memory_scan_guard.hpp"
#include <switch.h>
#include <algorithm>
#include <atomic>
#include <cstring>
#include <utility>

namespace nc::overlay {
namespace {
enum class Action { None, Refresh, Begin, Filter, Undo, Test, Remove };
struct Command {
    Action action=Action::None;
    Game expected;
    ScanValueType type=ScanValueType::U32;
    ScanCompare comparison=ScanCompare::Changed;
    bool unknown=true;
    int purpose=0;
    std::string value;
};
Mutex lock{};
UEvent wake{};
Thread worker{};
bool created=false;
std::atomic<bool> stopping{false},cancelled{false};
Snapshot view;
Command pending;
ScanSession session;
Game current;
Environment environment;
bool services=false;
// Failed persistence can leave the only complete ownership receipt in the
// native backend's RAM. Never reset that context before undoing it.
bool dirtyContext=false;
Game dirtyGame;
constexpr size_t WorkerStack=0x40000;
struct Guard { Guard(){mutexLock(&lock);} ~Guard(){mutexUnlock(&lock);} };

void publish(const std::string &status,const std::string &error={}) {
    Guard guard;
    view.game=current;view.ready=session.ready;view.type=session.type;
    view.baseline=session.baseline;view.streamed=session.streamed;
    view.partial=session.partial;view.candidateCount=session.candidateCount;
    view.coveredBytes=session.coveredBytes;view.totalBytes=session.totalBytes;
    view.rounds=session.rounds;
    view.canTest=!dirtyContext&&session.ready&&!session.baseline&&session.candidateCount==1&&session.candidates.size()==1&&session.rounds>=3;
    view.candidateAddress=0;view.candidateValue.clear();
    if(session.candidates.size()==1){view.candidateAddress=session.candidates[0].address;view.candidateValue=scanValueText(session.type,session.candidates[0].valueBits);}
    view.status=status;view.error=error;
    if(dirtyContext){const std::string warning=" Puede haber códigos activos con un recibo sólo en memoria. Usa Retirar; si no es posible, cierra y abre el juego antes de salir.";view.status+=warning;if(view.error.empty())view.error=warning;}
}
bool sameGame(const Game &expected,const Game &actual,std::string &error) {
    if(!expected.id||expected.id!=actual.id||expected.fullBuildId!=actual.fullBuildId){error="Cambió el juego abierto o su Build ID. Pulsa detectar y revisa el juego antes de continuar.";return false;}return true;
}
bool findCurrent(std::string &error) {
    std::vector<Game> games;
    if(!scanGames(games,environment,error))return false;
    const auto found=std::find_if(games.begin(),games.end(),[](const Game &game){return game.running;});
    if(found==games.end()){error="Abre un juego compatible y vuelve al overlay. No se detectó un juego en ejecución.";current={};return false;}
    Game next=*found;
    if(!resolveBuild(next,environment,error)||!next.running||!next.buildVerified||next.fullBuildId.size()!=64){if(error.empty())error="No se pudo verificar el juego abierto y su Build ID completo.";return false;}
    current=std::move(next);return true;
}
bool sameProcess(ScanIdentity &identity,std::string &error) {
    if(!session.ready){error="Primero inicia una búsqueda.";return false;}
    if(!peekScanProcess(current,identity,error))return false;
    if(!native::scan::same(identity,session.identity)){error="El juego se reinició o cambió su memoria. Inicia una búsqueda nueva; no se reutilizarán sus direcciones.";return false;}return true;
}
void updateOwned() {
    bool active=false;
    ScanIdentity identity;std::string ignored;
    if(current.id&&peekScanProcess(current,identity,ignored)){
        native::LiveReceipt receipt;
        active=native::loadLiveReceipt(receipt,ignored)&&receipt.valid&&receipt.pid==identity.pid&&receipt.title==current.id&&receipt.buildId==current.buildId&&(!receipt.changes.empty()||receipt.masterAdded);
    }
    Guard guard;view.ownActive=active||dirtyContext;
}
bool refreshCurrent(std::string &error) {
    if(!findCurrent(error)){session={};return false;}
    ScanIdentity identity;
    std::string lookup;
    if(peekScanProcess(current,identity,lookup)){
        ScanSession loaded;
        if(loadScanSession(identity,loaded,lookup)){
            ScanIdentity after;
            if(!peekScanProcess(current,after,error)||!native::scan::same(identity,after)){if(error.empty())error="El proceso cambió durante la recuperación de la búsqueda.";session={};return false;}
            session=std::move(loaded);
        }else session={};
    }else session={};
    updateOwned();return true;
}
unsigned bytesPerValue(){return session.type==ScanValueType::U8?1:session.type==ScanValueType::U16?2:4;}
std::string trialName(int purpose){static const char *names[]={"Salud","Municion","Vidas","Magia","Objetos","Dinero","Movimiento","Valor"};return std::string("NinMagic prueba ")+names[std::clamp(purpose,0,7)];}
bool reloadServices(std::string &error){
    if(dirtyContext){error="Primero retira los códigos pendientes. Se conserva el recibo en memoria sin reconectar los servicios.";return false;}
    // The NRO can have changed the shared receipt while this overlay was
    // hidden. Reload ownership before any explicit activation or undo.
    platformExit();services=platformInit(environment,error);
    {Guard guard;view.initialized=services;}
    return services;
}

void perform(const Command &command) {
    std::string error,status;
    bool ok=false;
    if(command.action==Action::Refresh){ok=refreshCurrent(error);status=session.ready?"Búsqueda recuperada de esta misma sesión.":"Juego detectado. Elige el tipo e inicia una búsqueda.";}
    else if(command.action==Action::Begin){
        if(findCurrent(error)&&sameGame(command.expected,current,error)){
            ScanIdentity identity;std::vector<ScanRegion> regions;
            // This is the sole explicit attachment boundary. Search and refresh
            // never attach the engine behind the user's confirmation.
            if(!cancelled.load()&&getScanProcess(current,identity,error)&&enumerateScanRegions(identity,regions,error)){
                ok=command.unknown?startUnknownScan(identity,regions,command.type,readScanMemory,session,error):startExactScan(identity,regions,command.type,command.value,readScanMemory,session,error);
                if(ok){ScanIdentity after;if(!peekScanProcess(current,after,error)||!native::scan::same(identity,after)){session={};ok=false;if(error.empty())error="El proceso cambió durante la lectura. Inicia una búsqueda nueva.";}}
            }
        }
        status="Referencia capturada mientras el juego seguía funcionando. Cambia el valor en el juego y compara.";
    }else if(command.action==Action::Filter){
        ScanIdentity identity;
        if(sameProcess(identity,error))ok=refineScan(identity,command.comparison,command.value,readScanMemory,session,error);
        if(ok){ScanIdentity after;if(!sameProcess(after,error))ok=false;}
        status=session.candidateCount==1?"Queda una coincidencia. Revisa las comparaciones antes de probarla.":"Comparación terminada. Cambia el valor en el juego y vuelve a comparar.";
    }else if(command.action==Action::Undo){
        ScanIdentity identity;
        if(!session.ready||session.rounds<=1)error="No hay una comparación anterior que recuperar.";
        else if(sameProcess(identity,error)){
            ok=restorePreviousScan(identity,session,error);
            if(ok){ScanIdentity after;if(!sameProcess(after,error))ok=false;}
        }
        status="Se recuperó la comparación anterior. Revisa lo que cambió en el juego antes de volver a filtrar.";
    }else if(command.action==Action::Test){
        ScanIdentity identity;
        if(cancelled.load()||stopping.load())error="Prueba cancelada antes de activar el candidato.";
        else if(dirtyContext)error="No se permiten nuevas pruebas hasta retirar los códigos pendientes; se conserva su recibo en memoria.";
        else if(!session.ready||session.baseline||session.candidateCount!=1||session.candidates.size()!=1||session.rounds<3)error="Para probar hacen falta una sola coincidencia y al menos dos comparaciones después de la primera lectura.";
        else if(reloadServices(error)&&sameProcess(identity,error)){
            uint8_t bytes[4]{};uint32_t bits=0;const auto &candidate=session.candidates.front();
            if(readScanMemory(identity,candidate.address,bytes,bytesPerValue(),error)){
                for(unsigned i=0;i<bytesPerValue();++i)bits|=uint32_t(bytes[i])<<(i*8);
                if(bits!=candidate.valueBits)error="El candidato cambió después de la última lectura. Compara otra vez antes de probarlo.";
                else {
                    Cheat cheat;
                    if(scanCandidateCheat(session,0,command.value,trialName(command.purpose),cheat,error)&&!cancelled.load()&&!stopping.load()){
                        Pack pack;pack.game=current;pack.compatible=true;pack.sessionOnly=true;pack.sessionBinding=identity;pack.cheats.push_back(std::move(cheat));
                        const auto result=applyLive(pack);ok=result.ok;
                        if(ok)status=result.message+" Comprueba su efecto en el juego. La dirección sólo vale para esta sesión.";
                        else {
                            // Activation can succeed while saving its receipt
                            // fails. Undo in this exact backend context first.
                            dirtyContext=true;dirtyGame=current;
                            const auto rollback=removeLive(dirtyGame);
                            dirtyContext=!rollback.ok;
                            error=result.message+" "+(rollback.ok?"Se retiraron los códigos de NinMagic del motor. Cierra y abre el juego para reiniciar sus valores.":"No se pudo confirmar la retirada inmediata: "+rollback.message);
                        }
                    }
                }
            }
        }
    }else if(command.action==Action::Remove){
        if(cancelled.load()||stopping.load())error="Retirada cancelada antes de modificar el motor.";
        else if(dirtyContext||reloadServices(error)){
            const Game target=dirtyContext?dirtyGame:command.expected;
            const auto result=removeLive(target);ok=result.ok;
            dirtyContext=!ok;if(!ok)dirtyGame=target;
            if(ok){status=result.message;dirtyGame={};}else error=result.message;
        }
    }
    if(cancelled.load()&&!ok&&error.empty())error="Operación cancelada. La búsqueda anterior se conserva.";
    if(!ok&&error.empty())error="No se pudo completar la operación.";
    updateOwned();publish(ok?status:error,ok?std::string{}:error);
}
void run(void*) {
    std::string error;
    const bool sm=R_SUCCEEDED(smInitialize());
    const bool mounted=sm&&R_SUCCEEDED(fsdevMountSdmc());
    if(sm&&mounted)services=platformInit(environment,error);
    else error="No se pudieron abrir los servicios y la microSD del overlay.";
    {Guard guard;view.initialized=services;view.busy=services;}
    if(services){
        setScanObserver([](uint64_t done,uint64_t total){
            {Guard guard;view.processedBytes=done;view.operationTotal=total;}
            // Yield CPU time while gameplay continues. Never pause the game.
            svcSleepThread(1000000);
            return !cancelled.load()&&!stopping.load();
        });
        Command initial;initial.action=Action::Refresh;perform(initial);
    }else publish(error,error);
    {Guard guard;view.busy=false;}
    while(!stopping.load()){
        waitSingle(waiterForUEvent(&wake),UINT64_MAX);
        if(stopping.load())break;
        Command command;
        {Guard guard;command=std::move(pending);pending={};}
        if(command.action!=Action::None&&services)perform(command);
        {Guard guard;view.busy=false;}
    }
    setScanObserver({});
    // Best effort before unload: an incomplete SD receipt must not be discarded
    // without trying to retire its activation using the surviving RAM receipt.
    if(services&&dirtyContext){const auto result=removeLive(dirtyGame);dirtyContext=!result.ok;}
    // Even partially successful service initialization needs balanced cleanup.
    platformExit();services=false;session={};current={};dirtyContext=false;dirtyGame={};
    if(mounted)fsdevUnmountDevice("sdmc");
    if(sm)smExit();
}
bool enqueue(Command command) {
    {Guard guard;if(!created||stopping.load()||!view.initialized||view.busy)return false;
        if(command.value.size()>64)return false;
        command.expected=view.game;pending=std::move(command);view.busy=true;view.processedBytes=0;view.operationTotal=0;view.error.clear();
        view.status=pending.action==Action::Undo?"Recuperando la comparación anterior de esta misma sesión...":"Trabajando; puedes ocultar el panel y seguir jugando.";cancelled.store(false);
    }
    ueventSignal(&wake);return true;
}
}

bool init(std::string &error) {
    error.clear();if(created)return true;
    mutexInit(&lock);ueventCreate(&wake,true);stopping.store(false);cancelled.store(false);view={};view.busy=true;
    Result rc=threadCreate(&worker,run,nullptr,nullptr,WorkerStack,0x3B,-2);
    if(R_FAILED(rc)){error="No se pudo reservar el hilo de búsqueda del overlay.";view.busy=false;view.status=view.error=error;return false;}
    rc=threadStart(&worker);
    if(R_FAILED(rc)){threadClose(&worker);error="No se pudo iniciar el hilo del buscador.";view.busy=false;view.status=view.error=error;return false;}
    created=true;return true;
}
void shutdown() {
    if(!created)return;
    stopping.store(true);cancelled.store(true);ueventSignal(&wake);
    threadWaitForExit(&worker);threadClose(&worker);created=false;
    Guard guard;view.initialized=false;view.busy=false;pending={};
}
Snapshot snapshot(){Guard guard;return view;}
bool refresh(){Command c;c.action=Action::Refresh;return enqueue(std::move(c));}
bool begin(ScanValueType type,bool unknown,const std::string &value,int purpose){if(unsigned(type)>unsigned(ScanValueType::F32))return false;Command c;c.action=Action::Begin;c.type=type;c.unknown=unknown;c.value=value;c.purpose=purpose;return enqueue(std::move(c));}
bool filter(ScanCompare comparison,const std::string &value){if(unsigned(comparison)>unsigned(ScanCompare::Decreased))return false;Command c;c.action=Action::Filter;c.comparison=comparison;c.value=value;return enqueue(std::move(c));}
bool undo(){Command c;c.action=Action::Undo;return enqueue(std::move(c));}
bool test(const std::string &value,int purpose){Command c;c.action=Action::Test;c.value=value;c.purpose=purpose;return enqueue(std::move(c));}
bool remove(){Command c;c.action=Action::Remove;return enqueue(std::move(c));}
void cancel(){cancelled.store(true);}
}

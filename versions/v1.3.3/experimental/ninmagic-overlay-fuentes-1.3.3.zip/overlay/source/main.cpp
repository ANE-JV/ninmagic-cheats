#define TESLA_INIT_IMPL
#include <tesla.hpp>
#include "controller.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

namespace {
using Renderer=tsl::gfx::Renderer;
using Color=tsl::Color;
constexpr Color ink{14,15,15,15},muted{9,11,13,15},dim{5,7,9,15};
constexpr Color cyan{3,14,15,15},pink{15,5,12,15},lime{11,15,5,15},orange{15,10,4,15},violet{11,8,15,15},blue{4,9,15,15};
constexpr Color navy{0,1,2,14},panel{1,2,3,15},edge{2,4,5,15};
enum class Page { Home, Setup, ConfirmStart, Compare, Review, ConfirmTest, ConfirmRemove, Edit, Help };
Page page=Page::Home,editReturn=Page::Setup;
bool rightSide=false,unknown=true;
bool purposeChosen=false;
// libtesla can call onHide from its input polling thread.
std::atomic<bool> passive{false};
int selected=0,purpose=0,editCursor=0;
nc::ScanValueType valueType=nc::ScanValueType::U32;
nc::ScanCompare comparison=nc::ScanCompare::Changed;
std::string value="100",editText,message;
std::array<uint8_t,64*64*4>logo{};
bool hasLogo=false;
nc::overlay::Snapshot state;

const char* purposeName(){const char*n[]={"Salud","Munición","Vidas","Magia / energía","Kits / objetos","Dinero","Velocidad / salto","Otro valor"};return n[std::clamp(purpose,0,7)];}
const char* typeName(){switch(valueType){case nc::ScanValueType::U8:return "Entero · 8 bits";case nc::ScanValueType::U16:return "Entero · 16 bits";case nc::ScanValueType::U32:return "Entero · 32 bits";case nc::ScanValueType::F32:return "Decimal · 32 bits";}return "Tipo";}
std::string mib(uint64_t n){char b[32];std::snprintf(b,sizeof(b),"%.1f MiB",double(n)/1048576.0);return b;}
void label(Renderer*r,const std::string&s,int x,int y,int size=18,Color c=ink,int maxWidth=402){const auto t=r->limitStringLength(s,false,float(size),maxWidth);r->drawString(t.c_str(),false,x,y,float(size),c);}
void wrap(Renderer*r,const std::string&s,int x,int y,int width,int size,int maxLines,Color c=muted){
    std::string line,word;int n=0;size_t at=0;
    while(at<s.size()&&n<maxLines){while(at<s.size()&&s[at]==' ')++at;const auto end=s.find(' ',at);word=s.substr(at,end==std::string::npos?end:end-at);at=end==std::string::npos?s.size():end+1;
        if(word.empty())continue;
        const auto trial=line.empty()?word:line+" "+word;
        if(!line.empty()&&r->drawString(trial.c_str(),false,0,0,float(size),Color{0,0,0,0}).first>static_cast<u32>(width)){
            label(r,line,x,y+n*(size+9),size,c,width);++n;line=word;
        }else line=trial;
        if(n==maxLines-1&&at<s.size()){line+=" "+s.substr(at);at=s.size();}
    }
    if(!line.empty()&&n<maxLines)label(r,line,x,y+n*(size+9),size,c,width);
}
void box(Renderer*r,int x,int y,int w,int h,Color fill=panel,Color border=edge){r->drawRect(x,y,w,h,fill);r->drawRect(x,y,w,1,border);r->drawRect(x,y+h-1,w,1,border);r->drawRect(x,y,1,h,border);r->drawRect(x+w-1,y,1,h,border);}
void stripe(Renderer*r,int y,int x=18,int width=412){const Color colors[]={cyan,blue,violet,pink,orange,lime};for(int i=0;i<6;++i)r->drawRect(x+i*width/6,y,(i==5?width-i*width/6:width/6),2,colors[i]);}
void row(Renderer*r,const std::string&s,int index,int y,bool enabled=true,const std::string&tag=""){
    if(index==selected){box(r,18,y-23,412,34,Color{1,3,4,15},cyan);r->drawRect(18,y-23,3,34,cyan);}
    label(r,s,31,y,18,enabled?(index==selected?ink:muted):dim,tag.empty()?386:285);
    if(!tag.empty())label(r,tag,331,y,12,enabled?cyan:dim,86);
}
void footer(Renderer*r,const std::string&first,const std::string&second="B  Volver",Color c=muted){r->drawRect(18,655,412,1,edge);label(r,first,22,683,15,c,404);label(r,second,22,707,13,muted,404);}
void place(){Renderer::setLayerPos(rightSide?tsl::cfg::ScreenWidth-tsl::cfg::LayerWidth:0,0);}
void refreshState(){state=nc::overlay::snapshot();}
void loadLogo(){
#ifdef __SWITCH__
    // RomFS locates this OVL through its SD path. Copy the small logo before
    // starting the worker, then release both mounts so the worker owns its SD.
    hasLogo=false;
    if(R_FAILED(fsdevMountSdmc()))return;
    struct SdGuard {~SdGuard(){fsdevUnmountDevice("sdmc");}} sd;
    if(R_FAILED(romfsInit()))return;
    struct RomGuard {~RomGuard(){romfsExit();}} rom;
    FILE*f=std::fopen("romfs:/logo.rgba","rb");if(!f)return;std::array<uint8_t,256*4>rowBytes{};bool ok=true;
    for(unsigned y=0;y<64&&ok;++y){if(std::fseek(f,long(y*4*256*4),SEEK_SET)||std::fread(rowBytes.data(),1,rowBytes.size(),f)!=rowBytes.size()){ok=false;break;}for(unsigned x=0;x<64;++x)for(unsigned c=0;c<4;++c)logo[(y*64+x)*4+c]=rowBytes[x*16+c];}
    if(std::fclose(f)!=0)ok=false;
    hasLogo=ok;
#endif
}
void header(Renderer*r){
    r->fillScreen(navy);r->drawRect(447,0,1,720,edge);
    if(hasLogo)r->drawBitmap(20,17,64,64,logo.data());else label(r,"NM",26,58,31,cyan,65);
    label(r,"NINMAGIC",98,45,25);label(r,"CREADOR EN JUEGO",100,68,12,cyan);stripe(r,96);
    wrap(r,state.game.name.empty()?"Abre un juego real":state.game.name,21,123,406,20,2,ink);
    label(r,state.game.id?nc::hexId(state.game.id):"JUEGO SIN IDENTIFICAR",22,174,12,state.game.id?muted:orange);
    label(r,state.game.buildVerified?state.game.buildId:"BID SIN COMPROBAR",258,174,12,state.game.buildVerified?cyan:orange,170);
}
void statusCard(Renderer*r){
    box(r,18,190,412,105);
    const auto detail=!message.empty()?message:state.error;
    if(!detail.empty()){label(r,"REQUIERE ATENCIÓN",30,214,11,orange);wrap(r,detail,30,241,388,14,2,muted);return;}
    const bool zero=state.ready&&!(state.baseline&&!state.streamed)&&state.candidateCount==0;
    const std::string status=state.busy?"LECTURA EN SEGUNDO PLANO":state.ownActive?"PRUEBA EN EL MOTOR · COMPRUEBA EL EFECTO":!state.ready?"PREPARA UNA BÚSQUEDA":zero?"SIN COINCIDENCIAS":state.baseline&&!state.streamed?"REFERENCIA GUARDADA":state.canTest?"CANDIDATO LISTO PARA REVISAR":"SIGUE COMPARANDO";
    label(r,status,30,214,11,state.busy?pink:state.canTest?orange:cyan);
    label(r,zero&&state.rounds>1?"0: Y recupera el paso anterior":state.ready&&!(state.baseline&&!state.streamed)?std::to_string(state.candidateCount)+" coincidencias":state.ready?"Primera lectura lista":"Sin una referencia activa",30,242,zero?20:22,zero?orange:ink);
    label(r,state.busy&&state.operationTotal?std::to_string(std::min<uint64_t>(100,state.processedBytes*100/state.operationTotal))+" % completado":state.ready?mib(state.coveredBytes)+" / "+mib(state.totalBytes)+(state.partial?" · PARCIAL":""):"Abre el juego y después este panel",30,269,13,state.partial?orange:muted);
    if(state.busy&&state.operationTotal){const auto done=std::min(state.processedBytes,state.operationTotal);r->drawRect(30,281,388,3,edge);r->drawRect(30,281,int(done*388/state.operationTotal),3,pink);}
}
void note(Renderer*r){const auto&detail=!message.empty()?message:!state.error.empty()?state.error:state.status;if(!detail.empty())wrap(r,detail,23,614,402,12,2,!message.empty()||!state.error.empty()?orange:muted);}
void drawHome(Renderer*r){
    statusCard(r);
    row(r,"Preparar nueva búsqueda",0,331,!state.busy);
    row(r,"Comparar lo que cambió",1,367,state.ready&&!state.busy);
    row(r,"Revisar candidato",2,403,state.canTest&&!state.busy,state.canTest?"1 valor":"");
    row(r,"Quitar mis cheats",3,439,!state.busy);
    row(r,rightSide?"Panel a la derecha":"Panel a la izquierda",4,475,true,"A cambia");
    row(r,"Mostrar HUD y seguir jugando",5,511);
    row(r,"Cómo buscar vida / munición",6,547);
    row(r,"Salir al menú de overlays",7,583,!state.busy);
    note(r);
    const bool canUndo=state.ready&&state.rounds>1&&!state.busy;
    footer(r,state.busy?"X  Cancelar lectura · B  Seguir jugando":canUndo?"Y  Recuperar paso anterior · A  Elegir":"A  Elegir · B  Seguir jugando",canUndo?"B  Jugar · Arriba / abajo  Mover · -  Ayuda":"Arriba / abajo  Mover · -  Ayuda");
}
void drawSetup(Renderer*r){
    label(r,"PREPARA LA BÚSQUEDA",22,211,13,pink);
    row(r,"Qué buscas: "+std::string(purposeName()),0,256);
    row(r,unknown?"Puntos / barra sin número":"Número visible en el juego",1,303);
    row(r,typeName(),2,350,true,"avanzado");
    row(r,unknown?"Valor: no hace falta un número":"Valor: "+value,3,397,!unknown);
    row(r,"Revisar e iniciar",4,444,!state.busy&&state.game.running);
    wrap(r,purpose==6?"Búsqueda numérica avanzada. Esta etiqueta no crea automáticamente un parche de salto ni de física.":unknown?"Primero guarda una referencia. Pierde un punto de salud o gasta munición, abre el panel y compara cómo cambió.":"Escribe el número que ves. El tipo de dato puede ser distinto al del juego; no se identifica por su aspecto.",23,490,402,18,4);
    note(r);footer(r,"A  Cambiar / elegir","B  Volver · Arriba / abajo  Mover");
}
void drawConfirmStart(Renderer*r){
    label(r,"ANTES DE CONECTAR EL MOTOR",22,211,13,orange);
    wrap(r,"Atmosphère puede cargar los cheats que ya existan en la SD al conectar el motor a este juego.",23,254,402,21,4,ink);
    wrap(r,"La búsqueda y sus filtros solo leen datos. Al confirmar puedes volver al juego; el hilo seguirá trabajando.",23,384,402,18,4);
    label(r,std::string(purposeName())+" · "+typeName(),23,524,17,cyan);
    label(r,unknown?"Referencia sin número conocido":"Valor exacto: "+value,23,555,16,muted);
    wrap(r,"Se indica la cobertura parcial. No detecta vida o munición automáticamente.",23,603,402,14,2,orange);
    footer(r,"A  Iniciar lectura y volver al juego","B  Cancelar",orange);
}
void drawCompare(Renderer*r){
    statusCard(r);label(r,"¿QUÉ PASÓ EN EL JUEGO?",22,326,13,pink);
    const char* names[]={"Igual al número escrito","Cambió","No cambió","Aumentó","Disminuyó"};
    for(int i=0;i<5;++i)row(r,names[i],i,368+i*42,state.ready&&!state.busy);
    label(r,"Valor para igualdad: "+value,23,584,15,cyan);
    wrap(r,"Cada comparación usa la lectura anterior. No cierres ni reinicies el juego.",23,612,402,13,2);
    footer(r,"A  Comparar y volver al juego","X  Editar número · B  Volver");
}
void drawReview(Renderer*r,bool confirm){
    label(r,confirm?"CONFIRMA UNA PRUEBA EXPERIMENTAL":"UN CANDIDATO · FUNCIÓN SIN COMPROBAR",22,211,12,orange);
    label(r,"Dirección de esta sesión",23,255,15,blue);label(r,"0x"+nc::hexId(state.candidateAddress),23,286,23);
    label(r,"Valor observado: "+state.candidateValue,23,328,17,muted);
    label(r,"VALOR QUE SE INTENTARÁ FIJAR",23,380,12,cyan);label(r,value,23,418,32,cyan);
    wrap(r,confirm?"Se bloquea con otros cheats activos o un maestro cargado. No se sabe qué controla esta dirección: comprueba el efecto en el juego.":"Una sola coincidencia no demuestra que sea vida, munición ni dinero. Revisa el valor y confirma antes de probarla.",23,466,402,19,4,confirm?orange:muted);
    label(r,"Solo esta sesión · sin exportar cheat portable",23,609,13,violet);
    footer(r,confirm?"A  Probar y volver al juego":"A  Revisar prueba experimental",confirm?"B  Cancelar":"X  Valor a fijar · B  Volver",confirm?orange:cyan);
}
void drawRemove(Renderer*r){
    label(r,"QUITAR LOS CÓDIGOS DE NINMAGIC",22,211,13,orange);
    wrap(r,"Se retirarán los códigos registrados por NinMagic en esta sesión y se recuperarán los estados anteriores que consten en su recibo.",23,264,402,22,5,ink);
    wrap(r,"Retirar un código no restaura los valores que ya cambió ni una partida guardada. Reinicia el juego si hace falta.",23,452,402,19,5,muted);
    footer(r,"A  Confirmar retirada","B  Cancelar",orange);
}
void drawEdit(Renderer*r){
    label(r,"VALOR NUMÉRICO",22,211,13,cyan);wrap(r,"Izquierda / derecha mueve el cursor. Arriba / abajo cambia el carácter.",23,255,402,19,3);
    box(r,20,356,408,92,panel,cyan);label(r,editText.empty()?"0":editText,32,402,26,ink,380);
    const std::string prefix=editText.substr(0,size_t(std::max(0,editCursor)));const auto dx=r->drawString(prefix.c_str(),false,0,0,26,Color{0,0,0,0}).first;
    r->drawRect(32+int(std::min<u32>(dx,364)),415,15,3,pink);
    wrap(r,"Usa un número válido para el tipo elegido. Los decimales usan punto; también se admite exponente.",23,493,402,18,4);
    footer(r,"A  Guardar · X  Añadir dígito","Y  Borrar carácter · B  Cancelar");
}
void drawHelp(Renderer*r){
    label(r,"BUSCAR PUNTOS BLANCOS DE SALUD",22,211,12,pink);
    const char* steps[]={"1  Elige Salud y Puntos / barra. No inventes un número para los puntos.","2  Guarda la referencia. Al ocultar el panel el juego recibe el mando y la lectura continúa.","3  Daño: Cambió. Sin perder salud: No cambió. Después recibe daño y compara Cambió otra vez.","4  Con una coincidencia y tres lecturas puedes revisar una prueba; todavía no demuestra su función.","5  Quita mis cheats retira los códigos registrados. Sin exportación portable."};
    for(int i=0;i<5;++i)wrap(r,steps[i],23,255+i*72,402,16,3,i==3?orange:muted);
    label(r,"Búsqueda guiada · sin activación automática",23,631,13,cyan);
    footer(r,"B  Volver","Mismo juego abierto · misma sesión");
}
void drawPassive(Renderer*r){
    r->clearScreen();box(r,12,15,422,117,Color{0,1,2,13},cyan);r->drawRect(12,15,4,117,state.busy?pink:lime);
    if(hasLogo)r->drawBitmap(24,25,64,64,logo.data());
    label(r,"NINMAGIC",101,49,22,cyan,315);
    label(r,state.busy?"Leyendo · "+(state.operationTotal?std::to_string(std::min<uint64_t>(100,state.processedBytes*100/state.operationTotal))+" %":"en curso"):state.ownActive?"Prueba en el motor":state.ready&&!(state.baseline&&!state.streamed)?std::to_string(state.candidateCount)+" coincidencias":state.ready?"Referencia guardada":"Panel preparado",101,79,16,ink,310);
    label(r,"Combo: ocultar HUD · repite: abrir panel",24,116,12,muted,395);
}
class Canvas final:public tsl::elm::Element {
public:
    explicit Canvas(std::function<void(Renderer*)>draw):render(std::move(draw)){}
    void draw(Renderer*r)override{render(r);}
    void layout(u16 x,u16 y,u16 w,u16 h)override{setBoundaries(x,y,w,h);}
private:std::function<void(Renderer*)>render;
};
class NinMagicGui final:public tsl::Gui {
public:
    tsl::elm::Element*createUI()override{return new Canvas([this](Renderer*r){draw(r);});}
    void update()override{refreshState();if(state.ready&&!purposeChosen)purpose=7;}
    bool handleInput(u64 keys,u64 held,const HidTouchState&,HidAnalogStickState,HidAnalogStickState)override;
private:
    void draw(Renderer*r){if(passive){drawPassive(r);return;}header(r);switch(page){case Page::Home:drawHome(r);break;case Page::Setup:drawSetup(r);break;case Page::ConfirmStart:drawConfirmStart(r);break;case Page::Compare:drawCompare(r);break;case Page::Review:drawReview(r,false);break;case Page::ConfirmTest:drawReview(r,true);break;case Page::ConfirmRemove:drawRemove(r);break;case Page::Edit:drawEdit(r);break;case Page::Help:drawHelp(r);break;}}
};
void edit(Page returnTo){editReturn=returnTo;editText=value.empty()?"0":value;editCursor=0;page=Page::Edit;}
void hideForGame(){passive=false;tsl::Overlay::get()->hide();}
void refused(){refreshState();message=state.error.empty()?"No se pudo iniciar la operación. Espera a que termine la lectura en curso.":state.error;}
bool NinMagicGui::handleInput(u64 keys,u64 held,const HidTouchState&,HidAnalogStickState,HidAnalogStickState){
    (void)held;if(passive)return true;
    if(keys&HidNpadButton_Minus){page=Page::Help;return true;}
    if(page==Page::Edit){
        if(keys&HidNpadButton_B){page=editReturn;return true;}
        if(keys&HidNpadButton_A){value=editText.empty()?"0":editText;page=editReturn;return true;}
        if(keys&HidNpadButton_X){if(editText.size()<24){editText+='0';editCursor=int(editText.size())-1;}return true;}
        if(keys&HidNpadButton_Y){if(editText.size()>1){editText.erase(size_t(editCursor),1);editCursor=std::min(editCursor,int(editText.size())-1);}else editText="0";return true;}
        if(keys&HidNpadButton_Left)editCursor=std::max(0,editCursor-1);
        if(keys&HidNpadButton_Right)editCursor=std::min(int(editText.size())-1,editCursor+1);
        if(keys&(HidNpadButton_Up|HidNpadButton_Down)){const std::string chars=valueType==nc::ScanValueType::F32?"0123456789.-e+":"0123456789";auto at=chars.find(editText[size_t(editCursor)]);if(at==std::string::npos)at=0;const int delta=keys&HidNpadButton_Up?1:-1;editText[size_t(editCursor)]=chars[size_t((int(at)+delta+int(chars.size()))%int(chars.size()))];}return true;
    }
    if(keys&HidNpadButton_B){if(page==Page::Home)hideForGame();else{page=Page::Home;selected=0;message.clear();}return true;}
    if(page==Page::Home){
        if(keys&HidNpadButton_X){if(state.busy)nc::overlay::cancel();else nc::overlay::refresh();return true;}
        if(keys&HidNpadButton_Y){if(!state.busy&&state.ready&&state.rounds>1){message.clear();if(!nc::overlay::undo())refused();else refreshState();}return true;}
        if(keys&HidNpadButton_Up)selected=(selected+7)%8;
        if(keys&HidNpadButton_Down)selected=(selected+1)%8;
        if(keys&HidNpadButton_A){message.clear();switch(selected){
            case 0:if(!state.busy){page=Page::Setup;selected=0;}break;
            case 1:if(state.ready&&!state.busy){page=Page::Compare;selected=int(comparison);}else message="Primero guarda una referencia del juego.";break;
            case 2:if(state.canTest&&!state.busy){value=state.candidateValue;valueType=state.type;page=Page::Review;}else message="Se necesita una coincidencia tras al menos tres lecturas.";break;
            case 3:if(!state.busy)page=Page::ConfirmRemove;break;
            case 4:rightSide=!rightSide;place();break;
            case 5:passive=true;tsl::hlp::requestForeground(false);break;
            case 6:page=Page::Help;break;
            case 7:if(state.busy)message="Cancela la lectura con X antes de salir.";else tsl::Overlay::get()->close();break;
        }}return true;
    }
    if(page==Page::Setup){
        if(keys&HidNpadButton_Up)selected=(selected+4)%5;
        if(keys&HidNpadButton_Down)selected=(selected+1)%5;
        if(keys&HidNpadButton_A){switch(selected){case 0:purpose=(purpose+1)%8;break;case 1:unknown=!unknown;break;case 2:valueType=static_cast<nc::ScanValueType>((unsigned(valueType)+1)%4);break;case 3:if(!unknown)edit(Page::Setup);break;case 4:if(state.game.running&&!state.busy)page=Page::ConfirmStart;else message="Abre un juego real. X en el menú vuelve a comprobarlo.";break;}}return true;
    }
    if(page==Page::ConfirmStart&&(keys&HidNpadButton_A)){if(nc::overlay::begin(valueType,unknown,value,purpose)){purposeChosen=true;page=Page::Home;selected=1;hideForGame();}else{page=Page::Home;refused();}return true;}
    if(page==Page::Compare){
        if(keys&HidNpadButton_Up)selected=(selected+4)%5;
        if(keys&HidNpadButton_Down)selected=(selected+1)%5;
        if(keys&HidNpadButton_X){edit(Page::Compare);return true;}
        if(keys&HidNpadButton_A){comparison=static_cast<nc::ScanCompare>(selected);if(nc::overlay::filter(comparison,value)){page=Page::Home;selected=1;hideForGame();}else{page=Page::Home;refused();}}return true;
    }
    if(page==Page::Review){if(keys&HidNpadButton_X)edit(Page::Review);else if(keys&HidNpadButton_A)page=Page::ConfirmTest;return true;}
    if(page==Page::ConfirmTest&&(keys&HidNpadButton_A)){if(nc::overlay::test(value,purpose)){page=Page::Home;selected=3;hideForGame();}else{page=Page::Home;refused();}return true;}
    if(page==Page::ConfirmRemove&&(keys&HidNpadButton_A)){if(nc::overlay::remove()){page=Page::Home;selected=0;}else{page=Page::Home;refused();}return true;}
    return true;
}
class NinMagicOverlay final:public tsl::Overlay {
public:
    void initServices()override{loadLogo();std::string error;if(!nc::overlay::init(error))message=error;else nc::overlay::refresh();}
    void exitServices()override{nc::overlay::shutdown();}
    void onShow()override{passive=false;place();refreshState();if(!state.busy)nc::overlay::refresh();}
    void onHide()override{passive=false;}
    std::unique_ptr<tsl::Gui>loadInitialGui()override{return initially<NinMagicGui>();}
};
}
int main(int argc,char**argv){return tsl::loop<NinMagicOverlay>(argc,argv);}

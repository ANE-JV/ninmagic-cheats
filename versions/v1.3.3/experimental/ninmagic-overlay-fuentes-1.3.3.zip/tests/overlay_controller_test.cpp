#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "controller.hpp"
#include "platform.hpp"
#include "live_receipt.hpp"
#include "switch.h"
#include <chrono>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

namespace {
unsigned checks=0;
void check(bool value,const char*message){++checks;if(!value)throw std::runtime_error(message);}
#define CHECK(value) check((value),#value)
nc::ScanIdentity identity{72,0x01006BB00C6F0000ULL,std::string(64,'A'),0x10000000,1024*1024,0x20000000,4096};
std::vector<uint8_t> memory(size_t(identity.mainSize),0);
std::atomic<bool> attached{false},own{false},wrongRead{false};
std::atomic<bool> failApply{false},failRemove{false},invalidDiskReceipt{false};
std::atomic<unsigned> ramGeneration{0},activationGeneration{0},undoGeneration{0};
std::atomic<unsigned> attachCalls{0},readCalls{0},writeCalls{0},removeCalls{0},platformStarts{0},platformStops{0};
std::atomic<uint64_t> process{identity.pid};
nc::Pack applied;
nc::Game game(){nc::Game result;result.id=identity.title;result.name="Host fixture";result.buildId=identity.fullBuildId.substr(0,16);result.fullBuildId=identity.fullBuildId;result.running=result.buildVerified=true;return result;}
nc::ScanIdentity now(){auto value=identity;value.pid=process.load();return value;}
void number(uint32_t value){for(unsigned i=0;i<4;++i)memory[100+i]=uint8_t(value>>(8*i));}
void idle(){const auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);while(nc::overlay::snapshot().busy){if(std::chrono::steady_clock::now()>end)throw std::runtime_error("controller worker timeout");std::this_thread::sleep_for(std::chrono::milliseconds(1));}}
void waitRead(unsigned before){const auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);while(readCalls<=before){if(std::chrono::steady_clock::now()>end)throw std::runtime_error("read not started");std::this_thread::sleep_for(std::chrono::milliseconds(1));}}
}
namespace nc {
bool platformInit(Environment&,std::string &error){error.clear();++platformStarts;++ramGeneration;return true;}
void platformExit(){++platformStops;}
bool scanGames(std::vector<Game>&games,Environment&,std::string&error){error.clear();games={game()};return true;}
bool resolveBuild(Game&value,Environment&,std::string&error){error.clear();value=game();return true;}
bool peekScanProcess(const Game&,ScanIdentity&value,std::string&error){error.clear();if(!attached){error="engine not attached";return false;}value=now();return true;}
bool getScanProcess(const Game&,ScanIdentity&value,std::string&error){error.clear();attached=true;++attachCalls;value=now();return true;}
bool enumerateScanRegions(const ScanIdentity&,std::vector<ScanRegion>&regions,std::string&error){error.clear();regions={{identity.mainBase,identity.mainSize,true}};return true;}
bool readScanMemory(const ScanIdentity&expected,uint64_t address,void*out,size_t count,std::string&error){
    ++readCalls;error.clear();if(wrongRead||expected.pid!=process||address<identity.mainBase||count>memory.size()||address-identity.mainBase>memory.size()-count){error="read/session rejected";return false;}
    std::memcpy(out,memory.data()+size_t(address-identity.mainBase),count);return true;
}
Outcome applyLive(const Pack&pack){applied=pack;++writeCalls;own=true;activationGeneration=ramGeneration.load();Outcome out;out.ok=!failApply;out.message=failApply?"activated but receipt ENOSPC":"fixture activated";return out;}
Outcome removeLive(const Game&){++removeCalls;undoGeneration=ramGeneration.load();Outcome out;out.ok=!failRemove;if(out.ok)own=false;out.message=failRemove?"fixture undo uncertain":"fixture removed";return out;}
namespace native {
bool loadLiveReceipt(LiveReceipt&receipt,std::string&error){error.clear();receipt={};if(invalidDiskReceipt){error="partial ENOSPC receipt";return false;}if(own){receipt.valid=true;receipt.pid=process;receipt.title=identity.title;receipt.buildId=identity.fullBuildId.substr(0,16);receipt.changes.resize(1);}return true;}
}
}
int main(){namespace fs=std::filesystem;const auto root=fs::temp_directory_path()/("ninmagic-overlay-controller-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{
    fs::create_directory(root);setenv("NC_SCANNER_ROOT",root.generic_string().c_str(),1);std::string error;
    CHECK(nc::overlay::init(error));idle();auto state=nc::overlay::snapshot();CHECK(state.initialized&&!state.ready&&state.game.running);CHECK(attachCalls==0&&writeCalls==0);
    CHECK(nc::overlay::refresh());idle();CHECK(attachCalls==0&&readCalls==0);
    // No render updates or snapshot polling while this read completes: the
    // background thread must progress independently of a visible UI.
    number(100);CHECK(nc::overlay::begin(nc::ScanValueType::U32,false,"100",0));CHECK(!nc::overlay::begin(nc::ScanValueType::U32,true,"",0));std::this_thread::sleep_for(std::chrono::milliseconds(150));idle();state=nc::overlay::snapshot();CHECK(state.ready&&state.rounds==1&&state.candidateCount==1&&!state.canTest);CHECK(attachCalls==1&&writeCalls==0&&state.processedBytes==identity.mainSize);
    CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==0&&!nc::overlay::snapshot().error.empty());
    number(90);CHECK(nc::overlay::filter(nc::ScanCompare::Decreased,""));idle();CHECK(nc::overlay::snapshot().rounds==2&&!nc::overlay::snapshot().canTest);
    number(80);CHECK(nc::overlay::filter(nc::ScanCompare::Decreased,""));idle();CHECK(nc::overlay::snapshot().canTest&&writeCalls==0);
    // A candidate changing since the final comparison must not be activated.
    number(79);CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==0&&nc::overlay::snapshot().error.find("cambió")!=std::string::npos);
    number(80);CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==1&&nc::overlay::snapshot().ownActive);CHECK(applied.sessionOnly&&applied.sessionBinding.pid==identity.pid&&applied.sessionBinding.fullBuildId==identity.fullBuildId&&applied.cheats.size()==1&&applied.cheats[0].opcodes.size()==3);
    CHECK(nc::overlay::remove());idle();CHECK(removeCalls==1&&!nc::overlay::snapshot().ownActive);
    // An activated code with an unsaved/invalid receipt is undone immediately
    // using the very same native backend generation, before any service reset.
    failApply=true;invalidDiskReceipt=true;CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==2&&!own&&removeCalls==2);CHECK(undoGeneration==activationGeneration&&!nc::overlay::snapshot().ownActive);
    // Ambiguous rollback keeps RAM ownership, blocks another test without a
    // service reinitialization, and allows explicit undo in that same context.
    failRemove=true;CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==3&&own&&removeCalls==3&&nc::overlay::snapshot().ownActive&&!nc::overlay::snapshot().canTest);const auto dirtyGeneration=ramGeneration.load();CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==3&&ramGeneration==dirtyGeneration);failRemove=false;CHECK(nc::overlay::remove());idle();CHECK(!own&&undoGeneration==dirtyGeneration&&ramGeneration==dirtyGeneration&&!nc::overlay::snapshot().ownActive);
    // A pending in-memory receipt receives another undo attempt before unload.
    failRemove=true;CHECK(nc::overlay::test("999",0));idle();const auto shutdownGeneration=ramGeneration.load(),beforeShutdownUndo=removeCalls.load();failRemove=false;nc::overlay::shutdown();CHECK(removeCalls==beforeShutdownUndo+1&&!own&&undoGeneration==shutdownGeneration);failApply=false;invalidDiskReceipt=false;
    // A reopened overlay can recover the same process's persisted scan.
    nc::overlay::shutdown();CHECK(mockSmOpen==mockSmClose&&mockSdOpen==mockSdClose);CHECK(nc::overlay::init(error));idle();CHECK(nc::overlay::snapshot().ready&&nc::overlay::snapshot().rounds==3);CHECK(attachCalls==1);
    process=identity.pid+1;CHECK(nc::overlay::test("999",0));idle();CHECK(writeCalls==4&&nc::overlay::snapshot().error.find("reinició")!=std::string::npos);
    process=identity.pid;CHECK(nc::overlay::refresh());idle();const auto oldRounds=nc::overlay::snapshot().rounds;
    const auto readsBefore=readCalls.load();CHECK(nc::overlay::begin(nc::ScanValueType::U32,true,"",0));waitRead(readsBefore);nc::overlay::cancel();idle();CHECK(nc::overlay::snapshot().rounds==oldRounds&&nc::overlay::snapshot().error.find("cancelada")!=std::string::npos);
    // Exit must synchronously cancel+join before code can be unloaded.
    const auto nextRead=readCalls.load();CHECK(nc::overlay::begin(nc::ScanValueType::U32,true,"",0));waitRead(nextRead);nc::overlay::shutdown();const auto stoppedAt=readCalls.load();std::this_thread::sleep_for(std::chrono::milliseconds(20));CHECK(readCalls==stoppedAt&&!nc::overlay::snapshot().initialized);CHECK(mockSmOpen==mockSmClose&&mockSdOpen==mockSdClose&&platformStarts==platformStops);CHECK(writeCalls==4);
    // A zero-result comparison is real, but explicit undo can recover the two
    // preceding candidates from the other slot without reading game memory.
    CHECK(nc::overlay::init(error));idle();number(100);for(unsigned i=0;i<4;++i)memory[200+i]=uint8_t(100u>>(8*i));CHECK(nc::overlay::begin(nc::ScanValueType::U32,false,"100",0));idle();CHECK(nc::overlay::snapshot().candidateCount==2&&nc::overlay::snapshot().rounds==1);CHECK(nc::overlay::undo());idle();CHECK(nc::overlay::snapshot().rounds==1&&!nc::overlay::snapshot().error.empty());
    number(90);for(unsigned i=0;i<4;++i)memory[200+i]=uint8_t(90u>>(8*i));CHECK(nc::overlay::filter(nc::ScanCompare::Decreased,""));idle();CHECK(nc::overlay::snapshot().candidateCount==2&&nc::overlay::snapshot().rounds==2);CHECK(nc::overlay::filter(nc::ScanCompare::Changed,""));idle();CHECK(nc::overlay::snapshot().candidateCount==0&&nc::overlay::snapshot().rounds==3);CHECK(nc::overlay::refresh());idle();CHECK(nc::overlay::snapshot().candidateCount==0);
    const auto readsBeforeUndo=readCalls.load(),writesBeforeUndo=writeCalls.load(),attachesBeforeUndo=attachCalls.load();CHECK(nc::overlay::undo());idle();CHECK(nc::overlay::snapshot().candidateCount==2&&nc::overlay::snapshot().rounds==2&&!nc::overlay::snapshot().canTest);CHECK(readCalls==readsBeforeUndo&&writeCalls==writesBeforeUndo&&attachCalls==attachesBeforeUndo);
    process=identity.pid+1;CHECK(nc::overlay::undo());idle();CHECK(nc::overlay::snapshot().rounds==2&&!nc::overlay::snapshot().error.empty()&&readCalls==readsBeforeUndo);process=identity.pid;nc::overlay::shutdown();CHECK(nc::overlay::init(error));idle();CHECK(nc::overlay::snapshot().candidateCount==2&&nc::overlay::snapshot().rounds==2);nc::overlay::shutdown();CHECK(mockSmOpen==mockSmClose&&mockSdOpen==mockSdClose&&platformStarts==platformStops);
    const auto canonical=fs::weakly_canonical(root);CHECK(canonical.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&canonical.filename().string().find("ninmagic-overlay-controller-")==0);fs::remove_all(canonical);
    std::cout<<"Overlay controller: "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception&exception){nc::overlay::shutdown();std::cerr<<"FAIL "<<exception.what()<<" ("<<root<<")\n";return 1;}}

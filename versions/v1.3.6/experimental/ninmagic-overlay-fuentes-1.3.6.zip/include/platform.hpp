#pragma once
#include "model.hpp"
#include "scanner.hpp"
namespace nc {
bool platformInit(Environment &env,std::string &error);
void platformExit();
bool scanGames(std::vector<Game> &games,Environment &env,std::string &error);
bool resolveBuild(Game &game,Environment &env,std::string &error);
// Read only: counts loaded dmnt entries (including disabled entries and master)
// for this exact running game without attaching the cheat engine.
bool inspectActive(const Game &game,unsigned &count,std::string &error);
// Queries only an already attached engine. Does not attach, enable or disable.
bool readLiveState(Pack &pack,std::string &error);
Outcome applyLive(const Pack &pack);
Outcome removeLive(const Game &game);
// Read-only session lookup; does not attach dmnt or change cheat states.
bool peekScanProcess(const Game &game,ScanIdentity &identity,std::string &error);
// Only call after explicit scan-start confirmation. An initial dmnt attachment
// can load and enable the game's pre-existing SD cheat file.
bool getScanProcess(const Game &game,ScanIdentity &identity,std::string &error);
bool enumerateScanRegions(const ScanIdentity &identity,std::vector<ScanRegion> &regions,std::string &error);
// Read only, at most 64 KiB per call, writable non-executable MAIN/HEAP pages.
bool readScanMemory(const ScanIdentity &identity,uint64_t address,void *buffer,size_t size,std::string &error);
}

#pragma once
#include "model.hpp"
namespace nc {
bool loadCatalog(Catalog &catalog,std::string &error);
bool syncCatalog(Catalog &catalog,std::string &error);
// Call from a worker: checks published releases and remote validators without
// downloading unchanged archives. force also refreshes the latest snapshot.
bool refreshCatalog(Catalog &catalog,bool force,std::string &error);
// Verified HTTPS transport shared by catalog and the executable updater.
bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error);
Pack findCheats(const Game &game,const Catalog &catalog);
void catalogExit();
}

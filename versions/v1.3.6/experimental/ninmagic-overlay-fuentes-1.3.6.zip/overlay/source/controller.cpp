#include "controller.hpp"
#include "platform.hpp"
#include "live_receipt.hpp"
#include "memory_scan_guard.hpp"
#include <switch.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <utility>

namespace nc::overlay {
namespace {
enum class Action { None, Refresh, Check, Begin, Filter, Undo, Test, Remove };
struct Command {
    Action action=Action::None;
    Game expected;
    ScanValueType type=ScanValueType::U32;
    ScanCompare comparison=ScanCompare::Changed;
    bool unknown=true;
    int purpose=0;
    std::string value;
};
Mutex lock{};
UEvent wake{};
Thread worker{};
bool created=false;
std::atomic<bool> stopping{false},cancelled{false};
Snapshot view;
Command pending;
ScanSession session;
Game current;
Environment environment;
bool services=false;
// Failed persistence can leave the only complete ownership receipt in the
// native backend's RAM. Never reset that context before undoing it.
bool dirtyContext=false;
Game dirtyGame;
struct TrialOutcome {
    bool attempted=false,ok=false,removed=false;
    ScanIdentity identity;
    std::string message;
} lastTrial;
struct TrialProbe {
    bool known=false,typeKnown=true;
    Game game;
    ScanIdentity identity;
    ScanValueType type=ScanValueType::U32;
    Cheat cheat;
    uint64_t address=0;
    uint32_t requestedBits=0;
} trial;
constexpr size_t WorkerStack=0x40000;
struct Guard { Guard(){mutexLock(&lock);} ~Guard(){mutexUnlock(&lock);} };

void publish(const std::string &status,const std::string &error={}) {
    Guard guard;
    view.game=current;view.ready=session.ready;view.type=session.type;
    view.baseline=session.baseline;view.streamed=session.streamed;
    view.partial=session.partial;view.candidateCount=session.candidateCount;
    view.coveredBytes=session.coveredBytes;view.totalBytes=session.totalBytes;
    view.rounds=session.rounds;
    view.canTest=!dirtyContext&&session.ready&&!session.baseline&&session.candidateCount==1&&session.candidates.size()==1&&session.rounds>=3;
    view.candidateAddress=0;view.candidateValue.clear();
    if(session.candidates.size()==1){view.candidateAddress=session.candidates[0].address;view.candidateValue=scanValueText(session.type,session.candidates[0].valueBits);}
    view.status=status;view.error=error;
    if(dirtyContext){const std::string warning=" Puede haber códigos activos con un recibo sólo en memoria. Usa Retirar; si no es posible, cierra y abre el juego antes de salir.";view.status+=warning;if(view.error.empty())view.error=warning;}
}
bool sameGame(const Game &expected,const Game &actual,std::string &error) {
    if(!expected.id||expected.id!=actual.id||expected.fullBuildId!=actual.fullBuildId){error="Cambió el juego abierto o su Build ID. Pulsa detectar y revisa el juego antes de continuar.";return false;}return true;
}
bool findCurrent(std::string &error) {
    std::vector<Game> games;
    if(!scanGames(games,environment,error))return false;
    const auto found=std::find_if(games.begin(),games.end(),[](const Game &game){return game.running;});
    if(found==games.end()){error="Abre un juego compatible y vuelve al overlay. No se detectó un juego en ejecución.";current={};return false;}
    Game next=*found;
    if(!resolveBuild(next,environment,error)||!next.running||!next.buildVerified||next.fullBuildId.size()!=64){if(error.empty())error="No se pudo verificar el juego abierto y su Build ID completo.";return false;}
    current=std::move(next);return true;
}
bool sameProcess(ScanIdentity &identity,std::string &error) {
    if(!session.ready){error="Primero inicia una búsqueda.";return false;}
    if(!peekScanProcess(current,identity,error))return false;
    if(!native::scan::same(identity,session.identity)){error="El juego se reinició o cambió su memoria. Inicia una búsqueda nueva; no se reutilizarán sus direcciones.";return false;}return true;
}
void updateOwned() {
    bool active=false;
    ScanIdentity identity;std::string ignored;
    if(current.id&&peekScanProcess(current,identity,ignored)){
        native::LiveReceipt receipt;
        active=native::loadLiveReceipt(receipt,ignored)&&receipt.valid&&receipt.pid==identity.pid&&receipt.title==current.id&&receipt.buildId==current.buildId&&(!receipt.changes.empty()||receipt.masterAdded);
    }
    Guard guard;view.ownActive=active||dirtyContext;
}
std::string trialValue(uint32_t bits){if(trial.typeKnown)return scanValueText(trial.type,bits);char value[16];std::snprintf(value,sizeof(value),"0x%08lX",static_cast<unsigned long>(bits));return value;}
void resetCheck(){
    Guard guard;
    view.trialAttempted=lastTrial.attempted;view.trialApplyOk=lastTrial.ok;view.trialRemoved=lastTrial.removed;
    view.trialMessage=lastTrial.message;view.trialSameSession=false;
    view.trialPid=lastTrial.attempted?lastTrial.identity.pid:trial.identity.pid;
    view.trialType=trial.type;view.trialTypeKnown=trial.known&&trial.typeKnown;view.engineChecked=view.trialEnabled=false;
    view.trialValueChecked=view.trialMatches=false;view.trialEngineState=CheatState::Unknown;
    view.requestedValue=trial.known?trialValue(trial.requestedBits):std::string{};
    view.currentValue.clear();view.checkDetail.clear();
}
bool probeDefinition(TrialProbe &probe,const Game &game,const ScanIdentity &identity,const Cheat &cheat,ScanValueType type){
    if(cheat.opcodes.size()!=3)return false;
    const uint32_t first=cheat.opcodes[0],width=(first>>24)&15,region=(first>>20)&15;
    if((first>>28)!=0||(width!=1&&width!=2&&width!=4)||region>2||(first&0x000FFF00u))return false;
    if(width<4&&cheat.opcodes[2]>=(uint32_t(1)<<(width*8)))return false;
    const uint64_t offset=(uint64_t(first&255)<<32)|cheat.opcodes[1],base=region==0?identity.mainBase:region==1?identity.heapBase:identity.aliasBase;
    const uint64_t extent=region==0?identity.mainSize:region==1?identity.heapSize:identity.aliasSize;
    if(offset>=extent||width>extent-offset)return false;
    if(base>UINT64_MAX-offset||!native::scan::allowed(identity,base+offset,width))return false;
    const unsigned typeWidth=type==ScanValueType::U8?1:type==ScanValueType::U16?2:4;
    if(width!=typeWidth)return false;
    probe={};probe.known=true;probe.game=game;probe.identity=identity;probe.type=type;
    probe.cheat=cheat;probe.address=base+offset;probe.requestedBits=cheat.opcodes[2];return true;
}
void recoverProbe(const ScanIdentity &identity){
    if(trial.known||lastTrial.attempted)return;
    native::LiveReceipt receipt;std::string ignored;
    if(!native::loadLiveReceipt(receipt,ignored)||!receipt.valid||receipt.pid!=identity.pid||receipt.title!=current.id||receipt.buildId!=current.buildId)return;
    // Recover only this application's single static experiment, never treat a
    // general catalog cheat as a memory-scanner trial.
    const native::Definition *definition=nullptr;
    for(const auto &change:receipt.changes){
        const auto &d=change.definition;
        if(d.count!=3||std::strncmp(d.name,"NinMagic prueba ",15)!=0)continue;
        if(definition)return;
        definition=&d;
    }
    if(!definition)return;
    const unsigned width=(definition->codes[0]>>24)&15;
    ScanValueType type=width==1?ScanValueType::U8:width==2?ScanValueType::U16:ScanValueType::U32;
    Cheat cheat;cheat.name=std::string(definition->name,std::find(definition->name,definition->name+sizeof(definition->name),'\0'));
    cheat.opcodes.assign(definition->codes,definition->codes+3);cheat.selected=true;
    if(probeDefinition(trial,current,identity,cheat,type))trial.typeKnown=width!=4;
}
void checkTrial(){
    resetCheck();
    ScanIdentity before;std::string error;
    if(!current.id||!peekScanProcess(current,before,error)){
        Guard guard;view.checkDetail=error.empty()?"No hay un proceso conectado que permita comprobar la prueba.":error;return;
    }
    recoverProbe(before);resetCheck();
    const ScanIdentity expected=trial.known?trial.identity:lastTrial.identity;
    if(!native::scan::same(expected,before)){
        Guard guard;view.checkDetail=lastTrial.attempted||trial.known?"El resultado pertenece a otra sesión. No se leyó su dirección en el proceso actual.":"No hay una prueba registrada para comprobar.";return;
    }
    {Guard guard;view.trialSameSession=true;}
    if(!trial.known){Guard guard;view.checkDetail="La última prueba no llegó a generar un código; se conserva su resultado.";return;}
    Pack pack;pack.game=trial.game;pack.compatible=true;pack.sessionOnly=true;pack.sessionBinding=trial.identity;pack.cheats.push_back(trial.cheat);
    std::string engineError;
    const bool engine=readLiveState(pack,engineError)&&pack.liveChecked&&pack.livePid==expected.pid&&pack.cheats.size()==1;
    ScanIdentity afterEngine;
    if(!peekScanProcess(current,afterEngine,error)||!native::scan::same(expected,afterEngine)){
        resetCheck();Guard guard;view.checkDetail="El proceso cambió al consultar el motor. Estado y valor sin confirmar.";return;
    }
    uint8_t bytes[4]{};const size_t width=trial.type==ScanValueType::U8?1:trial.type==ScanValueType::U16?2:4;
    std::string valueError;const bool valueRead=readScanMemory(expected,trial.address,bytes,width,valueError);
    ScanIdentity afterValue;
    if(!peekScanProcess(current,afterValue,error)||!native::scan::same(expected,afterValue)){
        resetCheck();Guard guard;view.checkDetail="El proceso cambió durante la lectura. Estado y valor sin confirmar.";return;
    }
    uint32_t bits=0;if(valueRead)for(size_t i=0;i<width;++i)bits|=uint32_t(bytes[i])<<(8*i);
    Guard guard;view.engineChecked=engine;view.trialEngineState=engine?pack.cheats.front().liveState:CheatState::Unknown;
    view.trialEnabled=engine&&view.trialEngineState==CheatState::Enabled;
    view.trialValueChecked=valueRead;view.trialMatches=valueRead&&bits==trial.requestedBits;
    if(valueRead)view.currentValue=trialValue(bits);
    view.checkDetail=engine?"Estado del motor consultado; la lectura no demuestra qué controla el valor.":engineError;
    if(!valueRead)view.checkDetail+=" No se pudo leer el valor actual: "+valueError;
    if(!lastTrial.attempted)view.checkDetail="Código recuperado de su recibo; no se conserva el resultado del botón A. "+view.checkDetail;
}
bool refreshCurrent(std::string &error) {
    if(!findCurrent(error)){session={};return false;}
    ScanIdentity identity;
    std::string lookup;
    if(peekScanProcess(current,identity,lookup)){
        ScanSession loaded;
        if(loadScanSession(identity,loaded,lookup)){
            ScanIdentity after;
            if(!peekScanProcess(current,after,error)||!native::scan::same(identity,after)){if(error.empty())error="El proceso cambió durante la recuperación de la búsqueda.";session={};return false;}
            session=std::move(loaded);
        }else session={};
    }else session={};
    updateOwned();return true;
}
unsigned bytesPerValue(){return session.type==ScanValueType::U8?1:session.type==ScanValueType::U16?2:4;}
std::string trialName(int purpose){static const char *names[]={"Salud","Municion","Vidas","Magia","Objetos","Dinero","Movimiento","Valor"};return std::string("NinMagic prueba ")+names[std::clamp(purpose,0,7)];}
bool reloadServices(std::string &error){
    if(dirtyContext){error="Primero retira los códigos pendientes. Se conserva el recibo en memoria sin reconectar los servicios.";return false;}
    // The NRO can have changed the shared receipt while this overlay was
    // hidden. Reload ownership before any explicit activation or undo.
    platformExit();services=platformInit(environment,error);
    {Guard guard;view.initialized=services;}
    return services;
}

void perform(const Command &command) {
    std::string error,status;
    bool ok=false,removeNoOp=false;
    if(command.action==Action::Refresh){ok=refreshCurrent(error);status=session.ready?"Búsqueda recuperada de esta misma sesión.":"Juego detectado. Elige el tipo e inicia una búsqueda.";}
    else if(command.action==Action::Check){ok=true;status="Consulta de solo lectura: revisa el estado del código y el valor observado.";}
    else if(command.action==Action::Begin){
        if(findCurrent(error)&&sameGame(command.expected,current,error)){
            ScanIdentity identity;std::vector<ScanRegion> regions;
            // This is the sole explicit attachment boundary. Search and refresh
            // never attach the engine behind the user's confirmation.
            if(!cancelled.load()&&getScanProcess(current,identity,error)&&enumerateScanRegions(identity,regions,error)){
                ok=command.unknown?startUnknownScan(identity,regions,command.type,readScanMemory,session,error):startExactScan(identity,regions,command.type,command.value,readScanMemory,session,error);
                if(ok){ScanIdentity after;if(!peekScanProcess(current,after,error)||!native::scan::same(identity,after)){session={};ok=false;if(error.empty())error="El proceso cambió durante la lectura. Inicia una búsqueda nueva.";}}
            }
        }
        status="Referencia capturada mientras el juego seguía funcionando. Cambia el valor en el juego y compara.";
    }else if(command.action==Action::Filter){
        ScanIdentity identity;
        if(sameProcess(identity,error))ok=refineScan(identity,command.comparison,command.value,readScanMemory,session,error);
        if(ok){ScanIdentity after;if(!sameProcess(after,error))ok=false;}
        status=session.candidateCount==1?"Queda una coincidencia. Revisa las comparaciones antes de probarla.":"Comparación terminada. Cambia el valor en el juego y vuelve a comparar.";
    }else if(command.action==Action::Undo){
        ScanIdentity identity;
        if(!session.ready||session.rounds<=1)error="No hay una comparación anterior que recuperar.";
        else if(sameProcess(identity,error)){
            ok=restorePreviousScan(identity,session,error);
            if(ok){ScanIdentity after;if(!sameProcess(after,error))ok=false;}
        }
        status="Se recuperó la comparación anterior. Revisa lo que cambió en el juego antes de volver a filtrar.";
    }else if(command.action==Action::Test){
        // A rejected new attempt must not display an earlier attempt's code
        // under its outcome. Native ownership/dirty receipts stay independent.
        trial={};lastTrial={};lastTrial.attempted=true;lastTrial.identity=session.identity;
        ScanIdentity identity;
        if(cancelled.load()||stopping.load())error="Prueba cancelada antes de activar el candidato.";
        else if(dirtyContext)error="No se permiten nuevas pruebas hasta retirar los códigos pendientes; se conserva su recibo en memoria.";
        else if(!session.ready||session.baseline||session.candidateCount!=1||session.candidates.size()!=1||session.rounds<3)error="Para probar hacen falta una sola coincidencia y al menos dos comparaciones después de la primera lectura.";
        else if(reloadServices(error)&&sameProcess(identity,error)){
            uint8_t bytes[4]{};uint32_t bits=0;const auto &candidate=session.candidates.front();
            if(readScanMemory(identity,candidate.address,bytes,bytesPerValue(),error)){
                for(unsigned i=0;i<bytesPerValue();++i)bits|=uint32_t(bytes[i])<<(i*8);
                if(bits!=candidate.valueBits)error="El candidato cambió después de la última lectura. Compara otra vez antes de probarlo.";
                else {
                    Cheat cheat;
                    if(scanCandidateCheat(session,0,command.value,trialName(command.purpose),cheat,error)&&!cancelled.load()&&!stopping.load()){
                        Pack pack;pack.game=current;pack.compatible=true;pack.sessionOnly=true;pack.sessionBinding=identity;pack.cheats.push_back(std::move(cheat));
                        probeDefinition(trial,current,identity,pack.cheats.front(),session.type);
                        const auto result=applyLive(pack);ok=result.ok;
                        if(ok)status=result.message+" Comprueba su efecto en el juego. La dirección sólo vale para esta sesión.";
                        else if(result.liveEffect==LiveEffect::Enabled||result.liveEffect==LiveEffect::Uncertain){
                            // Activation can succeed while saving its receipt
                            // fails. Undo in this exact backend context first.
                            dirtyContext=true;dirtyGame=current;
                            const auto rollback=removeLive(dirtyGame);
                            const bool removed=rollback.ok&&rollback.liveEffect==LiveEffect::Removed;
                            dirtyContext=!removed;
                            error=result.message+" "+(removed?"Se retiraron los códigos de NinMagic del motor. Cierra y abre el juego para reiniciar sus valores.":"No se pudo confirmar la retirada inmediata: "+rollback.message);
                        }
                        else error=result.message;
                    }
                }
            }
        }
    }else if(command.action==Action::Remove){
        if(cancelled.load()||stopping.load())error="Retirada cancelada antes de modificar el motor.";
        else if(dirtyContext||reloadServices(error)){
            const Game target=dirtyContext?dirtyGame:command.expected;
            const auto result=removeLive(target);ok=result.ok;
            removeNoOp=ok&&result.liveEffect==LiveEffect::NoOwned&&!dirtyContext;
            if(dirtyContext&&result.liveEffect==LiveEffect::NoOwned){ok=false;error="No se pudo confirmar la retirada de una activación previa. Se conserva el contexto; cierra y abre el juego.";}
            else if(ok&&result.liveEffect==LiveEffect::Removed)dirtyContext=false;
            else if(result.liveEffect==LiveEffect::Uncertain||result.liveEffect==LiveEffect::Enabled){dirtyContext=true;dirtyGame=target;}
            if(ok){status=result.message;dirtyGame={};}else if(error.empty())error=result.message;
        }
    }
    if(cancelled.load()&&!ok&&error.empty())error="Operación cancelada. La búsqueda anterior se conserva.";
    if(!ok&&error.empty())error="No se pudo completar la operación.";
    if(command.action==Action::Test){lastTrial.ok=ok;lastTrial.message=ok?status:error;}
    if(command.action==Action::Remove&&!removeNoOp){lastTrial.attempted=true;lastTrial.ok=false;lastTrial.removed=ok;lastTrial.identity=trial.known?trial.identity:session.identity;lastTrial.message=ok?status:error;}
    if(command.action==Action::Refresh||command.action==Action::Check||command.action==Action::Test||command.action==Action::Remove)checkTrial();else resetCheck();
    updateOwned();publish(ok?status:error,ok?std::string{}:error);
}
void run(void*) {
    std::string error;
    const bool sm=R_SUCCEEDED(smInitialize());
    const bool mounted=sm&&R_SUCCEEDED(fsdevMountSdmc());
    if(sm&&mounted)services=platformInit(environment,error);
    else error="No se pudieron abrir los servicios y la microSD del overlay.";
    {Guard guard;view.initialized=services;view.busy=services;}
    if(services){
        setScanObserver([](uint64_t done,uint64_t total){
            {Guard guard;view.processedBytes=done;view.operationTotal=total;}
            // Yield CPU time while gameplay continues. Never pause the game.
            svcSleepThread(1000000);
            return !cancelled.load()&&!stopping.load();
        });
        Command initial;initial.action=Action::Refresh;perform(initial);
    }else publish(error,error);
    {Guard guard;view.busy=false;}
    while(!stopping.load()){
        waitSingle(waiterForUEvent(&wake),UINT64_MAX);
        if(stopping.load())break;
        Command command;
        {Guard guard;command=std::move(pending);pending={};}
        if(command.action!=Action::None&&services)perform(command);
        {Guard guard;view.busy=false;}
    }
    setScanObserver({});
    // Best effort before unload: an incomplete SD receipt must not be discarded
    // without trying to retire its activation using the surviving RAM receipt.
    if(services&&dirtyContext){const auto result=removeLive(dirtyGame);dirtyContext=!(result.ok&&result.liveEffect==LiveEffect::Removed);}
    // Even partially successful service initialization needs balanced cleanup.
    platformExit();services=false;session={};current={};dirtyContext=false;dirtyGame={};trial={};lastTrial={};
    if(mounted)fsdevUnmountDevice("sdmc");
    if(sm)smExit();
}
bool enqueue(Command command) {
    {Guard guard;if(!created||stopping.load()||!view.initialized||view.busy)return false;
        if(command.value.size()>64)return false;
        command.expected=view.game;pending=std::move(command);view.busy=true;view.processedBytes=0;view.operationTotal=0;view.error.clear();
        view.status=pending.action==Action::Undo?"Recuperando la comparación anterior de esta misma sesión...":pending.action==Action::Check?"Consultando el código y leyendo su valor actual...":"Trabajando; puedes ocultar el panel y seguir jugando.";cancelled.store(false);
    }
    ueventSignal(&wake);return true;
}
}

bool init(std::string &error) {
    error.clear();if(created)return true;
    mutexInit(&lock);ueventCreate(&wake,true);stopping.store(false);cancelled.store(false);view={};view.busy=true;
    Result rc=threadCreate(&worker,run,nullptr,nullptr,WorkerStack,0x3B,-2);
    if(R_FAILED(rc)){error="No se pudo reservar el hilo de búsqueda del overlay.";view.busy=false;view.status=view.error=error;return false;}
    rc=threadStart(&worker);
    if(R_FAILED(rc)){threadClose(&worker);error="No se pudo iniciar el hilo del buscador.";view.busy=false;view.status=view.error=error;return false;}
    created=true;return true;
}
void shutdown() {
    if(!created)return;
    stopping.store(true);cancelled.store(true);ueventSignal(&wake);
    threadWaitForExit(&worker);threadClose(&worker);created=false;
    Guard guard;view.initialized=false;view.busy=false;pending={};
}
Snapshot snapshot(){Guard guard;return view;}
bool refresh(){Command c;c.action=Action::Refresh;return enqueue(std::move(c));}
bool check(){Command c;c.action=Action::Check;return enqueue(std::move(c));}
bool begin(ScanValueType type,bool unknown,const std::string &value,int purpose){if(unsigned(type)>unsigned(ScanValueType::F32))return false;Command c;c.action=Action::Begin;c.type=type;c.unknown=unknown;c.value=value;c.purpose=purpose;return enqueue(std::move(c));}
bool filter(ScanCompare comparison,const std::string &value){if(unsigned(comparison)>unsigned(ScanCompare::Decreased))return false;Command c;c.action=Action::Filter;c.comparison=comparison;c.value=value;return enqueue(std::move(c));}
bool undo(){Command c;c.action=Action::Undo;return enqueue(std::move(c));}
bool test(const std::string &value,int purpose){Command c;c.action=Action::Test;c.value=value;c.purpose=purpose;return enqueue(std::move(c));}
bool remove(){Command c;c.action=Action::Remove;return enqueue(std::move(c));}
void cancel(){cancelled.store(true);}
}

# Vistas de desarrollo del overlay

`preview/` contiene dieciocho vistas de la misma lógica de dibujo que usa el overlay, incluidas prueba aplicada, motor deshabilitado con valor distinto, informe, error, otra sesión, recibo sin resultado histórico, retirada, HUD con motor deshabilitado, un error anterior junto a una referencia inicial nueva o sin referencia activa y cobertura ampliada parcial de MAIN/HEAP más Heap validado en ALIAS.

El adaptador de `tools/mock/tesla.hpp` sustituye únicamente el renderer y los servicios de consola para poder inspeccionar el diseño en el PC. Usa los glifos DejaVu existentes como aproximación a las fuentes compartidas de Switch; no reproduce sus métricas con exactitud. El damero representa transparencia, no una captura del juego. Datos, valores y estados son ejemplos; estas imágenes no prueban ejecución en hardware.

Desde la carpeta principal `ninmagic-cheats`:

```powershell
g++ -std=c++20 -O2 -Wall -Wextra -Werror -Ioverlay/tools/mock -Ioverlay/include -Iinclude overlay/tools/preview.cpp -o "$env:TEMP/ninmagic-overlay-preview.exe"
& "$env:TEMP/ninmagic-overlay-preview.exe" romfs overlay/docs/preview
python tools/convert_preview.py overlay/docs/preview
```

El ejecutable comprueba 59 límites de entrada, texto y resultados. Una búsqueda nueva de puntos/barra empieza en U8, permite seleccionar U16/U32/F32 y no cambia el tipo de una sesión F32 existente; preparar el formulario no inicia una lectura ni prueba automáticamente. También se comprueban pasividad del HUD, confirmaciones, edición del valor, recuperación de pasos, conservación del resultado tras comprobar y distinción entre éxito, error y retirada. El resumen de búsqueda distingue operación en curso, ausencia de referencia, primera lectura guardada y cantidades filtradas, incluso cuando se conserva un error de prueba anterior. El mock reproduce el comportamiento real de `limitStringLength` de libtesla: quitar el último carácter incluso si cabe. Las comprobaciones verifican que la UI evita esa función, conserva los diez dígitos, respeta el ancho exacto y recorta UTF-8 solo cuando sobra ancho, reservando los puntos suspensivos. Los servicios de memoria están sustituidos por contadores: no se lee ni escribe la consola.

Los builds de Switch no incluyen `tools/mock/`.

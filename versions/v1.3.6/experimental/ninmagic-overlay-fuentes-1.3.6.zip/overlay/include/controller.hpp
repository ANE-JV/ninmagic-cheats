#pragma once
#include "model.hpp"
#include "scanner.hpp"
#include <cstdint>
#include <string>

namespace nc::overlay {
// A small copy published by the worker; never copy its candidate vector on the
// render thread. Only the worker accesses services and persistent scan state.
struct Snapshot {
    Game game;
    ScanValueType type=ScanValueType::U32;
    bool initialized=false,ready=false,busy=false,baseline=false,streamed=false;
    bool partial=false,canTest=false,ownActive=false;
    uint64_t candidateCount=0,coveredBytes=0,totalBytes=0;
    uint64_t processedBytes=0,operationTotal=0,candidateAddress=0;
    unsigned rounds=0;
    std::string candidateValue,status="Preparando el buscador...",error;
    // Historical outcome and a separate read-only observation. Neither means
    // the address has been demonstrated to control health or another effect.
    bool trialAttempted=false,trialApplyOk=false,trialRemoved=false,trialSameSession=false,trialTypeKnown=false;
    bool engineChecked=false,trialEnabled=false,trialValueChecked=false,trialMatches=false;
    uint64_t trialPid=0;
    ScanValueType trialType=ScanValueType::U32;
    CheatState trialEngineState=CheatState::Unknown;
    std::string trialMessage,requestedValue,currentValue,checkDetail;
};
bool init(std::string &error);
// Must finish before the loader unloads the overlay. Cancels at the scanner's
// next read boundary, joins its thread and then releases all native services.
void shutdown();
Snapshot snapshot();
bool refresh();
// Check the last trial's actual engine entry and value without attaching,
// enabling or writing. Its original result remains separate from this check.
bool check();
// Explicit user confirmation is required before begin: connecting dmnt can
// load/enable the game's pre-existing SD cheat file.
bool begin(ScanValueType type,bool unknown,const std::string &value,int purpose);
bool filter(ScanCompare comparison,const std::string &value);
// Explicitly recover the preceding comparison from the other validated slot.
// Does not attach dmnt, read game values or activate a candidate.
bool undo();
// Explicit experiment confirmation, one candidate and >=3 rounds required.
bool test(const std::string &value,int purpose);
bool remove();
void cancel();
}

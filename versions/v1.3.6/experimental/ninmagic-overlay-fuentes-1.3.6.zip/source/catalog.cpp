#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "catalog.hpp"
#include "cheats.hpp"
#include "archive_merge.hpp"
#include "release_index.hpp"
#include <minizip/unzip.h>
#ifdef __SWITCH__
#include <switch.h>
#include <curl/curl.h>
#endif
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <map>
#include <set>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>
#ifdef NC_CATALOG_TEST
#include <functional>
#endif

namespace nc {
namespace {
constexpr uint64_t MaxArchive=64ULL*1024*1024, MaxFile=2ULL*1024*1024;
constexpr uint64_t MaxExpanded=256ULL*1024*1024;
constexpr size_t MaxEntries=20000, MaxMembers=60000;
const char *GeneralUrl="https://github.com/HamletDuFromage/switch-cheats-db/releases/latest/download/contents_complete.zip";
const char *RawUrl="https://github.com/HamletDuFromage/switch-cheats-db/releases/latest/download/contents.zip";
const char *GraphicsUrl="https://codeload.github.com/ChanseyIsTheBest/NX-60FPS-RES-GFX-Cheats/zip/refs/heads/main";
struct RemoteStamp {std::string etag,modified,length;};
#ifdef NC_CATALOG_TEST
bool testNetworkReady=false;
std::function<bool(const std::string&,const std::string&,std::string&,RemoteStamp*,bool)> testTransfer;
#endif
#ifdef __SWITCH__
bool socketsReady=false, nifmReady=false, curlReady=false;
#endif

std::string root() {
#ifdef NC_CATALOG_TEST
    const char *value=std::getenv("NC_CATALOG_ROOT");return value?value:"catalog-test";
#else
    return "sdmc:/config/NinMagicCheats";
#endif
}
bool statPath(const std::string &path,struct stat &st) {return lstat(path.c_str(),&st)==0;}
bool regular(const std::string &path,uint64_t max) {
    struct stat st{};return statPath(path,st)&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=max;
}
bool directory(const std::string &path) {
    struct stat st{};
    if(statPath(path,st))return S_ISDIR(st.st_mode)&&!S_ISLNK(st.st_mode);
    if(errno!=ENOENT)return false;
#ifdef _WIN32
    return mkdir(path.c_str())==0;
#else
    return mkdir(path.c_str(),0777)==0;
#endif
}
bool ensureRoot(std::string &error) {
#ifndef NC_CATALOG_TEST
    if(!directory("sdmc:/config")){error="No se puede abrir la carpeta config de la microSD.";return false;}
#endif
    if(!directory(root())){error="No se puede abrir la carpeta de NinMagic Cheats.";return false;}
    return true;
}
bool readSmall(const std::string &path,std::string &out,size_t max) {
    out.clear();if(!regular(path,max))return false;
    FILE *f=fopen(path.c_str(),"rb");if(!f)return false;
    std::array<char,4096> b{};size_t n;
    while((n=fread(b.data(),1,b.size(),f))) {if(out.size()+n>max){fclose(f);return false;}out.append(b.data(),n);}
    bool ok=!ferror(f);fclose(f);return ok;
}
bool writeSmall(const std::string &path,const std::string &text) {
    struct stat st{};if(statPath(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)))return false;
    FILE *f=fopen(path.c_str(),"wb");if(!f)return false;
    bool ok=fwrite(text.data(),1,text.size(),f)==text.size()&&fflush(f)==0;
    if(ok)ok=fsync(fileno(f))==0;
    if(fclose(f)!=0)ok=false;
    return ok;
}
std::string upper(std::string value) {
    for(char &c:value)c=char(std::toupper(static_cast<unsigned char>(c)));
    return value;
}
bool hex16(const std::string &value) {
    return value.size()==16&&std::all_of(value.begin(),value.end(),[](unsigned char c){return std::isxdigit(c)!=0;});
}
bool memberIdentity(const std::string &path,uint64_t &title,std::string &build) {
    if(path.empty()||path.size()>512||path[0]=='/'||path.find('\\')!=std::string::npos||path.find(':')!=std::string::npos)return false;
    std::vector<std::string> parts;std::istringstream s(path);std::string part;
    while(std::getline(s,part,'/')) {if(part.empty()||part=="."||part=="..")return false;parts.push_back(part);}
    // Releases use contents/<TID>/cheats/<BID>.txt. GitHub's source ZIP adds
    // one repository folder before titles/. Mirrors may omit that folder.
    size_t p=0;
    if(parts.size()==5&&(parts[1]=="titles"||parts[1]=="contents"))p=1;
    if(parts.size()!=p+4||(parts[p]!="contents"&&parts[p]!="titles")||!hex16(parts[p+1])||parts[p+2]!="cheats")return false;
    const std::string &filename=parts[p+3];
    if(filename.size()!=20||upper(filename.substr(16))!=".TXT"||!hex16(filename.substr(0,16)))return false;
    title=0;for(unsigned char c:upper(parts[p+1]))title=(title<<4)|(c<='9'?c-'0':c-'A'+10);
    if(title<0x0100000000010000ULL)return false;
    build=upper(filename.substr(0,16));return build!="0000000000000000";
}
bool currentFile(unzFile zip,std::string &out,std::string &error) {
    unz_file_info64 info{};
    if(unzGetCurrentFileInfo64(zip,&info,nullptr,0,nullptr,0,nullptr,0)!=UNZ_OK||info.uncompressed_size>MaxFile||(info.flag&1)||(info.compression_method!=0&&info.compression_method!=8)) {
        error="El catálogo contiene un archivo no admitido o demasiado grande.";return false;
    }
    if(unzOpenCurrentFile(zip)!=UNZ_OK){error="No se puede abrir un cheat del catálogo.";return false;}
    out.clear();out.reserve(size_t(info.uncompressed_size));std::array<char,16384> buffer{};
    int n=0;bool ok=true;
    while((n=unzReadCurrentFile(zip,buffer.data(),unsigned(buffer.size())))>0) {
        if(out.size()+size_t(n)>MaxFile){ok=false;break;}out.append(buffer.data(),size_t(n));
    }
    const int closed=unzCloseCurrentFile(zip);
    if(n<0||closed!=UNZ_OK||out.size()!=info.uncompressed_size)ok=false;
    if(!ok)error="Catálogo dañado: el tamaño o el CRC del archivo no coincide.";
    return ok;
}
bool indexArchive(const std::string &file,const std::string &source,std::vector<CatalogEntry> &entries,std::string &error,bool verify,bool manual=false) {
    if(!regular(file,MaxArchive)){error="Falta el archivo de catálogo de "+source+".";return false;}
    unzFile zip=unzOpen64(file.c_str());
    if(!zip){error="El catálogo de "+source+" no es un ZIP válido.";return false;}
    unz_global_info64 global{};bool ok=unzGetGlobalInfo64(zip,&global)==UNZ_OK&&global.number_entry>0&&global.number_entry<=MaxMembers;
    std::set<std::pair<uint64_t,std::string>> unique;size_t start=entries.size();uint64_t expanded=0;
    int result=ok?unzGoToFirstFile(zip):UNZ_BADZIPFILE;
    for(uint64_t i=0;ok&&i<global.number_entry;++i) {
        unz_file_info64 info{};std::array<char,1024> name{};
        if(result!=UNZ_OK||unzGetCurrentFileInfo64(zip,&info,name.data(),unsigned(name.size()),nullptr,0,nullptr,0)!=UNZ_OK||info.size_filename>=name.size()||std::strlen(name.data())!=info.size_filename) {ok=false;break;}
        std::string checked;
        if(manual){const unsigned type=(info.external_fa>>16)&0xf000;if(info.uncompressed_size>MaxFile||(type!=0&&type!=0x8000&&type!=0x4000)||!currentFile(zip,checked,error)){ok=false;break;}}
        expanded+=info.uncompressed_size;
        if(expanded>MaxExpanded){ok=false;break;}
        uint64_t title=0;std::string build;
        if(memberIdentity(name.data(),title,build)) {
            if(entries.size()-start>=MaxEntries||!unique.emplace(title,build).second){error="Catálogo ambiguo: contiene un Build ID duplicado.";ok=false;break;}
            if(info.uncompressed_size==0||info.uncompressed_size>MaxFile||(info.flag&1)||(info.compression_method!=0&&info.compression_method!=8)){ok=false;break;}
            if(verify&&!manual) {std::string data;if(!currentFile(zip,data,error)){ok=false;break;}}
            if(manual){std::vector<Cheat> parsed;if(!parseCheats(checked,source,parsed,error)){ok=false;break;}}
            CatalogEntry entry;entry.titleId=title;entry.buildId=build;entry.source=source;entry.path=name.data();entry.archive=file;entries.push_back(std::move(entry));
        }
        result=unzGoToNextFile(zip);
    }
    if(result!=UNZ_END_OF_LIST_OF_FILE)ok=false;
    unzClose(zip);
    if(!ok||entries.size()==start) {
        entries.resize(start);if(error.empty())error="El catálogo de "+source+" está vacío, dañado o supera los límites.";return false;
    }
    return true;
}
void appendManual(Catalog &catalog){
    const auto path=root()+"/manual-cheats.zip";struct stat st{};
    if(!statPath(path,st)&&errno==ENOENT)return;
    std::vector<CatalogEntry> imported;std::string error;
    if(!indexArchive(path,"Importacion local",imported,error,true,true)){catalog.detail+=" · Importación local omitida: "+error;return;}
    catalog.entries.insert(catalog.entries.end(),imported.begin(),imported.end());
    catalog.detail+=" · "+std::to_string(imported.size())+" versiones de importación local";
}
bool loadSlot(char slot,Catalog &catalog,std::string &error,bool verify=false) {
    std::string path=root()+"/catalog-"+slot,complete;
    struct stat parent{};
    if(!statPath(path,parent)||!S_ISDIR(parent.st_mode)||S_ISLNK(parent.st_mode)){error="No existe una carpeta válida de catálogo.";return false;}
    if(!readSmall(path+"/complete.txt",complete,128)){error="El catálogo local todavía no está completo.";return false;}
    complete.erase(std::remove(complete.begin(),complete.end(),'\r'),complete.end());
    if(complete.rfind("NINMAGIC-CATALOG-1\n",0)!=0){error="El catálogo local todavía no está completo.";return false;}
    Catalog next;
    if(!indexArchive(path+"/general.zip","Hamlet",next.entries,error,verify)||!indexArchive(path+"/graphics.zip","NX-60FPS-RES-GFX",next.entries,error,verify))return false;
    next.generalReady=next.graphicsReady=true;
    auto newline=complete.find('\n',19);next.stamp=complete.substr(19,newline==std::string::npos?std::string::npos:newline-19);
    if(next.stamp.empty())next.stamp="Caché local";
    next.detail=std::to_string(next.entries.size())+" versiones de ambas bases de cheats";
    appendManual(next);
    catalog=std::move(next);return true;
}
char activeSlot() {std::string s;return readSmall(root()+"/active.txt",s,8)&&!s.empty()&&s[0]=='b'?'b':'a';}
bool safeUrl(const std::string &url) {
    if(url.size()<9||url.size()>2048||url.rfind("https://",0)!=0)return false;
    auto end=url.find('/',8);std::string host=url.substr(8,end==std::string::npos?std::string::npos:end-8);
    return !host.empty()&&host.find('@')==std::string::npos&&std::none_of(url.begin(),url.end(),[](unsigned char c){return c<=32||c==127||c=='\\';});
}
std::string trim(std::string v) {auto p=v.find_first_not_of(" \t\r\n");if(p==std::string::npos)return {};auto q=v.find_last_not_of(" \t\r\n");return v.substr(p,q-p+1);}
bool sourceUrls(std::string &general,std::string &graphics,std::string &error,std::string *raw=nullptr) {
    general=GeneralUrl;graphics=GraphicsUrl;if(raw)*raw=RawUrl;std::string contents,customRaw;
    struct stat st{};
    if(!statPath(root()+"/sources.ini",st))return errno==ENOENT;
    if(!readSmall(root()+"/sources.ini",contents,8192)){error="No se puede leer sources.ini.";return false;}
    std::istringstream input(contents);std::string line;
    while(std::getline(input,line)) {
        line=trim(line);if(line.empty()||line[0]=='#'||line[0]==';')continue;
        size_t eq=line.find('=');if(eq==std::string::npos){error="Línea inválida en sources.ini.";return false;}
        std::string key=trim(line.substr(0,eq)),value=trim(line.substr(eq+1));
        if(key!="general_url"&&key!="graphics_url"&&key!="raw_url"){error="Opción desconocida en sources.ini: "+key;return false;}
        if(!safeUrl(value)){error="Las fuentes deben ser URLs HTTPS válidas.";return false;}
        if(key=="raw_url")customRaw=value;else (key=="general_url"?general:graphics)=value;
    }
    if(raw)*raw=!customRaw.empty()?customRaw:general==GeneralUrl?RawUrl:"";
    return true;
}
#ifdef __SWITCH__
struct Download {FILE *file=nullptr;uint64_t written=0;};
size_t header(char *bytes,size_t size,size_t count,void *user) {
    if(size&&count>SIZE_MAX/size)return 0;
    size_t length=size*count;if(length>16384)return 0;
    auto &stamp=*static_cast<RemoteStamp*>(user);std::string line(bytes,length);
    if(line.rfind("HTTP/",0)==0){stamp={};return length;}
    auto colon=line.find(':');if(colon==std::string::npos)return length;
    std::string key=upper(trim(line.substr(0,colon))),value=trim(line.substr(colon+1));
    if(value.size()>512||std::any_of(value.begin(),value.end(),[](unsigned char c){return c<32||c==127;}))return length;
    if(key=="ETAG")stamp.etag=value;else if(key=="LAST-MODIFIED")stamp.modified=value;else if(key=="CONTENT-LENGTH")stamp.length=value;
    return length;
}
size_t receive(void *ptr,size_t size,size_t count,void *user) {
    auto &download=*static_cast<Download*>(user);
    if(size&&count>SIZE_MAX/size)return 0;
    size_t bytes=size*count;
    if(bytes>MaxArchive-download.written)return 0;
    size_t n=fwrite(ptr,1,bytes,download.file);download.written+=n;return n;
}
bool networkInit(std::string &error) {
    if(!socketsReady) {Result rc=socketInitializeDefault();if(R_FAILED(rc)){error="No se puede abrir la conexión de red.";return false;}socketsReady=true;}
    if(!nifmReady) {Result rc=nifmInitialize(NifmServiceType_User);if(R_FAILED(rc)){error="No se puede consultar la conexión de Internet.";return false;}nifmReady=true;}
    NifmInternetConnectionType type{};u32 strength=0;NifmInternetConnectionStatus status{};
    Result rc=nifmGetInternetConnectionStatus(&type,&strength,&status);
    if(R_FAILED(rc)||status!=NifmInternetConnectionStatus_Connected){error="Conecta la consola a Internet y vuelve a sincronizar.";return false;}
    if(!curlReady) {if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK){error="No se puede abrir HTTPS.";return false;}curlReady=true;}
    return true;
}
bool download(const std::string &url,const std::string &path,std::string &error,RemoteStamp *remote=nullptr,bool head=false) {
    if(!safeUrl(url)){error="URL de catálogo inválida.";return false;}
    struct stat st{};if(!head&&statPath(path,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La ruta del catálogo no es un archivo regular.";return false;}
    FILE *f=head?nullptr:fopen(path.c_str(),"wb");if(!head&&!f){error="No se puede escribir el catálogo en la microSD.";return false;}
    CURL *curl=curl_easy_init();if(!curl){if(f)fclose(f);error="No se puede iniciar la descarga.";return false;}
    Download d{f,0};char detail[CURL_ERROR_SIZE]{};RemoteStamp stamp;
    curl_easy_setopt(curl,CURLOPT_URL,url.c_str());
    curl_easy_setopt(curl,CURLOPT_USERAGENT,"NinMagic-Cheats/1.2.0");
    curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,1L);
    curl_easy_setopt(curl,CURLOPT_MAXREDIRS,5L);
    curl_easy_setopt(curl,CURLOPT_PROTOCOLS,long(CURLPROTO_HTTPS));
    curl_easy_setopt(curl,CURLOPT_REDIR_PROTOCOLS,long(CURLPROTO_HTTPS));
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYPEER,1L);
    curl_easy_setopt(curl,CURLOPT_SSL_VERIFYHOST,2L);
    curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,20L);
    curl_easy_setopt(curl,CURLOPT_TIMEOUT,180L);
    curl_easy_setopt(curl,CURLOPT_LOW_SPEED_LIMIT,512L);
    curl_easy_setopt(curl,CURLOPT_LOW_SPEED_TIME,30L);
    curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1L);
    curl_easy_setopt(curl,CURLOPT_FAILONERROR,1L);
    curl_easy_setopt(curl,CURLOPT_MAXFILESIZE_LARGE,curl_off_t(MaxArchive));
    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,receive);
    curl_easy_setopt(curl,CURLOPT_WRITEDATA,&d);
    curl_easy_setopt(curl,CURLOPT_ERRORBUFFER,detail);
    curl_easy_setopt(curl,CURLOPT_HEADERFUNCTION,header);
    curl_easy_setopt(curl,CURLOPT_HEADERDATA,&stamp);
    if(head)curl_easy_setopt(curl,CURLOPT_NOBODY,1L);
    CURLcode result=curl_easy_perform(curl);long status=0;curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&status);
    curl_easy_cleanup(curl);bool ok=result==CURLE_OK&&status==200&&(head||d.written>0);
    if(f){if(fflush(f)!=0)ok=false;if(ok&&fsync(fileno(f))!=0)ok=false;if(fclose(f)!=0)ok=false;}
    if(ok&&remote)*remote=stamp;
    if(!ok){
        if(!head)unlink(path.c_str());
        if(result==CURLE_OK)error="La descarga no contiene un ZIP válido (HTTP "+std::to_string(status)+").";
        else error="No se pudo descargar el catálogo por HTTPS: "+std::string(detail[0]?detail:curl_easy_strerror(result));
    }
    return ok;
}
#else
bool networkInit(std::string &error) {
#ifdef NC_CATALOG_TEST
    if(testNetworkReady)return true;
#endif
    error="La sincronización de red solo está disponible en Switch.";return false;
}
bool download(const std::string &url,const std::string &path,std::string &error,RemoteStamp *remote=nullptr,bool head=false) {
#ifdef NC_CATALOG_TEST
    if(testTransfer)return testTransfer(url,path,error,remote,head);
#else
    (void)url;(void)path;(void)error;(void)remote;(void)head;
#endif
    return false;
}
#endif
std::string stampText(const std::string &url,const RemoteStamp &stamp){return std::string("NMCREMOTE1\n")+url+"\n"+stamp.etag+"\n"+stamp.modified+"\n"+stamp.length+"\n";}
bool unchanged(const std::string &file,const std::string &url,const RemoteStamp &stamp){std::string previous;return (!stamp.etag.empty()||!stamp.modified.empty())&&readSmall(file,previous,4096)&&previous==stampText(url,stamp);}
struct Seen {std::string published,signature;};
using SeenMap=std::map<uint64_t,Seen>;
bool readSeen(const std::string &file,SeenMap &seen){
    seen.clear();std::string data;if(!readSmall(file,data,256*1024))return false;std::istringstream input(data);std::string header;if(!std::getline(input,header)||header!="NMCRELEASES1")return false;
    uint64_t id=0;std::string published,signature;
    while(input>>id>>published>>signature){if(!id||published.size()>64||signature.size()!=16||!hex16(signature)||seen.size()>=10000||seen.count(id))return false;seen[id]={published,signature};}
    return input.eof()&&!seen.empty();
}
std::string seenText(const SeenMap &seen){std::string data="NMCRELEASES1\n";for(const auto &row:seen)data+=std::to_string(row.first)+" "+row.second.published+" "+row.second.signature+"\n";return data;}
bool publishedReleases(std::vector<CheatRelease> &releases,std::string &error){
    releases.clear();
    for(unsigned page=1;page<=20;++page){const std::string file=root()+"/release-index.pending";const std::string url="https://api.github.com/repos/HamletDuFromage/switch-cheats-db/releases?per_page=100&page="+std::to_string(page);if(!download(url,file,error))return false;std::string json;bool loaded=readSmall(file,json,8*1024*1024);unlink(file.c_str());std::vector<CheatRelease> batch;if(!loaded||!parseCheatReleases(json,batch,error)){if(error.empty())error="No se pudo leer el historial publicado de cheats.";return false;}size_t count=batch.size();releases.insert(releases.end(),batch.begin(),batch.end());if(count<100){std::sort(releases.begin(),releases.end(),[](const auto &a,const auto &b){return a.published<b.published||(a.published==b.published&&a.id<b.id);});return true;}}
    error="El historial supera el límite de páginas de esta versión.";return false;
}
bool removeOutput(const std::string &path,std::string &error){struct stat st{};if(!statPath(path,st)){if(errno==ENOENT)return true;error="No se pudo revisar un archivo temporal de caché.";return false;}if(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||unlink(path.c_str())!=0){error="La caché contiene una ruta temporal no admitida.";return false;}return true;}
bool mergeInto(const std::vector<std::string> &inputs,const std::string &output,std::string &error){
    if(inputs.empty()){error="No hay archivos de cheats que combinar.";return false;}std::vector<std::string> chunk;std::string previous;unsigned part=0;
    for(size_t at=0;at<inputs.size();){chunk.clear();if(!previous.empty())chunk.push_back(previous);while(at<inputs.size()&&chunk.size()<8)chunk.push_back(inputs[at++]);const std::string target=at==inputs.size()?output:output+".merge-"+std::to_string(part++);if(!removeOutput(target,error)||!mergeCheatArchives(chunk,target,error))return false;if(!previous.empty()&&!removeOutput(previous,error))return false;previous=target;}
    return true;
}
}

bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error) {
    error.clear();return networkInit(error)&&download(url,path,error);
}
bool loadCatalog(Catalog &catalog,std::string &error) {
    error.clear();catalog={};char slot=activeSlot();
    if(loadSlot(slot,catalog,error))return true;
    std::string second;
    if(loadSlot(slot=='a'?'b':'a',catalog,second)) {catalog.detail+=" · recuperado de la copia anterior";error.clear();return true;}
    error="No hay una caché válida. Actualiza las bases de cheats para descargarlas.";return false;
}
bool syncCatalog(Catalog &catalog,std::string &error) {return refreshCatalog(catalog,true,error);}
bool refreshCatalog(Catalog &catalog,bool force,std::string &error) {
    error.clear();
    if(!ensureRoot(error))return false;
    std::string general,graphics,raw;
    if(!sourceUrls(general,graphics,error,&raw)||!networkInit(error))return false;
    // Only overwrite the inactive slot. The active archives remain readable
    // until both replacements, every accepted member CRC and commit marker pass.
    char current=activeSlot();Catalog previous;std::string ignored;
    bool cached=loadSlot(current,previous,ignored);
    if(!cached&&loadSlot(current=='a'?'b':'a',previous,ignored)){current=current=='a'?'b':'a';cached=true;}
    const std::string old=root()+"/catalog-"+current;
    SeenMap seen;if(!cached||!readSeen(old+"/releases-seen.txt",seen))seen.clear();
    std::string knownPublished;for(const auto &record:seen)knownPublished=std::max(knownPublished,record.second.published);
    std::vector<CheatRelease> releases,chosen;
    const bool official=general==GeneralUrl;
    std::string historyError;
    const bool historyOk=!official||publishedReleases(releases,historyError);
    size_t pending=0,selectedAssets=0;
    if(official&&historyOk&&!releases.empty()) {
        if(seen.empty()) {
            // A bare NRO must never download all past years on the console.
            // The full historical seed is prepared on the PC and bundled.
            // Fetch the latest first, but never mark older publications as
            // processed without reading them. The supplied historical seed
            // already includes its complete publication ledger.
            chosen.push_back(releases.back());
            pending=releases.size()-1;
        } else {
            for(const auto &release:releases){const auto oldRecord=seen.find(release.id);if(oldRecord!=seen.end()&&oldRecord->second.signature==cheatReleaseSignature(release))continue;if(selectedAssets+release.assets.size()>8){++pending;continue;}chosen.push_back(release);selectedAssets+=release.assets.size();}
            if(force&&std::none_of(chosen.begin(),chosen.end(),[&](const auto &release){return release.id==releases.back().id;}))chosen.push_back(releases.back());
        }
    }
    RemoteStamp graphicStamp,generalStamp,rawStamp;
    std::string probeError;
    bool graphicProbed=download(graphics,"",probeError,&graphicStamp,true);
    bool graphicsChanged=force||!cached||!graphicProbed||!unchanged(old+"/remote-graphics.txt",graphics,graphicStamp);
    bool generalChanged=force||!cached||!chosen.empty();
    if(!official||!historyOk) {
        probeError.clear();const bool probed=download(general,"",probeError,&generalStamp,true);
        generalChanged=force||!cached||!probed||!unchanged(old+"/remote-general.txt",general,generalStamp);
        if(!raw.empty()){probeError.clear();if(!download(raw,"",probeError,&rawStamp,true)||!unchanged(old+"/remote-raw.txt",raw,rawStamp))generalChanged=true;}
    }
    if(!generalChanged&&!graphicsChanged) {
        if(cached)catalog=std::move(previous);
        if(!historyOk){error=historyError;return false;}
        if(pending){error="Quedan lanzamientos de cheats pendientes. Vuelve a actualizar para continuar sin perder la base guardada.";return false;}
        return true;
    }
    char slot=current=='a'?'b':'a';std::string path=root()+"/catalog-"+slot;
    if(!directory(path)){error="No se puede crear la nueva caché.";return false;}
    struct stat st{};
    for(const char *name:{"complete.txt","general.zip","graphics.zip"}) {
        std::string target=path+"/"+name;
        if(statPath(target,st)&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La nueva caché contiene una ruta no admitida.";return false;}
    }
    unlink((path+"/complete.txt").c_str());
    std::vector<std::string> olderInputs,newerInputs,temporary;
    SeenMap nextSeen=seen;
    if(generalChanged&&official&&historyOk&&!chosen.empty()) {
        for(const auto &release:chosen) {
            auto assets=release.assets;std::sort(assets.begin(),assets.end(),[](const auto &a,const auto &b){return a.name=="contents.zip"&&b.name!="contents.zip";});
            for(const auto &asset:assets) {
                if(asset.size>MaxArchive){error="Un archivo histórico nuevo supera 64 MiB. Actualiza el historial en el PC; la base anterior se conserva.";return false;}
                const std::string target=path+"/release-"+std::to_string(release.id)+(asset.name=="contents.zip"?"-raw.zip":"-complete.zip");
                if(!download(asset.url,target,error))return false;
                struct stat actual{};if(!statPath(target,actual)||uint64_t(actual.st_size)!=asset.size){error="Un lanzamiento descargado no coincide con el tamaño publicado.";return false;}
                temporary.push_back(target);(release.published<knownPublished?olderInputs:newerInputs).push_back(target);
            }
            nextSeen[release.id]={release.published,cheatReleaseSignature(release)};
        }
    } else if(generalChanged) {
        if(!raw.empty()){const auto target=path+"/latest-raw.zip";if(!download(raw,target,error,&rawStamp))return false;temporary.push_back(target);newerInputs.push_back(target);}
        const auto target=path+"/latest-complete.zip";if(!download(general,target,error,&generalStamp))return false;temporary.push_back(target);newerInputs.push_back(target);
    }
    std::vector<std::string> generalInputs=olderInputs;
    if(cached)generalInputs.push_back(old+"/general.zip");
    generalInputs.insert(generalInputs.end(),newerInputs.begin(),newerInputs.end());
    if(!mergeInto(generalInputs,path+"/general.zip",error))return false;
    std::vector<std::string> graphicInputs;if(cached)graphicInputs.push_back(old+"/graphics.zip");
    if(graphicsChanged){const auto target=path+"/latest-graphics.zip";if(!download(graphics,target,error,&graphicStamp))return false;temporary.push_back(target);graphicInputs.push_back(target);}
    if(!mergeInto(graphicInputs,path+"/graphics.zip",error))return false;
    Catalog next;
    if(!indexArchive(path+"/general.zip","Hamlet",next.entries,error,true)||!indexArchive(path+"/graphics.zip","NX-60FPS-RES-GFX",next.entries,error,true))return false;
    time_t now=std::time(nullptr);struct tm when{};char stamp[40]="Actualizado";
    if(gmtime_r(&now,&when))std::strftime(stamp,sizeof(stamp),"%Y-%m-%d %H:%M UTC",&when);
    const auto retainedStamp=[&](const char *name,const std::string &url,const RemoteStamp &remote){
        std::string previousStamp;
        if(cached&&remote.etag.empty()&&remote.modified.empty()&&readSmall(old+"/"+name,previousStamp,4096)&&previousStamp.rfind(std::string("NMCREMOTE1\n")+url+"\n",0)==0)return previousStamp;
        return stampText(url,remote);
    };
    if(!writeSmall(path+"/releases-seen.txt",seenText(nextSeen))||!writeSmall(path+"/remote-general.txt",retainedStamp("remote-general.txt",general,generalStamp))||!writeSmall(path+"/remote-raw.txt",retainedStamp("remote-raw.txt",raw,rawStamp))||!writeSmall(path+"/remote-graphics.txt",retainedStamp("remote-graphics.txt",graphics,graphicStamp))||!writeSmall(path+"/last-check.txt",std::to_string(static_cast<long long>(now))+"\n")){error="No se pudo confirmar el índice de actualizaciones de la base.";return false;}
    for(const auto &file:temporary)if(!removeOutput(file,error))return false;
    if(!writeSmall(path+"/complete.txt",std::string("NINMAGIC-CATALOG-1\n")+stamp+"\n")){error="No se puede guardar el cierre de la caché.";return false;}
    if(!writeSmall(root()+"/active.pending",std::string(1,slot)+"\n")){error="No se puede guardar la selección de caché.";return false;}
    // FAT rename does not replace an existing destination. Retain the previous
    // marker as active.previous until the pending marker is in place.
    unlink((root()+"/active.previous").c_str());
    bool had=regular(root()+"/active.txt",8);
    if(had&&rename((root()+"/active.txt").c_str(),(root()+"/active.previous").c_str())!=0){error="No se puede conservar el marcador anterior.";return false;}
    if(rename((root()+"/active.pending").c_str(),(root()+"/active.txt").c_str())!=0) {
        if(had)rename((root()+"/active.previous").c_str(),(root()+"/active.txt").c_str());
        error="No se puede activar la nueva caché. Se conserva la anterior.";return false;
    }
    next.generalReady=next.graphicsReady=true;next.stamp=stamp;next.detail=std::to_string(next.entries.size())+" versiones de ambas bases de cheats";
    appendManual(next);
    catalog=std::move(next);
    if(!historyOk){error="Se conservó la base disponible, pero no se pudo comprobar todo el historial: "+historyError;return false;}
    if(pending){error="Base guardada; quedan "+std::to_string(pending)+" lanzamientos pendientes. Vuelve a actualizar para continuar, o instala el historial completo incluido en el paquete del PC.";return false;}
    return true;
}
Pack findCheats(const Game &game,const Catalog &catalog) {
    Pack result;result.game=game;std::set<std::string> builds;
    for(const auto &entry:catalog.entries)if(entry.titleId==game.id)builds.insert(entry.buildId);
    result.availableBuilds.assign(builds.begin(),builds.end());
    if(!game.buildVerified||!validBuild(game.buildId)) {result.detail="Abre este juego, vuelve a hbmenu y selecciónalo para comprobar su Build ID exacto.";return result;}
    std::vector<std::string> failures;
    for(const auto &entry:catalog.entries) {
        if(entry.titleId!=game.id||entry.buildId!=upper(game.buildId))continue;
        unzFile zip=regular(entry.archive,MaxArchive)?unzOpen64(entry.archive.c_str()):nullptr;
        if(!zip){failures.push_back(entry.source+": no se puede abrir su caché");continue;}
        std::string text,error;bool ok=unzLocateFile(zip,entry.path.c_str(),1)==UNZ_OK&&currentFile(zip,text,error);
        unzClose(zip);
        std::vector<Cheat> cheats;
        if(ok)ok=parseCheats(text,entry.source,cheats,error);
        if(!ok){failures.push_back(entry.source+": "+(error.empty()?"no se puede leer el archivo":error));continue;}
        // Keep each source file's master codes bound to its own selections.
        for(auto &cheat:cheats) {
            cheat.group=entry.source+":"+hexId(entry.titleId)+":"+entry.buildId;
            bool duplicate=std::any_of(result.cheats.begin(),result.cheats.end(),[&](const Cheat &c){return c.master==cheat.master&&c.name==cheat.name&&c.opcodes==cheat.opcodes&&c.group==cheat.group;});
            if(!duplicate)result.cheats.push_back(std::move(cheat));
        }
    }
    result.compatible=std::any_of(result.cheats.begin(),result.cheats.end(),[](const Cheat &c){return !c.master;});
    if(result.compatible)result.detail="Cheats del Title ID y Build ID exactos. Marca solo las opciones que quieras aplicar.";
    else if(builds.empty())result.detail="Las dos bases no contienen cheats para este Title ID.";
    else result.detail="Hay cheats para otras versiones, pero ninguno para este Build ID. No se aplicarán códigos incompatibles.";
    for(const auto &failure:failures)result.detail+=" "+failure;
    return result;
}
void catalogExit() {
#ifdef __SWITCH__
    if(curlReady){curl_global_cleanup();curlReady=false;}
    if(nifmReady){nifmExit();nifmReady=false;}
    if(socketsReady){socketExit();socketsReady=false;}
#endif
}
}

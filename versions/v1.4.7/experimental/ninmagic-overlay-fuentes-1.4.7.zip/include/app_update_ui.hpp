#pragma once
#include "app_update.hpp"

namespace nc {
enum class AppUpdateAction { None, ReviewCompletedRecord, Install };
inline bool publishedAppOnSd(const AppUpdateInfo&u){return u.sdVerified&&!u.version.empty()&&!u.sha256.empty()&&u.size&&u.sdVersion==u.version&&u.sdSha256==u.sha256&&u.sdSize==u.size;}
inline bool differentAppOnSd(const AppUpdateInfo&u){return u.sdVerified&&!u.runningVersion.empty()&&!u.sdVersion.empty()&&u.sdVersion!=u.runningVersion;}
inline bool currentPublishedApp(const AppUpdateInfo&u,const std::string&error){return error.empty()&&u.configured&&!u.available&&!u.prepared&&!u.installed&&!u.version.empty()&&u.runningVersion==u.version&&publishedAppOnSd(u)&&!differentAppOnSd(u);}
inline bool completedReviewReady(const CompletedUpdateInfo&r){return r.state==CompletedUpdateState::CanArchive&&!r.token.empty()&&!r.reviewSha256.empty();}
inline AppUpdateAction appUpdateAction(const AppUpdateInfo&u,const CompletedUpdateInfo&r,const std::string&error){
    if(r.state==CompletedUpdateState::CanArchive)return AppUpdateAction::ReviewCompletedRecord;
    if(r.state==CompletedUpdateState::Blocked||u.installed||publishedAppOnSd(u)||differentAppOnSd(u)||!error.empty())return AppUpdateAction::None;
    return u.configured&&u.available?AppUpdateAction::Install:AppUpdateAction::None;
}
}

[CmdletBinding()]
param(
    [string]$DevkitPro='C:\devkitPro',
    [ValidatePattern('^[0-9]+\.[0-9]+\.[0-9]+$')][string]$ExpectedVersion='1.4.7'
)
$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$temporaryParent=[IO.Path]::GetFullPath((Join-Path $env:USERPROFILE '.codex\tmp'))
$stageRoot=[IO.Path]::GetFullPath((Join-Path $temporaryParent 'ninmagic-cheats-overlay-build'))
if(-not $stageRoot.StartsWith($temporaryParent+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe overlay build staging folder.'}
if($stageRoot.Contains(' ')){throw 'devkitPro make needs a staging path without spaces.'}
$bash=Join-Path $DevkitPro 'msys2\usr\bin\bash.exe'
if(-not [IO.File]::Exists($bash)){throw 'devkitPro MSYS2 bash is unavailable.'}
foreach($name in @('overlay\Makefile','overlay\deps\libtesla\include\tesla.hpp','overlay\deps\libtesla\LICENSE','romfs\logo.rgba','assets\icon.jpg')){
    if(-not [IO.File]::Exists((Join-Path $projectRoot $name))){throw "Missing overlay input: $name"}
}
if([IO.Directory]::Exists($stageRoot)){Remove-Item -LiteralPath $stageRoot -Recurse -Force}
$null=New-Item -ItemType Directory -Path $stageRoot -Force
foreach($name in @('overlay','include','source','assets','romfs')){Copy-Item -LiteralPath (Join-Path $projectRoot $name) -Destination $stageRoot -Recurse}
$posixStage='/'+$stageRoot.Substring(0,1).ToLowerInvariant()+$stageRoot.Substring(2).Replace('\','/')
$posixDevkit='/'+$DevkitPro.Substring(0,1).ToLowerInvariant()+$DevkitPro.Substring(2).Replace('\','/')
if($posixStage.Contains("'") -or $posixDevkit.Contains("'")){throw 'Build paths cannot contain a quote.'}
$jobs=[Math]::Min(8,[Math]::Max(1,[Environment]::ProcessorCount))
$buildCommand="export DEVKITPRO='$posixDevkit'; export DEVKITA64=`"`$DEVKITPRO/devkitA64`"; export PATH=`"`$DEVKITPRO/tools/bin:`$PATH`"; cd '$posixStage/overlay' && make -j$jobs"
& $bash --login -c $buildCommand
if($LASTEXITCODE -ne 0){throw "Overlay compilation failed (exit $LASTEXITCODE)."}
$output=Join-Path $projectRoot 'dist\overlay'
$null=New-Item -ItemType Directory -Path $output -Force
foreach($extension in @('ovl','elf','nacp')){Copy-Item -LiteralPath (Join-Path $stageRoot "overlay\ninmagic-cheats.$extension") -Destination $output -Force}
# An overlay is an NRO container. Verify its NACP, image and embedded RomFS with
# the same structural validator as the application, without touching a device.
& python (Join-Path $PSScriptRoot 'verify_nro.py') (Join-Path $output 'ninmagic-cheats.ovl') --expected-version $ExpectedVersion --expected-title 'NinMagic Cheats' --output (Join-Path $output 'validation.json')
if($LASTEXITCODE -ne 0){throw 'Overlay container verification failed.'}
Write-Host "Overlay ready: $(Join-Path $output 'ninmagic-cheats.ovl')"
